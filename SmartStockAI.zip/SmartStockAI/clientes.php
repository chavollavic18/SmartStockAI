<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>SmartStock AI - Gestión de Clientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-light: #5a7ed7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --secondary-light: #48c765;
            --secondary-dark: #218838;
            --danger: #dc3545;
            --danger-light: #e55a6a;
            --danger-dark: #c82333;
            --warning: #ffc107;
            --warning-light: #ffd145;
            --warning-dark: #e0a800;
            --info: #17a2b8;
            --info-light: #3ab7cc;
            --info-dark: #138496;
            --dark: #2c3e50;
            --darker: #1a252f;
            --light: #f8f9fa;
            --lighter: #ffffff;
            --gray-100: #f8f9fa;
            --gray-200: #e9ecef;
            --gray-300: #dee2e6;
            --gray-400: #ced4da;
            --gray-500: #adb5bd;
            --gray-600: #6c757d;
            --gray-700: #495057;
            --gray-800: #343a40;
            --gray-900: #212529;

            --bg-primary: #f5f7fb;
            --bg-secondary: #ffffff;
            --bg-card: #ffffff;
            --bg-sidebar: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            --text-primary: #000000;
            --text-secondary: #6c757d;
            --text-muted: #6c757d;
            --border-color: rgba(0,0,0,0.1);
            --shadow-color: rgba(0,0,0,0.05);
            --shadow-hover: rgba(0,0,0,0.1);
            --input-bg: #ffffff;
            --input-border: #ced4da;
            --input-focus: rgba(58, 94, 199, 0.25);

            --success-bg: rgba(40, 167, 69, 0.1);
            --success-text: #28a745;
            --warning-bg: rgba(255, 193, 7, 0.1);
            --warning-text: #856404;
            --danger-bg: rgba(220, 53, 69, 0.1);
            --danger-text: #dc3545;
            --info-bg: rgba(23, 162, 184, 0.1);
            --info-text: #17a2b8;

            --border-radius: 12px;
            --border-radius-sm: 8px;
            --border-radius-lg: 16px;
            --transition: all 0.3s ease;
            --sidebar-width: 270px;
            --sidebar-collapsed: 80px;
            --font-main: 'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            --sidebar-opacity: 1;

            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }

        body.dark-mode {
            --bg-primary: #1a1f2e;
            --bg-secondary: #242a3a;
            --bg-card: #2c3345;
            --text-primary: #ffffff;
            --text-secondary: #a0a8b8;
            --text-muted: #7a8395;
            --border-color: rgba(255,255,255,0.1);
            --shadow-color: rgba(0,0,0,0.3);
            --shadow-hover: rgba(0,0,0,0.4);
            --input-bg: #2c3345;
            --input-border: #40485a;
            --input-focus: rgba(58, 94, 199, 0.5);

            --success-bg: rgba(40, 167, 69, 0.2);
            --success-text: #6fcf97;
            --warning-bg: rgba(255, 193, 7, 0.2);
            --warning-text: #f9ca7f;
            --danger-bg: rgba(220, 53, 69, 0.2);
            --danger-text: #f28b82;
            --info-bg: rgba(23, 162, 184, 0.2);
            --info-text: #7fd1e0;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: var(--font-main); }

        html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }

        body {
            background: var(--bg-primary);
            color: var(--text-primary);
            transition: var(--transition);
            min-height: 100vh;
            min-height: 100dvh;
            overflow-x: hidden;
            -webkit-tap-highlight-color: transparent;
            -webkit-font-smoothing: antialiased;
        }

        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg-secondary); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary-dark); }

        .app-container { display: flex; min-height: 100vh; min-height: 100dvh; }

        /* ============================================
           OVERLAY MÓVIL
           ============================================ */
        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.55);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
            z-index: 1040;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .sidebar-overlay.active {
            display: block !important;
            opacity: 1;
        }

        /* ============================================
           SIDEBAR
           ============================================ */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--bg-sidebar);
            color: #ffffff;
            height: 100vh;
            height: 100dvh;
            position: fixed;
            left: 0; top: 0;
            padding: 24px 16px;
            padding-top: calc(24px + var(--safe-top));
            padding-bottom: calc(24px + var(--safe-bottom));
            transition: var(--transition);
            z-index: 1050;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 25px rgba(0,0,0,0.15);
            overflow-y: auto;
            opacity: var(--sidebar-opacity);
            will-change: transform;
        }

        .sidebar-header {
            padding: 0 12px 24px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .sidebar .logo {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -0.5px;
            background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }
        .sidebar .logo span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .sidebar .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            -webkit-text-fill-color: white;
            flex-shrink: 0;
        }

        .sidebar .sidebar-toggle {
            background: rgba(255,255,255,0.15);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            font-size: 12px;
            flex-shrink: 0;
        }

        .sidebar .sidebar-toggle:hover {
            background: rgba(255,255,255,0.25);
            transform: scale(1.1);
        }

        .sidebar-close-btn {
            display: none;
            background: rgba(255,255,255,0.08);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            transition: var(--transition);
            flex-shrink: 0;
            touch-action: manipulation;
        }
        .sidebar-close-btn:hover { background: var(--danger); }

        .sidebar-nav-container {
            flex: 1;
            overflow-y: auto;
            padding-right: 4px;
            -webkit-overflow-scrolling: touch;
        }

        .menu-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #64748b;
            font-weight: 700;
            margin: 16px 12px 8px 12px;
        }

        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li { margin-bottom: 4px; }

        .sidebar-menu a {
            color: #94a3b8;
            text-decoration: none;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border-radius: 8px;
            transition: var(--transition);
            font-weight: 500;
            font-size: 14px;
            cursor: pointer;
            gap: 12px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .sidebar-menu a:hover {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.06);
            transform: translateX(3px);
        }

        .sidebar-menu a.active {
            color: #ffffff;
            background: var(--primary);
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .sidebar-menu i {
            font-size: 18px;
            width: 22px;
            text-align: center;
            flex-shrink: 0;
        }

        .sidebar-footer {
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            margin-top: auto;
        }

        .logout-btn {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
            width: 100%;
            padding: 12px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: var(--transition);
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .logout-btn:hover {
            background: var(--danger);
            color: white;
            border-color: var(--danger);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .sidebar.collapsed { width: var(--sidebar-collapsed); }
        .sidebar.collapsed .menu-label,
        .sidebar.collapsed .logo span,
        .sidebar.collapsed .sidebar-menu a span,
        .sidebar.collapsed .logout-btn span { display: none; }
        .sidebar.collapsed .sidebar-menu a { justify-content: center; padding: 12px; }
        .sidebar.collapsed .sidebar-menu i { margin: 0; }
        .sidebar.collapsed .sidebar-header { justify-content: center; }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
            transition: var(--transition);
            min-width: 0;
            overflow-x: hidden;
        }

        .main-content.expanded { margin-left: var(--sidebar-collapsed); }

        .header {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px 30px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 5px 20px var(--shadow-color);
            border: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .page-title i { color: var(--primary); }

        .controls { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }

        .theme-switcher, .notifications, .icon-btn {
            background: var(--bg-secondary);
            width: 44px; height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            color: var(--text-primary);
            position: relative;
            border: 1px solid var(--border-color);
            font-size: 16px;
            flex-shrink: 0;
            touch-action: manipulation;
        }

        .theme-switcher:hover, .notifications:hover, .icon-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px var(--shadow-hover);
        }

        .notification-badge {
            position: absolute;
            top: -5px; right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            min-width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            padding: 0 4px;
        }

        .notification-badge.hidden { display: none; }

        /* ============================================
           STATS CARDS
           ============================================ */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px var(--shadow-color);
            border: 1px solid var(--border-color);
            border-left: 4px solid var(--primary);
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px var(--shadow-hover);
        }

        .stat-title {
            color: var(--text-muted);
            font-size: 13px;
            margin-bottom: 5px;
            font-weight: 500;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1.2;
        }

        .stat-subtitle {
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 5px;
        }

        /* ============================================
           CLIENTS SECTION
           ============================================ */
        .clients-section {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px var(--shadow-color);
            border: 1px solid var(--border-color);
        }

        .clients-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .search-box {
            position: relative;
            flex: 1;
            min-width: 300px;
        }

        .search-box input {
            padding-left: 40px;
            color: var(--text-primary);
            background: var(--input-bg);
            border: 1px solid var(--input-border);
            border-radius: 8px;
            padding: 11px 12px 11px 40px;
            width: 100%;
            font-size: 16px;
            min-height: 44px;
        }

        .search-box input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem var(--input-focus);
        }

        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
        }

        .client-filters { display: flex; gap: 15px; flex-wrap: wrap; }
        .filter-group { min-width: 150px; }
        .client-actions { display: flex; gap: 10px; flex-wrap: wrap; }

        .client-table {
            width: 100%;
            border-collapse: collapse;
        }

        .client-table th, .client-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
            white-space: nowrap;
        }

        .client-table th {
            background-color: var(--bg-secondary);
            font-weight: 600;
            font-size: 14px;
            color: var(--primary);
        }

        .client-table tr:hover {
            background-color: var(--bg-secondary);
        }

        .client-status {
            display: inline-flex;
            align-items: center;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-active {
            background-color: var(--success-bg);
            color: var(--success-text);
        }

        .status-inactive {
            background-color: var(--danger-bg);
            color: var(--danger-text);
        }

        .client-actions-cell {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            cursor: pointer;
            transition: var(--transition);
            flex-shrink: 0;
            touch-action: manipulation;
        }

        .edit-btn {
            background-color: var(--info-bg);
            color: var(--primary);
        }

        .edit-btn:hover {
            background-color: var(--primary);
            color: white;
        }

        .delete-btn {
            background-color: var(--danger-bg);
            color: var(--danger);
        }

        .delete-btn:hover {
            background-color: var(--danger);
            color: white;
        }

        .view-btn {
            background-color: var(--success-bg);
            color: var(--secondary);
        }

        .view-btn:hover {
            background-color: var(--secondary);
            color: white;
        }

        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .pagination-info { color: var(--text-muted); }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: var(--text-muted);
        }

        .empty-state h4 {
            color: var(--text-primary);
            margin-bottom: 10px;
        }

        /* ============================================
           MODAL
           ============================================ */
        .modal-content {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            background: var(--bg-card);
            color: var(--text-primary);
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            border-bottom: none;
            padding: 18px 22px;
        }

        .modal-header h5 {
            color: white;
            font-size: 16px;
        }

        .modal-header .btn-close {
            filter: invert(1);
        }

        .modal-body { color: var(--text-primary); padding: 22px; }
        .modal-body p, .modal-body strong, .modal-body span { color: var(--text-primary); }
        .modal-body h6 { color: var(--primary); font-weight: 700; margin-bottom: 12px; }

        .modal-footer {
            border-top: 1px solid var(--border-color);
            border-radius: 0 0 var(--border-radius) var(--border-radius);
            padding: 16px 22px;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* ============================================
           FORM CONTROLS
           ============================================ */
        .form-control, .form-select {
            color: var(--text-primary) !important;
            background-color: var(--input-bg) !important;
            border: 1px solid var(--input-border);
            border-radius: 8px;
            padding: 11px 12px;
            font-size: 16px;
            min-height: 44px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem var(--input-focus);
            background-color: var(--input-bg);
            color: var(--text-primary);
        }

        .form-control::placeholder { color: var(--text-muted) !important; }

        .form-label {
            color: var(--text-primary);
            font-weight: 500;
            font-size: 13px;
        }

        .form-check-label { color: var(--text-primary); }
        .form-check-input { width: 18px; height: 18px; margin-top: 3px; }

        /* ============================================
           BUTTONS
           ============================================ */
        .btn {
            padding: 11px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .btn-primary { background: var(--primary); color: white !important; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3); }
        .btn-secondary { background: var(--gray-600); color: white !important; }
        .btn-secondary:hover { background: var(--gray-700); transform: translateY(-2px); }

        /* ============================================
           TOASTS
           ============================================ */
        .toast-container {
            position: fixed;
            top: calc(20px + var(--safe-top));
            right: calc(20px + var(--safe-right));
            left: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 8px;
            pointer-events: none;
            align-items: flex-end;
        }

        .toast {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            padding: 15px 20px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s forwards;
            color: var(--text-primary);
            min-width: 280px;
            max-width: 400px;
            border-left: 4px solid var(--primary);
            pointer-events: auto;
        }

        .toast.success { border-left-color: var(--secondary); }
        .toast.error { border-left-color: var(--danger); }
        .toast.warning { border-left-color: var(--warning); }

        .toast i { margin-right: 10px; font-size: 20px; flex-shrink: 0; }
        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        .toast.info i { color: var(--primary); }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        /* ============================================
           MENU TOGGLE MÓVIL (BOTÓN HAMBURGUESA)
           ============================================ */
        .menu-toggle {
            display: none;
            position: fixed;
            bottom: calc(20px + var(--safe-bottom));
            right: calc(20px + var(--safe-right));
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            border: none;
            cursor: pointer;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            z-index: 1200;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: var(--transition);
            touch-action: manipulation;
            -webkit-tap-highlight-color: transparent;
        }

        .menu-toggle:hover { transform: scale(1.1); background: var(--primary-dark); }
        .menu-toggle:active { transform: scale(0.92); }

        /* ============================================
           RESPONSIVE - TABLET (≤1200px)
           ============================================ */
        @media (max-width: 1200px) {
            .stats-cards { grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); }
        }

        /* ============================================
           RESPONSIVE - TABLET (≤992px)
           ============================================ */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%) !important;
                width: 88vw;
                max-width: 320px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .sidebar.mobile-open { transform: translateX(0) !important; }
            .sidebar.collapsed { width: 88vw; }
            .sidebar.collapsed .menu-label,
            .sidebar.collapsed .logo span,
            .sidebar.collapsed .sidebar-menu a span,
            .sidebar.collapsed .logout-btn span { display: inline; }
            .sidebar.collapsed .sidebar-menu a { justify-content: flex-start; padding: 12px 16px; }
            .sidebar.collapsed .sidebar-header { justify-content: space-between; }
            .sidebar-close-btn { display: flex !important; }
            .sidebar .sidebar-toggle { display: none; }

            .main-content {
                margin-left: 0 !important;
                padding: 20px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .main-content.expanded { margin-left: 0 !important; }

            .menu-toggle { display: flex !important; }

            .header { flex-direction: column; align-items: stretch; gap: 14px; padding: 16px 20px; }
            .controls { justify-content: space-between; }

            .clients-controls { flex-direction: column; align-items: stretch; }
            .search-box { min-width: 100%; width: 100%; }
            .client-filters { width: 100%; }
            .client-actions { width: 100%; justify-content: stretch; }
            .client-actions .btn { width: 100%; }
        }

        /* ============================================
           RESPONSIVE - MÓVIL (≤768px)
           ============================================ */
        @media (max-width: 768px) {
            .main-content {
                padding: 16px;
                padding-top: calc(16px + var(--safe-top));
                padding-bottom: calc(90px + var(--safe-bottom));
            }

            .sidebar {
                width: 88vw;
                max-width: 320px;
                padding: 20px 12px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }

            .header { padding: 14px 16px; margin-bottom: 18px; border-radius: var(--border-radius-sm); gap: 10px; }
            .page-title { font-size: 17px; }
            .page-title i { font-size: 16px; }
            .theme-switcher, .notifications, .icon-btn { width: 40px; height: 40px; font-size: 14px; }

            /* STATS - 2 columnas */
            .stats-cards { grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 16px; }
            .stat-card { padding: 14px; border-radius: var(--border-radius-sm); }
            .stat-value { font-size: 20px; }
            .stat-title { font-size: 11px; }
            .stat-subtitle { font-size: 10px; }

            /* CLIENTS SECTION */
            .clients-section { padding: 14px; border-radius: var(--border-radius-sm); margin-bottom: 16px; }
            .clients-controls { gap: 10px; }
            .client-filters { flex-direction: column; gap: 8px; }
            .filter-group { min-width: 100%; width: 100%; }

            /* TABLE - scroll horizontal */
            .table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; }
            .client-table { min-width: 700px; }
            .client-table th, .client-table td { padding: 10px 12px; font-size: 12px; }
            .client-table th { font-size: 11px; }

            .client-actions-cell { gap: 4px; }
            .action-btn { width: 32px; height: 32px; font-size: 12px; }

            /* PAGINATION */
            .pagination-container { flex-direction: column; align-items: stretch; gap: 10px; }
            .pagination-info { font-size: 12px; text-align: center; }
            .pagination { justify-content: center; flex-wrap: wrap; }

            /* MODALES - Bottom sheet */
            .modal-dialog { margin: 0; max-width: 100%; align-items: flex-end; min-height: calc(100% - 40px); }
            .modal-content { border-radius: var(--border-radius-lg) var(--border-radius-lg) 0 0; max-height: calc(100dvh - 40px); }
            .modal-header { padding: 16px 18px; border-radius: var(--border-radius-lg) var(--border-radius-lg) 0 0; }
            .modal-header h5 { font-size: 15px; }
            .modal-body { padding: 18px; max-height: 65vh; overflow-y: auto; }
            .modal-footer { padding: 14px 18px calc(14px + var(--safe-bottom)); flex-direction: column-reverse; }
            .modal-footer .btn { width: 100%; }

            /* FORM - 1 columna */
            .modal-body .row > [class*="col-"] { flex: 0 0 100%; max-width: 100%; }

            /* TOASTS */
            .toast-container { top: calc(12px + var(--safe-top)); right: 12px; left: 12px; align-items: stretch; }
            .toast { min-width: 0; max-width: 100%; width: 100%; padding: 12px 14px; font-size: 13px; }

            /* EMPTY STATE */
            .empty-state { padding: 30px 16px; }
            .empty-state i { font-size: 40px; }
            .empty-state h4 { font-size: 15px; }

            .menu-toggle { width: 48px; height: 48px; font-size: 18px; }
        }

        /* ============================================
           RESPONSIVE - MÓVIL PEQUEÑO (≤380px)
           ============================================ */
        @media (max-width: 380px) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); padding-bottom: calc(80px + var(--safe-bottom)); }
            .page-title { font-size: 15px; }
            .theme-switcher, .notifications, .icon-btn { width: 36px; height: 36px; font-size: 13px; }
            .stats-cards { grid-template-columns: 1fr; }
            .stat-value { font-size: 18px; }
            .client-table { min-width: 650px; }
        }

        /* ============================================
           LANDSCAPE MÓVIL
           ============================================ */
        @media (max-height: 500px) and (orientation: landscape) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); }
            .header { padding: 10px 16px; margin-bottom: 12px; }
            .sidebar { padding: 16px 12px; padding-top: calc(16px + var(--safe-top)); }
            .stats-cards { grid-template-columns: repeat(4, 1fr); }
            .modal-content { max-height: 95dvh; }
        }

        /* ============================================
           PANTALLAS GRANDES
           ============================================ */
        @media (min-width: 1440px) {
            .main-content { padding: 30px; }
            .stats-cards { grid-template-columns: repeat(4, 1fr); }
        }
        @media (min-width: 1920px) {
            .main-content { padding: 40px 60px; max-width: 1800px; margin-left: auto; margin-right: auto; }
        }

        /* ============================================
           TOUCH
           ============================================ */
        @media (hover: none) {
            .stat-card:hover { transform: none; }
            .theme-switcher:hover, .notifications:hover, .icon-btn:hover { transform: none; box-shadow: none; }
            .action-btn:hover { transform: none; }
            .edit-btn:hover { background-color: var(--info-bg); color: var(--primary); }
            .delete-btn:hover { background-color: var(--danger-bg); color: var(--danger); }
            .view-btn:hover { background-color: var(--success-bg); color: var(--secondary); }
            .btn:hover { transform: none; box-shadow: none; }
            .sidebar-menu a:hover { transform: none; background: transparent; }
            .sidebar-menu a.active:hover { background: var(--primary); }
        }

        /* ============================================
           REDUCED MOTION
           ============================================ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        /* ============================================
           PRINT
           ============================================ */
        @media print {
            .sidebar, .header, .menu-toggle, .controls, .client-actions,
            .client-filters, .search-box, .pagination-container, .action-buttons { display: none !important; }
            .main-content { margin-left: 0 !important; padding: 0 !important; }
            .stat-card, .clients-section { box-shadow: none; border: 1px solid #ddd; }
            .client-table { min-width: 0 !important; }
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- OVERLAY MÓVIL -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-brain"></i></div>
                    <span class="system-name-display">SmartStock AI</span>
                </div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú" type="button">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/principal.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes-stacked"></i> <span>Inventario</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-right-left"></i> <span>Transacciones</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-column"></i> <span>Reportes</span></a></li>
                </ul>

                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/clientes.php" class="active"><i class="fas fa-address-book"></i> <span>Clientes</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck-field"></i> <span>Proveedores</span></a></li>
                </ul>

                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users-gear"></i> <span>Usuarios</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-halved"></i> <span>Seguridad</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-circle-user"></i> <span>Mi Perfil</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-sliders"></i> <span>Configuración</span></a></li>
                </ul>
            </div>

            <div class="sidebar-footer">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    <span>Cerrar Sesión</span>
                </button>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="main-content" id="mainContent">
            <div class="header">
                <h1 class="page-title">
                    <i class="fas fa-address-book"></i>
                    Gestión de Clientes
                </h1>

                <div class="controls">
                    <div class="theme-switcher" id="themeToggle" title="Cambiar tema">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notifications" id="notificationBtn" title="Notificaciones">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge hidden" id="notificationBadge">0</span>
                    </div>
                </div>
            </div>

            <!-- Tarjetas de Estadísticas -->
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-title">Total de Clientes</div>
                    <div class="stat-value" id="totalClients">0</div>
                    <div class="stat-subtitle">Registrados en el sistema</div>
                </div>
                <div class="stat-card" style="border-left-color: var(--secondary);">
                    <div class="stat-title">Clientes Activos</div>
                    <div class="stat-value" id="activeClients">0</div>
                    <div class="stat-subtitle">Con compras recientes</div>
                </div>
                <div class="stat-card" style="border-left-color: var(--warning);">
                    <div class="stat-title">Nuevos este Mes</div>
                    <div class="stat-value" id="newClients">0</div>
                    <div class="stat-subtitle">Clientes registrados</div>
                </div>
                <div class="stat-card" style="border-left-color: var(--info);">
                    <div class="stat-title">Valor Promedio</div>
                    <div class="stat-value" id="avgValue">$0</div>
                    <div class="stat-subtitle">Por cliente</div>
                </div>
            </div>

            <!-- Sección de Clientes -->
            <div class="clients-section">
                <div class="clients-controls">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" class="form-control" id="searchInput" placeholder="Buscar clientes...">
                    </div>

                    <div class="client-filters">
                        <div class="filter-group">
                            <select class="form-select" id="statusFilter">
                                <option value="all">Todos los estados</option>
                                <option value="active">Activos</option>
                                <option value="inactive">Inactivos</option>
                            </select>
                        </div>
                        <div class="filter-group">
                            <select class="form-select" id="typeFilter">
                                <option value="all">Todos los tipos</option>
                                <option value="individual">Individual</option>
                                <option value="business">Empresa</option>
                            </select>
                        </div>
                    </div>

                    <div class="client-actions">
                        <button class="btn btn-primary" id="addClientBtn">
                            <i class="fas fa-plus"></i> Agregar Cliente
                        </button>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="client-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Teléfono</th>
                                <th>Tipo</th>
                                <th>Última Compra</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="clientsTableBody"></tbody>
                    </table>
                </div>

                <div class="empty-state" id="emptyState" style="display: none;">
                    <i class="fas fa-user-friends"></i>
                    <h4>No hay clientes registrados</h4>
                    <p>Agrega tu primer cliente para comenzar</p>
                    <button class="btn btn-primary mt-3" id="addFirstClientBtn">
                        <i class="fas fa-plus"></i> Agregar Primer Cliente
                    </button>
                </div>

                <div class="pagination-container">
                    <div class="pagination-info" id="paginationInfo">Mostrando 0 de 0 clientes</div>
                    <nav>
                        <ul class="pagination" id="pagination"></ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para Agregar/Editar Cliente -->
    <div class="modal fade" id="clientModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="clientModalLabel">Agregar Nuevo Cliente</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="clientForm">
                        <input type="hidden" id="clientId">
                        <div class="row g-3">
                            <div class="col-md-6 col-12">
                                <label for="clientName" class="form-label">Nombre Completo</label>
                                <input type="text" class="form-control" id="clientName" required>
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="clientEmail" class="form-label">Email</label>
                                <input type="email" class="form-control" id="clientEmail" required>
                            </div>
                        </div>
                        <div class="row g-3 mt-1">
                            <div class="col-md-6 col-12">
                                <label for="clientPhone" class="form-label">Teléfono</label>
                                <input type="tel" class="form-control" id="clientPhone">
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="clientType" class="form-label">Tipo de Cliente</label>
                                <select class="form-select" id="clientType" required>
                                    <option value="individual">Individual</option>
                                    <option value="business">Empresa</option>
                                </select>
                            </div>
                        </div>
                        <div class="row g-3 mt-1" id="businessFields" style="display: none;">
                            <div class="col-md-6 col-12">
                                <label for="companyName" class="form-label">Nombre de la Empresa</label>
                                <input type="text" class="form-control" id="companyName">
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="taxId" class="form-label">RFC / Identificación Fiscal</label>
                                <input type="text" class="form-control" id="taxId">
                            </div>
                        </div>
                        <div class="row g-3 mt-1">
                            <div class="col-12">
                                <label for="clientAddress" class="form-label">Dirección</label>
                                <textarea class="form-control" id="clientAddress" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="row g-3 mt-1">
                            <div class="col-md-6 col-12">
                                <label for="clientCity" class="form-label">Ciudad</label>
                                <input type="text" class="form-control" id="clientCity">
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="clientZip" class="form-label">Código Postal</label>
                                <input type="text" class="form-control" id="clientZip">
                            </div>
                        </div>
                        <div class="mt-3 form-check">
                            <input type="checkbox" class="form-check-input" id="clientStatus" checked>
                            <label class="form-check-label" for="clientStatus">Cliente Activo</label>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveClientBtn">Guardar Cliente</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para Ver Detalles del Cliente -->
    <div class="modal fade" id="clientDetailsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="clientDetailsModalLabel">Detalles del Cliente</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6 col-12">
                            <h6>Información Personal</h6>
                            <p><strong>Nombre:</strong> <span id="detailName"></span></p>
                            <p><strong>Email:</strong> <span id="detailEmail"></span></p>
                            <p><strong>Teléfono:</strong> <span id="detailPhone"></span></p>
                            <p><strong>Tipo:</strong> <span id="detailType"></span></p>
                            <p><strong>Estado:</strong> <span id="detailStatus"></span></p>
                        </div>
                        <div class="col-md-6 col-12">
                            <h6>Información de Contacto</h6>
                            <p><strong>Dirección:</strong> <span id="detailAddress"></span></p>
                            <p><strong>Ciudad:</strong> <span id="detailCity"></span></p>
                            <p><strong>Código Postal:</strong> <span id="detailZip"></span></p>
                            <div id="businessDetails" style="display: none;">
                                <p><strong>Empresa:</strong> <span id="detailCompany"></span></p>
                                <p><strong>RFC:</strong> <span id="detailTaxId"></span></p>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4">
                        <h6>Historial de Compras</h6>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Producto</th>
                                        <th>Cantidad</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody id="purchaseHistory"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle" aria-label="Abrir menú" type="button">
        <i class="fas fa-bars"></i>
    </button>
    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============================================
        // RESPONSIVE STATE
        // ============================================
        const APP_STATE = {
            isMobile: window.matchMedia('(max-width: 992px)').matches,
            isTouch: ('ontouchstart' in window) || (navigator.maxTouchPoints > 0)
        };

        function openMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.add('mobile-open');
            if (ov) ov.classList.add('active');
            document.body.style.overflow = 'hidden';
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(5);
        }

        function closeMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.remove('mobile-open');
            if (ov) ov.classList.remove('active');
            document.body.style.overflow = '';
        }

        function setupMobileSidebar() {
            const overlay = document.getElementById('sidebarOverlay');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.getElementById('menuToggle');

            console.log('🔍 setupMobileSidebar:');
            console.log('  - overlay:', !!overlay);
            console.log('  - closeBtn:', !!closeBtn);
            console.log('  - sidebar:', !!sidebar);
            console.log('  - menuToggle:', !!menuToggle);

            if (overlay) overlay.addEventListener('click', closeMobileSidebar);
            if (closeBtn) closeBtn.addEventListener('click', closeMobileSidebar);

            if (menuToggle) {
                // Clonar para quitar listeners previos
                const newToggle = menuToggle.cloneNode(true);
                menuToggle.parentNode.replaceChild(newToggle, menuToggle);

                newToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('🍔 Menú clickeado');
                    const sb = document.getElementById('sidebar');
                    if (sb && sb.classList.contains('mobile-open')) {
                        closeMobileSidebar();
                    } else {
                        openMobileSidebar();
                    }
                });
            } else {
                console.error('❌ menuToggle NO ENCONTRADO');
            }

            // Swipe para cerrar
            if (sidebar) {
                let touchStartX = 0, touchCurrentX = 0;
                sidebar.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
                sidebar.addEventListener('touchmove', (e) => {
                    touchCurrentX = e.touches[0].clientX;
                    const diff = touchCurrentX - touchStartX;
                    if (diff < 0 && diff > -100) sidebar.style.transform = `translateX(${diff}px)`;
                }, { passive: true });
                sidebar.addEventListener('touchend', () => {
                    const diff = touchCurrentX - touchStartX;
                    sidebar.style.transform = '';
                    if (diff < -60) closeMobileSidebar();
                    touchStartX = 0; touchCurrentX = 0;
                });
            }

            // Cerrar al navegar
            document.querySelectorAll('.sidebar-menu a').forEach(a => {
                a.addEventListener('click', () => {
                    if (window.matchMedia('(max-width: 992px)').matches) closeMobileSidebar();
                });
            });

            // Cerrar con Escape
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') closeMobileSidebar();
            });

            // Detectar resize
            window.addEventListener('resize', () => {
                if (window.matchMedia('(min-width: 993px)').matches) closeMobileSidebar();
            });
        }

        // ============================================
        // CLASE CLIENT MANAGER
        // ============================================
        class ClientManager {
            constructor() {
                this.clients = JSON.parse(localStorage.getItem('clients')) || [];

                if (this.clients.length === 0) {
                    this.initializeSampleData();
                }

                this.currentPage = 1;
                this.itemsPerPage = 10;
                this.filteredClients = [...this.clients];
            }

            initializeSampleData() {
                this.clients = [
                    { id: 'CLI-001', name: 'María González', email: 'maria.gonzalez@email.com', phone: '+52 55 1234 5678', type: 'individual', address: 'Av. Reforma 123, Col. Juárez', city: 'Ciudad de México', zipCode: '06600', status: 'active', createdAt: '2023-10-15', lastPurchase: '2023-12-10', totalPurchases: 5, totalValue: 1250.50 },
                    { id: 'CLI-002', name: 'Carlos Rodríguez', email: 'carlos.rodriguez@email.com', phone: '+52 55 2345 6789', type: 'individual', address: 'Calle Hidalgo 456, Centro', city: 'Guadalajara', zipCode: '44100', status: 'active', createdAt: '2023-09-20', lastPurchase: '2023-12-05', totalPurchases: 3, totalValue: 850.75 },
                    { id: 'CLI-003', name: 'TecnoSoluciones SA de CV', email: 'ventas@tecnosoluciones.com', phone: '+52 55 3456 7890', type: 'business', companyName: 'TecnoSoluciones SA de CV', taxId: 'TSO120304567', address: 'Blvd. Miguel de Cervantes 789, Industrial', city: 'Monterrey', zipCode: '66470', status: 'active', createdAt: '2023-08-05', lastPurchase: '2023-11-28', totalPurchases: 12, totalValue: 4500.25 },
                    { id: 'CLI-004', name: 'Ana Martínez', email: 'ana.martinez@email.com', phone: '+52 55 4567 8901', type: 'individual', address: 'Calle Morelos 321, Del Valle', city: 'Puebla', zipCode: '72400', status: 'inactive', createdAt: '2023-07-12', lastPurchase: '2023-09-15', totalPurchases: 2, totalValue: 320.00 },
                    { id: 'CLI-005', name: 'Distribuidora Comercial MX', email: 'contacto@distcomercial.mx', phone: '+52 55 5678 9012', type: 'business', companyName: 'Distribuidora Comercial MX', taxId: 'DCM980765432', address: 'Av. Universidad 654, Narvarte', city: 'Ciudad de México', zipCode: '03020', status: 'active', createdAt: '2023-11-01', lastPurchase: '2023-12-12', totalPurchases: 8, totalValue: 2100.80 },
                    { id: 'CLI-006', name: 'Roberto Silva', email: 'roberto.silva@email.com', phone: '+52 55 6789 0123', type: 'individual', address: 'Calle 5 de Mayo 987, Centro', city: 'Querétaro', zipCode: '76000', status: 'active', createdAt: '2023-10-28', lastPurchase: '2023-12-08', totalPurchases: 4, totalValue: 980.40 },
                    { id: 'CLI-007', name: 'Laura Fernández', email: 'laura.fernandez@email.com', phone: '+52 55 7890 1234', type: 'individual', address: 'Av. Revolución 654, San Pedro', city: 'San Luis Potosí', zipCode: '78230', status: 'inactive', createdAt: '2023-06-18', lastPurchase: '2023-08-22', totalPurchases: 1, totalValue: 150.00 },
                    { id: 'CLI-008', name: 'Importaciones del Norte', email: 'info@importacionesnorte.com', phone: '+52 55 8901 2345', type: 'business', companyName: 'Importaciones del Norte SA', taxId: 'IMP450123789', address: 'Blvd. López Mateos 321, Zona Industrial', city: 'Chihuahua', zipCode: '31000', status: 'active', createdAt: '2023-09-30', lastPurchase: '2023-12-01', totalPurchases: 6, totalValue: 3200.60 }
                ];
                this.saveClients();
            }

            getAllClients() { return this.clients; }
            getClientById(id) { return this.clients.find(client => client.id === id); }

            addClient(clientData) {
                const newClient = {
                    id: 'CLI-' + String(this.clients.length + 1).padStart(3, '0'),
                    ...clientData,
                    createdAt: new Date().toISOString().split('T')[0],
                    lastPurchase: null,
                    totalPurchases: 0,
                    totalValue: 0
                };
                this.clients.push(newClient);
                this.saveClients();
                return newClient;
            }

            updateClient(id, clientData) {
                const index = this.clients.findIndex(client => client.id === id);
                if (index !== -1) {
                    this.clients[index] = { ...this.clients[index], ...clientData };
                    this.saveClients();
                    return this.clients[index];
                }
                return null;
            }

            deleteClient(id) {
                const index = this.clients.findIndex(client => client.id === id);
                if (index !== -1) {
                    this.clients.splice(index, 1);
                    this.saveClients();
                    return true;
                }
                return false;
            }

            saveClients() {
                localStorage.setItem('clients', JSON.stringify(this.clients));
            }

            filterClients(searchTerm = '', statusFilter = 'all', typeFilter = 'all') {
                this.filteredClients = this.clients.filter(client => {
                    const matchesSearch = searchTerm === '' ||
                        client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        client.phone.includes(searchTerm);

                    const matchesStatus = statusFilter === 'all' || client.status === statusFilter;
                    const matchesType = typeFilter === 'all' || client.type === typeFilter;

                    return matchesSearch && matchesStatus && matchesType;
                });
                return this.filteredClients;
            }

            getPaginatedClients(page = 1) {
                this.currentPage = page;
                const startIndex = (page - 1) * this.itemsPerPage;
                const endIndex = startIndex + this.itemsPerPage;
                return this.filteredClients.slice(startIndex, endIndex);
            }

            getTotalPages() {
                return Math.ceil(this.filteredClients.length / this.itemsPerPage);
            }

            getStats() {
                const totalClients = this.clients.length;
                const activeClients = this.clients.filter(client => client.status === 'active').length;

                const currentMonth = new Date().getMonth();
                const currentYear = new Date().getFullYear();
                const newClients = this.clients.filter(client => {
                    const clientDate = new Date(client.createdAt);
                    return clientDate.getMonth() === currentMonth && clientDate.getFullYear() === currentYear;
                }).length;

                const totalValue = this.clients.reduce((sum, client) => sum + client.totalValue, 0);
                const avgValue = totalClients > 0 ? totalValue / totalClients : 0;

                return { totalClients, activeClients, newClients, avgValue };
            }

            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
                    <span>${message}</span>
                `;

                document.getElementById('toastContainer').appendChild(toast);

                setTimeout(() => {
                    toast.style.animation = 'slideOut 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }
        }

        const clientManager = new ClientManager();

        // ============================================
        // RENDERIZADO
        // ============================================
        function renderClientsTable() {
            const tableBody = document.getElementById('clientsTableBody');
            const emptyState = document.getElementById('emptyState');
            const paginationInfo = document.getElementById('paginationInfo');

            const clients = clientManager.getPaginatedClients(clientManager.currentPage);
            const totalClients = clientManager.filteredClients.length;
            const totalPages = clientManager.getTotalPages();

            if (clients.length === 0) {
                tableBody.innerHTML = '';
                emptyState.style.display = 'block';
                paginationInfo.textContent = 'Mostrando 0 de 0 clientes';
                return;
            }

            emptyState.style.display = 'none';

            let html = '';
            clients.forEach(client => {
                const statusClass = client.status === 'active' ? 'status-active' : 'status-inactive';
                const statusText = client.status === 'active' ? 'Activo' : 'Inactivo';
                const typeText = client.type === 'individual' ? 'Individual' : 'Empresa';

                html += `
                    <tr>
                        <td>${client.id}</td>
                        <td>${client.name}</td>
                        <td>${client.email}</td>
                        <td>${client.phone}</td>
                        <td>${typeText}</td>
                        <td>${client.lastPurchase ? new Date(client.lastPurchase).toLocaleDateString() : 'Nunca'}</td>
                        <td><span class="client-status ${statusClass}">${statusText}</span></td>
                        <td>
                            <div class="client-actions-cell">
                                <button class="action-btn view-btn" data-id="${client.id}" title="Ver detalles">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="action-btn edit-btn" data-id="${client.id}" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="action-btn delete-btn" data-id="${client.id}" title="Eliminar">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });

            tableBody.innerHTML = html;

            const startItem = (clientManager.currentPage - 1) * clientManager.itemsPerPage + 1;
            const endItem = Math.min(startItem + clientManager.itemsPerPage - 1, totalClients);
            paginationInfo.textContent = `Mostrando ${startItem}-${endItem} de ${totalClients} clientes`;

            renderPagination(totalPages);

            document.querySelectorAll('.view-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    viewClientDetails(this.getAttribute('data-id'));
                });
            });

            document.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    editClient(this.getAttribute('data-id'));
                });
            });

            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    deleteClient(this.getAttribute('data-id'));
                });
            });
        }

        function renderPagination(totalPages) {
            const pagination = document.getElementById('pagination');
            const currentPage = clientManager.currentPage;

            let html = '';

            html += `
                <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                    <a class="page-link" href="#" data-page="${currentPage - 1}">Anterior</a>
                </li>
            `;

            for (let i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                    html += `
                        <li class="page-item ${i === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${i}">${i}</a>
                        </li>
                    `;
                } else if (i === currentPage - 2 || i === currentPage + 2) {
                    html += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
                }
            }

            html += `
                <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                    <a class="page-link" href="#" data-page="${currentPage + 1}">Siguiente</a>
                </li>
            `;

            pagination.innerHTML = html;

            document.querySelectorAll('.page-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const page = parseInt(this.getAttribute('data-page'));
                    if (!isNaN(page) && page >= 1 && page <= totalPages) {
                        clientManager.currentPage = page;
                        renderClientsTable();
                        updateStats();
                    }
                });
            });
        }

        function updateStats() {
            const stats = clientManager.getStats();

            document.getElementById('totalClients').textContent = stats.totalClients;
            document.getElementById('activeClients').textContent = stats.activeClients;
            document.getElementById('newClients').textContent = stats.newClients;
            document.getElementById('avgValue').textContent = `$${stats.avgValue.toFixed(2)}`;
        }

        function viewClientDetails(clientId) {
            const client = clientManager.getClientById(clientId);
            if (!client) return;

            document.getElementById('detailName').textContent = client.name;
            document.getElementById('detailEmail').textContent = client.email;
            document.getElementById('detailPhone').textContent = client.phone;
            document.getElementById('detailType').textContent = client.type === 'individual' ? 'Individual' : 'Empresa';
            document.getElementById('detailStatus').textContent = client.status === 'active' ? 'Activo' : 'Inactivo';
            document.getElementById('detailAddress').textContent = client.address || 'No especificada';
            document.getElementById('detailCity').textContent = client.city || 'No especificada';
            document.getElementById('detailZip').textContent = client.zipCode || 'No especificado';

            const businessDetails = document.getElementById('businessDetails');
            if (client.type === 'business') {
                document.getElementById('detailCompany').textContent = client.companyName || 'No especificada';
                document.getElementById('detailTaxId').textContent = client.taxId || 'No especificado';
                businessDetails.style.display = 'block';
            } else {
                businessDetails.style.display = 'none';
            }

            const purchaseHistory = document.getElementById('purchaseHistory');
            let historyHtml = '';

            if (client.totalPurchases > 0) {
                const products = ['Laptop HP', 'Smartphone Samsung', 'Tablet Android', 'Monitor LG', 'Auriculares Bluetooth'];
                for (let i = 0; i < Math.min(5, client.totalPurchases); i++) {
                    const daysAgo = Math.floor(Math.random() * 30) + 1;
                    const purchaseDate = new Date();
                    purchaseDate.setDate(purchaseDate.getDate() - daysAgo);

                    const product = products[Math.floor(Math.random() * products.length)];
                    const quantity = Math.floor(Math.random() * 3) + 1;
                    const price = (Math.random() * 500 + 100).toFixed(2);
                    const total = (quantity * price).toFixed(2);

                    historyHtml += `
                        <tr>
                            <td>${purchaseDate.toLocaleDateString()}</td>
                            <td>${product}</td>
                            <td>${quantity}</td>
                            <td>$${total}</td>
                        </tr>
                    `;
                }
            } else {
                historyHtml = '<tr><td colspan="4" class="text-center">No hay historial de compras</td></tr>';
            }

            purchaseHistory.innerHTML = historyHtml;

            const modal = new bootstrap.Modal(document.getElementById('clientDetailsModal'));
            modal.show();
        }

        function editClient(clientId) {
            const client = clientManager.getClientById(clientId);
            if (!client) return;

            document.getElementById('clientId').value = client.id;
            document.getElementById('clientName').value = client.name;
            document.getElementById('clientEmail').value = client.email;
            document.getElementById('clientPhone').value = client.phone || '';
            document.getElementById('clientType').value = client.type;
            document.getElementById('clientAddress').value = client.address || '';
            document.getElementById('clientCity').value = client.city || '';
            document.getElementById('clientZip').value = client.zipCode || '';
            document.getElementById('clientStatus').checked = client.status === 'active';

            toggleBusinessFields(client.type);

            if (client.type === 'business') {
                document.getElementById('companyName').value = client.companyName || '';
                document.getElementById('taxId').value = client.taxId || '';
            }

            document.getElementById('clientModalLabel').textContent = 'Editar Cliente';

            const modal = new bootstrap.Modal(document.getElementById('clientModal'));
            modal.show();
        }

        function deleteClient(clientId) {
            const client = clientManager.getClientById(clientId);
            if (!client) return;

            if (confirm(`¿Estás seguro de que deseas eliminar al cliente "${client.name}"?`)) {
                if (clientManager.deleteClient(clientId)) {
                    clientManager.showNotification('Cliente eliminado correctamente', 'success');
                    applyFilters();
                    updateStats();
                } else {
                    clientManager.showNotification('Error al eliminar el cliente', 'error');
                }
            }
        }

        function applyFilters() {
            const searchTerm = document.getElementById('searchInput').value;
            const statusFilter = document.getElementById('statusFilter').value;
            const typeFilter = document.getElementById('typeFilter').value;

            clientManager.filterClients(searchTerm, statusFilter, typeFilter);
            clientManager.currentPage = 1;
            renderClientsTable();
        }

        function toggleBusinessFields(clientType) {
            const businessFields = document.getElementById('businessFields');
            if (clientType === 'business') {
                businessFields.style.display = 'flex';
            } else {
                businessFields.style.display = 'none';
            }
        }

        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            const themeIcon = document.querySelector('#themeToggle i');
            themeIcon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
            document.querySelector('meta[name="theme-color"]')?.setAttribute('content', document.body.classList.contains('dark-mode') ? '#1a1f2e' : '#3a5ec7');
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(10);
        }

        function toggleSidebarSimple() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const icon = document.querySelector('#sidebarToggle i');
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            icon.className = sidebar.classList.contains('collapsed') ? 'fas fa-chevron-right' : 'fas fa-chevron-left';
        }

        // ============================================
        // INIT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            // Aplicar preferencias guardadas
            const globalSettings = JSON.parse(localStorage.getItem('globalSettings')) || {};
            if (globalSettings.darkMode || localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#1a1f2e');
            }

            if (globalSettings.systemName) {
                document.querySelectorAll('.system-name-display').forEach(el => {
                    el.textContent = globalSettings.systemName;
                });
            }

            // Setup responsive
            setupMobileSidebar();

            // Prevenir zoom doble-tap iOS
            if (APP_STATE.isTouch) {
                let lastTouchEnd = 0;
                document.addEventListener('touchend', (e) => {
                    const now = Date.now();
                    if (now - lastTouchEnd <= 300) e.preventDefault();
                    lastTouchEnd = now;
                }, { passive: false });
            }

            // Detectar cambio de orientación
            window.addEventListener('orientationchange', () => {
                setTimeout(() => {
                    APP_STATE.isMobile = window.matchMedia('(max-width: 992px)').matches;
                    if (!APP_STATE.isMobile) closeMobileSidebar();
                }, 150);
            });

            renderClientsTable();
            updateStats();

            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            document.getElementById('sidebarToggle').addEventListener('click', toggleSidebarSimple);

            document.getElementById('logoutBtn').addEventListener('click', function() {
                if (confirm('¿Desea cerrar la sesión actual?')) {
                    localStorage.removeItem('currentUser');
                    window.location.href = 'http://localhost/SmartStockAI/login.php';
                }
            });

            document.getElementById('searchInput').addEventListener('input', applyFilters);
            document.getElementById('statusFilter').addEventListener('change', applyFilters);
            document.getElementById('typeFilter').addEventListener('change', applyFilters);

            document.getElementById('addClientBtn').addEventListener('click', function() {
                document.getElementById('clientForm').reset();
                document.getElementById('clientId').value = '';
                document.getElementById('clientModalLabel').textContent = 'Agregar Nuevo Cliente';
                document.getElementById('businessFields').style.display = 'none';
                const modal = new bootstrap.Modal(document.getElementById('clientModal'));
                modal.show();
            });

            document.getElementById('addFirstClientBtn').addEventListener('click', function() {
                document.getElementById('clientForm').reset();
                document.getElementById('clientId').value = '';
                document.getElementById('clientModalLabel').textContent = 'Agregar Nuevo Cliente';
                document.getElementById('businessFields').style.display = 'none';
                const modal = new bootstrap.Modal(document.getElementById('clientModal'));
                modal.show();
            });

            document.getElementById('clientType').addEventListener('change', function() {
                toggleBusinessFields(this.value);
            });

            document.getElementById('saveClientBtn').addEventListener('click', function() {
                const clientId = document.getElementById('clientId').value;
                const clientData = {
                    name: document.getElementById('clientName').value,
                    email: document.getElementById('clientEmail').value,
                    phone: document.getElementById('clientPhone').value,
                    type: document.getElementById('clientType').value,
                    address: document.getElementById('clientAddress').value,
                    city: document.getElementById('clientCity').value,
                    zipCode: document.getElementById('clientZip').value,
                    status: document.getElementById('clientStatus').checked ? 'active' : 'inactive'
                };

                if (clientData.type === 'business') {
                    clientData.companyName = document.getElementById('companyName').value;
                    clientData.taxId = document.getElementById('taxId').value;
                }

                if (!clientData.name || !clientData.email) {
                    clientManager.showNotification('Nombre y email son obligatorios', 'error');
                    return;
                }

                if (clientId) {
                    if (clientManager.updateClient(clientId, clientData)) {
                        clientManager.showNotification('Cliente actualizado correctamente', 'success');
                    } else {
                        clientManager.showNotification('Error al actualizar el cliente', 'error');
                    }
                } else {
                    clientManager.addClient(clientData);
                    clientManager.showNotification('Cliente agregado correctamente', 'success');
                }

                bootstrap.Modal.getInstance(document.getElementById('clientModal')).hide();
                applyFilters();
                updateStats();
            });

            console.log('%c✅ SmartStock AI - Clientes listo', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (APP_STATE.isMobile ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>