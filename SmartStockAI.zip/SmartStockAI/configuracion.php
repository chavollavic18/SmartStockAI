<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>SmartStock AI - Configuraciones Globales</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Inter:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 270px;
            --sidebar-collapsed: 80px;
            --font-family: 'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            --font-size: 14px;
            --sidebar-bg: var(--primary);
            --sidebar-text: #ffffff;
            --sidebar-opacity: 1;

            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #ffffff;
            --gray: #adb5bd;
        }

        .no-animations * {
            transition: none !important;
            animation: none !important;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-family);
        }

        html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }

        body {
            background: var(--bg);
            font-family: var(--font-family);
            font-size: var(--font-size);
            color: var(--text);
            transition: var(--transition);
            min-height: 100vh;
            min-height: 100dvh;
            overflow-x: hidden;
            -webkit-tap-highlight-color: transparent;
            -webkit-font-smoothing: antialiased;
        }

        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary-dark); }

        .app-container {
            display: flex;
            min-height: 100vh;
            min-height: 100dvh;
        }

        /* ============================================
           OVERLAY MÓVIL
           ============================================ */
        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.55);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
            z-index: 1040;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .sidebar-overlay.active {
            display: block !important;
            opacity: 1;
        }

        /* ============================================
           SIDEBAR
           ============================================ */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--sidebar-bg);
            opacity: var(--sidebar-opacity);
            color: var(--sidebar-text);
            height: 100vh;
            height: 100dvh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
            transition: var(--transition);
            z-index: 1050;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            will-change: transform;
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .logo {
            font-size: 22px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 0;
            color: var(--sidebar-text);
        }
        .logo span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .sidebar-close-btn {
            display: none;
            background: rgba(255,255,255,0.1);
            border: none;
            color: var(--sidebar-text);
            width: 36px;
            height: 36px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            transition: var(--transition);
            flex-shrink: 0;
            touch-action: manipulation;
        }
        .sidebar-close-btn:hover { background: var(--danger); color: white; }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
            flex: 1;
        }

        .sidebar-menu li { margin-bottom: 5px; }

        .sidebar-menu a {
            color: var(--sidebar-text) !important;
            text-decoration: none;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            transition: var(--transition);
            border-left: 4px solid transparent;
            min-height: 44px;
            touch-action: manipulation;
            font-size: 14px;
            font-weight: 500;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(255,255,255,0.15);
            border-left-color: var(--sidebar-text);
        }

        .sidebar-menu i {
            width: 25px;
            margin-right: 10px;
            text-align: center;
            font-size: 16px;
            flex-shrink: 0;
        }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
            transition: var(--transition);
            min-width: 0;
            overflow-x: hidden;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
            flex-wrap: wrap;
            gap: 12px;
        }

        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--text);
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            margin: 0;
        }

        .controls {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 44px;
            height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: var(--text);
            position: relative;
            border: 1px solid rgba(0,0,0,0.05);
            flex-shrink: 0;
            touch-action: manipulation;
        }

        .theme-switcher:hover, .notifications:hover {
            transform: translateY(-3px);
        }

        /* ============================================
           SECCIÓN DE CONFIGURACIONES
           ============================================ */
        .settings-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .settings-tabs {
            display: flex;
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 20px;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
            scroll-snap-type: x proximity;
            gap: 4px;
            padding-bottom: 4px;
        }

        .settings-tabs::-webkit-scrollbar { display: none; }

        .settings-tab {
            padding: 11px 18px;
            background: none;
            border: none;
            border-bottom: 3px solid transparent;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            color: var(--gray);
            font-size: 13px;
            white-space: nowrap;
            flex-shrink: 0;
            scroll-snap-align: start;
            min-height: 44px;
            touch-action: manipulation;
            display: flex;
            align-items: center;
            gap: 6px;
            border-radius: 8px 8px 0 0;
        }

        .settings-tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
            background: rgba(58, 94, 199, 0.05);
        }

        .settings-tab:hover:not(.active) {
            color: var(--primary);
            background: rgba(58, 94, 199, 0.03);
        }

        .settings-content { display: none; }
        .settings-content.active { display: block; animation: fadeIn 0.3s ease; }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(4px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .settings-group {
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e9ecef;
        }

        .settings-group:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }

        .dark-mode .settings-group { border-bottom-color: rgba(255,255,255,0.08); }

        .settings-group-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .settings-group-title i {
            font-size: 20px;
        }

        .settings-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 15px;
        }

        .settings-item {
            display: flex;
            flex-direction: column;
            min-width: 0;
        }

        .settings-label {
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
            color: var(--text);
            font-size: 13px;
        }

        .settings-description {
            font-size: 12px;
            color: var(--gray);
            margin-top: 6px;
            line-height: 1.5;
        }

        .settings-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
            flex-wrap: wrap;
        }

        .dark-mode .settings-actions { border-top-color: rgba(255,255,255,0.08); }

        /* ============================================
           TOGGLE SWITCH
           ============================================ */
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 52px;
            height: 28px;
            flex-shrink: 0;
        }

        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 20px;
            width: 20px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }

        input:checked + .toggle-slider { background-color: var(--primary); }
        input:checked + .toggle-slider:before { transform: translateX(24px); }

        /* ============================================
           COLOR PICKER
           ============================================ */
        .color-picker {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        .color-option {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            cursor: pointer;
            border: 2px solid transparent;
            transition: var(--transition);
            touch-action: manipulation;
            position: relative;
        }

        .color-option.active {
            border-color: var(--text);
            transform: scale(1.15);
            box-shadow: 0 0 0 3px var(--card-bg), 0 0 0 5px currentColor;
        }

        /* ============================================
           TOASTS
           ============================================ */
        .toast-container {
            position: fixed;
            top: calc(20px + var(--safe-top));
            right: calc(20px + var(--safe-right));
            left: 20px;
            z-index: 1100;
            display: flex;
            flex-direction: column;
            gap: 8px;
            pointer-events: none;
            align-items: flex-end;
        }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 15px 20px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s forwards;
            color: var(--text);
            min-width: 280px;
            max-width: 400px;
            border-left: 4px solid var(--primary);
            pointer-events: auto;
        }

        .toast.success { border-left-color: var(--secondary); }
        .toast.error { border-left-color: var(--danger); }
        .toast.warning { border-left-color: var(--warning); }
        .toast.info { border-left-color: var(--primary); }

        .toast i {
            margin-right: 10px;
            font-size: 20px;
            flex-shrink: 0;
        }

        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        .toast.info i { color: var(--primary); }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        /* ============================================
           MODAL
           ============================================ */
        .instructions-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
        }

        .instructions-modal.active { display: flex; }

        .instructions-content {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            width: 100%;
            max-width: 800px;
            max-height: calc(100vh - 40px);
            max-height: calc(100dvh - 40px);
            overflow-y: auto;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            color: var(--text);
            -webkit-overflow-scrolling: touch;
        }

        .instructions-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #dee2e6;
            gap: 10px;
        }

        .dark-mode .instructions-header { border-bottom-color: rgba(255,255,255,0.08); }

        .instructions-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--primary);
            margin: 0;
        }

        .instructions-close {
            background: none;
            border: none;
            font-size: 28px;
            cursor: pointer;
            color: var(--gray);
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            flex-shrink: 0;
            touch-action: manipulation;
        }
        .instructions-close:hover { background: var(--danger); color: white; }

        .table { color: var(--text); }

        /* ============================================
           FORM CONTROLS
           ============================================ */
        .form-control, .form-select {
            color: var(--text) !important;
            background-color: var(--card-bg) !important;
            border: 1px solid rgba(0,0,0,0.1);
            border-radius: 8px;
            padding: 11px 12px;
            font-size: 16px;
            min-height: 44px;
            transition: var(--transition);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.25);
            background-color: var(--card-bg);
        }

        .form-control::placeholder { color: var(--gray) !important; }

        .btn {
            padding: 11px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            min-height: 44px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            touch-action: manipulation;
        }

        .btn-primary { background: var(--primary); color: white !important; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3); }
        .btn-secondary { background: var(--gray); color: white !important; }
        .btn-warning { background: var(--warning); color: #000 !important; }
        .btn-outline-primary { border: 1px solid var(--primary); color: var(--primary); background: transparent; }
        .btn-outline-primary:hover { background: var(--primary); color: white !important; }
        .btn-outline-secondary { border: 1px solid var(--gray); color: var(--text); background: transparent; }
        .btn-outline-secondary:hover { background: var(--gray); color: white !important; }
        .btn-outline-success { border: 1px solid var(--secondary); color: var(--secondary); background: transparent; }
        .btn-outline-success:hover { background: var(--secondary); color: white !important; }
        .btn-outline-danger { border: 1px solid var(--danger); color: var(--danger); background: transparent; }
        .btn-outline-danger:hover { background: var(--danger); color: white !important; }

        /* ============================================
           BOTONES FLOTANTES
           ============================================ */
        .instructions-btn {
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 50%;
            width: 52px;
            height: 52px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            bottom: calc(88px + var(--safe-bottom));
            right: calc(20px + var(--safe-right));
            z-index: 1100;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            cursor: pointer;
            transition: var(--transition);
            font-size: 20px;
            touch-action: manipulation;
        }
        .instructions-btn:hover { transform: scale(1.1); }
        .instructions-btn:active { transform: scale(0.92); }

        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 56px;
            height: 56px;
            border-radius: 50%;
            position: fixed;
            bottom: calc(20px + var(--safe-bottom));
            right: calc(20px + var(--safe-right));
            z-index: 1200;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            font-size: 22px;
            touch-action: manipulation;
            -webkit-tap-highlight-color: transparent;
        }
        .menu-toggle:hover { transform: scale(1.1); background: var(--primary-dark); }
        .menu-toggle:active { transform: scale(0.92); }

        /* ============================================
           RESPONSIVE - TABLET (≤992px)
           ============================================ */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%) !important;
                width: 88vw;
                max-width: 320px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .sidebar.mobile-open { transform: translateX(0) !important; }
            .sidebar-close-btn { display: flex !important; }

            .main-content {
                margin-left: 0 !important;
                padding: 20px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }

            .menu-toggle { display: flex !important; }

            .header { flex-direction: column; align-items: stretch; gap: 14px; }
            .controls { justify-content: space-between; }
        }

        /* ============================================
           RESPONSIVE - MÓVIL (≤768px)
           ============================================ */
        @media (max-width: 768px) {
            .main-content {
                padding: 16px;
                padding-top: calc(16px + var(--safe-top));
                padding-bottom: calc(90px + var(--safe-bottom));
            }

            .sidebar { width: 88vw; max-width: 320px; padding: 20px 12px; }

            .header { padding-bottom: 12px; margin-bottom: 18px; gap: 10px; }
            .page-title { font-size: 17px; }
            .page-title i { font-size: 16px; }
            .theme-switcher, .notifications { width: 40px; height: 40px; font-size: 14px; }

            .settings-section { padding: 16px; border-radius: 10px; margin-bottom: 16px; }
            .settings-tabs { gap: 4px; margin-bottom: 16px; }
            .settings-tab { padding: 9px 14px; font-size: 12px; }
            .settings-tab i { font-size: 12px; }
            .settings-group-title { font-size: 15px; }
            .settings-group-title i { font-size: 17px; }

            .settings-row {
                grid-template-columns: 1fr;
                gap: 14px;
            }

            .settings-actions {
                flex-direction: column-reverse;
                gap: 8px;
            }

            .settings-actions .btn { width: 100%; }

            /* Modales - Bottom sheet */
            .instructions-modal {
                padding: 0;
                padding-top: calc(40px + var(--safe-top));
                align-items: flex-end;
            }
            .instructions-content {
                max-width: 100%;
                width: 100%;
                border-radius: 20px 20px 0 0;
                max-height: calc(100dvh - 40px);
                padding: 20px;
            }
            .instructions-title { font-size: 18px; }

            /* Toasts */
            .toast-container {
                top: calc(12px + var(--safe-top));
                right: 12px;
                left: 12px;
                align-items: stretch;
            }
            .toast { min-width: 0; max-width: 100%; width: 100%; padding: 12px 14px; font-size: 13px; }

            .menu-toggle { width: 48px; height: 48px; font-size: 18px; }
            .instructions-btn { width: 46px; height: 46px; font-size: 18px; bottom: calc(80px + var(--safe-bottom)); }
        }

        /* ============================================
           RESPONSIVE - MÓVIL PEQUEÑO (≤380px)
           ============================================ */
        @media (max-width: 380px) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); padding-bottom: calc(80px + var(--safe-bottom)); }
            .page-title { font-size: 15px; }
            .theme-switcher, .notifications { width: 36px; height: 36px; font-size: 13px; }
            .settings-tab { padding: 8px 12px; font-size: 11px; }
            .settings-section { padding: 14px; }
        }

        /* ============================================
           LANDSCAPE MÓVIL
           ============================================ */
        @media (max-height: 500px) and (orientation: landscape) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); }
            .header { padding: 10px 16px; margin-bottom: 12px; }
            .sidebar { padding: 16px 12px; padding-top: calc(16px + var(--safe-top)); }
            .instructions-content { max-height: 95dvh; }
        }

        /* ============================================
           PANTALLAS GRANDES
           ============================================ */
        @media (min-width: 1440px) {
            .main-content { padding: 30px; }
        }
        @media (min-width: 1920px) {
            .main-content { padding: 40px 60px; max-width: 1800px; margin-left: auto; margin-right: auto; }
        }

        /* ============================================
           TOUCH
           ============================================ */
        @media (hover: none) {
            .theme-switcher:hover, .notifications:hover { transform: none; }
            .sidebar-menu a:hover { background: transparent; }
            .sidebar-menu a.active:hover { background: rgba(255,255,255,0.15); }
            .settings-tab:hover:not(.active) { background: none; }
            .btn:hover { transform: none; box-shadow: none; }
            .color-option:hover { transform: none; }
            .color-option.active:hover { transform: scale(1.15); }
            .instructions-btn:hover { transform: none; }
            .menu-toggle:hover { transform: none; }
        }

        /* ============================================
           REDUCED MOTION
           ============================================ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        /* ============================================
           PRINT
           ============================================ */
        @media print {
            .sidebar, .header, .menu-toggle, .instructions-btn, .controls,
            .settings-actions, .settings-tabs { display: none !important; }
            .main-content { margin-left: 0 !important; padding: 0 !important; }
            .settings-section { box-shadow: none; border: 1px solid #ddd; }
            .settings-content { display: block !important; }
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- OVERLAY MÓVIL -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot"></i><span class="system-name-display">SmartStock AI</span>
                </div>
                <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú" type="button">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <ul class="sidebar-menu" id="sidebarMenu">
                <li data-module="dashboard"><a href="http://localhost/SmartStockAI/principal.php"><i class="fas fa-home"></i> <span data-i18n="menu_dashboard">Dashboard</span></a></li>
                <li data-module="inventario"><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes"></i> <span data-i18n="menu_inventory">Inventario</span></a></li>
                <li data-module="proveedores"><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck"></i> <span data-i18n="menu_suppliers">Proveedores</span></a></li>
                <li data-module="usuarios"><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users"></i> <span data-i18n="menu_users">Usuarios</span></a></li>
                <li data-module="transacciones"><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-exchange-alt"></i> <span data-i18n="menu_transactions">Transacciones</span></a></li>
                <li data-module="reportes"><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-line"></i> <span data-i18n="menu_reports">Reportes</span></a></li>
                <li data-module="clientes"><a href="http://localhost/SmartStockAI/clientes.php"><i class="fas fa-user-friends"></i> <span data-i18n="menu_clients">Clientes</span></a></li>
                <li data-module="perfil"><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-user"></i> <span data-i18n="menu_profile">Mi Perfil</span></a></li>
                <li data-module="seguridad"><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-alt"></i> <span data-i18n="menu_security">Seguridad</span></a></li>
                <li><a href="#" class="active"><i class="fas fa-cog"></i> <span data-i18n="menu_settings">Configuraciones</span></a></li>
                <li><a href="http://localhost/SmartStockAI/login.php"><i class="fas fa-sign-out-alt"></i> <span data-i18n="menu_logout">Cerrar Sesión</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content" id="mainContent">
            <div class="header">
                <h1 class="page-title" data-i18n="page_title">
                    <i class="fas fa-sliders"></i>
                    Configuraciones Globales
                </h1>

                <div class="controls">
                    <div class="theme-switcher" id="themeToggle" title="Cambiar Tema">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notifications" id="notificationBtn" title="Probar Notificación">
                        <i class="fas fa-bell"></i>
                    </div>
                </div>
            </div>

            <!-- Sección de Configuraciones -->
            <div class="settings-section">
                <div class="settings-tabs">
                    <button class="settings-tab active" data-tab="general"><i class="fas fa-cog"></i><span data-i18n="tab_general">General</span></button>
                    <button class="settings-tab" data-tab="empresa"><i class="fas fa-building"></i><span data-i18n="tab_company">Empresa y Reportes</span></button>
                    <button class="settings-tab" data-tab="modulos"><i class="fas fa-th-large"></i><span data-i18n="tab_modules">Módulos</span></button>
                    <button class="settings-tab" data-tab="inventario"><i class="fas fa-boxes"></i><span data-i18n="tab_inventory">Inventario/IVA</span></button>
                    <button class="settings-tab" data-tab="sistema"><i class="fas fa-desktop"></i><span data-i18n="tab_system">Sistema</span></button>
                    <button class="settings-tab" data-tab="seguridad"><i class="fas fa-shield-alt"></i><span data-i18n="tab_security">Seguridad</span></button>
                    <button class="settings-tab" data-tab="notificaciones"><i class="fas fa-bell"></i><span data-i18n="tab_notifications">Notificaciones</span></button>
                    <button class="settings-tab" data-tab="apariencia"><i class="fas fa-palette"></i><span data-i18n="tab_appearance">Apariencia</span></button>
                    <button class="settings-tab" data-tab="database"><i class="fas fa-database"></i><span data-i18n="tab_database">Base de Datos</span></button>
                    <button class="settings-tab" data-tab="avanzado"><i class="fas fa-sliders-h"></i><span data-i18n="tab_advanced">Avanzado</span></button>
                    <button class="settings-tab" data-tab="logs"><i class="fas fa-history"></i><span data-i18n="tab_audit">Auditoría</span></button>
                </div>

                <!-- Pestaña General -->
                <div class="settings-content active" id="general-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-info-circle"></i><span data-i18n="group_basic_info">Información Básica</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_system_name">Nombre del Sistema</label>
                                <input type="text" class="form-control" id="systemName" placeholder="SmartStock AI">
                                <div class="settings-description" data-i18n="desc_system_name">Nombre que se mostrará en las páginas del sistema</div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_system_language">Idioma del Sistema</label>
                                <select class="form-select" id="systemLanguage">
                                    <option value="es">Español</option>
                                    <option value="en">English</option>
                                </select>
                            </div>
                        </div>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_timezone">Zona Horaria</label>
                                <select class="form-select" id="systemTimezone">
                                    <option value="America/Mexico_City">Ciudad de México (UTC-6)</option>
                                    <option value="UTC">UTC</option>
                                </select>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_date_format">Formato de Fecha</label>
                                <select class="form-select" id="dateFormat">
                                    <option value="dd/mm/yyyy">DD/MM/YYYY</option>
                                    <option value="yyyy-mm-dd">YYYY-MM-DD</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Empresa & Reportes -->
                <div class="settings-content" id="empresa-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-building"></i><span data-i18n="group_fiscal_data">Datos Fiscales y Plantillas</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_company_name">Nombre de la Empresa</label>
                                <input type="text" class="form-control" id="companyName" placeholder="Empresa S.A.">
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_tax_id">RFC / Identificación Fiscal</label>
                                <input type="text" class="form-control" id="companyTaxId" placeholder="ABC123456XYZ">
                            </div>
                        </div>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_company_email">Correo Electrónico de Contacto</label>
                                <input type="email" class="form-control" id="companyEmail" placeholder="contacto@empresa.com">
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_report_footer">Lema o Pie de Página de Reportes</label>
                                <input type="text" class="form-control" id="reportFooter" placeholder="Gracias por su preferencia">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Módulos Activos -->
                <div class="settings-content" id="modulos-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-th-large"></i><span data-i18n="group_modules_title">Activar o Desactivar Páginas del Sistema</span></h3>
                        <p class="text-muted" data-i18n="desc_modules">Controla qué opciones están accesibles desde el menú lateral principal.</p>
                        <div class="settings-row">
                            <div class="settings-item d-flex justify-content-between align-items-center border p-3 rounded">
                                <span><i class="fas fa-user-friends me-2"></i> <span data-i18n="mod_clients">Módulo Clientes</span></span>
                                <label class="toggle-switch">
                                    <input type="checkbox" class="module-toggle" data-module="clientes" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <div class="settings-item d-flex justify-content-between align-items-center border p-3 rounded">
                                <span><i class="fas fa-truck me-2"></i> <span data-i18n="mod_suppliers">Módulo Proveedores</span></span>
                                <label class="toggle-switch">
                                    <input type="checkbox" class="module-toggle" data-module="proveedores" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                        <div class="settings-row">
                            <div class="settings-item d-flex justify-content-between align-items-center border p-3 rounded">
                                <span><i class="fas fa-exchange-alt me-2"></i> <span data-i18n="mod_transactions">Módulo Transacciones</span></span>
                                <label class="toggle-switch">
                                    <input type="checkbox" class="module-toggle" data-module="transacciones" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <div class="settings-item d-flex justify-content-between align-items-center border p-3 rounded">
                                <span><i class="fas fa-chart-line me-2"></i> <span data-i18n="mod_reports">Módulo Reportes</span></span>
                                <label class="toggle-switch">
                                    <input type="checkbox" class="module-toggle" data-module="reportes" checked>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Inventario y Finanzas -->
                <div class="settings-content" id="inventario-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-calculator"></i><span data-i18n="group_finance_params">Parámetros Financieros y de Stock</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_currency">Moneda Principal</label>
                                <select class="form-select" id="currencySymbol">
                                    <option value="MXN">Pesos Mexicanos (MXN $)</option>
                                    <option value="USD">Dólares (USD $)</option>
                                    <option value="EUR">Euros (EUR €)</option>
                                </select>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_tax_rate">Porcentaje de IVA por Defecto (%)</label>
                                <input type="number" class="form-control" id="defaultTax" min="0" max="100" value="16">
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_min_stock">Stock Mínimo Crítico Global</label>
                                <input type="number" class="form-control" id="minStockAlert" min="1" value="5">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Sistema -->
                <div class="settings-content" id="sistema-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-hdd"></i><span data-i18n="group_maintenance">Mantenimiento del Sistema</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_clear_cache">Limpieza de Cache Local</label>
                                <button type="button" class="btn btn-warning" id="clearCacheBtn" style="width: 100%;">
                                    <i class="fas fa-broom"></i><span data-i18n="btn_clear_cache">Limpiar Caché del Navegador</span>
                                </button>
                                <div class="settings-description" data-i18n="desc_clear_cache">Elimina archivos temporales almacenados localmente</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Seguridad -->
                <div class="settings-content" id="seguridad-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-user-shield"></i><span data-i18n="group_session_security">Políticas de Sesión y Claves</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_session_timeout">Tiempo de Inactividad (Minutos)</label>
                                <input type="number" class="form-control" id="sessionTimeout" min="5" max="120" value="30">
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_2fa">Doble Factor de Autenticación (2FA)</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="twoFactorAuth">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="twoFactorStatus">Desactivado</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Notificaciones -->
                <div class="settings-content" id="notificaciones-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-bell"></i><span data-i18n="group_alerts_pref">Preferencias de Alertas</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_stock_alerts">Alertas del Sistema y Navegador</label>
                                <div class="d-flex align-items-center mb-3">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="stockAlerts" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span data-i18n="lbl_enable_popups">Activar Notificaciones Emergentes/Sistema</span>
                                </div>
                                <button type="button" class="btn btn-outline-primary" id="requestPermissionBtn" style="width: 100%;">
                                    <i class="fas fa-key"></i><span data-i18n="btn_grant_notifications">Conceder Permiso de Notificaciones</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Apariencia Extendida -->
                <div class="settings-content" id="apariencia-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-palette"></i><span data-i18n="group_color_theme">Tema y Paleta de Colores</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_theme_color">Color Principal del Sistema</label>
                                <div class="color-picker">
                                    <div class="color-option active" style="background-color: #3a5ec7;" data-color="blue" title="Azul Institucional"></div>
                                    <div class="color-option" style="background-color: #28a745;" data-color="green" title="Verde Esmeralda"></div>
                                    <div class="color-option" style="background-color: #dc3545;" data-color="red" title="Rojo Carmín"></div>
                                    <div class="color-option" style="background-color: #6f42c1;" data-color="purple" title="Morado Neón"></div>
                                    <div class="color-option" style="background-color: #fd7e14;" data-color="orange" title="Naranja Cálido"></div>
                                    <div class="color-option" style="background-color: #20c997;" data-color="teal" title="Turquesa Moderno"></div>
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_dark_mode">Modo Oscuro</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="darkMode">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="darkModeStatus">Desactivado</span>
                                </div>
                            </div>
                        </div>

                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_auto_dark_mode">Modo Oscuro Automático</label>
                                <select class="form-select" id="autoDarkMode">
                                    <option value="disabled">Desactivado</option>
                                    <option value="system">Según preferencia del Navegador/S.O.</option>
                                    <option value="schedule">Programado por horario</option>
                                </select>
                            </div>
                            <div class="settings-item d-none" id="scheduleInputs">
                                <label class="settings-label" data-i18n="lbl_dark_schedule">Horario Nocturno (Inicio - Fin)</label>
                                <div class="d-flex gap-2">
                                    <input type="time" class="form-control" id="darkStart" value="19:00">
                                    <input type="time" class="form-control" id="darkEnd" value="07:00">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-font"></i><span data-i18n="group_typography">Tipografía y Diseño de Layout</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_font_family">Fuente del Sistema</label>
                                <select class="form-select" id="fontFamily">
                                    <option value="'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif">Plus Jakarta Sans (Predeterminada)</option>
                                    <option value="'Segoe UI', Tahoma, Geneva, Verdana, sans-serif">Segoe UI</option>
                                    <option value="'Roboto', sans-serif">Roboto</option>
                                    <option value="'Inter', sans-serif">Inter UI</option>
                                    <option value="'Poppins', sans-serif">Poppins Modern</option>
                                    <option value="'Montserrat', sans-serif">Montserrat</option>
                                    <option value="system-ui, -apple-system, BlinkMacSystemFont">Nativa del S.O.</option>
                                </select>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_ui_density">Densidad de la Interfaz</label>
                                <select class="form-select" id="uiDensity">
                                    <option value="comfortable">Cómoda (Estándar)</option>
                                    <option value="compact">Compacta</option>
                                    <option value="ultra-compact">Ultra Compacta</option>
                                </select>
                            </div>
                        </div>

                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_border_radius">Estilo de Bordes (Redondeado)</label>
                                <select class="form-select" id="borderRadius">
                                    <option value="0px">Sin redondeado (0px)</option>
                                    <option value="6px">Suave (6px)</option>
                                    <option value="12px" selected>Estándar (12px)</option>
                                    <option value="20px">Redondeado Pronunciado (20px)</option>
                                </select>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_animations">Efectos Visuales y Animaciones</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="enableAnimations" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span data-i18n="lbl_animations_active">Animaciones Activas</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-sliders-h"></i><span data-i18n="group_sidebar_style">Personalización del Menú Lateral</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_sidebar_theme">Estilo de Color del Menú</label>
                                <select class="form-select" id="sidebarTheme">
                                    <option value="accent">Color Primario Seleccionado</option>
                                    <option value="dark">Oscuro Elegante</option>
                                    <option value="light">Blanco / Claro Minimalista</option>
                                </select>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_sidebar_opacity">Transparencia del Menú</label>
                                <input type="range" class="form-range" id="sidebarOpacity" min="70" max="100" value="100">
                                <div class="settings-description text-end" id="opacityVal">100%</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Base de Datos -->
                <div class="settings-content" id="database-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-server"></i><span data-i18n="group_db_integrity">Estado e Integridad del Almacenamiento</span></h3>
                        <div class="settings-row">
                            <div class="settings-item border p-3 rounded text-center">
                                <h5 data-i18n="lbl_conn_status">Estado de Conexión</h5>
                                <span class="badge bg-success" data-i18n="status_connected">Conectado / LocalStorage Activo</span>
                            </div>
                            <div class="settings-item border p-3 rounded text-center">
                                <h5 data-i18n="lbl_audit_records">Registros de Auditoría</h5>
                                <span class="badge bg-info" id="dbLogCount">0 Eventos</span>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button class="btn btn-outline-success" id="optimizeDbBtn" style="width: 100%;">
                                <i class="fas fa-wrench"></i><span data-i18n="btn_optimize_db">Optimizar Caché de la Base de Datos</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Avanzado -->
                <div class="settings-content" id="avanzado-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-plug"></i><span data-i18n="group_integrations">Integraciones y Credenciales</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_api_key">API Key</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="apiKey" readonly>
                                    <button class="btn btn-outline-secondary" type="button" id="generateApiKey" title="Generar nueva clave">
                                        <i class="fas fa-sync-alt"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-database"></i><span data-i18n="group_backup_restore">Respaldo y Restauración</span></h3>
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label" data-i18n="lbl_export_import">Exportar / Importar Ajustes</label>
                                <div class="d-flex gap-2 flex-wrap">
                                    <button type="button" class="btn btn-outline-primary" id="exportSettingsBtn" style="flex: 1; min-width: 140px;">
                                        <i class="fas fa-download"></i><span data-i18n="btn_export">Exportar</span>
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary" id="importSettingsBtn" style="flex: 1; min-width: 140px;">
                                        <i class="fas fa-upload"></i><span data-i18n="btn_import">Importar</span>
                                    </button>
                                    <input type="file" id="importFileInput" accept=".json" style="display: none;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pestaña Auditoría -->
                <div class="settings-content" id="logs-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title"><i class="fas fa-history"></i><span data-i18n="group_audit_log">Registro de Cambios Recientes</span></h3>
                        <div class="table-responsive">
                            <table class="table table-hover border">
                                <thead>
                                    <tr>
                                        <th data-i18n="th_date">Fecha y Hora</th>
                                        <th data-i18n="th_action">Acción Realizada</th>
                                        <th data-i18n="th_user">Usuario</th>
                                    </tr>
                                </thead>
                                <tbody id="auditLogTable"></tbody>
                            </table>
                        </div>
                        <button class="btn btn-outline-danger mt-2" id="clearLogsBtn" style="width: 100%;">
                            <i class="fas fa-trash"></i><span data-i18n="btn_clear_audit">Limpiar Historial de Auditoría</span>
                        </button>
                    </div>
                </div>

                <div class="settings-actions">
                    <button type="button" class="btn btn-secondary" id="resetSettingsBtn">
                        <i class="fas fa-undo"></i><span data-i18n="btn_reset">Restablecer</span>
                    </button>
                    <button type="button" class="btn btn-primary" id="saveSettingsBtn">
                        <i class="fas fa-save"></i><span data-i18n="btn_save">Guardar Configuraciones</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <button class="instructions-btn" id="instructionsBtn" title="Instrucciones" type="button">
        <i class="fas fa-question"></i>
    </button>

    <button class="menu-toggle" id="menuToggle" aria-label="Abrir menú" type="button">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Modal Instrucciones -->
    <div class="instructions-modal" id="instructionsModal">
        <div class="instructions-content">
            <div class="instructions-header">
                <h2 class="instructions-title" data-i18n="modal_title">Instrucciones de Configuración</h2>
                <button class="instructions-close" id="instructionsClose" type="button">&times;</button>
            </div>
            <p data-i18n="modal_intro">Siga estos pasos para administrar el sistema:</p>
            <ul>
                <li data-i18n="modal_step1"><strong>Cambios en tiempo real:</strong> Seleccione el color, idioma o el modo oscuro y observe cómo la interfaz responde dinámicamente.</li>
                <li data-i18n="modal_step2"><strong>Gestión de Módulos:</strong> Active o desactive páginas para habilitarlas u ocultarlas de la barra lateral automáticamente.</li>
                <li data-i18n="modal_step3"><strong>Respaldo:</strong> Puede guardar sus configuraciones exportándolas en un archivo JSON desde la pestaña Avanzado.</li>
                <li data-i18n="modal_step4"><strong>Notificaciones:</strong> Permita que el navegador emita alertas nativas del sistema cuando ocurra un evento relevante.</li>
            </ul>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============================================
        // RESPONSIVE STATE + MENÚ MÓVIL
        // ============================================
        const APP_STATE = {
            isMobile: window.matchMedia('(max-width: 992px)').matches,
            isTouch: ('ontouchstart' in window) || (navigator.maxTouchPoints > 0)
        };

        function openMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.add('mobile-open');
            if (ov) ov.classList.add('active');
            document.body.style.overflow = 'hidden';
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(5);
        }

        function closeMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.remove('mobile-open');
            if (ov) ov.classList.remove('active');
            document.body.style.overflow = '';
        }

        function setupMobileSidebar() {
            const overlay = document.getElementById('sidebarOverlay');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.getElementById('menuToggle');

            console.log('🔍 setupMobileSidebar:');
            console.log('  - overlay:', !!overlay);
            console.log('  - closeBtn:', !!closeBtn);
            console.log('  - sidebar:', !!sidebar);
            console.log('  - menuToggle:', !!menuToggle);

            if (overlay) overlay.addEventListener('click', closeMobileSidebar);
            if (closeBtn) closeBtn.addEventListener('click', closeMobileSidebar);

            if (menuToggle) {
                // Clonar para quitar listeners previos
                const newToggle = menuToggle.cloneNode(true);
                menuToggle.parentNode.replaceChild(newToggle, menuToggle);

                newToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('🍔 Menú clickeado');
                    const sb = document.getElementById('sidebar');
                    if (sb && sb.classList.contains('mobile-open')) {
                        closeMobileSidebar();
                    } else {
                        openMobileSidebar();
                    }
                });
            } else {
                console.error('❌ menuToggle NO ENCONTRADO');
            }

            // Swipe para cerrar
            if (sidebar) {
                let touchStartX = 0, touchCurrentX = 0;
                sidebar.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
                sidebar.addEventListener('touchmove', (e) => {
                    touchCurrentX = e.touches[0].clientX;
                    const diff = touchCurrentX - touchStartX;
                    if (diff < 0 && diff > -100) sidebar.style.transform = `translateX(${diff}px)`;
                }, { passive: true });
                sidebar.addEventListener('touchend', () => {
                    const diff = touchCurrentX - touchStartX;
                    sidebar.style.transform = '';
                    if (diff < -60) closeMobileSidebar();
                    touchStartX = 0; touchCurrentX = 0;
                });
            }

            // Cerrar al navegar
            document.querySelectorAll('.sidebar-menu a').forEach(a => {
                a.addEventListener('click', () => {
                    if (window.matchMedia('(max-width: 992px)').matches) closeMobileSidebar();
                });
            });

            // Cerrar con Escape
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') closeMobileSidebar();
            });

            // Detectar resize
            window.addEventListener('resize', () => {
                if (window.matchMedia('(min-width: 993px)').matches) closeMobileSidebar();
            });
        }

        // ============================================
        // DICCIONARIO DE TRADUCCIONES
        // ============================================
        const i18nDictionary = {
            es: {
                menu_dashboard: "Dashboard",
                menu_inventory: "Inventario",
                menu_suppliers: "Proveedores",
                menu_users: "Usuarios",
                menu_transactions: "Transacciones",
                menu_reports: "Reportes",
                menu_clients: "Clientes",
                menu_profile: "Mi Perfil",
                menu_security: "Seguridad",
                menu_settings: "Configuraciones",
                menu_logout: "Cerrar Sesión",
                page_title: "Configuraciones Globales",
                tab_general: "General",
                tab_company: "Empresa y Reportes",
                tab_modules: "Módulos",
                tab_inventory: "Inventario/IVA",
                tab_system: "Sistema",
                tab_security: "Seguridad",
                tab_notifications: "Notificaciones",
                tab_appearance: "Apariencia",
                tab_database: "Base de Datos",
                tab_advanced: "Avanzado",
                tab_audit: "Auditoría",
                group_basic_info: "Información Básica",
                lbl_system_name: "Nombre del Sistema",
                desc_system_name: "Nombre que se mostrará en las páginas del sistema",
                lbl_system_language: "Idioma del Sistema",
                lbl_timezone: "Zona Horaria",
                lbl_date_format: "Formato de Fecha",
                group_fiscal_data: "Datos Fiscales y Plantillas",
                lbl_company_name: "Nombre de la Empresa",
                lbl_tax_id: "RFC / Identificación Fiscal",
                lbl_company_email: "Correo Electrónico de Contacto",
                lbl_report_footer: "Lema o Pie de Página de Reportes",
                group_modules_title: "Activar o Desactivar Páginas del Sistema",
                desc_modules: "Controla qué opciones están accesibles desde el menú lateral principal.",
                mod_clients: "Módulo Clientes",
                mod_suppliers: "Módulo Proveedores",
                mod_transactions: "Módulo Transacciones",
                mod_reports: "Módulo Reportes",
                group_finance_params: "Parámetros Financieros y de Stock",
                lbl_currency: "Moneda Principal",
                lbl_tax_rate: "Porcentaje de IVA por Defecto (%)",
                lbl_min_stock: "Stock Mínimo Crítico Global",
                group_maintenance: "Mantenimiento del Sistema",
                lbl_clear_cache: "Limpieza de Cache Local",
                btn_clear_cache: "Limpiar Caché del Navegador",
                desc_clear_cache: "Elimina archivos temporales almacenados localmente",
                group_session_security: "Políticas de Sesión y Claves",
                lbl_session_timeout: "Tiempo de Inactividad (Minutos)",
                lbl_2fa: "Doble Factor de Autenticación (2FA)",
                group_alerts_pref: "Preferencias de Alertas",
                lbl_stock_alerts: "Alertas del Sistema y Navegador",
                lbl_enable_popups: "Activar Notificaciones Emergentes/Sistema",
                btn_grant_notifications: "Conceder Permiso de Notificaciones",
                group_color_theme: "Tema y Paleta de Colores",
                lbl_theme_color: "Color Principal del Sistema",
                lbl_dark_mode: "Modo Oscuro",
                lbl_auto_dark_mode: "Modo Oscuro Automático",
                lbl_dark_schedule: "Horario Nocturno (Inicio - Fin)",
                group_typography: "Tipografía y Diseño de Layout",
                lbl_font_family: "Fuente del Sistema",
                lbl_ui_density: "Densidad de la Interfaz",
                lbl_border_radius: "Estilo de Bordes (Redondeado)",
                lbl_animations: "Efectos Visuales y Animaciones",
                lbl_animations_active: "Animaciones Activas",
                group_sidebar_style: "Personalización del Menú Lateral",
                lbl_sidebar_theme: "Estilo de Color del Menú",
                lbl_sidebar_opacity: "Transparencia del Menú",
                group_db_integrity: "Estado e Integridad del Almacenamiento",
                lbl_conn_status: "Estado de Conexión",
                status_connected: "Conectado / LocalStorage Activo",
                lbl_audit_records: "Registros de Auditoría",
                btn_optimize_db: "Optimizar Caché de la Base de Datos",
                group_integrations: "Integraciones y Credenciales",
                lbl_api_key: "API Key",
                group_backup_restore: "Respaldo y Restauración",
                lbl_export_import: "Exportar / Importar Ajustes",
                btn_export: "Exportar",
                btn_import: "Importar",
                group_audit_log: "Registro de Cambios Recientes",
                th_date: "Fecha y Hora",
                th_action: "Acción Realizada",
                th_user: "Usuario",
                btn_clear_audit: "Limpiar Historial de Auditoría",
                btn_reset: "Restablecer",
                btn_save: "Guardar Configuraciones",
                modal_title: "Instrucciones de Configuración",
                modal_intro: "Siga estos pasos para administrar el sistema:",
                modal_step1: "Cambios en tiempo real: Seleccione el color, idioma o el modo oscuro y observe cómo la interfaz responde dinámicamente.",
                modal_step2: "Gestión de Módulos: Active o desactive páginas para habilitarlas u ocultarlas de la barra lateral automáticamente.",
                modal_step3: "Respaldo: Puede guardar sus configuraciones exportándolas en un archivo JSON desde la pestaña Avanzado.",
                modal_step4: "Notificaciones: Permita que el navegador emita alertas nativas del sistema cuando ocurra un evento relevante.",
                txt_active: "Activado",
                txt_inactive: "Desactivado",
                msg_saved: "Configuraciones guardadas con éxito",
                msg_reset: "Configuraciones restablecidas por defecto",
                msg_cache_cleared: "Caché del navegador limpiada con éxito",
                msg_perm_granted: "Permisos de notificación concedidos por el navegador",
                msg_perm_denied: "Permisos de notificación denegados por el usuario"
            },
            en: {
                menu_dashboard: "Dashboard",
                menu_inventory: "Inventory",
                menu_suppliers: "Suppliers",
                menu_users: "Users",
                menu_transactions: "Transactions",
                menu_reports: "Reports",
                menu_clients: "Clients",
                menu_profile: "My Profile",
                menu_security: "Security",
                menu_settings: "Settings",
                menu_logout: "Log Out",
                page_title: "Global Settings",
                tab_general: "General",
                tab_company: "Company & Reports",
                tab_modules: "Modules",
                tab_inventory: "Inventory/Tax",
                tab_system: "System",
                tab_security: "Security",
                tab_notifications: "Notifications",
                tab_appearance: "Appearance",
                tab_database: "Database",
                tab_advanced: "Advanced",
                tab_audit: "Audit Logs",
                group_basic_info: "Basic Information",
                lbl_system_name: "System Name",
                desc_system_name: "Name displayed across system pages",
                lbl_system_language: "System Language",
                lbl_timezone: "Timezone",
                lbl_date_format: "Date Format",
                group_fiscal_data: "Tax Data & Templates",
                lbl_company_name: "Company Name",
                lbl_tax_id: "Tax ID / VAT",
                lbl_company_email: "Contact Email",
                lbl_report_footer: "Reports Footer / Motto",
                group_modules_title: "Enable or Disable System Pages",
                desc_modules: "Controls options accessible from the main sidebar.",
                mod_clients: "Clients Module",
                mod_suppliers: "Suppliers Module",
                mod_transactions: "Transactions Module",
                mod_reports: "Reports Module",
                group_finance_params: "Financial & Stock Parameters",
                lbl_currency: "Primary Currency",
                lbl_tax_rate: "Default Tax Rate (%)",
                lbl_min_stock: "Global Critical Minimum Stock",
                group_maintenance: "System Maintenance",
                lbl_clear_cache: "Clear Local Cache",
                btn_clear_cache: "Clear Browser Cache",
                desc_clear_cache: "Deletes locally stored temporary files",
                group_session_security: "Session & Key Policies",
                lbl_session_timeout: "Inactivity Timeout (Minutes)",
                lbl_2fa: "Two-Factor Authentication (2FA)",
                group_alerts_pref: "Alert Preferences",
                lbl_stock_alerts: "System & Browser Alerts",
                lbl_enable_popups: "Enable System/Popup Notifications",
                btn_grant_notifications: "Grant Browser Notification Permissions",
                group_color_theme: "Theme & Color Palette",
                lbl_theme_color: "Primary System Color",
                lbl_dark_mode: "Dark Mode",
                lbl_auto_dark_mode: "Automatic Dark Mode",
                lbl_dark_schedule: "Night Schedule (Start - End)",
                group_typography: "Typography & Layout Design",
                lbl_font_family: "System Font",
                lbl_ui_density: "UI Density",
                lbl_border_radius: "Border Radius Style",
                lbl_animations: "Visual Effects & Animations",
                lbl_animations_active: "Transition Animations Active",
                group_sidebar_style: "Sidebar Customization",
                lbl_sidebar_theme: "Sidebar Color Style",
                lbl_sidebar_opacity: "Sidebar Transparency",
                group_db_integrity: "Storage Status & Integrity",
                lbl_conn_status: "Connection Status",
                status_connected: "Connected / LocalStorage Active",
                lbl_audit_records: "Audit Records",
                btn_optimize_db: "Optimize Database Cache",
                group_integrations: "Integrations & Credentials",
                lbl_api_key: "API Key",
                group_backup_restore: "Backup & Restore",
                lbl_export_import: "Export / Import Settings",
                btn_export: "Export",
                btn_import: "Import",
                group_audit_log: "Recent Changes Log",
                th_date: "Date & Time",
                th_action: "Action Taken",
                th_user: "User",
                btn_clear_audit: "Clear Audit Log",
                btn_reset: "Reset",
                btn_save: "Save Settings",
                modal_title: "Configuration Instructions",
                modal_intro: "Follow these steps to manage the system:",
                modal_step1: "Real-time changes: Pick a color, language, or dark mode and watch the UI update dynamically.",
                modal_step2: "Module Management: Enable or disable pages to automatically show/hide them from the sidebar.",
                modal_step3: "Backup: Save your settings by exporting them to a JSON file from the Advanced tab.",
                modal_step4: "Notifications: Allow your browser to send native system alerts when key events occur.",
                txt_active: "Enabled",
                txt_inactive: "Disabled",
                msg_saved: "Settings saved successfully",
                msg_reset: "Settings reset to default",
                msg_cache_cleared: "Browser cache successfully cleared",
                msg_perm_granted: "Notification permissions granted by browser",
                msg_perm_denied: "Notification permissions denied by user"
            }
        };

        // ============================================
        // GLOBAL SETTINGS MANAGER
        // ============================================
        class GlobalSettingsManager {
            constructor() {
                this.settings = JSON.parse(localStorage.getItem('globalSettings')) || this.getDefaultSettings();
                this.logs = JSON.parse(localStorage.getItem('auditLogs')) || [];
                this.applySettings();
                this.initStorageListener();
            }

            getDefaultSettings() {
                return {
                    systemName: 'SmartStock AI',
                    systemLanguage: 'es',
                    systemTimezone: 'America/Mexico_City',
                    dateFormat: 'dd/mm/yyyy',
                    companyName: 'SmartStock Inc.',
                    companyTaxId: 'TAX-123456',
                    companyEmail: 'contacto@empresa.com',
                    reportFooter: 'Documento generado automáticamente por SmartStock AI',
                    currencySymbol: 'MXN',
                    defaultTax: 16,
                    minStockAlert: 5,
                    sessionTimeout: 30,
                    twoFactorAuth: false,
                    stockAlerts: true,
                    themeColor: 'blue',
                    darkMode: false,
                    autoDarkMode: 'disabled',
                    darkStart: '19:00',
                    darkEnd: '07:00',
                    fontFamily: "'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
                    uiDensity: 'comfortable',
                    borderRadius: '12px',
                    enableAnimations: true,
                    sidebarTheme: 'accent',
                    sidebarOpacity: '100',
                    apiKey: this.generateApiKey(),
                    modules: {
                        clientes: true,
                        proveedores: true,
                        transacciones: true,
                        reportes: true
                    }
                };
            }

            generateApiKey() {
                return 'sk_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
            }

            getSettings() { return this.settings; }

            updateSettings(newSettings, actionName = 'Actualización de configuración') {
                this.settings = { ...this.settings, ...newSettings };
                localStorage.setItem('globalSettings', JSON.stringify(this.settings));
                this.addAuditLog(actionName);
                this.applySettings();
                return this.settings;
            }

            resetSettings() {
                this.settings = this.getDefaultSettings();
                localStorage.setItem('globalSettings', JSON.stringify(this.settings));
                this.addAuditLog('Restablecimiento completo del sistema');
                this.applySettings();
                return this.settings;
            }

            addAuditLog(action) {
                const newLog = {
                    date: new Date().toLocaleString(),
                    action: action,
                    user: 'Admin'
                };
                this.logs.unshift(newLog);
                if (this.logs.length > 20) this.logs.pop();
                localStorage.setItem('auditLogs', JSON.stringify(this.logs));
            }

            applySettings() {
                let isDark = this.settings.darkMode;
                if (this.settings.autoDarkMode === 'system') {
                    isDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
                } else if (this.settings.autoDarkMode === 'schedule') {
                    const now = new Date();
                    const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
                    const start = this.settings.darkStart || '19:00';
                    const end = this.settings.darkEnd || '07:00';
                    if (start > end) {
                        isDark = currentTime >= start || currentTime < end;
                    } else {
                        isDark = currentTime >= start && currentTime < end;
                    }
                }

                if (isDark) {
                    document.body.classList.add('dark-mode');
                    const icon = document.querySelector('#themeToggle i');
                    if (icon) icon.className = 'fas fa-sun';
                } else {
                    document.body.classList.remove('dark-mode');
                    const icon = document.querySelector('#themeToggle i');
                    if (icon) icon.className = 'fas fa-moon';
                }

                document.documentElement.style.setProperty('--font-family', this.settings.fontFamily || "'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif");

                if (this.settings.uiDensity === 'compact') {
                    document.documentElement.style.setProperty('--font-size', '13px');
                } else if (this.settings.uiDensity === 'ultra-compact') {
                    document.documentElement.style.setProperty('--font-size', '12px');
                } else {
                    document.documentElement.style.setProperty('--font-size', '14px');
                }

                document.documentElement.style.setProperty('--border-radius', this.settings.borderRadius || '12px');

                if (this.settings.enableAnimations) {
                    document.body.classList.remove('no-animations');
                } else {
                    document.body.classList.add('no-animations');
                }

                const colors = {
                    blue: '#3a5ec7',
                    green: '#28a745',
                    red: '#dc3545',
                    purple: '#6f42c1',
                    orange: '#fd7e14',
                    teal: '#20c997'
                };
                const activePrimary = colors[this.settings.themeColor] || colors.blue;
                document.documentElement.style.setProperty('--primary', activePrimary);

                if (this.settings.sidebarTheme === 'dark') {
                    document.documentElement.style.setProperty('--sidebar-bg', '#111827');
                    document.documentElement.style.setProperty('--sidebar-text', '#ffffff');
                } else if (this.settings.sidebarTheme === 'light') {
                    document.documentElement.style.setProperty('--sidebar-bg', '#ffffff');
                    document.documentElement.style.setProperty('--sidebar-text', '#333333');
                } else {
                    document.documentElement.style.setProperty('--sidebar-bg', activePrimary);
                    document.documentElement.style.setProperty('--sidebar-text', '#ffffff');
                }

                const opacityVal = (parseInt(this.settings.sidebarOpacity || 100) / 100).toString();
                document.documentElement.style.setProperty('--sidebar-opacity', opacityVal);

                document.querySelectorAll('.system-name-display').forEach(el => el.textContent = this.settings.systemName || 'SmartStock AI');

                if (this.settings.modules) {
                    Object.keys(this.settings.modules).forEach(mod => {
                        const menuLi = document.querySelector(`#sidebarMenu li[data-module="${mod}"]`);
                        if (menuLi) {
                            menuLi.style.display = this.settings.modules[mod] ? 'block' : 'none';
                        }
                    });
                }

                this.applyLanguage(this.settings.systemLanguage || 'es');
            }

            applyLanguage(lang) {
                const langData = i18nDictionary[lang] || i18nDictionary['es'];
                document.querySelectorAll('[data-i18n]').forEach(element => {
                    const key = element.getAttribute('data-i18n');
                    if (langData[key]) {
                        element.textContent = langData[key];
                    }
                });
            }

            initStorageListener() {
                window.addEventListener('storage', (e) => {
                    if (e.key === 'globalSettings') {
                        this.settings = JSON.parse(e.newValue) || this.getDefaultSettings();
                        this.applySettings();
                        loadSettingsToForm();
                    }
                });
            }

            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `<i class="fas fa-info-circle"></i><span>${message}</span>`;
                document.getElementById('toastContainer').appendChild(toast);
                setTimeout(() => {
                    toast.style.animation = 'slideOut 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);

                if (this.settings.stockAlerts && "Notification" in window) {
                    if (Notification.permission === "granted") {
                        new Notification(this.settings.systemName || "SmartStock AI", {
                            body: message,
                            icon: "https://cdn-icons-png.flaticon.com/512/2540/2540201.png"
                        });
                    }
                }
            }
        }

        const settingsManager = new GlobalSettingsManager();

        function loadSettingsToForm() {
            const s = settingsManager.getSettings();

            if (document.getElementById('systemName')) document.getElementById('systemName').value = s.systemName;
            if (document.getElementById('systemLanguage')) document.getElementById('systemLanguage').value = s.systemLanguage;
            if (document.getElementById('systemTimezone')) document.getElementById('systemTimezone').value = s.systemTimezone;
            if (document.getElementById('dateFormat')) document.getElementById('dateFormat').value = s.dateFormat;

            if (document.getElementById('companyName')) document.getElementById('companyName').value = s.companyName;
            if (document.getElementById('companyTaxId')) document.getElementById('companyTaxId').value = s.companyTaxId;
            if (document.getElementById('companyEmail')) document.getElementById('companyEmail').value = s.companyEmail;
            if (document.getElementById('reportFooter')) document.getElementById('reportFooter').value = s.reportFooter;

            if (document.getElementById('currencySymbol')) document.getElementById('currencySymbol').value = s.currencySymbol;
            if (document.getElementById('defaultTax')) document.getElementById('defaultTax').value = s.defaultTax;
            if (document.getElementById('minStockAlert')) document.getElementById('minStockAlert').value = s.minStockAlert;

            if (document.getElementById('sessionTimeout')) document.getElementById('sessionTimeout').value = s.sessionTimeout;
            if (document.getElementById('apiKey')) document.getElementById('apiKey').value = s.apiKey;

            const lang = s.systemLanguage || 'es';
            const activeText = i18nDictionary[lang].txt_active;
            const inactiveText = i18nDictionary[lang].txt_inactive;

            const darkModeCheck = document.getElementById('darkMode');
            if (darkModeCheck) {
                darkModeCheck.checked = s.darkMode;
                document.getElementById('darkModeStatus').textContent = s.darkMode ? activeText : inactiveText;
            }

            if (document.getElementById('autoDarkMode')) {
                document.getElementById('autoDarkMode').value = s.autoDarkMode || 'disabled';
                const schedInputs = document.getElementById('scheduleInputs');
                if (s.autoDarkMode === 'schedule') {
                    schedInputs.classList.remove('d-none');
                } else {
                    schedInputs.classList.add('d-none');
                }
            }
            if (document.getElementById('darkStart')) document.getElementById('darkStart').value = s.darkStart || '19:00';
            if (document.getElementById('darkEnd')) document.getElementById('darkEnd').value = s.darkEnd || '07:00';

            if (document.getElementById('fontFamily')) document.getElementById('fontFamily').value = s.fontFamily || "'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
            if (document.getElementById('uiDensity')) document.getElementById('uiDensity').value = s.uiDensity || "comfortable";
            if (document.getElementById('borderRadius')) document.getElementById('borderRadius').value = s.borderRadius || "12px";
            if (document.getElementById('enableAnimations')) document.getElementById('enableAnimations').checked = s.enableAnimations !== false;

            if (document.getElementById('sidebarTheme')) document.getElementById('sidebarTheme').value = s.sidebarTheme || "accent";
            if (document.getElementById('sidebarOpacity')) {
                document.getElementById('sidebarOpacity').value = s.sidebarOpacity || "100";
                document.getElementById('opacityVal').textContent = `${s.sidebarOpacity || 100}%`;
            }

            const twoFactorCheck = document.getElementById('twoFactorAuth');
            if (twoFactorCheck) {
                twoFactorCheck.checked = s.twoFactorAuth;
                document.getElementById('twoFactorStatus').textContent = s.twoFactorAuth ? activeText : inactiveText;
            }

            const stockAlertsCheck = document.getElementById('stockAlerts');
            if (stockAlertsCheck) stockAlertsCheck.checked = s.stockAlerts;

            document.querySelectorAll('.color-option').forEach(option => {
                option.classList.remove('active');
                if (option.getAttribute('data-color') === s.themeColor) {
                    option.classList.add('active');
                }
            });

            document.querySelectorAll('.module-toggle').forEach(chk => {
                const mod = chk.getAttribute('data-module');
                if (s.modules && s.modules[mod] !== undefined) {
                    chk.checked = s.modules[mod];
                }
            });

            renderLogs();
        }

        function renderLogs() {
            const logs = JSON.parse(localStorage.getItem('auditLogs')) || [];
            const tbody = document.getElementById('auditLogTable');
            const dbCount = document.getElementById('dbLogCount');

            if (dbCount) dbCount.textContent = `${logs.length} Eventos`;

            if (tbody) {
                tbody.innerHTML = '';
                if (logs.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">Sin registros de auditoría</td></tr>';
                    return;
                }

                logs.forEach(log => {
                    tbody.innerHTML += `<tr><td>${log.date}</td><td>${log.action}</td><td><span class="badge bg-secondary">${log.user}</span></td></tr>`;
                });
            }
        }

        function saveSettingsFromForm() {
            const activeColor = document.querySelector('.color-option.active');

            const modulesConfig = {};
            document.querySelectorAll('.module-toggle').forEach(chk => {
                modulesConfig[chk.getAttribute('data-module')] = chk.checked;
            });

            const currentLang = document.getElementById('systemLanguage').value;

            const settings = {
                systemName: document.getElementById('systemName').value,
                systemLanguage: currentLang,
                systemTimezone: document.getElementById('systemTimezone').value,
                dateFormat: document.getElementById('dateFormat').value,
                companyName: document.getElementById('companyName').value,
                companyTaxId: document.getElementById('companyTaxId').value,
                companyEmail: document.getElementById('companyEmail').value,
                reportFooter: document.getElementById('reportFooter').value,
                currencySymbol: document.getElementById('currencySymbol').value,
                defaultTax: parseFloat(document.getElementById('defaultTax').value),
                minStockAlert: parseInt(document.getElementById('minStockAlert').value),
                sessionTimeout: parseInt(document.getElementById('sessionTimeout').value),
                twoFactorAuth: document.getElementById('twoFactorAuth') ? document.getElementById('twoFactorAuth').checked : false,
                stockAlerts: document.getElementById('stockAlerts') ? document.getElementById('stockAlerts').checked : true,
                themeColor: activeColor ? activeColor.getAttribute('data-color') : 'blue',
                darkMode: document.getElementById('darkMode').checked,
                autoDarkMode: document.getElementById('autoDarkMode').value,
                darkStart: document.getElementById('darkStart').value,
                darkEnd: document.getElementById('darkEnd').value,
                fontFamily: document.getElementById('fontFamily').value,
                uiDensity: document.getElementById('uiDensity').value,
                borderRadius: document.getElementById('borderRadius').value,
                enableAnimations: document.getElementById('enableAnimations').checked,
                sidebarTheme: document.getElementById('sidebarTheme').value,
                sidebarOpacity: document.getElementById('sidebarOpacity').value,
                apiKey: document.getElementById('apiKey').value,
                modules: modulesConfig
            };

            settingsManager.updateSettings(settings, 'Guardó cambios de configuración global');
            loadSettingsToForm();
            settingsManager.showNotification(i18nDictionary[currentLang].msg_saved, 'success');
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Setup responsive + menú móvil
            setupMobileSidebar();

            loadSettingsToForm();

            document.getElementById('systemLanguage').addEventListener('change', (e) => {
                const selectedLang = e.target.value;
                settingsManager.updateSettings({ systemLanguage: selectedLang }, 'Cambio de idioma del sistema');
                loadSettingsToForm();
            });

            document.getElementById('themeToggle').addEventListener('click', () => {
                const current = settingsManager.getSettings().darkMode;
                settingsManager.updateSettings({ darkMode: !current }, 'Cambió el tema visual');
                loadSettingsToForm();
                if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(10);
            });

            document.getElementById('requestPermissionBtn').addEventListener('click', () => {
                if ("Notification" in window) {
                    Notification.requestPermission().then(permission => {
                        const lang = settingsManager.getSettings().systemLanguage || 'es';
                        if (permission === "granted") {
                            settingsManager.showNotification(i18nDictionary[lang].msg_perm_granted, 'success');
                        } else {
                            settingsManager.showNotification(i18nDictionary[lang].msg_perm_denied, 'warning');
                        }
                    });
                }
            });

            document.getElementById('notificationBtn').addEventListener('click', () => {
                const lang = settingsManager.getSettings().systemLanguage || 'es';
                const testMsg = lang === 'es' ? 'Esta es una prueba del sistema de alertas.' : 'This is a test alert notification.';

                if ("Notification" in window && Notification.permission !== "granted") {
                    Notification.requestPermission().then(() => {
                        settingsManager.showNotification(testMsg, 'info');
                    });
                } else {
                    settingsManager.showNotification(testMsg, 'info');
                }
            });

            document.getElementById('autoDarkMode').addEventListener('change', (e) => {
                const schedInputs = document.getElementById('scheduleInputs');
                if (e.target.value === 'schedule') {
                    schedInputs.classList.remove('d-none');
                } else {
                    schedInputs.classList.add('d-none');
                }
                settingsManager.updateSettings({ autoDarkMode: e.target.value });
            });

            document.getElementById('sidebarTheme').addEventListener('change', (e) => {
                settingsManager.updateSettings({ sidebarTheme: e.target.value });
            });

            document.getElementById('sidebarOpacity').addEventListener('input', (e) => {
                document.getElementById('opacityVal').textContent = `${e.target.value}%`;
                settingsManager.updateSettings({ sidebarOpacity: e.target.value });
            });

            document.getElementById('fontFamily').addEventListener('change', (e) => {
                settingsManager.updateSettings({ fontFamily: e.target.value });
            });

            document.getElementById('uiDensity').addEventListener('change', (e) => {
                settingsManager.updateSettings({ uiDensity: e.target.value });
            });

            document.getElementById('borderRadius').addEventListener('change', (e) => {
                settingsManager.updateSettings({ borderRadius: e.target.value });
            });

            document.getElementById('enableAnimations').addEventListener('change', (e) => {
                settingsManager.updateSettings({ enableAnimations: e.target.checked });
            });

            document.getElementById('saveSettingsBtn').addEventListener('click', saveSettingsFromForm);

            document.getElementById('resetSettingsBtn').addEventListener('click', () => {
                const lang = settingsManager.getSettings().systemLanguage || 'es';
                const confirmMsg = lang === 'es' ? '¿Desea restablecer todas las configuraciones por defecto?' : 'Reset all settings to default?';

                if (confirm(confirmMsg)) {
                    settingsManager.resetSettings();
                    loadSettingsToForm();
                    settingsManager.showNotification(i18nDictionary[lang].msg_reset, 'warning');
                }
            });

            document.querySelectorAll('.settings-tab').forEach(tab => {
                tab.addEventListener('click', function() {
                    document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
                    document.querySelectorAll('.settings-content').forEach(c => c.classList.remove('active'));
                    this.classList.add('active');
                    const tabId = this.getAttribute('data-tab');
                    const content = document.getElementById(`${tabId}-tab`);
                    if (content) content.classList.add('active');

                    // Auto-scroll tab into view en móvil
                    if (APP_STATE.isMobile) {
                        this.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
                    }
                });
            });

            document.querySelectorAll('.color-option').forEach(option => {
                option.addEventListener('click', function() {
                    document.querySelectorAll('.color-option').forEach(o => o.classList.remove('active'));
                    this.classList.add('active');
                    const selectedColor = this.getAttribute('data-color');
                    settingsManager.updateSettings({ themeColor: selectedColor }, 'Cambio de color de tema');
                });
            });

            document.getElementById('generateApiKey').addEventListener('click', () => {
                const newKey = settingsManager.generateApiKey();
                document.getElementById('apiKey').value = newKey;
                settingsManager.showNotification('Nueva API Key generada', 'info');
            });

            document.getElementById('clearCacheBtn').addEventListener('click', () => {
                const lang = settingsManager.getSettings().systemLanguage || 'es';
                settingsManager.addAuditLog('Limpieza de caché local');
                renderLogs();
                settingsManager.showNotification(i18nDictionary[lang].msg_cache_cleared, 'success');
            });

            document.getElementById('exportSettingsBtn').addEventListener('click', () => {
                const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(settingsManager.getSettings(), null, 2));
                const downloadAnchor = document.createElement('a');
                downloadAnchor.setAttribute("href", dataStr);
                downloadAnchor.setAttribute("download", "smartstock_config.json");
                document.body.appendChild(downloadAnchor);
                downloadAnchor.click();
                downloadAnchor.remove();
                settingsManager.addAuditLog('Exportó archivo de configuración');
                renderLogs();
            });

            const fileInput = document.getElementById('importFileInput');
            document.getElementById('importSettingsBtn').addEventListener('click', () => fileInput.click());

            fileInput.addEventListener('change', (event) => {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        try {
                            const importedSettings = JSON.parse(e.target.result);
                            settingsManager.updateSettings(importedSettings, 'Importó archivo de configuración');
                            loadSettingsToForm();
                            settingsManager.showNotification('Configuración importada exitosamente', 'success');
                        } catch (err) {
                            settingsManager.showNotification('El archivo no es un JSON válido', 'error');
                        }
                    };
                    reader.readAsText(file);
                }
            });

            document.getElementById('optimizeDbBtn').addEventListener('click', () => {
                settingsManager.addAuditLog('Optimización de base de datos local');
                renderLogs();
                settingsManager.showNotification('Caché y tablas locales optimizadas con éxito', 'success');
            });

            document.getElementById('clearLogsBtn').addEventListener('click', () => {
                localStorage.removeItem('auditLogs');
                renderLogs();
                settingsManager.showNotification('Historial de auditoría eliminado', 'warning');
            });

            document.getElementById('darkMode').addEventListener('change', (e) => {
                const isChecked = e.target.checked;
                settingsManager.updateSettings({ darkMode: isChecked }, 'Cambio de Modo Oscuro');
                const lang = settingsManager.getSettings().systemLanguage || 'es';
                document.getElementById('darkModeStatus').textContent = isChecked ? i18nDictionary[lang].txt_active : i18nDictionary[lang].txt_inactive;
            });

            const twoFactorCheck = document.getElementById('twoFactorAuth');
            if (twoFactorCheck) {
                twoFactorCheck.addEventListener('change', (e) => {
                    const lang = settingsManager.getSettings().systemLanguage || 'es';
                    document.getElementById('twoFactorStatus').textContent = e.target.checked ? i18nDictionary[lang].txt_active : i18nDictionary[lang].txt_inactive;
                    settingsManager.updateSettings({ twoFactorAuth: e.target.checked }, 'Cambio de 2FA');
                });
            }

            const modal = document.getElementById('instructionsModal');
            document.getElementById('instructionsBtn').addEventListener('click', () => modal.classList.add('active'));
            document.getElementById('instructionsClose').addEventListener('click', () => modal.classList.remove('active'));
            modal.addEventListener('click', (e) => {
                if (e.target === modal) modal.classList.remove('active');
            });

            // Escape para cerrar modal
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    modal.classList.remove('active');
                }
            });

            console.log('%c✅ SmartStock AI - Configuración lista', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (APP_STATE.isMobile ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>