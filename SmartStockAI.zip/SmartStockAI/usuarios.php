<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>SmartStock AI - Gestión de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 270px;
            --sidebar-collapsed: 80px;
            --primary-rgb: 58, 94, 199;
            --font-main: 'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;

            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #ffffff;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-main);
        }

        html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }

        body {
            background: var(--bg);
            color: var(--text);
            transition: var(--transition);
            min-height: 100vh;
            min-height: 100dvh;
            overflow-x: hidden;
            -webkit-tap-highlight-color: transparent;
            -webkit-font-smoothing: antialiased;
        }

        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary-dark); }

        .app-container { display: flex; min-height: 100vh; min-height: 100dvh; }

        /* ============================================
           OVERLAY MÓVIL
           ============================================ */
        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.55);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
            z-index: 1040;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .sidebar-overlay.active {
            display: block !important;
            opacity: 1;
        }

        /* ============================================
           SIDEBAR
           ============================================ */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            color: #ffffff;
            height: 100vh;
            height: 100dvh;
            position: fixed;
            left: 0; top: 0;
            padding: 24px 16px;
            padding-top: calc(24px + var(--safe-top));
            padding-bottom: calc(24px + var(--safe-bottom));
            transition: var(--transition);
            z-index: 1050;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 25px rgba(0,0,0,0.15);
            overflow-y: auto;
            will-change: transform;
        }

        .sidebar-header {
            padding: 0 12px 24px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .sidebar .logo {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -0.5px;
            background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }
        .sidebar .logo span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .sidebar .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            -webkit-text-fill-color: white;
            flex-shrink: 0;
        }

        .sidebar .sidebar-toggle {
            background: rgba(255,255,255,0.15);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            font-size: 12px;
            flex-shrink: 0;
        }

        .sidebar .sidebar-toggle:hover {
            background: rgba(255,255,255,0.25);
            transform: scale(1.1);
        }

        .sidebar-close-btn {
            display: none;
            background: rgba(255,255,255,0.08);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            transition: var(--transition);
            flex-shrink: 0;
            touch-action: manipulation;
        }
        .sidebar-close-btn:hover { background: var(--danger); }

        .sidebar-nav-container {
            flex: 1;
            overflow-y: auto;
            padding-right: 4px;
            -webkit-overflow-scrolling: touch;
        }

        .menu-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #64748b;
            font-weight: 700;
            margin: 16px 12px 8px 12px;
        }

        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li { margin-bottom: 4px; }

        .sidebar-menu a {
            color: #94a3b8;
            text-decoration: none;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border-radius: 8px;
            transition: var(--transition);
            font-weight: 500;
            font-size: 14px;
            cursor: pointer;
            gap: 12px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .sidebar-menu a:hover {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.06);
            transform: translateX(3px);
        }

        .sidebar-menu a.active {
            color: #ffffff;
            background: var(--primary);
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .sidebar-menu i {
            font-size: 18px;
            width: 22px;
            text-align: center;
            flex-shrink: 0;
        }

        .sidebar-footer {
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            margin-top: auto;
        }

        .logout-btn {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
            width: 100%;
            padding: 12px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: var(--transition);
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .logout-btn:hover {
            background: var(--danger);
            color: white;
            border-color: var(--danger);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .sidebar.collapsed { width: var(--sidebar-collapsed); }
        .sidebar.collapsed .menu-label,
        .sidebar.collapsed .logo span,
        .sidebar.collapsed .sidebar-menu a span,
        .sidebar.collapsed .logout-btn span { display: none; }
        .sidebar.collapsed .sidebar-menu a { justify-content: center; padding: 12px; }
        .sidebar.collapsed .sidebar-menu i { margin: 0; }
        .sidebar.collapsed .sidebar-header { justify-content: center; }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
            transition: var(--transition);
            min-width: 0;
            overflow-x: hidden;
        }

        .main-content.expanded { margin-left: var(--sidebar-collapsed); }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
            flex-wrap: wrap;
            gap: 12px;
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: var(--text);
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            margin: 0;
        }

        .page-title i { color: var(--primary); }

        .controls {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 44px;
            height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: var(--text);
            position: relative;
            border: 1px solid rgba(0,0,0,0.05);
            flex-shrink: 0;
            touch-action: manipulation;
        }

        .theme-switcher:hover, .notifications:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        .notification-badge.hidden { display: none; }
        .notification-container { position: relative; }

        .notification-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            width: 350px;
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            z-index: 1000;
            display: none;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .notification-dropdown.show { display: block; animation: slideDown 0.3s ease; }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .notification-header {
            padding: 15px;
            border-bottom: 1px solid var(--gray);
            font-weight: 600;
            background: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .notification-header button {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            cursor: pointer;
            min-height: 32px;
            touch-action: manipulation;
        }

        .notification-list { max-height: 350px; overflow-y: auto; -webkit-overflow-scrolling: touch; }

        .notification-item {
            padding: 15px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
        }

        .notification-item:hover { background: rgba(58, 94, 199, 0.05); }
        .notification-item.unread { background: rgba(58, 94, 199, 0.1); border-left: 3px solid var(--primary); }
        .notification-item strong { display: block; margin-bottom: 5px; color: var(--primary); }
        .notification-item p { margin-bottom: 5px; font-size: 13px; }
        .notification-item small { color: var(--gray); font-size: 11px; }

        .notification-footer {
            padding: 10px 15px;
            text-align: center;
            border-top: 1px solid var(--gray);
        }

        .notification-footer a {
            color: var(--primary);
            text-decoration: none;
            font-size: 13px;
        }

        /* ============================================
           STATS CARDS
           ============================================ */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            transition: var(--transition);
            border-left: 4px solid transparent;
        }

        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .stat-users { border-left-color: var(--primary); }
        .stat-active { border-left-color: var(--secondary); }
        .stat-pending { border-left-color: var(--warning); }
        .stat-inactive { border-left-color: var(--danger); }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 20px;
            flex-shrink: 0;
        }

        .stat-users .stat-icon { background: rgba(58, 94, 199, 0.2); color: var(--primary); }
        .stat-active .stat-icon { background: rgba(40, 167, 69, 0.2); color: var(--secondary); }
        .stat-pending .stat-icon { background: rgba(255, 193, 7, 0.2); color: var(--warning); }
        .stat-inactive .stat-icon { background: rgba(220, 53, 69, 0.2); color: var(--danger); }

        .stat-content { flex: 1; min-width: 0; }
        .stat-value { font-size: 24px; font-weight: 700; color: var(--text); line-height: 1.2; }
        .stat-label { color: var(--gray); font-size: 14px; margin-bottom: 5px; }
        .stat-trend { font-size: 12px; display: flex; align-items: center; gap: 5px; flex-wrap: wrap; }
        .trend-up { color: var(--secondary); }
        .trend-down { color: var(--danger); }

        /* ============================================
           CHARTS
           ============================================ */
        .charts-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .chart-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .chart-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .chart-title i { margin-right: 8px; }
        .chart-container { position: relative; height: 250px; }

        /* ============================================
           FILTROS
           ============================================ */
        .filters-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .filters-section h5 { margin-bottom: 15px; color: var(--primary); }
        .search-box { position: relative; }

        .search-box input {
            padding-left: 40px;
            color: var(--text);
            border-radius: var(--border-radius);
            border: 1px solid rgba(0,0,0,0.1);
            height: 44px;
            background: var(--bg);
            font-size: 16px;
            width: 100%;
        }

        .search-box input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.25);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }

        .search-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--card-bg);
            border-radius: 0 0 var(--border-radius) var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            z-index: 100;
            max-height: 200px;
            overflow-y: auto;
            display: none;
            border: 1px solid rgba(0,0,0,0.1);
            border-top: none;
        }

        .search-suggestions.show { display: block; animation: fadeIn 0.3s ease; }

        .suggestion-item {
            padding: 12px 15px;
            cursor: pointer;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .suggestion-item:hover { background: rgba(58, 94, 199, 0.05); }
        .suggestion-item i { color: var(--primary); width: 20px; }

        .advanced-filters-toggle {
            background: transparent;
            border: 1px solid rgba(58, 94, 199, 0.3);
            color: var(--primary);
            font-size: 14px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 15px;
            border-radius: 20px;
            margin-top: 15px;
            transition: var(--transition);
            min-height: 44px;
            touch-action: manipulation;
        }

        .advanced-filters-toggle:hover {
            background: rgba(58, 94, 199, 0.1);
            border-color: var(--primary);
        }

        .advanced-filters-content {
            display: none;
            margin-top: 20px;
            padding: 20px;
            background: rgba(58, 94, 199, 0.05);
            border-radius: var(--border-radius);
            border: 1px solid rgba(58, 94, 199, 0.1);
        }

        .advanced-filters-content.show { display: block; animation: fadeIn 0.3s ease; }
        .filter-group { margin-bottom: 20px; }
        .filter-title { font-weight: 600; margin-bottom: 10px; color: var(--primary); font-size: 14px; }
        .filter-tags { display: flex; flex-wrap: wrap; gap: 8px; }

        .filter-tag {
            background: var(--card-bg);
            border: 1px solid rgba(0,0,0,0.1);
            border-radius: 20px;
            padding: 8px 15px;
            font-size: 13px;
            cursor: pointer;
            transition: var(--transition);
            min-height: 38px;
            display: inline-flex;
            align-items: center;
            touch-action: manipulation;
        }

        .filter-tag.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .filter-tag:hover {
            background: rgba(58, 94, 199, 0.1);
            border-color: var(--primary);
        }

        .filter-tag.active:hover { background: var(--primary-dark); }

        /* ============================================
           ACCIONES MASIVAS
           ============================================ */
        .bulk-actions {
            background: var(--primary);
            border-radius: var(--border-radius);
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3);
            display: none;
            color: white;
            animation: slideDown 0.3s ease;
        }

        .bulk-actions.show { display: block; }
        .bulk-actions .btn-outline-primary { background: white; border: none; color: var(--primary) !important; }
        .bulk-actions .btn-outline-primary:hover { background: var(--light); transform: translateY(-2px); }
        .bulk-actions .btn-outline-warning { background: white; border: none; color: var(--warning) !important; }
        .bulk-actions .btn-outline-danger { background: white; border: none; color: var(--danger) !important; }
        .bulk-actions .btn-outline-secondary { background: white; border: none; color: var(--gray) !important; }

        /* ============================================
           TABLA
           ============================================ */
        .users-table {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            background: rgba(58, 94, 199, 0.02);
            flex-wrap: wrap;
            gap: 12px;
        }

        .table-title { font-size: 18px; font-weight: 600; color: var(--primary); display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .table-info { color: var(--gray); font-size: 14px; }
        .table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        table { width: 100%; border-collapse: collapse; }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            color: var(--text);
            white-space: nowrap;
        }

        th {
            font-weight: 600;
            background: rgba(58, 94, 199, 0.05);
            color: var(--primary);
            font-size: 14px;
        }

        tr:hover { background: rgba(58, 94, 199, 0.02); }
        .user-info-cell { display: flex; align-items: center; gap: 10px; }

        .user-avatar-thumb {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--primary);
            flex-shrink: 0;
        }

        .user-tags { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 5px; }

        .user-tag {
            background: #e9ecef;
            border-radius: 12px;
            padding: 2px 8px;
            font-size: 10px;
            color: #495057;
        }

        .tag-admin { background: #ebf8ff; color: #3182ce; }
        .tag-supervisor { background: #f0fff4; color: #38a169; }
        .tag-new { background: #fff5f5; color: #e53e3e; }
        .tag-vip { background: #fff5f0; color: #dd6b20; }

        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
            display: inline-block;
            white-space: nowrap;
        }

        .badge.bg-success { background-color: var(--secondary); }
        .badge.bg-warning { background-color: var(--warning); color: #000; }
        .badge.bg-danger { background-color: var(--danger); }
        .badge.bg-info { background-color: var(--info); }
        .badge.bg-primary { background-color: var(--primary); }
        .badge.bg-secondary { background-color: var(--gray); }
        .badge.bg-dark { background-color: #343a40; }

        .action-btn {
            padding: 6px 10px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            margin-right: 3px;
            margin-bottom: 3px;
            transition: var(--transition);
            color: white;
            font-size: 12px;
            width: 34px;
            height: 34px;
            touch-action: manipulation;
        }

        .btn-view { background: var(--info); }
        .btn-edit { background: var(--primary); }
        .btn-delete { background: var(--danger); }
        .btn-permissions { background: #6f42c1; }
        .btn-email { background: var(--warning); color: #000; }
        .btn-reset { background: var(--secondary); }

        .action-btn:hover { opacity: 0.8; transform: translateY(-2px); }

        /* ============================================
           PAGINACIÓN
           ============================================ */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-top: 1px solid rgba(0,0,0,0.05);
            flex-wrap: wrap;
            gap: 12px;
        }

        .pagination-info { color: var(--gray); font-size: 14px; }
        .pagination { display: flex; gap: 5px; list-style: none; padding: 0; margin: 0; flex-wrap: wrap; }

        .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 40px;
            height: 40px;
            padding: 0 10px;
            border-radius: 8px;
            border: 1px solid rgba(0,0,0,0.1);
            color: var(--text);
            text-decoration: none;
            transition: var(--transition);
            font-size: 14px;
            background: var(--card-bg);
            touch-action: manipulation;
        }

        .page-link:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.active .page-link {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.disabled .page-link { opacity: 0.5; cursor: not-allowed; }

        /* ============================================
           MODALES
           ============================================ */
        .modal-content {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            color: var(--text) !important;
            background-color: var(--card-bg) !important;
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border-top-left-radius: var(--border-radius);
            border-top-right-radius: var(--border-radius);
            padding: 20px;
        }

        .modal-header h5 { color: white; font-size: 16px; }
        .modal-header .btn-close { filter: invert(1); }
        .modal-body { padding: 25px; color: var(--text) !important; }

        .modal-body p,
        .modal-body span,
        .modal-body strong,
        .modal-body div:not(.badge) {
            color: var(--text) !important;
        }

        .modal-footer {
            padding: 20px;
            border-top: 1px solid rgba(0,0,0,0.05);
            flex-wrap: wrap;
            gap: 8px;
        }

        .user-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
            border: 3px solid var(--primary);
            box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3);
        }

        .avatar-upload { position: relative; display: inline-block; }

        .avatar-upload-label {
            position: absolute;
            bottom: 0;
            right: 0;
            background: var(--primary);
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: 2px solid white;
            touch-action: manipulation;
        }

        .permissions-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
            max-height: 300px;
            overflow-y: auto;
            padding: 10px;
            background: rgba(58, 94, 199, 0.05);
            border-radius: var(--border-radius);
            -webkit-overflow-scrolling: touch;
        }

        .permission-item {
            display: flex;
            align-items: center;
            padding: 10px;
            background: var(--card-bg);
            border-radius: 8px;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .permission-item input[type="checkbox"] {
            margin-right: 10px;
            width: 18px;
            height: 18px;
            cursor: pointer;
            flex-shrink: 0;
        }

        .permission-item label { cursor: pointer; font-size: 14px; }

        /* ============================================
           HISTORIAL
           ============================================ */
        .activity-log {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .activity-log h5 { margin-bottom: 15px; color: var(--primary); }

        .activity-item {
            display: flex;
            padding: 12px 0;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: var(--transition);
            gap: 10px;
        }

        .activity-item:hover { background: rgba(58, 94, 199, 0.02); }
        .activity-item:last-child { border-bottom: none; }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }

        .activity-login .activity-icon { background: rgba(40, 167, 69, 0.2); color: var(--secondary); }
        .activity-edit .activity-icon { background: rgba(58, 94, 199, 0.2); color: var(--primary); }
        .activity-create .activity-icon { background: rgba(23, 162, 184, 0.2); color: var(--info); }
        .activity-delete .activity-icon { background: rgba(220, 53, 69, 0.2); color: var(--danger); }
        .activity-permissions .activity-icon { background: rgba(111, 66, 193, 0.2); color: #6f42c1; }
        .activity-email .activity-icon { background: rgba(255, 193, 7, 0.2); color: var(--warning); }

        .activity-info { flex: 1; min-width: 0; }
        .activity-title { font-weight: 600; margin-bottom: 3px; }
        .activity-desc { font-size: 14px; color: var(--gray); margin-bottom: 3px; }
        .activity-time { font-size: 12px; color: var(--gray); }
        .activity-user { font-size: 12px; font-weight: 600; color: var(--primary); }

        /* ============================================
           PASSWORD STRENGTH
           ============================================ */
        .password-strength {
            height: 5px;
            border-radius: 5px;
            margin-top: 8px;
            transition: var(--transition);
            background: #e9ecef;
            overflow: hidden;
        }

        .strength-bar {
            height: 100%;
            width: 0;
            transition: width 0.3s ease;
        }

        .strength-weak .strength-bar { background-color: var(--danger); width: 25%; }
        .strength-medium .strength-bar { background-color: var(--warning); width: 50%; }
        .strength-strong .strength-bar { background-color: var(--secondary); width: 75%; }
        .strength-very-strong .strength-bar { background-color: var(--primary); width: 100%; }

        .password-requirements { font-size: 12px; color: var(--gray); margin-top: 5px; }
        .password-match { font-size: 12px; margin-top: 5px; }
        .match-success { color: var(--secondary); }
        .match-error { color: var(--danger); }

        /* ============================================
           EXPORT OPTIONS
           ============================================ */
        .export-options {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            z-index: 100;
            width: 200px;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .export-options.show { display: block; animation: fadeIn 0.3s ease; }

        .export-option {
            padding: 10px 12px;
            cursor: pointer;
            border-radius: 5px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            min-height: 40px;
            touch-action: manipulation;
        }

        .export-option:hover { background: rgba(58, 94, 199, 0.05); }
        .export-option i { width: 20px; color: var(--primary); }

        /* ============================================
           TOOLTIPS
           ============================================ */
        [data-tooltip] { position: relative; }

        [data-tooltip]:before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 5px 10px;
            background: var(--dark);
            color: white;
            border-radius: 4px;
            font-size: 11px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 1000;
            pointer-events: none;
        }

        [data-tooltip]:hover:before {
            opacity: 1;
            visibility: visible;
            bottom: 120%;
        }

        @media (hover: none) {
            [data-tooltip]:before { display: none; }
        }

        /* ============================================
           TOASTS
           ============================================ */
        .toast-container {
            position: fixed;
            top: calc(20px + var(--safe-top));
            right: calc(20px + var(--safe-right));
            left: 20px;
            z-index: 1100;
            display: flex;
            flex-direction: column;
            gap: 10px;
            pointer-events: none;
            align-items: flex-end;
        }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            padding: 15px 20px;
            display: flex;
            align-items: center;
            animation: slideInRight 0.3s forwards;
            min-width: 280px;
            max-width: 400px;
            border-left: 4px solid var(--primary);
            color: var(--text);
            pointer-events: auto;
        }

        .toast.success { border-left-color: var(--secondary); }
        .toast.error { border-left-color: var(--danger); }
        .toast.warning { border-left-color: var(--warning); }
        .toast.info { border-left-color: var(--primary); }
        .toast i { margin-right: 15px; font-size: 20px; flex-shrink: 0; }
        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        .toast.info i { color: var(--primary); }

        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        /* ============================================
           BOTONES
           ============================================ */
        .btn {
            padding: 11px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            min-height: 44px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            touch-action: manipulation;
        }

        .btn-primary { background: var(--primary); color: white !important; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3); }
        .btn-success { background: var(--secondary); color: white !important; }
        .btn-success:hover { background: #218838; transform: translateY(-2px); }
        .btn-secondary { background: var(--gray); color: white !important; }
        .btn-outline-secondary { border: 1px solid var(--gray); color: var(--text) !important; background: transparent; }
        .btn-outline-secondary:hover { background: var(--gray); color: white !important; }
        .btn-sm { padding: 6px 12px; font-size: 12px; min-height: 36px; }

        /* ============================================
           EMPTY STATE
           ============================================ */
        .empty-state { text-align: center; padding: 40px; color: var(--gray); }
        .empty-state i { font-size: 48px; margin-bottom: 15px; color: var(--gray); }
        .empty-state h4 { margin-bottom: 10px; }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

        /* ============================================
           FORM CONTROLS
           ============================================ */
        .form-control, .form-select {
            color: var(--text) !important;
            background-color: var(--card-bg) !important;
            border: 1px solid rgba(0,0,0,0.1);
            border-radius: 8px;
            padding: 11px 12px;
            font-size: 16px;
            min-height: 44px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.25);
        }

        .form-control::placeholder { color: #999 !important; }
        .form-label { font-size: 13px; font-weight: 500; color: var(--text); }

        /* ============================================
           MENU TOGGLE (BOTÓN HAMBURGUESA)
           ============================================ */
        .menu-toggle {
            display: none;
            position: fixed;
            bottom: calc(20px + var(--safe-bottom));
            right: calc(20px + var(--safe-right));
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            border: none;
            cursor: pointer;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            z-index: 1200;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: var(--transition);
            touch-action: manipulation;
            -webkit-tap-highlight-color: transparent;
        }

        .menu-toggle:hover { transform: scale(1.1); background: var(--primary-dark); }
        .menu-toggle:active { transform: scale(0.92); }

        /* ============================================
           RESPONSIVE - TABLET (≤1200px)
           ============================================ */
        @media (max-width: 1200px) {
            .charts-container { grid-template-columns: 1fr; }
        }

        /* ============================================
           RESPONSIVE - TABLET (≤992px)
           ============================================ */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%) !important;
                width: 88vw;
                max-width: 320px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .sidebar.mobile-open { transform: translateX(0) !important; }
            .sidebar.collapsed { width: 88vw; }
            .sidebar.collapsed .menu-label,
            .sidebar.collapsed .logo span,
            .sidebar.collapsed .sidebar-menu a span,
            .sidebar.collapsed .logout-btn span { display: inline; }
            .sidebar.collapsed .sidebar-menu a { justify-content: flex-start; padding: 12px 16px; }
            .sidebar.collapsed .sidebar-header { justify-content: space-between; }
            .sidebar-close-btn { display: flex !important; }
            .sidebar .sidebar-toggle { display: none; }

            .main-content {
                margin-left: 0 !important;
                padding: 20px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .main-content.expanded { margin-left: 0 !important; }

            .menu-toggle { display: flex !important; }

            .header { flex-direction: column; align-items: stretch; gap: 14px; }
            .controls { justify-content: space-between; width: 100%; }
            .controls .btn-primary { flex: 1; }

            .notification-dropdown {
                position: fixed;
                top: auto;
                bottom: calc(90px + var(--safe-bottom));
                left: 16px;
                right: 16px;
                width: auto;
                max-width: 440px;
                margin: 0 auto;
            }

            .table-header { flex-direction: column; align-items: stretch; }
            .pagination-container { flex-direction: column; align-items: stretch; }
        }

        /* ============================================
           RESPONSIVE - MÓVIL (≤768px)
           ============================================ */
        @media (max-width: 768px) {
            .main-content {
                padding: 16px;
                padding-top: calc(16px + var(--safe-top));
                padding-bottom: calc(90px + var(--safe-bottom));
            }

            .header { padding-bottom: 12px; margin-bottom: 18px; gap: 10px; }
            .page-title { font-size: 17px; }
            .page-title i { font-size: 16px; }
            .theme-switcher, .notifications { width: 40px; height: 40px; font-size: 14px; }

            /* STATS - 2 columnas */
            .stats-container { grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 16px; }
            .stat-card { padding: 14px; border-radius: 10px; flex-direction: column; align-items: flex-start; gap: 8px; }
            .stat-icon { width: 40px; height: 40px; font-size: 18px; margin-right: 0; }
            .stat-value { font-size: 18px; }
            .stat-label { font-size: 11px; }
            .stat-trend { font-size: 10px; }

            /* CHARTS */
            .charts-container { gap: 12px; margin-bottom: 16px; }
            .chart-card { padding: 14px; border-radius: 10px; }
            .chart-title { font-size: 14px; }
            .chart-container { height: 200px; }

            /* ACTIVITY */
            .activity-log { padding: 14px; border-radius: 10px; margin-bottom: 16px; }
            .activity-item { flex-direction: row; }
            .activity-icon { width: 36px; height: 36px; font-size: 14px; }

            /* FILTROS */
            .filters-section { padding: 14px; border-radius: 10px; margin-bottom: 16px; }
            .filter-actions { flex-direction: column; }
            .filter-actions .btn { width: 100%; }
            .advanced-filters-toggle { width: 100%; justify-content: center; }

            /* BULK ACTIONS */
            .bulk-actions { padding: 12px 14px; }
            .bulk-actions .d-flex { flex-direction: column; gap: 10px; align-items: stretch !important; }
            .bulk-actions .d-flex .btn { width: 100%; }

            /* TABLA */
            .users-table { border-radius: 10px; margin-bottom: 16px; }
            .table-header { padding: 14px 16px; }
            .table-title { font-size: 14px; }
            table { min-width: 800px; }
            th, td { padding: 10px 12px; font-size: 12px; }
            th { font-size: 11px; }
            .action-btn { width: 32px; height: 32px; font-size: 11px; margin-right: 2px; }
            .user-avatar-thumb { width: 30px; height: 30px; }

            /* PAGINACIÓN */
            .pagination-container { padding: 14px; }
            .pagination-info { font-size: 12px; text-align: center; width: 100%; }
            .page-link { min-width: 36px; height: 36px; font-size: 12px; }

            /* MODALES - Bottom sheet */
            .modal-dialog { margin: 0; max-width: 100%; align-items: flex-end; min-height: calc(100% - 40px); }
            .modal-content { border-radius: 20px 20px 0 0; max-height: calc(100dvh - 40px); }
            .modal-header { padding: 16px 18px; border-radius: 20px 20px 0 0; }
            .modal-header h5 { font-size: 15px; }
            .modal-body { padding: 20px; max-height: 65vh; overflow-y: auto; }
            .modal-footer { padding: 14px 18px calc(14px + var(--safe-bottom)); flex-direction: column-reverse; }
            .modal-footer .btn { width: 100%; }

            /* Permissions grid */
            .permissions-container { grid-template-columns: 1fr; max-height: 260px; }

            /* TOASTS */
            .toast-container { top: calc(12px + var(--safe-top)); right: 12px; left: 12px; align-items: stretch; }
            .toast { min-width: 0; max-width: 100%; width: 100%; padding: 12px 14px; font-size: 13px; }

            /* Search suggestions */
            .search-suggestions { position: fixed; left: 16px; right: 16px; top: auto; }

            .menu-toggle { width: 48px; height: 48px; font-size: 18px; }
        }

        /* ============================================
           RESPONSIVE - MÓVIL PEQUEÑO (≤380px)
           ============================================ */
        @media (max-width: 380px) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); padding-bottom: calc(80px + var(--safe-bottom)); }
            .page-title { font-size: 15px; }
            .theme-switcher, .notifications { width: 36px; height: 36px; font-size: 13px; }
            .stats-container { grid-template-columns: 1fr; }
            .stat-value { font-size: 16px; }
            .chart-container { height: 180px; }
        }

        /* ============================================
           LANDSCAPE MÓVIL
           ============================================ */
        @media (max-height: 500px) and (orientation: landscape) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); }
            .header { padding: 10px 16px; margin-bottom: 12px; }
            .chart-container { height: 180px; }
            .sidebar { padding: 16px 12px; padding-top: calc(16px + var(--safe-top)); }
            .stats-container { grid-template-columns: repeat(4, 1fr); }
            .modal-content { max-height: 95dvh; }
        }

        /* ============================================
           PANTALLAS GRANDES
           ============================================ */
        @media (min-width: 1440px) {
            .main-content { padding: 30px; }
            .chart-container { height: 300px; }
        }
        @media (min-width: 1920px) {
            .main-content { padding: 40px 60px; max-width: 1800px; margin-left: auto; margin-right: auto; }
        }

        /* ============================================
           TOUCH
           ============================================ */
        @media (hover: none) {
            .stat-card:hover { transform: none; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
            .theme-switcher:hover, .notifications:hover { transform: none; }
            .action-btn:hover { transform: none; opacity: 1; }
            .btn:hover { transform: none; box-shadow: none; }
            .sidebar-menu a:hover { transform: none; background: transparent; }
            .sidebar-menu a.active:hover { background: var(--primary); }
            .page-link:hover { background: var(--card-bg); color: var(--text); border-color: rgba(0,0,0,0.1); }
            .page-item.active .page-link:hover { background: var(--primary); color: white; }
        }

        /* ============================================
           REDUCED MOTION
           ============================================ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        /* ============================================
           PRINT
           ============================================ */
        @media print {
            .sidebar, .header, .menu-toggle, .controls, .filters-section,
            .charts-container, .activity-log, .bulk-actions, .action-btn,
            .pagination-container, .sidebar-overlay { display: none !important; }
            .main-content { margin-left: 0 !important; padding: 0 !important; }
            .stat-card, .users-table { box-shadow: none; border: 1px solid #ddd; page-break-inside: avoid; }
            table { min-width: 0 !important; }
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- OVERLAY MÓVIL -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <!-- SIDEBAR -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-brain"></i></div>
                    <span class="system-name-display">SmartStock AI</span>
                </div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú" type="button">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/principal.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes-stacked"></i> <span>Inventario</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-right-left"></i> <span>Transacciones</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-column"></i> <span>Reportes</span></a></li>
                </ul>

                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/clientes.php"><i class="fas fa-address-book"></i> <span>Clientes</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck-field"></i> <span>Proveedores</span></a></li>
                </ul>

                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/usuarios.php" class="active"><i class="fas fa-users-gear"></i> <span>Usuarios</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-halved"></i> <span>Seguridad</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-circle-user"></i> <span>Mi Perfil</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-sliders"></i> <span>Configuración</span></a></li>
                </ul>
            </div>

            <div class="sidebar-footer">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    <span>Cerrar Sesión</span>
                </button>
            </div>
        </aside>

        <!-- MAIN CONTENT -->
        <div class="main-content" id="mainContent">
            <div class="header">
                <h1 class="page-title">
                    <i class="fas fa-users-cog"></i>
                    Gestión de Usuarios
                </h1>

                <div class="controls">
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notification-container">
                        <div class="notifications" id="notificationBtn">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge" id="notificationBadge">3</span>
                        </div>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-header">
                                <span><i class="fas fa-bell me-2"></i>Notificaciones</span>
                                <button id="markAllRead">Marcar todas</button>
                            </div>
                            <div class="notification-list" id="notificationList"></div>
                            <div class="notification-footer">
                                <a href="#" id="viewAllNotifications">Ver todas las notificaciones</a>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary" id="btnNewUser">
                        <i class="fas fa-user-plus"></i> Nuevo Usuario
                    </button>
                </div>
            </div>

            <div class="stats-container">
                <div class="stat-card stat-users">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-content">
                        <div class="stat-label">Total de Usuarios</div>
                        <div class="stat-value" id="totalUsers">0</div>
                        <div class="stat-trend" id="totalTrend">
                            <i class="fas fa-arrow-up trend-up"></i>
                            <span class="trend-up">+12% este mes</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-active">
                    <div class="stat-icon"><i class="fas fa-user-check"></i></div>
                    <div class="stat-content">
                        <div class="stat-label">Usuarios Activos</div>
                        <div class="stat-value" id="activeUsers">0</div>
                        <div class="stat-trend">
                            <i class="fas fa-circle text-success"></i>
                            <span id="activePercentage">0% del total</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-pending">
                    <div class="stat-icon"><i class="fas fa-user-clock"></i></div>
                    <div class="stat-content">
                        <div class="stat-label">Usuarios Pendientes</div>
                        <div class="stat-value" id="pendingUsers">0</div>
                        <div class="stat-trend" id="pendingTrend">
                            <i class="fas fa-exclamation-triangle text-warning"></i>
                            <span class="text-warning">Requieren activación</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-inactive">
                    <div class="stat-icon"><i class="fas fa-user-slash"></i></div>
                    <div class="stat-content">
                        <div class="stat-label">Usuarios Inactivos</div>
                        <div class="stat-value" id="inactiveUsers">0</div>
                        <div class="stat-trend">
                            <i class="fas fa-clock"></i>
                            <span id="inactiveInfo">Última semana</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="charts-container">
                <div class="chart-card">
                    <div class="chart-title"><i class="fas fa-chart-pie"></i> Distribución por Rol</div>
                    <div class="chart-container"><canvas id="usersByRoleChart"></canvas></div>
                </div>
                <div class="chart-card">
                    <div class="chart-title"><i class="fas fa-chart-line"></i> Actividad de Usuarios (últimos 7 días)</div>
                    <div class="chart-container"><canvas id="userActivityChart"></canvas></div>
                </div>
            </div>

            <div class="activity-log">
                <h5><i class="fas fa-history me-2"></i> Actividad Reciente</h5>
                <div id="activityList"></div>
            </div>

            <div class="bulk-actions" id="bulkActions">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-check-circle me-2"></i>
                        <span id="selectedCount">0 usuarios seleccionados</span>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-sm btn-outline-primary" id="btnBulkActivate" data-tooltip="Activar">
                            <i class="fas fa-check"></i> Activar
                        </button>
                        <button class="btn btn-sm btn-outline-warning" id="btnBulkDeactivate" data-tooltip="Desactivar">
                            <i class="fas fa-ban"></i> Desactivar
                        </button>
                        <button class="btn btn-sm btn-outline-danger" id="btnBulkDelete" data-tooltip="Eliminar">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" id="btnBulkEmail" data-tooltip="Email">
                            <i class="fas fa-envelope"></i> Email
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" id="btnClearSelection">
                            <i class="fas fa-times"></i> Limpiar
                        </button>
                    </div>
                </div>
            </div>

            <div class="filters-section">
                <h5><i class="fas fa-filter me-2"></i>Filtros y Búsqueda</h5>
                <div class="row g-3">
                    <div class="col-md-4 col-12">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" class="form-control" id="searchInput" placeholder="Buscar por nombre, email o ID...">
                            <div class="search-suggestions" id="searchSuggestions"></div>
                        </div>
                    </div>
                    <div class="col-md-2 col-6">
                        <select class="form-select" id="roleFilter">
                            <option value="all">Rol: Todos</option>
                            <option value="Administrador">Administrador</option>
                            <option value="Supervisor">Supervisor</option>
                            <option value="Usuario">Usuario</option>
                            <option value="Invitado">Invitado</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-6">
                        <select class="form-select" id="statusFilter">
                            <option value="all">Estado: Todos</option>
                            <option value="Activo">Activo</option>
                            <option value="Inactivo">Inactivo</option>
                            <option value="Pendiente">Pendiente</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-6" style="position: relative;">
                        <button class="btn btn-outline-secondary w-100" id="btnExport">
                            <i class="fas fa-download"></i> Exportar
                        </button>
                        <div class="export-options" id="exportOptions">
                            <div class="export-option" data-format="csv"><i class="fas fa-file-csv"></i> CSV</div>
                            <div class="export-option" data-format="excel"><i class="fas fa-file-excel"></i> Excel</div>
                            <div class="export-option" data-format="pdf"><i class="fas fa-file-pdf"></i> PDF</div>
                            <div class="export-option" data-format="json"><i class="fas fa-file-code"></i> JSON</div>
                        </div>
                    </div>
                    <div class="col-md-2 col-6">
                        <button class="btn btn-outline-secondary w-100" id="btnRefresh">
                            <i class="fas fa-sync-alt"></i> Actualizar
                        </button>
                    </div>
                </div>

                <button class="advanced-filters-toggle" id="advancedFiltersToggle">
                    <i class="fas fa-sliders-h"></i> Filtros avanzados
                </button>
                <div class="advanced-filters-content" id="advancedFiltersContent">
                    <div class="row g-3">
                        <div class="col-md-4 col-12">
                            <div class="filter-group">
                                <div class="filter-title">Fecha de Registro</div>
                                <div class="row g-2">
                                    <div class="col-6"><input type="date" class="form-control" id="dateFrom"></div>
                                    <div class="col-6"><input type="date" class="form-control" id="dateTo"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-12">
                            <div class="filter-group">
                                <div class="filter-title">Último Acceso</div>
                                <div class="filter-tags" id="lastAccessTags">
                                    <div class="filter-tag" data-value="today">Hoy</div>
                                    <div class="filter-tag" data-value="week">Esta semana</div>
                                    <div class="filter-tag" data-value="month">Este mes</div>
                                    <div class="filter-tag" data-value="never">Nunca</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-12">
                            <div class="filter-group">
                                <div class="filter-title">Etiquetas</div>
                                <div class="filter-tags" id="tagFilters">
                                    <div class="filter-tag" data-value="admin">Administradores</div>
                                    <div class="filter-tag" data-value="supervisor">Supervisores</div>
                                    <div class="filter-tag" data-value="new">Nuevos</div>
                                    <div class="filter-tag" data-value="vip">VIP</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <button class="btn btn-sm btn-primary me-2 mb-2" id="applyAdvancedFilters"><i class="fas fa-check me-1"></i> Aplicar</button>
                            <button class="btn btn-sm btn-outline-secondary mb-2" id="clearAdvancedFilters"><i class="fas fa-times me-1"></i> Limpiar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="users-table">
                <div class="table-header">
                    <h3 class="table-title"><i class="fas fa-list"></i> Lista de Usuarios</h3>
                    <span class="table-info" id="userCount">Mostrando 0 de 0 usuarios</span>
                </div>

                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th width="50"><input type="checkbox" id="selectAllUsers"></th>
                                <th>ID</th>
                                <th>Usuario</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th>Estado</th>
                                <th>Último acceso</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="usersTableBody"></tbody>
                    </table>
                </div>

                <div class="pagination-container">
                    <div class="pagination-info" id="paginationInfo">Mostrando 1-8 de 0 usuarios</div>
                    <ul class="pagination" id="pagination"></ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Usuario -->
    <div class="modal fade" id="userModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle"><i class="fas fa-user-plus me-2"></i> Agregar Nuevo Usuario</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="userForm">
                        <input type="hidden" id="userId">
                        <div class="text-center mb-4">
                            <div class="avatar-upload">
                                <img src="https://ui-avatars.com/api/?name=NU&background=3a5ec7&color=fff&size=100" id="userAvatarPreview" class="user-avatar">
                                <label for="userAvatar" class="avatar-upload-label" data-tooltip="Cambiar avatar">
                                    <i class="fas fa-camera"></i>
                                </label>
                                <input type="file" id="userAvatar" accept="image/*" style="display: none;">
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-md-6 col-12">
                                <label for="userName" class="form-label">Nombre completo</label>
                                <input type="text" class="form-control" id="userName" required placeholder="Ej: Juan Pérez">
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="userEmail" class="form-label">Email</label>
                                <input type="email" class="form-control" id="userEmail" required placeholder="ejemplo@correo.com">
                            </div>
                        </div>

                        <div class="row g-3 mt-1">
                            <div class="col-md-6 col-12">
                                <label for="userPhone" class="form-label">Teléfono</label>
                                <input type="tel" class="form-control" id="userPhone" placeholder="+1234567890">
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="userDepartment" class="form-label">Departamento</label>
                                <select class="form-select" id="userDepartment">
                                    <option value="">Seleccionar</option>
                                    <option value="Ventas">Ventas</option>
                                    <option value="Compras">Compras</option>
                                    <option value="Inventario">Inventario</option>
                                    <option value="Administración">Administración</option>
                                    <option value="IT">IT</option>
                                </select>
                            </div>
                        </div>

                        <div class="row g-3 mt-1">
                            <div class="col-md-6 col-12">
                                <label for="userRole" class="form-label">Rol</label>
                                <select class="form-select" id="userRole" required>
                                    <option value="">Seleccionar rol</option>
                                    <option value="Administrador">Administrador</option>
                                    <option value="Supervisor">Supervisor</option>
                                    <option value="Usuario">Usuario</option>
                                    <option value="Invitado">Invitado</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="userStatus" class="form-label">Estado</label>
                                <select class="form-select" id="userStatus" required>
                                    <option value="Activo">Activo</option>
                                    <option value="Inactivo">Inactivo</option>
                                    <option value="Pendiente">Pendiente</option>
                                </select>
                            </div>
                        </div>

                        <div class="row g-3 mt-1" id="passwordFields">
                            <div class="col-md-6 col-12">
                                <label for="userPassword" class="form-label">Contraseña</label>
                                <input type="password" class="form-control" id="userPassword">
                                <div class="password-strength" id="passwordStrength">
                                    <div class="strength-bar"></div>
                                </div>
                                <div class="password-requirements">Mínimo 8 caracteres, mayúsculas, minúsculas y números</div>
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="userPasswordConfirm" class="form-label">Confirmar contraseña</label>
                                <input type="password" class="form-control" id="userPasswordConfirm">
                                <div class="password-match" id="passwordMatch"></div>
                            </div>
                        </div>

                        <div class="mt-3">
                            <label for="userDescription" class="form-label">Descripción/Notas</label>
                            <textarea class="form-control" id="userDescription" rows="2" placeholder="Información adicional..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times me-1"></i> Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveUser"><i class="fas fa-save me-1"></i> Guardar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Ver Usuario -->
    <div class="modal fade" id="viewUserModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user-circle me-2"></i> Detalles del Usuario</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <img id="viewUserAvatar" src="https://ui-avatars.com/api/?name=AV&background=3a5ec7&color=fff&size=100" alt="Avatar" class="user-avatar">
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6 col-12">
                            <p><strong>ID:</strong> <span id="viewUserId"></span></p>
                            <p><strong>Nombre:</strong> <span id="viewUserName"></span></p>
                            <p><strong>Email:</strong> <span id="viewUserEmail"></span></p>
                            <p><strong>Teléfono:</strong> <span id="viewUserPhone">-</span></p>
                        </div>
                        <div class="col-md-6 col-12">
                            <p><strong>Rol:</strong> <span id="viewUserRole" class="badge"></span></p>
                            <p><strong>Estado:</strong> <span id="viewUserStatus" class="badge"></span></p>
                            <p><strong>Departamento:</strong> <span id="viewUserDepartment">-</span></p>
                            <p><strong>Último acceso:</strong> <span id="viewUserLastAccess"></span></p>
                        </div>
                    </div>

                    <div class="row g-3 mt-2">
                        <div class="col-md-6 col-12">
                            <p><strong>Fecha de registro:</strong> <span id="viewUserRegistration"></span></p>
                        </div>
                        <div class="col-md-6 col-12">
                            <p><strong>IP de registro:</strong> <span id="viewUserIP">192.168.1.1</span></p>
                        </div>
                    </div>

                    <div class="mt-3">
                        <strong>Descripción/Notas:</strong>
                        <p id="viewUserDescription" class="mt-2 p-3 bg-light rounded">Sin descripción</p>
                    </div>

                    <div class="mt-4">
                        <strong><i class="fas fa-key me-2"></i>Permisos:</strong>
                        <div id="viewUserPermissions" class="permissions-container mt-2"></div>
                    </div>

                    <div class="mt-4">
                        <strong><i class="fas fa-history me-2"></i>Actividad reciente:</strong>
                        <div id="viewUserActivity" class="mt-2"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times me-1"></i> Cerrar</button>
                    <button type="button" class="btn btn-primary" id="btnEditFromView"><i class="fas fa-edit me-1"></i> Editar</button>
                    <button type="button" class="btn btn-success" id="btnEmailFromView"><i class="fas fa-envelope me-1"></i> Email</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Permisos -->
    <div class="modal fade" id="permissionsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-key me-2"></i> Gestión de Permisos</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3 mb-3">
                        <div class="col-md-6 col-12"><p><strong>Usuario:</strong> <span id="permissionsUserName"></span></p></div>
                        <div class="col-md-6 col-12"><p><strong>Rol:</strong> <span id="permissionsUserRole"></span></p></div>
                    </div>

                    <h6 class="mb-3">Permisos del usuario:</h6>
                    <div class="permissions-container">
                        <div class="permission-item"><input type="checkbox" id="permInventory"><label for="permInventory">Gestión de Inventario</label></div>
                        <div class="permission-item"><input type="checkbox" id="permUsers"><label for="permUsers">Gestión de Usuarios</label></div>
                        <div class="permission-item"><input type="checkbox" id="permReports"><label for="permReports">Ver Reportes</label></div>
                        <div class="permission-item"><input type="checkbox" id="permSales"><label for="permSales">Gestión de Ventas</label></div>
                        <div class="permission-item"><input type="checkbox" id="permSettings"><label for="permSettings">Configuración</label></div>
                        <div class="permission-item"><input type="checkbox" id="permExport"><label for="permExport">Exportar Datos</label></div>
                        <div class="permission-item"><input type="checkbox" id="permClients"><label for="permClients">Gestión de Clientes</label></div>
                        <div class="permission-item"><input type="checkbox" id="permSuppliers"><label for="permSuppliers">Gestión de Proveedores</label></div>
                        <div class="permission-item"><input type="checkbox" id="permTransactions"><label for="permTransactions">Ver Transacciones</label></div>
                        <div class="permission-item"><input type="checkbox" id="permAudit"><label for="permAudit">Auditoría</label></div>
                    </div>

                    <div class="mt-3">
                        <label class="form-check">
                            <input type="checkbox" class="form-check-input" id="permSelectAll">
                            <span class="form-check-label">Seleccionar todos</span>
                        </label>
                    </div>

                    <div class="alert alert-info mt-3">
                        <i class="fas fa-info-circle me-2"></i>
                        Los permisos heredados del rol no se pueden modificar individualmente.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times me-1"></i> Cancelar</button>
                    <button type="button" class="btn btn-primary" id="savePermissions"><i class="fas fa-save me-1"></i> Guardar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Email -->
    <div class="modal fade" id="emailModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-envelope me-2"></i> Enviar Correo</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="emailUserId">
                    <input type="hidden" id="emailUserEmail">
                    <div class="mb-3">
                        <label for="emailTo" class="form-label">Para</label>
                        <input type="email" class="form-control" id="emailTo" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="emailSubject" class="form-label">Asunto</label>
                        <input type="text" class="form-control" id="emailSubject" value="Notificación de SmartStock AI">
                    </div>
                    <div class="mb-3">
                        <label for="emailMessage" class="form-label">Mensaje</label>
                        <textarea class="form-control" id="emailMessage" rows="5" placeholder="Escribe tu mensaje..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-check">
                            <input type="checkbox" class="form-check-input" id="emailCopyMe">
                            <span class="form-check-label">Enviarme una copia</span>
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times me-1"></i> Cancelar</button>
                    <button type="button" class="btn btn-primary" id="sendEmail"><i class="fas fa-paper-plane me-1"></i> Enviar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Reset Password -->
    <div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-key me-2"></i> Restablecer Contraseña</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="resetUserId">
                    <input type="hidden" id="resetUserEmail">
                    <p>Se enviará un enlace de restablecimiento al correo del usuario.</p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        El usuario recibirá un correo con instrucciones.
                    </div>
                    <div class="mb-3">
                        <label for="resetEmail" class="form-label">Correo del usuario</label>
                        <input type="email" class="form-control" id="resetEmail" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times me-1"></i> Cancelar</button>
                    <button type="button" class="btn btn-primary" id="sendResetLink"><i class="fas fa-paper-plane me-1"></i> Enviar</button>
                </div>
            </div>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle" aria-label="Abrir menú" type="button">
        <i class="fas fa-bars"></i>
    </button>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============================================
        // RESPONSIVE STATE
        // ============================================
        const APP_STATE = {
            isMobile: window.matchMedia('(max-width: 992px)').matches,
            isTouch: ('ontouchstart' in window) || (navigator.maxTouchPoints > 0)
        };

        function openMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.add('mobile-open');
            if (ov) ov.classList.add('active');
            document.body.style.overflow = 'hidden';
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(5);
        }

        function closeMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.remove('mobile-open');
            if (ov) ov.classList.remove('active');
            document.body.style.overflow = '';
        }

        function setupMobileSidebar() {
            const overlay = document.getElementById('sidebarOverlay');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.getElementById('menuToggle');

            console.log('🔍 setupMobileSidebar:');
            console.log('  - overlay:', !!overlay);
            console.log('  - closeBtn:', !!closeBtn);
            console.log('  - sidebar:', !!sidebar);
            console.log('  - menuToggle:', !!menuToggle);

            if (overlay) overlay.addEventListener('click', closeMobileSidebar);
            if (closeBtn) closeBtn.addEventListener('click', closeMobileSidebar);

            if (menuToggle) {
                // Clonar para quitar listeners previos
                const newToggle = menuToggle.cloneNode(true);
                menuToggle.parentNode.replaceChild(newToggle, menuToggle);

                newToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('🍔 Menú clickeado');
                    const sb = document.getElementById('sidebar');
                    if (sb && sb.classList.contains('mobile-open')) {
                        closeMobileSidebar();
                    } else {
                        openMobileSidebar();
                    }
                });
            }

            // Swipe para cerrar
            if (sidebar) {
                let touchStartX = 0, touchCurrentX = 0;
                sidebar.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
                sidebar.addEventListener('touchmove', (e) => {
                    touchCurrentX = e.touches[0].clientX;
                    const diff = touchCurrentX - touchStartX;
                    if (diff < 0 && diff > -100) sidebar.style.transform = `translateX(${diff}px)`;
                }, { passive: true });
                sidebar.addEventListener('touchend', () => {
                    const diff = touchCurrentX - touchStartX;
                    sidebar.style.transform = '';
                    if (diff < -60) closeMobileSidebar();
                    touchStartX = 0; touchCurrentX = 0;
                });
            }

            // Cerrar al navegar
            document.querySelectorAll('.sidebar-menu a').forEach(a => {
                a.addEventListener('click', () => {
                    if (window.matchMedia('(max-width: 992px)').matches) closeMobileSidebar();
                });
            });

            // Cerrar con Escape
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') closeMobileSidebar();
            });

            // Detectar resize
            window.addEventListener('resize', () => {
                if (window.matchMedia('(min-width: 993px)').matches) closeMobileSidebar();
            });
        }

        // ============================================
        // CLASE PARA GESTIONAR USUARIOS (SIN CAMBIOS)
        // ============================================
        class EnhancedUserManager {
            constructor() {
                this.users = JSON.parse(localStorage.getItem('users')) || [];
                this.activityLog = JSON.parse(localStorage.getItem('userActivity')) || [];
                this.notifications = JSON.parse(localStorage.getItem('notifications')) || [];
                this.currentUserId = null;
                this.currentPage = 1;
                this.itemsPerPage = 8;
                this.filteredUsers = [];
                this.selectedUsers = new Set();
                this.activeFilters = {
                    search: '', role: 'all', status: 'all',
                    dateFrom: '', dateTo: '', lastAccess: [], tags: []
                };
                this.charts = {};
                this.initEmailJS();
                if (this.users.length === 0) this.initializeSampleData();
                if (this.activityLog.length === 0) this.initializeSampleActivity();
                if (this.notifications.length === 0) this.initializeNotifications();
            }

            initEmailJS() {
                this.emailJSConfig = {
                    serviceId: 'service_smartstock',
                    templateId: 'template_user_notification',
                    publicKey: 'YOUR_PUBLIC_KEY'
                };
                if (typeof emailjs !== 'undefined') emailjs.init(this.emailJSConfig.publicKey);
            }

            initializeSampleData() {
                const now = new Date();
                this.users = [
                    { id: 'USR-001', name: 'Admin User', email: 'admin@smartstock.com', phone: '+34 612 345 678', department: 'Administración', role: 'Administrador', status: 'Activo', lastAccess: 'Hoy, 09:45', avatar: 'https://ui-avatars.com/api/?name=Admin+User&background=3a5ec7&color=fff&size=100', description: 'Usuario administrador principal', permissions: { inventory: true, users: true, reports: true, sales: true, settings: true, export: true, clients: true, suppliers: true, transactions: true, audit: true }, registrationDate: '2023-01-15', registrationIP: '192.168.1.100', tags: ['admin', 'vip'] },
                    { id: 'USR-002', name: 'María García', email: 'maria.garcia@empresa.com', phone: '+34 623 456 789', department: 'Ventas', role: 'Supervisor', status: 'Activo', lastAccess: 'Ayer, 16:30', avatar: 'https://ui-avatars.com/api/?name=Maria+Garcia&background=28a745&color=fff&size=100', description: 'Supervisora del departamento de ventas', permissions: { inventory: true, users: false, reports: true, sales: true, settings: false, export: true, clients: true, suppliers: false, transactions: true, audit: false }, registrationDate: '2023-03-20', registrationIP: '192.168.1.105', tags: ['supervisor'] },
                    { id: 'USR-003', name: 'Juan Pérez', email: 'juan.perez@empresa.com', phone: '+34 634 567 890', department: 'Compras', role: 'Usuario', status: 'Pendiente', lastAccess: 'Nunca', avatar: 'https://ui-avatars.com/api/?name=Juan+Perez&background=ffc107&color=000&size=100', description: 'Nuevo usuario pendiente', permissions: { inventory: true, users: false, reports: false, sales: false, settings: false, export: false, clients: false, suppliers: true, transactions: false, audit: false }, registrationDate: '2023-06-10', registrationIP: '192.168.1.110', tags: ['new'] },
                    { id: 'USR-004', name: 'Laura Rodríguez', email: 'laura.rodriguez@empresa.com', phone: '+34 645 678 901', department: 'Inventario', role: 'Supervisor', status: 'Activo', lastAccess: 'Hoy, 08:15', avatar: 'https://ui-avatars.com/api/?name=Laura+Rodriguez&background=28a745&color=fff&size=100', description: 'Supervisora de inventario', permissions: { inventory: true, users: false, reports: true, sales: false, settings: false, export: true, clients: false, suppliers: true, transactions: true, audit: false }, registrationDate: '2023-02-28', registrationIP: '192.168.1.115', tags: ['supervisor'] },
                    { id: 'USR-005', name: 'Carlos López', email: 'carlos.lopez@empresa.com', phone: '+34 656 789 012', department: 'Ventas', role: 'Usuario', status: 'Inactivo', lastAccess: '15/05/2023', avatar: 'https://ui-avatars.com/api/?name=Carlos+Lopez&background=6c757d&color=fff&size=100', description: 'Usuario desactivado', permissions: { inventory: true, users: false, reports: false, sales: true, settings: false, export: false, clients: true, suppliers: false, transactions: true, audit: false }, registrationDate: '2023-04-05', registrationIP: '192.168.1.120', tags: [] },
                    { id: 'USR-006', name: 'Ana Martínez', email: 'ana.martinez@empresa.com', phone: '+34 667 890 123', department: 'Compras', role: 'Usuario', status: 'Activo', lastAccess: 'Ayer, 17:45', avatar: 'https://ui-avatars.com/api/?name=Ana+Martinez&background=17a2b8&color=fff&size=100', description: 'Usuario de compras', permissions: { inventory: true, users: false, reports: false, sales: false, settings: false, export: false, clients: false, suppliers: true, transactions: true, audit: false }, registrationDate: '2023-05-12', registrationIP: '192.168.1.125', tags: [] },
                    { id: 'USR-007', name: 'Roberto Sánchez', email: 'roberto.sanchez@empresa.com', phone: '+34 678 901 234', department: 'IT', role: 'Supervisor', status: 'Activo', lastAccess: 'Hoy, 10:20', avatar: 'https://ui-avatars.com/api/?name=Roberto+Sanchez&background=28a745&color=fff&size=100', description: 'Supervisor de IT', permissions: { inventory: true, users: true, reports: true, sales: false, settings: true, export: true, clients: false, suppliers: false, transactions: true, audit: true }, registrationDate: '2023-03-15', registrationIP: '192.168.1.130', tags: ['supervisor', 'vip'] },
                    { id: 'USR-008', name: 'Invitado', email: 'invitado@empresa.com', phone: '', department: '', role: 'Invitado', status: 'Inactivo', lastAccess: '12/05/2023', avatar: 'https://ui-avatars.com/api/?name=Invitado&background=6c757d&color=fff&size=100', description: 'Cuenta de invitado', permissions: { inventory: false, users: false, reports: false, sales: false, settings: false, export: false, clients: false, suppliers: false, transactions: false, audit: false }, registrationDate: '2023-01-10', registrationIP: '192.168.1.135', tags: [] }
                ];
                this.saveUsers();
            }

            initializeSampleActivity() {
                const now = new Date();
                this.activityLog = [
                    { id: 'ACT-001', userId: 'USR-001', type: 'login', title: 'Inicio de sesión', description: 'Admin User inició sesión', timestamp: now.toISOString(), ip: '192.168.1.100' },
                    { id: 'ACT-002', userId: 'USR-002', type: 'edit', title: 'Usuario actualizado', description: 'María García actualizó su perfil', timestamp: new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString(), ip: '192.168.1.105' },
                    { id: 'ACT-003', userId: 'USR-001', type: 'create', title: 'Nuevo usuario', description: 'Juan Pérez fue registrado', timestamp: new Date(now.getTime() - 5 * 60 * 60 * 1000).toISOString(), ip: '192.168.1.100' },
                    { id: 'ACT-004', userId: 'USR-001', type: 'permissions', title: 'Permisos actualizados', description: 'Permisos de Carlos López actualizados', timestamp: new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString(), ip: '192.168.1.100' },
                    { id: 'ACT-005', userId: 'USR-004', type: 'login', title: 'Inicio de sesión', description: 'Laura Rodríguez inició sesión', timestamp: new Date(now.getTime() - 30 * 60 * 1000).toISOString(), ip: '192.168.1.115' }
                ];
                this.saveActivity();
            }

            initializeNotifications() {
                this.notifications = [
                    { id: 1, title: 'Nuevo usuario registrado', message: 'Juan Pérez se ha registrado', time: 'Hace 5 minutos', read: false, type: 'user', userId: 'USR-003' },
                    { id: 2, title: 'Intento de acceso fallido', message: '3 intentos fallidos en admin', time: 'Hace 12 minutos', read: false, type: 'security' },
                    { id: 3, title: 'Actualización de permisos', message: 'Permisos de María García actualizados', time: 'Ayer a las 14:30', read: true, type: 'user', userId: 'USR-002' }
                ];
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
            }

            generateId() {
                const lastId = this.users.length > 0 ? Math.max(...this.users.map(u => parseInt(u.id.split('-')[1]))) : 0;
                return `USR-${String(lastId + 1).padStart(3, '0')}`;
            }
            generateActivityId() {
                const lastId = this.activityLog.length > 0 ? Math.max(...this.activityLog.map(a => parseInt(a.id.split('-')[1]))) : 0;
                return `ACT-${String(lastId + 1).padStart(3, '0')}`;
            }
            getRoleClass(role) {
                return { 'Administrador': 'bg-primary', 'Supervisor': 'bg-info', 'Usuario': 'bg-secondary', 'Invitado': 'bg-dark' }[role] || 'bg-secondary';
            }
            getStatusClass(status) {
                return { 'Activo': 'bg-success', 'Inactivo': 'bg-danger', 'Pendiente': 'bg-warning' }[status] || 'bg-secondary';
            }
            getTagClass(tag) {
                return { 'admin': 'tag-admin', 'supervisor': 'tag-supervisor', 'new': 'tag-new', 'vip': 'tag-vip' }[tag] || '';
            }
            getUnreadNotifications() { return this.notifications.filter(n => !n.read); }
            markAllNotificationsAsRead() { this.notifications.forEach(n => n.read = true); localStorage.setItem('notifications', JSON.stringify(this.notifications)); return this.notifications; }
            markNotificationAsRead(id) { const n = this.notifications.find(n => n.id === id); if (n) { n.read = true; localStorage.setItem('notifications', JSON.stringify(this.notifications)); } }
            addNotification(title, message, type = 'info', userId = null) {
                const newNotification = { id: this.notifications.length + 1, title, message, time: 'Ahora', read: false, type, userId };
                this.notifications.unshift(newNotification);
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
                this.showNotification(message, 'info');
                return newNotification;
            }
            addUser(user) {
                user.id = this.generateId();
                user.lastAccess = 'Nunca';
                user.avatar = user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=3a5ec7&color=fff&size=100`;
                user.registrationDate = new Date().toISOString().split('T')[0];
                user.registrationIP = '192.168.1.' + Math.floor(Math.random() * 255);
                user.tags = user.tags || [];
                user.permissions = this.getDefaultPermissions(user.role);
                this.users.push(user);
                this.saveUsers();
                this.logActivity(user.id, 'create', 'Nuevo usuario', `${user.name} fue registrado`);
                this.addNotification('Nuevo usuario registrado', `${user.name} se ha registrado`, 'user', user.id);
                this.showNotification('Usuario agregado correctamente', 'success');
                return user.id;
            }
            getDefaultPermissions(role) {
                switch(role) {
                    case 'Administrador': return { inventory: true, users: true, reports: true, sales: true, settings: true, export: true, clients: true, suppliers: true, transactions: true, audit: true };
                    case 'Supervisor': return { inventory: true, users: false, reports: true, sales: true, settings: false, export: true, clients: true, suppliers: true, transactions: true, audit: false };
                    case 'Usuario': return { inventory: true, users: false, reports: false, sales: false, settings: false, export: false, clients: false, suppliers: true, transactions: true, audit: false };
                    case 'Invitado': return { inventory: false, users: false, reports: false, sales: false, settings: false, export: false, clients: false, suppliers: false, transactions: false, audit: false };
                    default: return { inventory: false, users: false, reports: false, sales: false, settings: false, export: false, clients: false, suppliers: false, transactions: false, audit: false };
                }
            }
            updateUser(id, updatedUser) {
                const index = this.users.findIndex(u => u.id === id);
                if (index !== -1) {
                    if (!updatedUser.avatar) updatedUser.avatar = this.users[index].avatar;
                    if (!updatedUser.permissions) updatedUser.permissions = this.users[index].permissions;
                    updatedUser.registrationDate = this.users[index].registrationDate;
                    updatedUser.registrationIP = this.users[index].registrationIP;
                    updatedUser.tags = this.users[index].tags || [];
                    this.users[index] = {...updatedUser, id};
                    this.saveUsers();
                    this.logActivity(id, 'edit', 'Usuario actualizado', `${updatedUser.name} fue actualizado`);
                    this.addNotification('Usuario actualizado', `${updatedUser.name} fue actualizado`, 'user', id);
                    this.showNotification('Usuario actualizado correctamente', 'success');
                    return true;
                }
                return false;
            }
            updateUserPermissions(id, permissions) {
                const index = this.users.findIndex(u => u.id === id);
                if (index !== -1) {
                    this.users[index].permissions = permissions;
                    this.saveUsers();
                    this.logActivity(id, 'permissions', 'Permisos actualizados', `Permisos de ${this.users[index].name} actualizados`);
                    this.addNotification('Permisos actualizados', `Permisos de ${this.users[index].name} actualizados`, 'user', id);
                    this.showNotification('Permisos actualizados correctamente', 'success');
                    return true;
                }
                return false;
            }
            deleteUser(id) {
                const index = this.users.findIndex(u => u.id === id);
                if (index !== -1) {
                    const userName = this.users[index].name;
                    this.users.splice(index, 1);
                    this.saveUsers();
                    this.logActivity(id, 'delete', 'Usuario eliminado', `${userName} fue eliminado`);
                    this.addNotification('Usuario eliminado', `${userName} fue eliminado`, 'user', id);
                    this.showNotification('Usuario eliminado correctamente', 'success');
                    return true;
                }
                return false;
            }
            async sendEmail(to, subject, message, copyMe = false) {
                if (typeof emailjs === 'undefined') {
                    this.showNotification('EmailJS no configurado', 'error');
                    this.showEmailPreview(to, subject, message);
                    return false;
                }
                try {
                    this.showNotification('Enviando correo...', 'info');
                    const templateParams = { to_email: to, subject, message, from_name: 'SmartStock AI', reply_to: copyMe ? 'admin@smartstock.com' : '' };
                    const response = await emailjs.send(this.emailJSConfig.serviceId, this.emailJSConfig.templateId, templateParams);
                    if (response.status === 200) {
                        this.showNotification(`Correo enviado a ${to}`, 'success');
                        this.logActivity(null, 'email', 'Correo enviado', `Correo enviado a ${to}`);
                        return true;
                    } else throw new Error('Error');
                } catch (error) {
                    this.showNotification('Error al enviar', 'error');
                    this.showEmailPreview(to, subject, message);
                    return false;
                }
            }
            showEmailPreview(to, subject, message) {
                const w = window.open('', '_blank', 'width=600,height=400');
                w.document.write(`<html><head><title>Preview</title><style>body{font-family:Arial;padding:20px;}.email-container{max-width:600px;margin:0 auto;}.header{background:#3a5ec7;color:white;padding:20px;}.content{padding:20px;border:1px solid #ddd;}.footer{padding:20px;color:#666;}</style></head><body><div class="email-container"><div class="header"><h2>SmartStock AI</h2></div><div class="content"><p><strong>Para:</strong> ${to}</p><p><strong>Asunto:</strong> ${subject}</p><hr><p>${message.replace(/\n/g, '<br>')}</p></div><div class="footer"><p>Correo de respaldo.</p></div></div></body></html>`);
            }
            bulkActivateUsers(userIds) {
                let count = 0;
                userIds.forEach(id => { const u = this.getUserById(id); if (u && u.status !== 'Activo') { u.status = 'Activo'; count++; this.logActivity(id, 'edit', 'Usuario activado', `${u.name} fue activado`); } });
                if (count > 0) { this.saveUsers(); this.showNotification(`${count} usuarios activados`, 'success'); }
                return count;
            }
            bulkDeactivateUsers(userIds) {
                let count = 0;
                userIds.forEach(id => { const u = this.getUserById(id); if (u && u.status === 'Activo') { u.status = 'Inactivo'; count++; this.logActivity(id, 'edit', 'Usuario desactivado', `${u.name} fue desactivado`); } });
                if (count > 0) { this.saveUsers(); this.showNotification(`${count} usuarios desactivados`, 'success'); }
                return count;
            }
            bulkDeleteUsers(userIds) {
                let count = 0;
                userIds.forEach(id => { const u = this.getUserById(id); if (u) { this.deleteUser(id); count++; } });
                if (count > 0) this.showNotification(`${count} usuarios eliminados`, 'success');
                return count;
            }
            bulkSendEmail(userIds, subject, message) {
                const emails = [];
                userIds.forEach(id => { const u = this.getUserById(id); if (u && u.email) emails.push(u.email); });
                if (emails.length > 0) {
                    this.showNotification(`Correo enviado a ${emails.length} usuarios`, 'success');
                    this.logActivity(null, 'email', 'Correo masivo', `Correo a ${emails.length} usuarios`);
                    this.showEmailPreview(emails.join(', '), subject, message);
                }
                return emails.length;
            }
            updateFilters(newFilters) { this.activeFilters = { ...this.activeFilters, ...newFilters }; this.applyFilters(); }
            applyFilters() {
                this.filteredUsers = this.users.filter(user => {
                    const matchesSearch = this.activeFilters.search === '' ||
                                         user.name.toLowerCase().includes(this.activeFilters.search.toLowerCase()) ||
                                         user.email.toLowerCase().includes(this.activeFilters.search.toLowerCase()) ||
                                         user.id.toLowerCase().includes(this.activeFilters.search.toLowerCase()) ||
                                         (user.phone && user.phone.includes(this.activeFilters.search));
                    const matchesRole = this.activeFilters.role === 'all' || user.role === this.activeFilters.role;
                    const matchesStatus = this.activeFilters.status === 'all' || user.status === this.activeFilters.status;
                    const matchesDateFrom = this.activeFilters.dateFrom === '' || user.registrationDate >= this.activeFilters.dateFrom;
                    const matchesDateTo = this.activeFilters.dateTo === '' || user.registrationDate <= this.activeFilters.dateTo;
                    let matchesLastAccess = true;
                    if (this.activeFilters.lastAccess && this.activeFilters.lastAccess.length > 0) {
                        const la = user.lastAccess.toLowerCase();
                        matchesLastAccess = this.activeFilters.lastAccess.some(a => {
                            if (a === 'never') return la === 'nunca';
                            if (a === 'today') return la.includes('hoy');
                            if (a === 'week') return la.includes('ayer') || la.includes('semana');
                            if (a === 'month') return true;
                            return false;
                        });
                    }
                    const matchesTags = this.activeFilters.tags.length === 0 || this.activeFilters.tags.some(tag => user.tags.includes(tag));
                    return matchesSearch && matchesRole && matchesStatus && matchesDateFrom && matchesDateTo && matchesLastAccess && matchesTags;
                });
                return this.filteredUsers;
            }
            generateCharts() { this.generateUsersByRoleChart(); this.generateUserActivityChart(); }
            generateUsersByRoleChart() {
                const ctx = document.getElementById('usersByRoleChart');
                if (!ctx) return;
                const roles = ['Administrador', 'Supervisor', 'Usuario', 'Invitado'];
                const roleCounts = roles.map(role => this.users.filter(u => u.role === role).length);
                if (this.charts.usersByRole) this.charts.usersByRole.destroy();
                this.charts.usersByRole = new Chart(ctx, {
                    type: 'doughnut',
                    data: { labels: roles, datasets: [{ data: roleCounts, backgroundColor: ['rgba(58, 94, 199, 0.7)', 'rgba(23, 162, 184, 0.7)', 'rgba(108, 117, 125, 0.7)', 'rgba(52, 58, 64, 0.7)'], borderColor: ['rgba(58, 94, 199, 1)', 'rgba(23, 162, 184, 1)', 'rgba(108, 117, 125, 1)', 'rgba(52, 58, 64, 1)'], borderWidth: 1 }] },
                    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, cutout: '60%' }
                });
            }
            generateUserActivityChart() {
                const ctx = document.getElementById('userActivityChart');
                if (!ctx) return;
                const labels = [], data = [];
                for (let i = 6; i >= 0; i--) {
                    const date = new Date();
                    date.setDate(date.getDate() - i);
                    const dateStr = date.toISOString().split('T')[0];
                    labels.push(date.toLocaleDateString('es', { weekday: 'short' }));
                    data.push(this.activityLog.filter(a => a.timestamp.split('T')[0] === dateStr).length);
                }
                if (this.charts.userActivity) this.charts.userActivity.destroy();
                this.charts.userActivity = new Chart(ctx, {
                    type: 'line',
                    data: { labels, datasets: [{ label: 'Actividad', data, backgroundColor: 'rgba(58, 94, 199, 0.1)', borderColor: 'rgba(58, 94, 199, 1)', borderWidth: 2, tension: 0.3, fill: true, pointBackgroundColor: 'rgba(58, 94, 199, 1)', pointBorderColor: '#fff', pointBorderWidth: 2, pointRadius: 4 }] },
                    options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 }, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } } }
                });
            }
            logActivity(userId, type, title, description) {
                const activity = { id: this.generateActivityId(), userId, type, title, description, timestamp: new Date().toISOString(), ip: '192.168.1.' + Math.floor(Math.random() * 255) };
                this.activityLog.unshift(activity);
                if (this.activityLog.length > 50) this.activityLog = this.activityLog.slice(0, 50);
                this.saveActivity();
            }
            getRecentActivity(limit = 5) { return this.activityLog.slice(0, limit); }
            getUserActivity(userId, limit = 5) { return this.activityLog.filter(a => a.userId === userId).slice(0, limit); }
            getSearchSuggestions(query) {
                if (query.length < 2) return [];
                const suggestions = [];
                const seen = new Set();
                this.users.forEach(user => {
                    if (user.name.toLowerCase().includes(query.toLowerCase()) && !seen.has(user.name)) { suggestions.push({ text: user.name, icon: 'fa-user', type: 'Nombre' }); seen.add(user.name); }
                    if (user.email.toLowerCase().includes(query.toLowerCase()) && !seen.has(user.email)) { suggestions.push({ text: user.email, icon: 'fa-envelope', type: 'Email' }); seen.add(user.email); }
                    if (user.id.toLowerCase().includes(query.toLowerCase()) && !seen.has(user.id)) { suggestions.push({ text: user.id, icon: 'fa-id-card', type: 'ID' }); seen.add(user.id); }
                    if (user.phone && user.phone.includes(query) && !seen.has(user.phone)) { suggestions.push({ text: user.phone, icon: 'fa-phone', type: 'Teléfono' }); seen.add(user.phone); }
                });
                return suggestions.slice(0, 5);
            }
            exportData(format) {
                let dataToExport = this.filteredUsers.length > 0 ? this.filteredUsers : this.users;
                switch(format) {
                    case 'csv': this.exportToCSV(dataToExport); break;
                    case 'excel': this.exportToExcel(dataToExport); break;
                    case 'pdf': this.exportToPDF(dataToExport); break;
                    case 'json': this.exportToJSON(dataToExport); break;
                }
            }
            exportToCSV(data) {
                const headers = ['ID', 'Nombre', 'Email', 'Teléfono', 'Rol', 'Estado', 'Último Acceso', 'Fecha Registro'];
                const csvRows = [headers.join(',')];
                for (const row of data) csvRows.push([row.id, `"${row.name}"`, `"${row.email}"`, `"${row.phone || ''}"`, row.role, row.status, `"${row.lastAccess}"`, row.registrationDate].join(','));
                const blob = new Blob(['\uFEFF' + csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `usuarios_${new Date().toISOString().split('T')[0]}.csv`;
                a.click();
                URL.revokeObjectURL(url);
                this.showNotification('Datos exportados a CSV', 'success');
            }
            exportToExcel(data) {
                const worksheet = XLSX.utils.json_to_sheet(data.map(u => ({ ID: u.id, Nombre: u.name, Email: u.email, Teléfono: u.phone || '', Rol: u.role, Estado: u.status, 'Último Acceso': u.lastAccess, 'Fecha Registro': u.registrationDate, Departamento: u.department || '' })));
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, 'Usuarios');
                XLSX.writeFile(workbook, `usuarios_${new Date().toISOString().split('T')[0]}.xlsx`);
                this.showNotification('Datos exportados a Excel', 'success');
            }
            exportToPDF(data) {
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();
                doc.setFontSize(20);
                doc.setTextColor(58, 94, 199);
                doc.text('Reporte de Usuarios', 105, 15, { align: 'center' });
                doc.setFontSize(10);
                doc.setTextColor(100, 100, 100);
                doc.text(`Generado el: ${new Date().toLocaleDateString()}`, 105, 22, { align: 'center' });
                const stats = this.getStats();
                doc.setFontSize(12);
                doc.setTextColor(0, 0, 0);
                doc.text(`Total: ${stats.total} | Activos: ${stats.active} | Pendientes: ${stats.pending}`, 20, 35);
                doc.autoTable({
                    startY: 45,
                    head: [['ID', 'Nombre', 'Email', 'Rol', 'Estado']],
                    body: data.map(u => [u.id, u.name, u.email, u.role, u.status]),
                    styles: { fontSize: 8 },
                    headStyles: { fillColor: [58, 94, 199] }
                });
                doc.save(`usuarios_${new Date().toISOString().split('T')[0]}.pdf`);
                this.showNotification('Datos exportados a PDF', 'success');
            }
            exportToJSON(data) {
                const jsonContent = JSON.stringify(data, null, 2);
                const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `usuarios_${new Date().toISOString().split('T')[0]}.json`;
                a.click();
                URL.revokeObjectURL(url);
                this.showNotification('Datos exportados a JSON', 'success');
            }
            getStats() {
                const total = this.users.length;
                const active = this.users.filter(u => u.status === 'Activo').length;
                const pending = this.users.filter(u => u.status === 'Pendiente').length;
                const inactive = this.users.filter(u => u.status === 'Inactivo').length;
                return { total, active, pending, inactive };
            }
            getUserById(id) { return this.users.find(u => u.id === id); }
            getAllUsers() { return this.users; }
            filterUsers(searchTerm = '', role = 'all', status = 'all') { return this.updateFilters({ search: searchTerm, role, status }); }
            getPaginatedUsers(page = 1) { const s = (page - 1) * this.itemsPerPage; return this.filteredUsers.slice(s, s + this.itemsPerPage); }
            getTotalPages() { return Math.ceil(this.filteredUsers.length / this.itemsPerPage); }
            saveUsers() { localStorage.setItem('users', JSON.stringify(this.users)); }
            saveActivity() { localStorage.setItem('userActivity', JSON.stringify(this.activityLog)); }
            showNotification(message, type = 'info') {
                const toastContainer = document.getElementById('toastContainer');
                if (!toastContainer) return;
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'}"></i><span>${message}</span>`;
                toastContainer.appendChild(toast);
                setTimeout(() => {
                    toast.style.animation = 'slideOutRight 0.3s forwards';
                    setTimeout(() => { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 300);
                }, 3000);
            }
        }

        const userManager = new EnhancedUserManager();

        // ============================================
        // FUNCIONES DE RENDERIZADO
        // ============================================
        function renderUsersTable() {
            const tableBody = document.getElementById('usersTableBody');
            if (!tableBody) return;
            tableBody.innerHTML = '';
            const searchTerm = document.getElementById('searchInput').value;
            const role = document.getElementById('roleFilter').value;
            const status = document.getElementById('statusFilter').value;
            userManager.updateFilters({ search: searchTerm, role, status });
            const users = userManager.getPaginatedUsers(userManager.currentPage);
            const totalPages = userManager.getTotalPages();
            document.getElementById('userCount').textContent = `Mostrando ${users.length} de ${userManager.filteredUsers.length} usuarios`;
            document.getElementById('paginationInfo').textContent = `Mostrando ${users.length} de ${userManager.filteredUsers.length} usuarios`;
            updateStats();
            if (users.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="8" class="text-center py-5"><div class="empty-state"><i class="fas fa-users-slash"></i><h4>No se encontraron usuarios</h4><p>Intenta con otros filtros</p><button class="btn btn-primary mt-3" onclick="document.getElementById('btnNewUser').click()"><i class="fas fa-user-plus me-2"></i>Nuevo Usuario</button></div></td></tr>`;
            } else {
                users.forEach(user => {
                    const roleClass = userManager.getRoleClass(user.role);
                    const statusClass = userManager.getStatusClass(user.status);
                    const isSelected = userManager.selectedUsers.has(user.id);
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td><input type="checkbox" class="bulk-checkbox user-checkbox" data-id="${user.id}" ${isSelected ? 'checked' : ''}></td>
                        <td><span class="badge bg-primary">${user.id}</span>${user.tags && user.tags.length > 0 ? `<div class="user-tags mt-1">${user.tags.map(tag => `<span class="user-tag ${userManager.getTagClass(tag)}">${tag}</span>`).join('')}</div>` : ''}</td>
                        <td><div class="user-info-cell"><img src="${user.avatar}" class="user-avatar-thumb" alt="${user.name}"><div><strong>${user.name}</strong>${user.department ? `<div class="text-muted small">${user.department}</div>` : ''}</div></div></td>
                        <td>${user.email}</td>
                        <td><span class="badge ${roleClass}">${user.role}</span></td>
                        <td><span class="badge ${statusClass}">${user.status}</span></td>
                        <td>${user.lastAccess}</td>
                        <td>
                            <button class="action-btn btn-view" data-id="${user.id}" data-tooltip="Ver"><i class="fas fa-eye"></i></button>
                            <button class="action-btn btn-edit" data-id="${user.id}" data-tooltip="Editar"><i class="fas fa-edit"></i></button>
                            <button class="action-btn btn-permissions" data-id="${user.id}" data-tooltip="Permisos"><i class="fas fa-key"></i></button>
                            <button class="action-btn btn-email" data-id="${user.id}" data-tooltip="Email"><i class="fas fa-envelope"></i></button>
                            <button class="action-btn btn-reset" data-id="${user.id}" data-tooltip="Reset"><i class="fas fa-sync-alt"></i></button>
                            <button class="action-btn btn-delete" data-id="${user.id}" data-tooltip="Eliminar"><i class="fas fa-trash"></i></button>
                        </td>`;
                    tableBody.appendChild(row);
                });
            }
            updateBulkActions();
            renderPagination(totalPages);
            addTableEventListeners();
        }

        function renderPagination(totalPages) {
            const pagination = document.getElementById('pagination');
            if (!pagination) return;
            pagination.innerHTML = '';
            if (totalPages <= 1) return;
            const currentPage = userManager.currentPage;
            const prevLi = document.createElement('li');
            prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
            prevLi.innerHTML = `<a class="page-link" href="#"><i class="fas fa-chevron-left"></i></a>`;
            prevLi.addEventListener('click', (e) => { e.preventDefault(); if (currentPage > 1) { userManager.currentPage--; renderUsersTable(); } });
            pagination.appendChild(prevLi);
            const maxVisible = 5;
            let start = Math.max(1, currentPage - Math.floor(maxVisible / 2));
            let end = Math.min(totalPages, start + maxVisible - 1);
            if (end - start + 1 < maxVisible) start = Math.max(1, end - maxVisible + 1);
            for (let i = start; i <= end; i++) {
                const pageLi = document.createElement('li');
                pageLi.className = `page-item ${currentPage === i ? 'active' : ''}`;
                pageLi.innerHTML = `<a class="page-link" href="#">${i}</a>`;
                pageLi.addEventListener('click', (e) => { e.preventDefault(); userManager.currentPage = i; renderUsersTable(); });
                pagination.appendChild(pageLi);
            }
            const nextLi = document.createElement('li');
            nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
            nextLi.innerHTML = `<a class="page-link" href="#"><i class="fas fa-chevron-right"></i></a>`;
            nextLi.addEventListener('click', (e) => { e.preventDefault(); if (currentPage < totalPages) { userManager.currentPage++; renderUsersTable(); } });
            pagination.appendChild(nextLi);
        }

        function updateStats() {
            const stats = userManager.getStats();
            document.getElementById('totalUsers').textContent = stats.total;
            document.getElementById('activeUsers').textContent = stats.active;
            document.getElementById('pendingUsers').textContent = stats.pending;
            document.getElementById('inactiveUsers').textContent = stats.inactive;
            const activePercentage = stats.total > 0 ? Math.round((stats.active / stats.total) * 100) : 0;
            document.getElementById('activePercentage').textContent = `${activePercentage}% del total`;
        }

        function updateBulkActions() {
            const selectedCount = userManager.selectedUsers.size;
            document.getElementById('selectedCount').textContent = `${selectedCount} usuarios seleccionados`;
            if (selectedCount > 0) document.getElementById('bulkActions').classList.add('show');
            else document.getElementById('bulkActions').classList.remove('show');
        }

        function renderRecentActivity() {
            const activityList = document.getElementById('activityList');
            if (!activityList) return;
            activityList.innerHTML = '';
            const activities = userManager.getRecentActivity(5);
            if (activities.length === 0) {
                activityList.innerHTML = '<p class="text-center py-3">No hay actividad reciente</p>';
            } else {
                activities.forEach(activity => {
                    const user = activity.userId ? userManager.getUserById(activity.userId) : null;
                    const userName = user ? user.name : 'Sistema';
                    const timeAgo = getTimeAgo(activity.timestamp);
                    const item = document.createElement('div');
                    item.className = 'activity-item';
                    item.innerHTML = `
                        <div class="activity-icon activity-${activity.type}"><i class="fas ${getActivityIcon(activity.type)}"></i></div>
                        <div class="activity-info">
                            <div class="activity-title">${activity.title}</div>
                            <div class="activity-desc">${activity.description}</div>
                            <div class="d-flex justify-content-between">
                                <span class="activity-user">${userName}</span>
                                <span class="activity-time">${timeAgo}</span>
                            </div>
                        </div>`;
                    activityList.appendChild(item);
                });
            }
        }

        function renderNotifications() {
            const list = document.getElementById('notificationList');
            const badge = document.getElementById('notificationBadge');
            if (!list || !badge) return;
            const unreadCount = userManager.getUnreadNotifications().length;
            badge.textContent = unreadCount;
            badge.classList.toggle('hidden', unreadCount === 0);
            list.innerHTML = '';
            userManager.notifications.slice(0, 5).forEach(notification => {
                const item = document.createElement('div');
                item.className = `notification-item ${notification.read ? '' : 'unread'}`;
                item.dataset.id = notification.id;
                item.innerHTML = `<strong>${notification.title}</strong><p>${notification.message}</p><small>${notification.time}</small>`;
                item.addEventListener('click', () => {
                    userManager.markNotificationAsRead(notification.id);
                    renderNotifications();
                    if (notification.userId) viewUser(notification.userId);
                });
                list.appendChild(item);
            });
        }

        function getActivityIcon(type) {
            return { 'login': 'fa-sign-in-alt', 'create': 'fa-user-plus', 'edit': 'fa-edit', 'delete': 'fa-trash', 'permissions': 'fa-key', 'email': 'fa-envelope' }[type] || 'fa-info-circle';
        }

        function getTimeAgo(timestamp) {
            const now = new Date();
            const time = new Date(timestamp);
            const diffMs = now - time;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMs / 3600000);
            const diffDays = Math.floor(diffMs / 86400000);
            if (diffMins < 1) return 'Hace un momento';
            if (diffMins < 60) return `Hace ${diffMins} min`;
            if (diffHours < 24) return `Hace ${diffHours} h`;
            if (diffDays < 7) return `Hace ${diffDays} d`;
            return time.toLocaleDateString();
        }

        function addTableEventListeners() {
            document.querySelectorAll('.btn-view').forEach(btn => btn.addEventListener('click', function() { viewUser(this.getAttribute('data-id')); }));
            document.querySelectorAll('.btn-edit').forEach(btn => btn.addEventListener('click', function() { openEditModal(this.getAttribute('data-id')); }));
            document.querySelectorAll('.btn-delete').forEach(btn => btn.addEventListener('click', function() { deleteUser(this.getAttribute('data-id')); }));
            document.querySelectorAll('.btn-permissions').forEach(btn => btn.addEventListener('click', function() { openPermissionsModal(this.getAttribute('data-id')); }));
            document.querySelectorAll('.btn-email').forEach(btn => btn.addEventListener('click', function() { openEmailModal(this.getAttribute('data-id')); }));
            document.querySelectorAll('.btn-reset').forEach(btn => btn.addEventListener('click', function() { openResetPasswordModal(this.getAttribute('data-id')); }));
            document.querySelectorAll('.user-checkbox').forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const userId = this.getAttribute('data-id');
                    if (this.checked) userManager.selectedUsers.add(userId);
                    else { userManager.selectedUsers.delete(userId); document.getElementById('selectAllUsers').checked = false; }
                    updateBulkActions();
                });
            });
        }

        function viewUser(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            document.getElementById('viewUserId').textContent = user.id;
            document.getElementById('viewUserName').textContent = user.name;
            document.getElementById('viewUserEmail').textContent = user.email;
            document.getElementById('viewUserPhone').textContent = user.phone || '-';
            document.getElementById('viewUserRole').textContent = user.role;
            document.getElementById('viewUserRole').className = `badge ${userManager.getRoleClass(user.role)}`;
            document.getElementById('viewUserStatus').textContent = user.status;
            document.getElementById('viewUserStatus').className = `badge ${userManager.getStatusClass(user.status)}`;
            document.getElementById('viewUserDepartment').textContent = user.department || '-';
            document.getElementById('viewUserLastAccess').textContent = user.lastAccess;
            document.getElementById('viewUserRegistration').textContent = user.registrationDate || '-';
            document.getElementById('viewUserDescription').textContent = user.description || 'Sin descripción';
            document.getElementById('viewUserAvatar').src = user.avatar;

            const permissionsContainer = document.getElementById('viewUserPermissions');
            permissionsContainer.innerHTML = '';
            const permissionLabels = { inventory: 'Inventario', users: 'Usuarios', reports: 'Reportes', sales: 'Ventas', settings: 'Configuración', export: 'Exportar', clients: 'Clientes', suppliers: 'Proveedores', transactions: 'Transacciones', audit: 'Auditoría' };
            for (const [key, value] of Object.entries(user.permissions)) {
                const item = document.createElement('div');
                item.className = 'permission-item';
                item.innerHTML = `<input type="checkbox" ${value ? 'checked' : ''} disabled><label>${permissionLabels[key] || key}</label>`;
                permissionsContainer.appendChild(item);
            }

            const activityContainer = document.getElementById('viewUserActivity');
            const userActivity = userManager.getUserActivity(userId, 3);
            if (userActivity.length === 0) activityContainer.innerHTML = '<p class="text-muted">Sin actividad reciente</p>';
            else activityContainer.innerHTML = userActivity.map(a => `<div class="d-flex justify-content-between mb-2"><span>${a.title}</span><small class="text-muted">${getTimeAgo(a.timestamp)}</small></div>`).join('');

            document.getElementById('btnEditFromView').onclick = () => { bootstrap.Modal.getInstance(document.getElementById('viewUserModal')).hide(); openEditModal(userId); };
            document.getElementById('btnEmailFromView').onclick = () => { bootstrap.Modal.getInstance(document.getElementById('viewUserModal')).hide(); openEmailModal(userId); };
            new bootstrap.Modal(document.getElementById('viewUserModal')).show();
        }

        function openEditModal(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            document.getElementById('modalTitle').textContent = 'Editar Usuario';
            document.getElementById('userId').value = user.id;
            document.getElementById('userName').value = user.name;
            document.getElementById('userEmail').value = user.email;
            document.getElementById('userPhone').value = user.phone || '';
            document.getElementById('userDepartment').value = user.department || '';
            document.getElementById('userRole').value = user.role;
            document.getElementById('userStatus').value = user.status;
            document.getElementById('userDescription').value = user.description || '';
            document.getElementById('userAvatarPreview').src = user.avatar;
            document.getElementById('passwordFields').style.display = 'none';
            new bootstrap.Modal(document.getElementById('userModal')).show();
        }

        function openPermissionsModal(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            document.getElementById('permissionsUserName').textContent = user.name;
            document.getElementById('permissionsUserRole').textContent = user.role;
            document.getElementById('permInventory').checked = user.permissions.inventory;
            document.getElementById('permUsers').checked = user.permissions.users;
            document.getElementById('permReports').checked = user.permissions.reports;
            document.getElementById('permSales').checked = user.permissions.sales;
            document.getElementById('permSettings').checked = user.permissions.settings;
            document.getElementById('permExport').checked = user.permissions.export;
            document.getElementById('permClients').checked = user.permissions.clients;
            document.getElementById('permSuppliers').checked = user.permissions.suppliers;
            document.getElementById('permTransactions').checked = user.permissions.transactions;
            document.getElementById('permAudit').checked = user.permissions.audit;
            document.getElementById('savePermissions').setAttribute('data-user-id', user.id);
            new bootstrap.Modal(document.getElementById('permissionsModal')).show();
        }

        function openEmailModal(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            document.getElementById('emailUserId').value = user.id;
            document.getElementById('emailUserEmail').value = user.email;
            document.getElementById('emailTo').value = user.email;
            document.getElementById('emailSubject').value = 'Notificación de SmartStock AI';
            document.getElementById('emailMessage').value = '';
            new bootstrap.Modal(document.getElementById('emailModal')).show();
        }

        function openResetPasswordModal(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            document.getElementById('resetUserId').value = user.id;
            document.getElementById('resetUserEmail').value = user.email;
            document.getElementById('resetEmail').value = user.email;
            new bootstrap.Modal(document.getElementById('resetPasswordModal')).show();
        }

        function deleteUser(userId) {
            if (confirm('¿Eliminar este usuario?')) {
                userManager.deleteUser(userId);
                if (userManager.selectedUsers.has(userId)) userManager.selectedUsers.delete(userId);
                renderUsersTable();
                renderRecentActivity();
                renderNotifications();
            }
        }

        function saveUser() {
            const form = document.getElementById('userForm');
            if (!form.checkValidity()) { form.reportValidity(); return; }
            const userId = document.getElementById('userId').value;
            const user = {
                name: document.getElementById('userName').value,
                email: document.getElementById('userEmail').value,
                phone: document.getElementById('userPhone').value,
                department: document.getElementById('userDepartment').value,
                role: document.getElementById('userRole').value,
                status: document.getElementById('userStatus').value,
                description: document.getElementById('userDescription').value,
                avatar: document.getElementById('userAvatarPreview').src
            };
            if (!userId) {
                const password = document.getElementById('userPassword').value;
                const confirm = document.getElementById('userPasswordConfirm').value;
                if (password !== confirm) { userManager.showNotification('Las contraseñas no coinciden', 'error'); return; }
                if (password.length < 8) { userManager.showNotification('Contraseña mínima de 8 caracteres', 'error'); return; }
                user.password = password;
            }
            if (userId) userManager.updateUser(userId, user);
            else userManager.addUser(user);
            bootstrap.Modal.getInstance(document.getElementById('userModal')).hide();
            renderUsersTable();
            renderRecentActivity();
            renderNotifications();
            userManager.generateCharts();
        }

        function savePermissions() {
            const userId = document.getElementById('savePermissions').getAttribute('data-user-id');
            const permissions = {
                inventory: document.getElementById('permInventory').checked,
                users: document.getElementById('permUsers').checked,
                reports: document.getElementById('permReports').checked,
                sales: document.getElementById('permSales').checked,
                settings: document.getElementById('permSettings').checked,
                export: document.getElementById('permExport').checked,
                clients: document.getElementById('permClients').checked,
                suppliers: document.getElementById('permSuppliers').checked,
                transactions: document.getElementById('permTransactions').checked,
                audit: document.getElementById('permAudit').checked
            };
            userManager.updateUserPermissions(userId, permissions);
            bootstrap.Modal.getInstance(document.getElementById('permissionsModal')).hide();
            renderRecentActivity();
            renderNotifications();
        }

        async function sendEmail() {
            const to = document.getElementById('emailTo').value;
            const subject = document.getElementById('emailSubject').value;
            const message = document.getElementById('emailMessage').value;
            const copyMe = document.getElementById('emailCopyMe').checked;
            if (!message) { userManager.showNotification('Escribe un mensaje', 'error'); return; }
            await userManager.sendEmail(to, subject, message, copyMe);
            bootstrap.Modal.getInstance(document.getElementById('emailModal')).hide();
            renderRecentActivity();
        }

        async function sendResetLink() {
            const email = document.getElementById('resetEmail').value;
            const subject = 'Restablecimiento de contraseña - SmartStock AI';
            const message = `Hola,\n\nHas solicitado restablecer tu contraseña. Haz clic aquí:\n\nhttps://smartstock.ai/reset-password?token=ejemplo123\n\nSaludos,\nEquipo SmartStock AI`;
            await userManager.sendEmail(email, subject, message, false);
            bootstrap.Modal.getInstance(document.getElementById('resetPasswordModal')).hide();
            userManager.showNotification('Enlace enviado', 'success');
            renderRecentActivity();
        }

        function clearFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('roleFilter').value = 'all';
            document.getElementById('statusFilter').value = 'all';
            document.getElementById('dateFrom').value = '';
            document.getElementById('dateTo').value = '';
            document.querySelectorAll('.filter-tag.active').forEach(tag => tag.classList.remove('active'));
            userManager.activeFilters = { search: '', role: 'all', status: 'all', dateFrom: '', dateTo: '', lastAccess: [], tags: [] };
            userManager.currentPage = 1;
            renderUsersTable();
        }

        function applyAdvancedFilters() {
            const lastAccess = [], tags = [];
            document.querySelectorAll('#lastAccessTags .filter-tag.active').forEach(tag => lastAccess.push(tag.getAttribute('data-value')));
            document.querySelectorAll('#tagFilters .filter-tag.active').forEach(tag => tags.push(tag.getAttribute('data-value')));
            userManager.updateFilters({ dateFrom: document.getElementById('dateFrom').value, dateTo: document.getElementById('dateTo').value, lastAccess, tags });
            userManager.currentPage = 1;
            renderUsersTable();
            document.getElementById('advancedFiltersContent').classList.remove('show');
        }

        function toggleSidebarSimple() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const icon = document.querySelector('#sidebarToggle i');
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            if (sidebar.classList.contains('collapsed')) icon.className = 'fas fa-chevron-right';
            else icon.className = 'fas fa-chevron-left';
        }

        // ============================================
        // INICIALIZACIÓN
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            }

            // Setup responsive
            setupMobileSidebar();

            renderUsersTable();
            renderRecentActivity();
            renderNotifications();
            userManager.generateCharts();

            document.getElementById('sidebarToggle').addEventListener('click', toggleSidebarSimple);

            document.getElementById('logoutBtn').addEventListener('click', function() {
                if (confirm('¿Cerrar la sesión actual?')) {
                    localStorage.removeItem('currentUser');
                    window.location.href = 'http://localhost/SmartStockAI/login.php';
                }
            });

            document.getElementById('themeToggle').addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
                const icon = this.querySelector('i');
                icon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
                localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
                if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(10);
            });

            document.getElementById('notificationBtn').addEventListener('click', function(e) {
                e.stopPropagation();
                document.getElementById('notificationDropdown').classList.toggle('show');
            });

            document.getElementById('markAllRead').addEventListener('click', function() {
                userManager.markAllNotificationsAsRead();
                renderNotifications();
            });

            document.getElementById('saveUser').addEventListener('click', saveUser);
            document.getElementById('savePermissions').addEventListener('click', savePermissions);
            document.getElementById('sendEmail').addEventListener('click', sendEmail);
            document.getElementById('sendResetLink').addEventListener('click', sendResetLink);

            document.getElementById('btnNewUser').addEventListener('click', function() {
                document.getElementById('modalTitle').textContent = 'Agregar Nuevo Usuario';
                document.getElementById('userForm').reset();
                document.getElementById('userId').value = '';
                document.getElementById('userAvatarPreview').src = 'https://ui-avatars.com/api/?name=NU&background=3a5ec7&color=fff&size=100';
                document.getElementById('passwordFields').style.display = 'flex';
                document.getElementById('passwordStrength').className = 'password-strength';
                document.querySelector('.strength-bar').style.width = '0';
                document.getElementById('passwordMatch').textContent = '';
                new bootstrap.Modal(document.getElementById('userModal')).show();
            });

            document.getElementById('userAvatar').addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) { document.getElementById('userAvatarPreview').src = e.target.result; };
                    reader.readAsDataURL(file);
                }
            });

            document.getElementById('searchInput').addEventListener('input', function() {
                userManager.currentPage = 1;
                renderUsersTable();
            });

            document.getElementById('roleFilter').addEventListener('change', function() { userManager.currentPage = 1; renderUsersTable(); });
            document.getElementById('statusFilter').addEventListener('change', function() { userManager.currentPage = 1; renderUsersTable(); });

            document.getElementById('btnRefresh').addEventListener('click', function() {
                renderUsersTable();
                renderRecentActivity();
                renderNotifications();
                userManager.generateCharts();
                userManager.showNotification('Datos actualizados', 'success');
            });

            document.getElementById('selectAllUsers').addEventListener('change', function() {
                document.querySelectorAll('.user-checkbox').forEach(checkbox => {
                    checkbox.checked = this.checked;
                    const userId = checkbox.getAttribute('data-id');
                    if (this.checked) userManager.selectedUsers.add(userId);
                    else userManager.selectedUsers.delete(userId);
                });
                updateBulkActions();
            });

            document.getElementById('btnBulkActivate').addEventListener('click', function() {
                const userIds = Array.from(userManager.selectedUsers);
                userManager.bulkActivateUsers(userIds);
                userManager.selectedUsers.clear();
                document.getElementById('selectAllUsers').checked = false;
                renderUsersTable();
                renderRecentActivity();
                renderNotifications();
            });

            document.getElementById('btnBulkDeactivate').addEventListener('click', function() {
                const userIds = Array.from(userManager.selectedUsers);
                userManager.bulkDeactivateUsers(userIds);
                userManager.selectedUsers.clear();
                document.getElementById('selectAllUsers').checked = false;
                renderUsersTable();
                renderRecentActivity();
                renderNotifications();
            });

            document.getElementById('btnBulkDelete').addEventListener('click', function() {
                if (confirm(`¿Eliminar ${userManager.selectedUsers.size} usuarios?`)) {
                    const userIds = Array.from(userManager.selectedUsers);
                    userManager.bulkDeleteUsers(userIds);
                    userManager.selectedUsers.clear();
                    document.getElementById('selectAllUsers').checked = false;
                    renderUsersTable();
                    renderRecentActivity();
                    renderNotifications();
                }
            });

            document.getElementById('btnBulkEmail').addEventListener('click', function() {
                const userIds = Array.from(userManager.selectedUsers);
                const subject = prompt('Asunto:', 'Notificación de SmartStock AI');
                if (subject) {
                    const message = prompt('Mensaje:');
                    if (message) userManager.bulkSendEmail(userIds, subject, message);
                }
            });

            document.getElementById('btnClearSelection').addEventListener('click', function() {
                userManager.selectedUsers.clear();
                document.getElementById('selectAllUsers').checked = false;
                renderUsersTable();
            });

            document.getElementById('advancedFiltersToggle').addEventListener('click', function() {
                document.getElementById('advancedFiltersContent').classList.toggle('show');
            });

            document.querySelectorAll('.filter-tag').forEach(tag => {
                tag.addEventListener('click', function() { this.classList.toggle('active'); });
            });

            document.getElementById('applyAdvancedFilters').addEventListener('click', applyAdvancedFilters);
            document.getElementById('clearAdvancedFilters').addEventListener('click', clearFilters);

            document.getElementById('searchInput').addEventListener('input', function() {
                const searchTerm = this.value;
                const suggestions = userManager.getSearchSuggestions(searchTerm);
                const container = document.getElementById('searchSuggestions');
                if (container && suggestions.length > 0 && searchTerm.length >= 2) {
                    container.innerHTML = '';
                    suggestions.forEach(s => {
                        const el = document.createElement('div');
                        el.className = 'suggestion-item';
                        el.innerHTML = `<i class="fas ${s.icon}"></i><span>${s.text}</span><small class="text-muted ms-auto">${s.type}</small>`;
                        el.addEventListener('click', function() {
                            document.getElementById('searchInput').value = s.text;
                            userManager.updateFilters({ search: s.text });
                            container.classList.remove('show');
                            userManager.currentPage = 1;
                            renderUsersTable();
                        });
                        container.appendChild(el);
                    });
                    container.classList.add('show');
                } else if (container) container.classList.remove('show');
            });

            document.getElementById('btnExport').addEventListener('click', function(e) {
                e.stopPropagation();
                document.getElementById('exportOptions').classList.toggle('show');
            });

            document.querySelectorAll('.export-option').forEach(option => {
                option.addEventListener('click', function(e) {
                    e.stopPropagation();
                    userManager.exportData(this.getAttribute('data-format'));
                    document.getElementById('exportOptions').classList.remove('show');
                });
            });

            document.getElementById('userPassword').addEventListener('input', function() {
                const password = this.value;
                const indicator = document.getElementById('passwordStrength');
                let strength = 0;
                if (password.length >= 8) strength++;
                if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
                if (password.match(/\d/)) strength++;
                if (password.match(/[^a-zA-Z\d]/)) strength++;
                indicator.className = 'password-strength';
                if (password.length === 0) document.querySelector('.strength-bar').style.width = '0';
                else if (strength <= 1) indicator.classList.add('strength-weak');
                else if (strength === 2) indicator.classList.add('strength-medium');
                else if (strength === 3) indicator.classList.add('strength-strong');
                else indicator.classList.add('strength-very-strong');

                const confirm = document.getElementById('userPasswordConfirm').value;
                const match = document.getElementById('passwordMatch');
                if (confirm && password !== confirm) { match.textContent = 'No coinciden'; match.className = 'password-match match-error'; }
                else if (confirm) { match.textContent = 'Coinciden'; match.className = 'password-match match-success'; }
                else match.textContent = '';
            });

            document.getElementById('userPasswordConfirm').addEventListener('input', function() {
                const password = document.getElementById('userPassword').value;
                const confirm = this.value;
                const match = document.getElementById('passwordMatch');
                if (password && confirm && password !== confirm) { match.textContent = 'No coinciden'; match.className = 'password-match match-error'; }
                else if (password && confirm) { match.textContent = 'Coinciden'; match.className = 'password-match match-success'; }
                else match.textContent = '';
            });

            document.getElementById('permSelectAll').addEventListener('change', function() {
                document.querySelectorAll('#permissionsModal .permission-item input[type="checkbox"]').forEach(c => { c.checked = this.checked; });
            });

            document.getElementById('viewAllNotifications').addEventListener('click', function(e) {
                e.preventDefault();
                userManager.showNotification('Mostrando todas las notificaciones', 'info');
                document.getElementById('notificationDropdown').classList.remove('show');
            });

            document.addEventListener('click', function(event) {
                const searchInput = document.getElementById('searchInput');
                const searchSuggestions = document.getElementById('searchSuggestions');
                if (searchInput && searchSuggestions && !searchInput.contains(event.target) && !searchSuggestions.contains(event.target)) searchSuggestions.classList.remove('show');
                const btnExport = document.getElementById('btnExport');
                const exportOptions = document.getElementById('exportOptions');
                if (btnExport && exportOptions && !btnExport.contains(event.target) && !exportOptions.contains(event.target)) exportOptions.classList.remove('show');
                const notifBtn = document.getElementById('notificationBtn');
                const notifDropdown = document.getElementById('notificationDropdown');
                if (notifBtn && notifDropdown && !notifBtn.contains(event.target) && !notifDropdown.contains(event.target)) notifDropdown.classList.remove('show');
            });

            setInterval(() => { renderNotifications(); }, 30000);

            console.log('%c✅ SmartStock AI - Usuarios cargado', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (APP_STATE.isMobile ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>