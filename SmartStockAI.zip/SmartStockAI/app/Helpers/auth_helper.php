<?php
// app/Helpers/auth_helper.php
require_once __DIR__ . '/../Controllers/AuthController.php';

function requireAuth() {
    $auth = new AuthController(); // Sin namespace
    $auth->requireAuth();
}

function requireRole($role) {
    $auth = new AuthController(); // Sin namespace
    $auth->requireRole($role);
}

function getCurrentUser() {
    $auth = new AuthController(); // Sin namespace
    return $auth->getCurrentUser();
}

function isLoggedIn() {
    $auth = new AuthController(); // Sin namespace
    return $auth->isLoggedIn();
}
?>