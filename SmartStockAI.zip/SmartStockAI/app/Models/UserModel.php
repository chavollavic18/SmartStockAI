<?php
// app/Models/UserModel.php
// QUITAR: namespace Models;

require_once __DIR__ . '/../Config/Database.php';

class UserModel {
    private $conn;

    public function __construct() {
        $this->conn = Database::getConnection(); // Sin namespace
    }

    public function getUserByUsername($username) {
        $query = "SELECT u.*, r.nombre as rol_nombre 
                  FROM usuarios u 
                  INNER JOIN roles r ON u.rol_id = r.id 
                  WHERE u.username = :username AND u.activo = true";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        return $stmt->fetch();
    }

    public function updateLastAccess($user_id) {
        $query = "UPDATE usuarios SET ultimo_acceso = CURRENT_TIMESTAMP WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $user_id);
        return $stmt->execute();
    }
}
?>