<?php
// app/Config/Database.php
// QUITAR: namespace Config;

class Database {
    public static function getConnection() {
        static $conn = null;
        
        if ($conn === null) {
            $host = 'localhost';
            $dbname = 'smartstock_ai';
            $username = 'postgres';
            $password = 'postgres';
            
            try {
                $conn = new PDO(
                    "pgsql:host=$host;dbname=$dbname", 
                    $username, 
                    $password
                );
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            } catch(PDOException $e) {
                error_log("Error de conexión: " . $e->getMessage());
                throw new Exception("Error al conectar con la base de datos");
            }
        }
        
        return $conn;
    }
}
?>