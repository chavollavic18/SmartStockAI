<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --bg: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            --card-bg: rgba(255, 255, 255, 0.95);
            --text: #2c3e50;
            --border-radius: 16px;
            --transition: all 0.3s ease;
        }

        .dark-mode {
            --bg: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460);
            --card-bg: rgba(26, 30, 42, 0.95);
            --text: #f8f9fa;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: var(--light);
            transition: var(--transition);
        }

        .login-container {
            max-width: 450px;
            width: 100%;
        }

        .login-card {
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            background: var(--card-bg);
            color: var(--text);
            transition: var(--transition);
        }

        .login-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .login-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 60%);
            transform: rotate(30deg);
        }

        .logo {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            position: relative;
            display: inline-block;
        }

        .logo::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 3px;
        }

        .login-body {
            padding: 30px;
        }

        .form-control {
            padding: 14px 16px;
            border-radius: 10px;
            margin-bottom: 18px;
            margin-top: 18px;
            border: 1px solid #e1e5eb;
            transition: var(--transition);
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.2);
            transform: translateY(-2px);
        }

        .btn-login {
            background: var(--primary-dark);
            border: none;
            color: white;
            padding: 14px;
            border-radius: 10px;
            font-weight: 600;
            width: 100%;
            transition: var(--transition);
            margin-top: 8px;
        }

        .btn-login:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 14px rgba(0, 0, 0, 0.2);
            color: white;
            background: var(--primary);
        }

        .input-group-text {
            background-color: white;
            border-right: none;
            padding: 0 16px;
            width: 50px;
            height: 54px;
            margin-top: 18px;
        }

        .input-group .btn {
            background-color: white;
            border-right: none;
            padding: 0 16px;
            width: 50px;
            height: 54px;
            margin-top: 18px;
            border: 1px solid #e1e5eb;
        }

        .input-group .btn:hover {
            background-color: #f8f9fa;
        }

        .additional-options {
            text-align: center;
            margin-top: 22px;
            font-size: 14px;
        }

        .system-info {
            text-align: center;
            margin-top: 28px;
            font-size: 13px;
            color: var(--primary);
        }

        .language-selector, .theme-switcher {
            position: fixed;
            top: 20px;
            z-index: 100;
            display: flex;
            align-items: center;
            background: rgba(255, 255, 255, 0.2);
            padding: 5px 10px;
            border-radius: 20px;
            color: white;
            backdrop-filter: blur(5px);
            transition: var(--transition);
        }

        .language-selector { 
            right: 20px; 
        }
        
        .theme-switcher { 
            left: 20px; 
        }

        .theme-switcher button {
            background: transparent;
            border: none;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
        }

        .theme-switcher button:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(30deg);
        }

        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        .particle {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            animation: float 15s infinite ease-in-out;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0) translateX(0); }
            25% { transform: translateY(-20px) translateX(10px); }
            50% { transform: translateY(-35px) translateX(-15px); }
            75% { transform: translateY(-15px) translateX(15px); }
        }

        .notification-toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: white;
            color: var(--dark);
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            transform: translateY(20px);
            transition: var(--transition);
        }

        .notification-toast.show {
            opacity: 1;
            transform: translateY(0);
        }

        .social-login-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 10px;
            font-weight: 500;
            transition: var(--transition);
        }

        .social-login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .btn-google { 
            background-color: #fff; 
            color: #757575; 
            border: 1px solid #e1e5eb; 
        }
        
        .btn-microsoft { 
            background-color: #0078d4; 
            color: white; 
            border: none; 
        }
        
        .btn-linkedin { 
            background-color: #0077b5; 
            color: white; 
            border: none; 
        }

        .progress {
            height: 8px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .password-strength {
            font-size: 12px;
            margin-top: -10px;
            margin-bottom: 15px;
        }

        .security-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 18px;
            color: var(--gray);
            font-size: 13px;
        }

        .security-badge i {
            margin-right: 8px;
            color: var(--secondary);
        }

        .system-features {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
            text-align: center;
        }

        .feature {
            padding: 10px;
        }

        .feature i {
            font-size: 24px;
            color: var(--primary);
            margin-bottom: 8px;
        }

        .feature p {
            margin: 0;
            font-size: 12px;
            color: var(--gray);
        }

        @media (max-width: 576px) {
            body { padding: 15px; }
            .login-header, .login-body { padding: 20px; }
            .language-selector, .theme-switcher { top: 15px; }
            .language-selector { right: 15px; }
            .theme-switcher { left: 15px; }
            .system-features { flex-direction: column; gap: 15px; }
        }

        .loading {
            display: none;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
            margin-right: 10px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="particles" id="particles"></div>
    
    <div class="theme-switcher">
        <button id="themeToggle"><i class="fas fa-moon"></i></button>
    </div>
    
    <button class="btn btn-help" id="helpButton" style="position: fixed; bottom: 20px; left: 20px; z-index: 100; background: rgba(255,255,255,0.2); border: none; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
        <i class="fas fa-question"></i>
    </button>
    
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="fas fa-robot me-2"></i>SmartStock AI
                </div>
                <p class="mb-0 mt-2">Sistema de Gestión de Inventarios Inteligente</p>
            </div>
            
            <div class="login-body">
                <div class="system-features">
                    <div class="feature">
                        <i class="fas fa-brain"></i>
                        <p>AI Predictiva</p>
                    </div>
                    <div class="feature">
                        <i class="fas fa-bolt"></i>
                        <p>Rápido</p>
                    </div>
                    <div class="feature">
                        <i class="fas fa-shield-alt"></i>
                        <p>Seguro</p>
                    </div>
                </div>
                
                <form id="loginForm">
                    <div class="mb-3">
                        <label for="username" class="form-label">Usuario</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Ingresa tu usuario" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Contraseña</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Ingresa tu contraseña" required>
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="progress mt-2 d-none" id="passwordStrengthBar">
                            <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                        </div>
                        <small class="password-strength text-muted" id="passwordStrengthText"></small>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="rememberMe" name="rememberMe">
                        <label class="form-check-label" for="rememberMe">Recordar mi usuario</label>
                        <a href="#" class="float-end text-decoration-none" id="forgotPassword">¿Olvidaste tu contraseña?</a>
                    </div>
                    
                    <button type="submit" class="btn btn-login mb-3" id="loginButton">
                        <div class="loading" id="loginLoading"></div>
                        <i class="fas fa-sign-in-alt me-2"></i>Iniciar Sesión
                    </button>
                </form>
                
                <div class="additional-options">
                    <p class="mb-2">¿No tienes una cuenta? <a href="#" class="text-decoration-none" id="requestAccess">Solicitar acceso</a></p>
                </div>
                
                <div class="security-badge">
                    <i class="fas fa-shield-alt"></i>
                    <span>Sistema protegido con encriptación SSL</span>
                </div>
            </div>
        </div>
        
        <div class="system-info">
            <p>© 2025 SmartStock AI.</p>
            <p class="mb-0">Último acceso: <span id="lastAccess"></span></p>
        </div>
    </div>
    
    <div class="notification-toast" id="notification">
        <i class="fas fa-check-circle"></i>
        <span id="notification-text">Inicio de sesión exitoso</span>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Función para crear partículas de fondo
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particlesCount = 30;
            
            for (let i = 0; i < particlesCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                const size = Math.random() * 20 + 5;
                const posX = Math.random() * 100;
                const posY = Math.random() * 100;
                const delay = Math.random() * 15;
                
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.left = `${posX}%`;
                particle.style.top = `${posY}%`;
                particle.style.animationDelay = `${delay}s`;
                
                particlesContainer.appendChild(particle);
            }
        }
        
        // Función para mostrar notificación
        function showNotification(message, isSuccess = true) {
            const notification = document.getElementById('notification');
            const notificationText = document.getElementById('notification-text');
            const icon = notification.querySelector('i');
            
            notificationText.textContent = message;
            icon.className = isSuccess ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
            notification.style.borderLeft = isSuccess ? '4px solid var(--secondary)' : '4px solid var(--danger)';
            
            notification.classList.add('show');
            
            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
        }
        
        // Función para cambiar tema
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            const themeIcon = document.querySelector('#themeToggle i');
            themeIcon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
            showNotification(document.body.classList.contains('dark-mode') ? 'Modo oscuro activado' : 'Modo claro activado');
            
            // Guardar preferencia
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }
        
        // Función para evaluar fortaleza de contraseña
        function checkPasswordStrength(password) {
            let strength = 0;
            const bar = document.getElementById('passwordStrengthBar');
            const text = document.getElementById('passwordStrengthText');
            
            if (password.length > 0) {
                bar.classList.remove('d-none');
            } else {
                bar.classList.add('d-none');
                return;
            }
            
            if (password.length >= 8) strength += 20;
            if (/\d/.test(password)) strength += 20;
            if (/[a-z]/.test(password)) strength += 20;
            if (/[A-Z]/.test(password)) strength += 20;
            if (/[^A-Za-z0-9]/.test(password)) strength += 20;
            
            const progressBar = bar.querySelector('.progress-bar');
            progressBar.style.width = `${strength}%`;
            
            if (strength < 40) {
                progressBar.className = 'progress-bar bg-danger';
                text.textContent = 'Contraseña débil';
            } else if (strength < 80) {
                progressBar.className = 'progress-bar bg-warning';
                text.textContent = 'Contraseña media';
            } else {
                progressBar.className = 'progress-bar bg-success';
                text.textContent = 'Contraseña fuerte';
            }
        }
        
        // Función para obtener cookies
        function getCookie(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) return parts.pop().split(';').shift();
        }
        
        // Función para enviar el formulario de login a CodeIgniter
        async function submitLoginForm() {
            try {
                // Mostrar loading
                document.getElementById('loginLoading').style.display = 'inline-block';
                document.getElementById('loginButton').disabled = true;

                // Petición a la ruta de CodeIgniter
                const response = await fetch('login_process', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        username: document.getElementById('username').value,
                        password: document.getElementById('password').value,
                        rememberMe: document.getElementById('rememberMe').checked
                    })
                });

                // Leer como texto para evitar errores de JSON si PHP devuelve HTML
                const textResponse = await response.text();
                
                let result;
                try {
                    result = JSON.parse(textResponse);
                } catch (e) {
                    console.error("Respuesta del servidor:", textResponse);
                    showNotification('Error interno del servidor. Revisa la consola (F12).', false);
                    return;
                }

                if (result.success) {
                    showNotification(result.message);
                    setTimeout(() => {
                        window.location.href = result.redirect;
                    }, 1500);
                } else {
                    showNotification(result.message, false);
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('Error de conexión: ' + error.message, false);
            } finally {
                document.getElementById('loginLoading').style.display = 'none';
                document.getElementById('loginButton').disabled = false;
            }
        }
        
        // Inicialización cuando el DOM está listo
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
            document.getElementById('lastAccess').textContent = new Date().toLocaleString();
            
            // Cargar tema guardado
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            }
            
            // Cargar usuario recordado desde cookies
            const rememberedUser = getCookie('remembered_user');
            if (rememberedUser) {
                document.getElementById('username').value = rememberedUser;
                document.getElementById('rememberMe').checked = true;
            }
            
            // Manejar envío del formulario
            document.getElementById('loginForm').addEventListener('submit', function(e) {
                e.preventDefault();
                
                const username = document.getElementById('username').value;
                const password = document.getElementById('password').value;
                
                if (username === '' || password === '') {
                    showNotification('Por favor, complete todos los campos', false);
                    return;
                }
                
                // Enviar formulario a CodeIgniter
                submitLoginForm();
            });
            
            // Mostrar/ocultar contraseña
            document.getElementById('togglePassword').addEventListener('click', function() {
                const passwordInput = document.getElementById('password');
                const icon = this.querySelector('i');
                
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    icon.className = 'fas fa-eye-slash';
                } else {
                    passwordInput.type = 'password';
                    icon.className = 'fas fa-eye';
                }
            });
            
            // Cambiar tema
            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            
            // Solicitar acceso
            document.getElementById('requestAccess').addEventListener('click', function(e) {
                e.preventDefault();
                showNotification('Solicitud de acceso enviada correctamente');
            });
            
            // Olvidé mi contraseña
            document.getElementById('forgotPassword').addEventListener('click', function(e) {
                e.preventDefault();
                showNotification('Se ha enviado un enlace para restablecer tu contraseña');
            });
            
            // Botón de ayuda
            document.getElementById('helpButton').addEventListener('click', function() {
                showNotification('Centro de ayuda abierto');
            });
            
            // Verificar fortaleza de la contraseña en tiempo real
            document.getElementById('password').addEventListener('input', function() {
                checkPasswordStrength(this.value);
            });
        });
    </script>
</body>
</html>