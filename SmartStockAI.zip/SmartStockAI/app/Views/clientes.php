<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Gestión de Clientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 250px;
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #000000;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #000000;
            transition: var(--transition);
            min-height: 100vh;
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--primary);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: var(--transition);
            border-left: 4px solid transparent;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .sidebar-menu i {
            width: 25px;
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: var(--transition);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: #000000;
        }

        .controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: #000000;
            position: relative;
        }

        .theme-switcher:hover, .notifications:hover {
            transform: translateY(-3px);
        }

        /* Sección de Clientes */
        .clients-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .clients-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .search-box {
            position: relative;
            flex: 1;
            min-width: 300px;
        }

        .search-box input {
            padding-left: 40px;
        }

        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
        }

        .client-filters {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .filter-group {
            min-width: 150px;
        }

        .client-actions {
            display: flex;
            gap: 10px;
        }

        .client-table {
            width: 100%;
            border-collapse: collapse;
        }

        .client-table th, .client-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .client-table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }

        .client-table tr:hover {
            background-color: #f5f5f5;
        }

        .client-status {
            display: inline-flex;
            align-items: center;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-active {
            background-color: #d4edda;
            color: #155724;
        }

        .status-inactive {
            background-color: #f8d7da;
            color: #721c24;
        }

        .client-actions-cell {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            cursor: pointer;
            transition: var(--transition);
        }

        .edit-btn {
            background-color: #e7f1ff;
            color: var(--primary);
        }

        .edit-btn:hover {
            background-color: var(--primary);
            color: white;
        }

        .delete-btn {
            background-color: #fdeaea;
            color: var(--danger);
        }

        .delete-btn:hover {
            background-color: var(--danger);
            color: white;
        }

        .view-btn {
            background-color: #e8f5e8;
            color: var(--secondary);
        }

        .view-btn:hover {
            background-color: var(--secondary);
            color: white;
        }

        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin: 10px 0;
        }

        .stat-title {
            color: var(--gray);
            font-size: 0.9rem;
        }

        .trend-up {
            color: var(--secondary);
        }

        .trend-down {
            color: var(--danger);
        }

        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .pagination-info {
            color: var(--gray);
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: var(--gray);
        }

        /* Modal */
        .modal-content {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .modal-header {
            background-color: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            border-bottom: none;
        }

        .modal-footer {
            border-top: 1px solid #e9ecef;
            border-radius: 0 0 var(--border-radius) var(--border-radius);
        }

        /* Toast de notificaciones */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
        }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s forwards;
            color: #000000;
        }

        .toast.success {
            border-left: 4px solid var(--secondary);
        }

        .toast.error {
            border-left: 4px solid var(--danger);
        }

        .toast.warning {
            border-left: 4px solid var(--warning);
        }

        .toast i {
            margin-right: 10px;
            font-size: 20px;
        }

        .toast.success i {
            color: var(--secondary);
        }

        .toast.error i {
            color: var(--danger);
        }

        .toast.warning i {
            color: var(--warning);
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 0;
            }
            
            .sidebar.open {
                transform: translateX(0);
                width: var(--sidebar-width);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
            }

            .clients-controls {
                flex-direction: column;
                align-items: flex-start;
            }

            .search-box {
                min-width: 100%;
            }

            .client-filters {
                width: 100%;
            }

            .client-actions {
                width: 100%;
                justify-content: flex-end;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .controls {
                margin-top: 15px;
            }
            
            .menu-toggle {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .stats-cards {
                grid-template-columns: 1fr;
            }

            .client-table {
                display: block;
                overflow-x: auto;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px;
            }
            
            .clients-section {
                padding: 15px;
            }
            
            .client-filters {
                flex-direction: column;
                width: 100%;
            }
            
            .filter-group {
                min-width: 100%;
            }
            
            .pagination-container {
                flex-direction: column;
                align-items: center;
            }
        }

        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 1001;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        /* Asegurar que todos los textos sean negros */
        body, body *:not(.sidebar *):not(.modal-header *):not(.action-btn):not(.client-status) {
            color: #000000 !important;
        }

        /* Ajustes para mantener contraste en elementos especiales */
        .sidebar, .modal-header, .action-btn, .client-status {
            color: white !important;
        }

        /* Inputs y selects */
        .form-control, .form-select {
            color: #000000 !important;
            background-color: #ffffff !important;
        }

        .form-control::placeholder {
            color: #666 !important;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot me-2"></i>SmartStock AI
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <li><a href="http://localhost/SmartStockAI/admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes"></i> Inventario</a></li>
                <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck"></i> Proveedores</a></li>
                <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users"></i> Usuarios</a></li>
                <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-exchange-alt"></i> Transacciones</a></li>
                <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-line"></i> Reportes</a></li>
                <li><a href="#" class="active"><i class="fas fa-user-friends"></i> Clientes</a></li>
                <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-user"></i> Mi Perfil</a></li>
                <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-alt"></i> Seguridad</a></li>
                <li><a href="http://localhost/SmartStockAI/login.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a></li>
                <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-cog"></i> Configuración</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1 class="page-title">Gestión de Clientes</h1>
                
                <div class="controls">
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notifications" id="notificationBtn">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge hidden" id="notificationBadge">0</span>
                    </div>
                </div>
            </div>
            
            <!-- Tarjetas de Estadísticas -->
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-title">Total de Clientes</div>
                    <div class="stat-value" id="totalClients">0</div>
                    <div class="stat-subtitle">Registrados en el sistema</div>
                </div>
                <div class="stat-card">
                    <div class="stat-title">Clientes Activos</div>
                    <div class="stat-value" id="activeClients">0</div>
                    <div class="stat-subtitle">Con compras recientes</div>
                </div>
                <div class="stat-card">
                    <div class="stat-title">Nuevos este Mes</div>
                    <div class="stat-value" id="newClients">0</div>
                    <div class="stat-subtitle">Clientes registrados</div>
                </div>
                <div class="stat-card">
                    <div class="stat-title">Valor Promedio</div>
                    <div class="stat-value" id="avgValue">$0</div>
                    <div class="stat-subtitle">Por cliente</div>
                </div>
            </div>
            
            <!-- Sección de Clientes -->
            <div class="clients-section">
                <div class="clients-controls">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" class="form-control" id="searchInput" placeholder="Buscar clientes...">
                    </div>
                    
                    <div class="client-filters">
                        <div class="filter-group">
                            <select class="form-select" id="statusFilter">
                                <option value="all">Todos los estados</option>
                                <option value="active">Activos</option>
                                <option value="inactive">Inactivos</option>
                            </select>
                        </div>
                        <div class="filter-group">
                            <select class="form-select" id="typeFilter">
                                <option value="all">Todos los tipos</option>
                                <option value="individual">Individual</option>
                                <option value="business">Empresa</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="client-actions">
                        <button class="btn btn-primary" id="addClientBtn">
                            <i class="fas fa-plus me-2"></i>Agregar Cliente
                        </button>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="client-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Teléfono</th>
                                <th>Tipo</th>
                                <th>Última Compra</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="clientsTableBody">
                            <!-- Los clientes se cargarán aquí dinámicamente -->
                        </tbody>
                    </table>
                </div>
                
                <div class="empty-state" id="emptyState" style="display: none;">
                    <i class="fas fa-user-friends"></i>
                    <h4>No hay clientes registrados</h4>
                    <p>Agrega tu primer cliente para comenzar</p>
                    <button class="btn btn-primary mt-3" id="addFirstClientBtn">
                        <i class="fas fa-plus me-2"></i>Agregar Primer Cliente
                    </button>
                </div>
                
                <div class="pagination-container">
                    <div class="pagination-info" id="paginationInfo">
                        Mostrando 0 de 0 clientes
                    </div>
                    <nav>
                        <ul class="pagination" id="pagination">
                            <!-- La paginación se generará aquí dinámicamente -->
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para Agregar/Editar Cliente -->
    <div class="modal fade" id="clientModal" tabindex="-1" aria-labelledby="clientModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="clientModalLabel">Agregar Nuevo Cliente</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="clientForm">
                        <input type="hidden" id="clientId">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="clientName" class="form-label">Nombre Completo</label>
                                    <input type="text" class="form-control" id="clientName" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="clientEmail" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="clientEmail" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="clientPhone" class="form-label">Teléfono</label>
                                    <input type="tel" class="form-control" id="clientPhone">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="clientType" class="form-label">Tipo de Cliente</label>
                                    <select class="form-select" id="clientType" required>
                                        <option value="individual">Individual</option>
                                        <option value="business">Empresa</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="businessFields" style="display: none;">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="companyName" class="form-label">Nombre de la Empresa</label>
                                    <input type="text" class="form-control" id="companyName">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="taxId" class="form-label">RFC / Identificación Fiscal</label>
                                    <input type="text" class="form-control" id="taxId">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="clientAddress" class="form-label">Dirección</label>
                                    <textarea class="form-control" id="clientAddress" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="clientCity" class="form-label">Ciudad</label>
                                    <input type="text" class="form-control" id="clientCity">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="clientZip" class="form-label">Código Postal</label>
                                    <input type="text" class="form-control" id="clientZip">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="clientStatus" checked>
                            <label class="form-check-label" for="clientStatus">Cliente Activo</label>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveClientBtn">Guardar Cliente</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para Ver Detalles del Cliente -->
    <div class="modal fade" id="clientDetailsModal" tabindex="-1" aria-labelledby="clientDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="clientDetailsModalLabel">Detalles del Cliente</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Información Personal</h6>
                            <p><strong>Nombre:</strong> <span id="detailName"></span></p>
                            <p><strong>Email:</strong> <span id="detailEmail"></span></p>
                            <p><strong>Teléfono:</strong> <span id="detailPhone"></span></p>
                            <p><strong>Tipo:</strong> <span id="detailType"></span></p>
                            <p><strong>Estado:</strong> <span id="detailStatus"></span></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Información de Contacto</h6>
                            <p><strong>Dirección:</strong> <span id="detailAddress"></span></p>
                            <p><strong>Ciudad:</strong> <span id="detailCity"></span></p>
                            <p><strong>Código Postal:</strong> <span id="detailZip"></span></p>
                            <div id="businessDetails" style="display: none;">
                                <p><strong>Empresa:</strong> <span id="detailCompany"></span></p>
                                <p><strong>RFC:</strong> <span id="detailTaxId"></span></p>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4">
                        <h6>Historial de Compras</h6>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Producto</th>
                                        <th>Cantidad</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody id="purchaseHistory">
                                    <!-- El historial de compras se cargará aquí -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
    
    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Clase para gestionar clientes
        class ClientManager {
            constructor() {
                this.clients = JSON.parse(localStorage.getItem('clients')) || [];
                
                // Inicializar con datos de ejemplo si no hay clientes
                if (this.clients.length === 0) {
                    this.initializeSampleData();
                }
                
                this.currentPage = 1;
                this.itemsPerPage = 10;
                this.filteredClients = [...this.clients];
            }
            
            initializeSampleData() {
                this.clients = [
                    {
                        id: 'CLI-001',
                        name: 'María González',
                        email: 'maria.gonzalez@email.com',
                        phone: '+52 55 1234 5678',
                        type: 'individual',
                        address: 'Av. Reforma 123, Col. Juárez',
                        city: 'Ciudad de México',
                        zipCode: '06600',
                        status: 'active',
                        createdAt: '2023-10-15',
                        lastPurchase: '2023-12-10',
                        totalPurchases: 5,
                        totalValue: 1250.50
                    },
                    {
                        id: 'CLI-002',
                        name: 'Carlos Rodríguez',
                        email: 'carlos.rodriguez@email.com',
                        phone: '+52 55 2345 6789',
                        type: 'individual',
                        address: 'Calle Hidalgo 456, Centro',
                        city: 'Guadalajara',
                        zipCode: '44100',
                        status: 'active',
                        createdAt: '2023-09-20',
                        lastPurchase: '2023-12-05',
                        totalPurchases: 3,
                        totalValue: 850.75
                    },
                    {
                        id: 'CLI-003',
                        name: 'TecnoSoluciones SA de CV',
                        email: 'ventas@tecnosoluciones.com',
                        phone: '+52 55 3456 7890',
                        type: 'business',
                        companyName: 'TecnoSoluciones SA de CV',
                        taxId: 'TSO120304567',
                        address: 'Blvd. Miguel de Cervantes 789, Industrial',
                        city: 'Monterrey',
                        zipCode: '66470',
                        status: 'active',
                        createdAt: '2023-08-05',
                        lastPurchase: '2023-11-28',
                        totalPurchases: 12,
                        totalValue: 4500.25
                    },
                    {
                        id: 'CLI-004',
                        name: 'Ana Martínez',
                        email: 'ana.martinez@email.com',
                        phone: '+52 55 4567 8901',
                        type: 'individual',
                        address: 'Calle Morelos 321, Del Valle',
                        city: 'Puebla',
                        zipCode: '72400',
                        status: 'inactive',
                        createdAt: '2023-07-12',
                        lastPurchase: '2023-09-15',
                        totalPurchases: 2,
                        totalValue: 320.00
                    },
                    {
                        id: 'CLI-005',
                        name: 'Distribuidora Comercial MX',
                        email: 'contacto@distcomercial.mx',
                        phone: '+52 55 5678 9012',
                        type: 'business',
                        companyName: 'Distribuidora Comercial MX',
                        taxId: 'DCM980765432',
                        address: 'Av. Universidad 654, Narvarte',
                        city: 'Ciudad de México',
                        zipCode: '03020',
                        status: 'active',
                        createdAt: '2023-11-01',
                        lastPurchase: '2023-12-12',
                        totalPurchases: 8,
                        totalValue: 2100.80
                    },
                    {
                        id: 'CLI-006',
                        name: 'Roberto Silva',
                        email: 'roberto.silva@email.com',
                        phone: '+52 55 6789 0123',
                        type: 'individual',
                        address: 'Calle 5 de Mayo 987, Centro',
                        city: 'Querétaro',
                        zipCode: '76000',
                        status: 'active',
                        createdAt: '2023-10-28',
                        lastPurchase: '2023-12-08',
                        totalPurchases: 4,
                        totalValue: 980.40
                    },
                    {
                        id: 'CLI-007',
                        name: 'Laura Fernández',
                        email: 'laura.fernandez@email.com',
                        phone: '+52 55 7890 1234',
                        type: 'individual',
                        address: 'Av. Revolución 654, San Pedro',
                        city: 'San Luis Potosí',
                        zipCode: '78230',
                        status: 'inactive',
                        createdAt: '2023-06-18',
                        lastPurchase: '2023-08-22',
                        totalPurchases: 1,
                        totalValue: 150.00
                    },
                    {
                        id: 'CLI-008',
                        name: 'Importaciones del Norte',
                        email: 'info@importacionesnorte.com',
                        phone: '+52 55 8901 2345',
                        type: 'business',
                        companyName: 'Importaciones del Norte SA',
                        taxId: 'IMP450123789',
                        address: 'Blvd. López Mateos 321, Zona Industrial',
                        city: 'Chihuahua',
                        zipCode: '31000',
                        status: 'active',
                        createdAt: '2023-09-30',
                        lastPurchase: '2023-12-01',
                        totalPurchases: 6,
                        totalValue: 3200.60
                    }
                ];
                this.saveClients();
            }
            
            getAllClients() {
                return this.clients;
            }
            
            getClientById(id) {
                return this.clients.find(client => client.id === id);
            }
            
            addClient(clientData) {
                const newClient = {
                    id: 'CLI-' + String(this.clients.length + 1).padStart(3, '0'),
                    ...clientData,
                    createdAt: new Date().toISOString().split('T')[0],
                    lastPurchase: null,
                    totalPurchases: 0,
                    totalValue: 0
                };
                
                this.clients.push(newClient);
                this.saveClients();
                return newClient;
            }
            
            updateClient(id, clientData) {
                const index = this.clients.findIndex(client => client.id === id);
                if (index !== -1) {
                    this.clients[index] = { ...this.clients[index], ...clientData };
                    this.saveClients();
                    return this.clients[index];
                }
                return null;
            }
            
            deleteClient(id) {
                const index = this.clients.findIndex(client => client.id === id);
                if (index !== -1) {
                    this.clients.splice(index, 1);
                    this.saveClients();
                    return true;
                }
                return false;
            }
            
            saveClients() {
                localStorage.setItem('clients', JSON.stringify(this.clients));
            }
            
            filterClients(searchTerm = '', statusFilter = 'all', typeFilter = 'all') {
                this.filteredClients = this.clients.filter(client => {
                    const matchesSearch = searchTerm === '' || 
                        client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        client.phone.includes(searchTerm);
                    
                    const matchesStatus = statusFilter === 'all' || client.status === statusFilter;
                    const matchesType = typeFilter === 'all' || client.type === typeFilter;
                    
                    return matchesSearch && matchesStatus && matchesType;
                });
                
                return this.filteredClients;
            }
            
            getPaginatedClients(page = 1) {
                this.currentPage = page;
                const startIndex = (page - 1) * this.itemsPerPage;
                const endIndex = startIndex + this.itemsPerPage;
                return this.filteredClients.slice(startIndex, endIndex);
            }
            
            getTotalPages() {
                return Math.ceil(this.filteredClients.length / this.itemsPerPage);
            }
            
            getStats() {
                const totalClients = this.clients.length;
                const activeClients = this.clients.filter(client => client.status === 'active').length;
                
                // Clientes nuevos este mes
                const currentMonth = new Date().getMonth();
                const currentYear = new Date().getFullYear();
                const newClients = this.clients.filter(client => {
                    const clientDate = new Date(client.createdAt);
                    return clientDate.getMonth() === currentMonth && clientDate.getFullYear() === currentYear;
                }).length;
                
                // Valor promedio por cliente
                const totalValue = this.clients.reduce((sum, client) => sum + client.totalValue, 0);
                const avgValue = totalClients > 0 ? totalValue / totalClients : 0;
                
                return {
                    totalClients,
                    activeClients,
                    newClients,
                    avgValue
                };
            }
            
            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
                    <span>${message}</span>
                `;
                
                document.getElementById('toastContainer').appendChild(toast);
                
                setTimeout(() => {
                    toast.style.animation = 'slideOut 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }
        }

        // Instancia global del administrador de clientes
        const clientManager = new ClientManager();

        // Función para renderizar la tabla de clientes
        function renderClientsTable() {
            const tableBody = document.getElementById('clientsTableBody');
            const emptyState = document.getElementById('emptyState');
            const paginationInfo = document.getElementById('paginationInfo');
            
            const clients = clientManager.getPaginatedClients(clientManager.currentPage);
            const totalClients = clientManager.filteredClients.length;
            const totalPages = clientManager.getTotalPages();
            
            if (clients.length === 0) {
                tableBody.innerHTML = '';
                emptyState.style.display = 'block';
                paginationInfo.textContent = 'Mostrando 0 de 0 clientes';
                return;
            }
            
            emptyState.style.display = 'none';
            
            let html = '';
            clients.forEach(client => {
                const statusClass = client.status === 'active' ? 'status-active' : 'status-inactive';
                const statusText = client.status === 'active' ? 'Activo' : 'Inactivo';
                const typeText = client.type === 'individual' ? 'Individual' : 'Empresa';
                
                html += `
                    <tr>
                        <td>${client.id}</td>
                        <td>${client.name}</td>
                        <td>${client.email}</td>
                        <td>${client.phone}</td>
                        <td>${typeText}</td>
                        <td>${client.lastPurchase ? new Date(client.lastPurchase).toLocaleDateString() : 'Nunca'}</td>
                        <td><span class="client-status ${statusClass}">${statusText}</span></td>
                        <td>
                            <div class="client-actions-cell">
                                <button class="action-btn view-btn" data-id="${client.id}" title="Ver detalles">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="action-btn edit-btn" data-id="${client.id}" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="action-btn delete-btn" data-id="${client.id}" title="Eliminar">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });
            
            tableBody.innerHTML = html;
            
            // Actualizar información de paginación
            const startItem = (clientManager.currentPage - 1) * clientManager.itemsPerPage + 1;
            const endItem = Math.min(startItem + clientManager.itemsPerPage - 1, totalClients);
            paginationInfo.textContent = `Mostrando ${startItem}-${endItem} de ${totalClients} clientes`;
            
            // Renderizar paginación
            renderPagination(totalPages);
            
            // Agregar event listeners a los botones de acción
            document.querySelectorAll('.view-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const clientId = this.getAttribute('data-id');
                    viewClientDetails(clientId);
                });
            });
            
            document.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const clientId = this.getAttribute('data-id');
                    editClient(clientId);
                });
            });
            
            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const clientId = this.getAttribute('data-id');
                    deleteClient(clientId);
                });
            });
        }
        
        // Función para renderizar la paginación
        function renderPagination(totalPages) {
            const pagination = document.getElementById('pagination');
            const currentPage = clientManager.currentPage;
            
            let html = '';
            
            // Botón anterior
            html += `
                <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                    <a class="page-link" href="#" data-page="${currentPage - 1}">Anterior</a>
                </li>
            `;
            
            // Páginas
            for (let i = 1; i <= totalPages; i++) {
                if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                    html += `
                        <li class="page-item ${i === currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${i}">${i}</a>
                        </li>
                    `;
                } else if (i === currentPage - 2 || i === currentPage + 2) {
                    html += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
                }
            }
            
            // Botón siguiente
            html += `
                <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                    <a class="page-link" href="#" data-page="${currentPage + 1}">Siguiente</a>
                </li>
            `;
            
            pagination.innerHTML = html;
            
            // Agregar event listeners a los enlaces de paginación
            document.querySelectorAll('.page-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const page = parseInt(this.getAttribute('data-page'));
                    if (!isNaN(page)) {
                        clientManager.currentPage = page;
                        renderClientsTable();
                        updateStats();
                    }
                });
            });
        }
        
        // Función para actualizar las estadísticas
        function updateStats() {
            const stats = clientManager.getStats();
            
            document.getElementById('totalClients').textContent = stats.totalClients;
            document.getElementById('activeClients').textContent = stats.activeClients;
            document.getElementById('newClients').textContent = stats.newClients;
            document.getElementById('avgValue').textContent = `$${stats.avgValue.toFixed(2)}`;
        }
        
        // Función para ver detalles del cliente
        function viewClientDetails(clientId) {
            const client = clientManager.getClientById(clientId);
            if (!client) return;
            
            // Llenar los detalles en el modal
            document.getElementById('detailName').textContent = client.name;
            document.getElementById('detailEmail').textContent = client.email;
            document.getElementById('detailPhone').textContent = client.phone;
            document.getElementById('detailType').textContent = client.type === 'individual' ? 'Individual' : 'Empresa';
            document.getElementById('detailStatus').textContent = client.status === 'active' ? 'Activo' : 'Inactivo';
            document.getElementById('detailAddress').textContent = client.address || 'No especificada';
            document.getElementById('detailCity').textContent = client.city || 'No especificada';
            document.getElementById('detailZip').textContent = client.zipCode || 'No especificado';
            
            // Mostrar información de empresa si es aplicable
            const businessDetails = document.getElementById('businessDetails');
            if (client.type === 'business') {
                document.getElementById('detailCompany').textContent = client.companyName || 'No especificada';
                document.getElementById('detailTaxId').textContent = client.taxId || 'No especificado';
                businessDetails.style.display = 'block';
            } else {
                businessDetails.style.display = 'none';
            }
            
            // Generar historial de compras simulado
            const purchaseHistory = document.getElementById('purchaseHistory');
            let historyHtml = '';
            
            if (client.totalPurchases > 0) {
                // Generar compras simuladas
                const products = ['Laptop HP', 'Smartphone Samsung', 'Tablet Android', 'Monitor LG', 'Auriculares Bluetooth'];
                for (let i = 0; i < Math.min(5, client.totalPurchases); i++) {
                    const daysAgo = Math.floor(Math.random() * 30) + 1;
                    const purchaseDate = new Date();
                    purchaseDate.setDate(purchaseDate.getDate() - daysAgo);
                    
                    const product = products[Math.floor(Math.random() * products.length)];
                    const quantity = Math.floor(Math.random() * 3) + 1;
                    const price = (Math.random() * 500 + 100).toFixed(2);
                    const total = (quantity * price).toFixed(2);
                    
                    historyHtml += `
                        <tr>
                            <td>${purchaseDate.toLocaleDateString()}</td>
                            <td>${product}</td>
                            <td>${quantity}</td>
                            <td>$${total}</td>
                        </tr>
                    `;
                }
            } else {
                historyHtml = '<tr><td colspan="4" class="text-center">No hay historial de compras</td></tr>';
            }
            
            purchaseHistory.innerHTML = historyHtml;
            
            // Mostrar el modal
            const modal = new bootstrap.Modal(document.getElementById('clientDetailsModal'));
            modal.show();
        }
        
        // Función para editar cliente
        function editClient(clientId) {
            const client = clientManager.getClientById(clientId);
            if (!client) return;
            
            // Llenar el formulario con los datos del cliente
            document.getElementById('clientId').value = client.id;
            document.getElementById('clientName').value = client.name;
            document.getElementById('clientEmail').value = client.email;
            document.getElementById('clientPhone').value = client.phone || '';
            document.getElementById('clientType').value = client.type;
            document.getElementById('clientAddress').value = client.address || '';
            document.getElementById('clientCity').value = client.city || '';
            document.getElementById('clientZip').value = client.zipCode || '';
            document.getElementById('clientStatus').checked = client.status === 'active';
            
            // Mostrar campos de empresa si es aplicable
            toggleBusinessFields(client.type);
            
            if (client.type === 'business') {
                document.getElementById('companyName').value = client.companyName || '';
                document.getElementById('taxId').value = client.taxId || '';
            }
            
            // Cambiar el título del modal
            document.getElementById('clientModalLabel').textContent = 'Editar Cliente';
            
            // Mostrar el modal
            const modal = new bootstrap.Modal(document.getElementById('clientModal'));
            modal.show();
        }
        
        // Función para eliminar cliente
        function deleteClient(clientId) {
            const client = clientManager.getClientById(clientId);
            if (!client) return;
            
            if (confirm(`¿Estás seguro de que deseas eliminar al cliente "${client.name}"?`)) {
                if (clientManager.deleteClient(clientId)) {
                    clientManager.showNotification('Cliente eliminado correctamente', 'success');
                    applyFilters();
                    updateStats();
                } else {
                    clientManager.showNotification('Error al eliminar el cliente', 'error');
                }
            }
        }
        
        // Función para aplicar filtros
        function applyFilters() {
            const searchTerm = document.getElementById('searchInput').value;
            const statusFilter = document.getElementById('statusFilter').value;
            const typeFilter = document.getElementById('typeFilter').value;
            
            clientManager.filterClients(searchTerm, statusFilter, typeFilter);
            clientManager.currentPage = 1;
            renderClientsTable();
        }
        
        // Función para alternar campos de empresa
        function toggleBusinessFields(clientType) {
            const businessFields = document.getElementById('businessFields');
            if (clientType === 'business') {
                businessFields.style.display = 'flex';
            } else {
                businessFields.style.display = 'none';
            }
        }
        
        // Función para cambiar tema
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            const themeIcon = document.querySelector('#themeToggle i');
            themeIcon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
            
            // Guardar preferencia
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }
        
        // Función para toggle del menú en móviles
        function toggleMenu() {
            document.getElementById('sidebar').classList.toggle('open');
        }
        
        // Inicialización cuando el DOM está listo
        document.addEventListener('DOMContentLoaded', function() {
            // Cargar tema guardado
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            }
            
            // Renderizar tabla de clientes
            renderClientsTable();
            
            // Actualizar estadísticas
            updateStats();
            
            // Event listeners
            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            document.getElementById('menuToggle').addEventListener('click', toggleMenu);
            
            // Búsqueda y filtros
            document.getElementById('searchInput').addEventListener('input', applyFilters);
            document.getElementById('statusFilter').addEventListener('change', applyFilters);
            document.getElementById('typeFilter').addEventListener('change', applyFilters);
            
            // Agregar cliente
            document.getElementById('addClientBtn').addEventListener('click', function() {
                // Limpiar el formulario
                document.getElementById('clientForm').reset();
                document.getElementById('clientId').value = '';
                document.getElementById('clientModalLabel').textContent = 'Agregar Nuevo Cliente';
                document.getElementById('businessFields').style.display = 'none';
                
                const modal = new bootstrap.Modal(document.getElementById('clientModal'));
                modal.show();
            });
            
            document.getElementById('addFirstClientBtn').addEventListener('click', function() {
                document.getElementById('clientForm').reset();
                document.getElementById('clientId').value = '';
                document.getElementById('clientModalLabel').textContent = 'Agregar Nuevo Cliente';
                document.getElementById('businessFields').style.display = 'none';
                
                const modal = new bootstrap.Modal(document.getElementById('clientModal'));
                modal.show();
            });
            
            // Cambiar tipo de cliente
            document.getElementById('clientType').addEventListener('change', function() {
                toggleBusinessFields(this.value);
            });
            
            // Guardar cliente
            document.getElementById('saveClientBtn').addEventListener('click', function() {
                const clientId = document.getElementById('clientId').value;
                const clientData = {
                    name: document.getElementById('clientName').value,
                    email: document.getElementById('clientEmail').value,
                    phone: document.getElementById('clientPhone').value,
                    type: document.getElementById('clientType').value,
                    address: document.getElementById('clientAddress').value,
                    city: document.getElementById('clientCity').value,
                    zipCode: document.getElementById('clientZip').value,
                    status: document.getElementById('clientStatus').checked ? 'active' : 'inactive'
                };
                
                // Agregar campos de empresa si es aplicable
                if (clientData.type === 'business') {
                    clientData.companyName = document.getElementById('companyName').value;
                    clientData.taxId = document.getElementById('taxId').value;
                }
                
                if (clientId) {
                    // Actualizar cliente existente
                    if (clientManager.updateClient(clientId, clientData)) {
                        clientManager.showNotification('Cliente actualizado correctamente', 'success');
                    } else {
                        clientManager.showNotification('Error al actualizar el cliente', 'error');
                    }
                } else {
                    // Agregar nuevo cliente
                    clientManager.addClient(clientData);
                    clientManager.showNotification('Cliente agregado correctamente', 'success');
                }
                
                // Cerrar modal y actualizar tabla
                bootstrap.Modal.getInstance(document.getElementById('clientModal')).hide();
                applyFilters();
                updateStats();
            });
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>