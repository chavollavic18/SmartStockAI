<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Transacciones y Pedidos Inteligentes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Chart.js para gráficos -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- jsPDF para exportar PDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <!-- SheetJS para Excel -->
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 250px;
            --primary-rgb: 58, 94, 199;
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #000000;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #000000;
            transition: var(--transition);
            min-height: 100vh;
        }

        /* Scrollbar personalizado */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--primary);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary-dark);
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar mejorado */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: var(--transition);
            border-left: 4px solid transparent;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .sidebar-menu i {
            width: 25px;
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: var(--transition);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: #000000;
        }

        .page-title i {
            color: var(--primary);
            margin-right: 10px;
        }

        .controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: #000000;
            position: relative;
        }

        .theme-switcher:hover, .notifications:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        /* Badge de notificaciones */
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        .notification-badge.hidden {
            display: none;
        }

        /* Dropdown de notificaciones */
        .notification-container {
            position: relative;
        }

        .notification-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            width: 350px;
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            z-index: 1000;
            display: none;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .notification-dropdown.show {
            display: block;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .notification-header {
            padding: 15px;
            border-bottom: 1px solid var(--gray);
            font-weight: 600;
            background: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .notification-header button {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
        }

        .notification-list {
            max-height: 350px;
            overflow-y: auto;
        }

        .notification-item {
            padding: 15px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
        }

        .notification-item:hover {
            background: rgba(58, 94, 199, 0.05);
        }

        .notification-item.unread {
            background: rgba(58, 94, 199, 0.1);
            border-left: 3px solid var(--primary);
        }

        .notification-item strong {
            display: block;
            margin-bottom: 5px;
            color: var(--primary);
        }

        .notification-item p {
            margin-bottom: 5px;
            font-size: 13px;
        }

        .notification-item small {
            color: var(--gray);
            font-size: 11px;
        }

        .notification-footer {
            padding: 10px 15px;
            text-align: center;
            border-top: 1px solid var(--gray);
        }

        /* Filtros y Búsqueda */
        .filters-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .filters-section h5 {
            margin-bottom: 15px;
            color: var(--primary);
        }

        .search-box {
            position: relative;
        }

        .search-box input {
            padding-left: 40px;
            color: #000000;
            border-radius: var(--border-radius);
            border: 1px solid rgba(0,0,0,0.1);
        }

        .search-box input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.25);
        }

        .search-box input::placeholder {
            color: #999;
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 12px;
            color: var(--gray);
        }

        .filter-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 15px;
        }

        /* Estadísticas rápidas mejoradas */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            transition: var(--transition);
            border-left: 4px solid transparent;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        .stat-sales {
            border-left-color: var(--primary);
        }

        .stat-orders {
            border-left-color: var(--secondary);
        }

        .stat-pending {
            border-left-color: var(--warning);
        }

        .stat-completed {
            border-left-color: var(--info);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }

        .stat-sales .stat-icon {
            background: rgba(58, 94, 199, 0.1);
            color: var(--primary);
        }

        .stat-orders .stat-icon {
            background: rgba(40, 167, 69, 0.1);
            color: var(--secondary);
        }

        .stat-pending .stat-icon {
            background: rgba(255, 193, 7, 0.1);
            color: var(--warning);
        }

        .stat-completed .stat-icon {
            background: rgba(23, 162, 184, 0.1);
            color: var(--info);
        }

        .stat-content {
            flex: 1;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: #000000;
            line-height: 1.2;
        }

        .stat-label {
            color: var(--gray);
            font-size: 14px;
            margin-bottom: 5px;
        }

        .stat-trend {
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .trend-up {
            color: var(--secondary);
        }

        .trend-down {
            color: var(--danger);
        }

        /* Configuración de notificaciones mejorada */
        .notification-settings {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .notification-settings h5 {
            margin-bottom: 15px;
            color: var(--primary);
        }

        .setting-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .setting-item:last-child {
            border-bottom: none;
        }

        .setting-info {
            flex: 1;
        }

        .setting-title {
            font-weight: 600;
            margin-bottom: 3px;
        }

        .setting-desc {
            font-size: 13px;
            color: var(--gray);
        }

        /* Switch personalizado mejorado */
        .switch {
            position: relative;
            display: inline-block;
            width: 52px;
            height: 26px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 26px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 20px;
            width: 20px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: var(--primary);
        }

        input:checked + .slider:before {
            transform: translateX(26px);
        }

        /* Tabs de navegación mejorados */
        .nav-tabs {
            border-bottom: 2px solid rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .nav-tabs .nav-link {
            color: #000000;
            border: none;
            padding: 12px 25px;
            font-weight: 500;
            transition: var(--transition);
        }

        .nav-tabs .nav-link i {
            margin-right: 8px;
        }

        .nav-tabs .nav-link:hover {
            border-color: transparent;
            background: rgba(58, 94, 199, 0.05);
        }

        .nav-tabs .nav-link.active {
            color: var(--primary);
            border-bottom: 3px solid var(--primary);
            background: transparent;
            font-weight: 600;
        }

        /* Tabla de Transacciones mejorada */
        .transactions-table {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid var(--gray);
            background: rgba(0,0,0,0.02);
        }

        .table-title {
            font-size: 18px;
            font-weight: 600;
            color: #000000;
        }

        .table-title i {
            color: var(--primary);
            margin-right: 8px;
        }

        .table-actions {
            display: flex;
            gap: 10px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            color: #000000;
        }

        th {
            font-weight: 600;
            background: rgba(0,0,0,0.02);
            color: var(--primary);
            font-size: 14px;
        }

        tr:hover {
            background: rgba(58, 94, 199, 0.02);
        }

        /* Badges para estados */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }

        .badge.bg-success {
            background-color: var(--secondary);
        }

        .badge.bg-warning {
            background-color: var(--warning);
            color: #000;
        }

        .badge.bg-danger {
            background-color: var(--danger);
        }

        .badge.bg-info {
            background-color: var(--info);
        }

        .badge.bg-primary {
            background-color: var(--primary);
        }

        .badge.bg-secondary {
            background-color: var(--gray);
        }

        /* Botones de acción */
        .action-btn {
            padding: 6px 10px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            transition: var(--transition);
            color: white;
            font-size: 12px;
        }

        .btn-view {
            background: var(--info);
        }

        .btn-edit {
            background: var(--primary);
        }

        .btn-delete {
            background: var(--danger);
        }

        .btn-process {
            background: var(--warning);
            color: #000;
        }

        .btn-notify {
            background: #25D366;
        }

        .btn-track {
            background: var(--secondary);
        }

        .action-btn:hover {
            opacity: 0.8;
            transform: translateY(-2px);
        }

        /* Modal mejorado */
        .modal-content {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            color: #000000 !important;
            background-color: #ffffff !important;
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border-top-left-radius: var(--border-radius);
            border-top-right-radius: var(--border-radius);
            padding: 20px;
        }

        .modal-header h5 {
            color: white;
        }

        .modal-header .btn-close {
            filter: invert(1);
        }

        .modal-body {
            padding: 25px;
            color: #000000 !important;
        }

        .modal-body p, 
        .modal-body span, 
        .modal-body strong,
        .modal-body div:not(.badge) {
            color: #000000 !important;
        }

        .modal-footer {
            padding: 20px;
            border-top: 1px solid rgba(0,0,0,0.05);
        }

        /* Lista de productos en modal */
        .product-list {
            max-height: 250px;
            overflow-y: auto;
            border: 1px solid rgba(0,0,0,0.05);
            border-radius: var(--border-radius);
            margin: 15px 0;
        }

        .product-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 15px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: var(--transition);
        }

        .product-item:hover {
            background: rgba(58, 94, 199, 0.05);
        }

        .product-item:last-child {
            border-bottom: none;
        }

        .product-info {
            flex: 1;
        }

        .product-name {
            font-weight: 600;
            margin-bottom: 3px;
        }

        .product-meta {
            font-size: 12px;
            color: var(--gray);
        }

        .product-price {
            font-weight: 600;
            color: var(--primary);
        }

        .transaction-summary {
            background: rgba(58, 94, 199, 0.05);
            border-radius: var(--border-radius);
            padding: 15px;
            margin-top: 15px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding: 5px 0;
        }

        .summary-total {
            font-weight: 700;
            font-size: 18px;
            border-top: 2px solid var(--primary);
            padding-top: 10px;
            margin-top: 10px;
            color: var(--primary);
        }

        /* Paginación mejorada */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-top: 1px solid rgba(0,0,0,0.05);
        }

        .pagination-info {
            color: var(--gray);
            font-size: 14px;
        }

        .pagination {
            display: flex;
            gap: 5px;
        }

        .page-item {
            list-style: none;
        }

        .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: 8px;
            border: 1px solid rgba(0,0,0,0.1);
            color: #000000;
            text-decoration: none;
            transition: var(--transition);
            font-size: 14px;
        }

        .page-link:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.active .page-link {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.disabled .page-link {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Modal de notificaciones */
        .notification-modal .modal-body {
            padding: 0;
        }

        .notification-type {
            display: flex;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            cursor: pointer;
            transition: var(--transition);
        }

        .notification-type:hover {
            background: rgba(58, 94, 199, 0.05);
            transform: translateX(5px);
        }

        .notification-type:last-child {
            border-bottom: none;
        }

        .notification-type i {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 20px;
        }

        .whatsapp-notification {
            background: rgba(37, 211, 102, 0.1);
            color: #25D366;
        }

        .sms-notification {
            background: rgba(58, 94, 199, 0.1);
            color: var(--primary);
        }

        .email-notification {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger);
        }

        .notification-type div {
            flex: 1;
        }

        .notification-type strong {
            display: block;
            margin-bottom: 3px;
        }

        .notification-type p {
            color: var(--gray);
            font-size: 13px;
            margin: 0;
        }

        /* Gráficos */
        .charts-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .chart-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .chart-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .chart-title i {
            margin-right: 8px;
        }

        .chart-container {
            height: 250px;
            position: relative;
        }

        /* Timeline de pedidos */
        .timeline {
            position: relative;
            padding: 20px 0;
            margin-top: 20px;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 20px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: var(--primary);
            opacity: 0.3;
        }

        .timeline-item {
            position: relative;
            padding-left: 50px;
            margin-bottom: 25px;
        }

        .timeline-marker {
            position: absolute;
            left: 11px;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: var(--primary);
            border: 3px solid var(--card-bg);
            z-index: 1;
        }

        .timeline-marker.completed {
            background: var(--secondary);
        }

        .timeline-marker.pending {
            background: var(--warning);
        }

        .timeline-content {
            background: var(--bg);
            padding: 15px;
            border-radius: 8px;
        }

        .timeline-date {
            font-size: 12px;
            color: var(--gray);
            margin-bottom: 5px;
        }

        .timeline-title {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .timeline-desc {
            font-size: 13px;
            color: var(--gray);
        }

        /* Toast de notificaciones */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
        }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            padding: 15px 20px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            animation: slideInRight 0.3s forwards;
            min-width: 300px;
            border-left: 4px solid var(--primary);
        }

        .toast.success {
            border-left-color: var(--secondary);
        }

        .toast.error {
            border-left-color: var(--danger);
        }

        .toast.warning {
            border-left-color: var(--warning);
        }

        .toast.info {
            border-left-color: var(--primary);
        }

        .toast i {
            margin-right: 15px;
            font-size: 20px;
        }

        .toast.success i {
            color: var(--secondary);
        }

        .toast.error i {
            color: var(--danger);
        }

        .toast.warning i {
            color: var(--warning);
        }

        .toast.info i {
            color: var(--primary);
        }

        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* Tooltips */
        [data-tooltip] {
            position: relative;
            cursor: help;
        }

        [data-tooltip]:before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 5px 10px;
            background: var(--dark);
            color: white;
            border-radius: 4px;
            font-size: 12px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 1000;
        }

        [data-tooltip]:hover:before {
            opacity: 1;
            visibility: visible;
            bottom: 120%;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .charts-section {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 0;
            }
            
            .sidebar.open {
                transform: translateX(0);
                width: var(--sidebar-width);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .controls {
                margin-top: 15px;
                width: 100%;
                justify-content: space-between;
            }
        }

        @media (max-width: 768px) {
            .stats-container {
                grid-template-columns: 1fr;
            }

            .filters-section .row {
                gap: 10px;
            }

            .filter-actions {
                flex-direction: column;
            }

            .filter-actions .btn {
                width: 100%;
            }

            .table-header {
                flex-direction: column;
                gap: 10px;
            }

            .pagination-container {
                flex-direction: column;
                gap: 10px;
            }

            .notification-dropdown {
                width: 300px;
                right: -50px;
            }

            .charts-section {
                grid-template-columns: 1fr;
            }

            .modal-dialog {
                margin: 10px;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px;
            }

            .stats-container {
                gap: 10px;
            }

            .stat-card {
                padding: 15px;
            }

            .stat-icon {
                width: 50px;
                height: 50px;
                font-size: 20px;
            }

            .stat-value {
                font-size: 22px;
            }

            .notification-dropdown {
                width: 280px;
                right: -70px;
            }

            .toast {
                min-width: 250px;
            }

            .nav-tabs .nav-link {
                padding: 10px 15px;
                font-size: 14px;
            }

            .nav-tabs .nav-link i {
                margin-right: 5px;
            }
        }

        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 1001;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            cursor: pointer;
            transition: var(--transition);
        }

        .menu-toggle:hover {
            transform: scale(1.1);
            background: var(--primary-dark);
        }

        /* Asegurar que todos los textos sean negros */
        body, body *:not(.sidebar *):not(.modal-header *):not(.action-btn):not(.badge):not(.page-link:hover):not(.page-item.active .page-link) {
            color: #000000 !important;
        }

        /* Ajustes para mantener contraste en elementos especiales */
        .sidebar, .modal-header, .action-btn, .badge, .page-link:hover, .page-item.active .page-link {
            color: white !important;
        }

        /* Inputs y selects */
        .form-control, .form-select {
            color: #000000 !important;
            background-color: #ffffff !important;
            border: 1px solid rgba(0,0,0,0.1);
            border-radius: 8px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.25);
        }

        .form-control::placeholder {
            color: #999 !important;
        }

        /* Botones */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
        }

        .btn-primary {
            background: var(--primary);
            color: white !important;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3);
        }

        .btn-success {
            background: var(--secondary);
            color: white !important;
        }

        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
        }

        .btn-warning {
            background: var(--warning);
            color: #000 !important;
        }

        .btn-warning:hover {
            background: #e0a800;
            transform: translateY(-2px);
        }

        .btn-info {
            background: var(info);
            color: white !important;
        }

        .btn-info:hover {
            background: #138496;
            transform: translateY(-2px);
        }

        .btn-outline-secondary {
            border: 1px solid var(--gray);
            color: #000 !important;
        }

        .btn-outline-secondary:hover {
            background: var(--gray);
            color: white !important;
        }

        /* Estado vacío */
        .empty-state {
            text-align: center;
            padding: 40px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: var(--gray);
        }

        .empty-state h4 {
            margin-bottom: 10px;
        }

        /* Animaciones adicionales */
        .fade-in {
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .slide-up {
            animation: slideUp 0.3s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot me-2"></i>SmartStock AI
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <li><a href="http://localhost/SmartStockAI/admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes"></i> Inventario</a></li>
                <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-line"></i> Reportes</a></li>
                <li><a href="http://localhost/SmartStockAI/clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
                <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck"></i> Proveedores</a></li>
                <li><a href="#" class="active"><i class="fas fa-exchange-alt"></i> Transacciones</a></li>
                <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-user"></i> Usuarios</a></li>
                <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-user-circle"></i> Perfil</a></li>
                <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-cog"></i> Configuración</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1 class="page-title">
                    <i class="fas fa-exchange-alt"></i>
                    Gestión de Transacciones y Pedidos
                </h1>
                
                <div class="controls">
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notification-container">
                        <div class="notifications" id="notificationBtn">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge" id="notificationBadge">5</span>
                        </div>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-header">
                                <span><i class="fas fa-bell me-2"></i>Notificaciones</span>
                                <button id="markAllRead">Marcar todas</button>
                            </div>
                            <div class="notification-list" id="notificationList">
                                <!-- Las notificaciones se cargarán aquí dinámicamente -->
                            </div>
                            <div class="notification-footer">
                                <a href="#" id="viewAllNotifications">Ver todas las notificaciones</a>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTransactionModal">
                        <i class="fas fa-plus me-2"></i>Nueva Transacción
                    </button>
                </div>
            </div>
            
            <!-- Estadísticas rápidas -->
            <div class="stats-container">
                <div class="stat-card stat-sales">
                    <div class="stat-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Ventas del Mes</div>
                        <div class="stat-value" id="monthlySales">$12,458</div>
                        <div class="stat-trend">
                            <i class="fas fa-arrow-up trend-up"></i>
                            <span class="trend-up">+12.5% vs mes anterior</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-orders">
                    <div class="stat-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Pedidos Activos</div>
                        <div class="stat-value" id="activeOrders">48</div>
                        <div class="stat-trend">
                            <i class="fas fa-arrow-up trend-up"></i>
                            <span class="trend-up">+8 nuevos hoy</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-pending">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Pendientes de Procesar</div>
                        <div class="stat-value" id="pendingOrders">12</div>
                        <div class="stat-trend">
                            <i class="fas fa-exclamation-triangle trend-down"></i>
                            <span class="trend-down">3 urgentes</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-completed">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Completados Hoy</div>
                        <div class="stat-value" id="completedToday">18</div>
                        <div class="stat-trend">
                            <i class="fas fa-check-circle text-success"></i>
                            <span class="text-success">Tasa de éxito 94%</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Gráficos -->
            <div class="charts-section">
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-chart-bar"></i>
                        Ventas por Día (Últimos 7 días)
                    </div>
                    <div class="chart-container">
                        <canvas id="salesChart"></canvas>
                    </div>
                </div>
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-chart-pie"></i>
                        Estado de Pedidos
                    </div>
                    <div class="chart-container">
                        <canvas id="ordersChart"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Configuración de notificaciones -->
            <div class="notification-settings">
                <h5><i class="fas fa-bell me-2"></i>Configuración de Notificaciones</h5>
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-title">Notificaciones por WhatsApp</div>
                        <div class="setting-desc">Recibir alertas en tiempo real por WhatsApp</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="whatsappNotifications" checked>
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-title">Notificaciones por SMS</div>
                        <div class="setting-desc">Recibir alertas por mensaje de texto</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="smsNotifications">
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-title">Notificaciones por Email</div>
                        <div class="setting-desc">Recibir alertas por correo electrónico</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="emailNotifications" checked>
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-title">Notificaciones de Stock Bajo</div>
                        <div class="setting-desc">Alertas cuando el stock esté por debajo del mínimo</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="stockNotifications" checked>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>
            
            <!-- Filtros y Búsqueda -->
            <div class="filters-section">
                <h5><i class="fas fa-filter me-2"></i>Filtros Avanzados</h5>
                <div class="row g-3">
                    <div class="col-md-3">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" class="form-control" id="searchInput" placeholder="Buscar transacciones...">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <select class="form-select" id="typeFilter">
                            <option value="all">Todos los tipos</option>
                            <option value="Venta">Venta</option>
                            <option value="Compra">Compra</option>
                            <option value="Devolución">Devolución</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select class="form-select" id="statusFilter">
                            <option value="all">Todos los estados</option>
                            <option value="Completado">Completado</option>
                            <option value="Pendiente">Pendiente</option>
                            <option value="Procesando">Procesando</option>
                            <option value="Enviado">Enviado</option>
                            <option value="Cancelado">Cancelado</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input type="date" class="form-control" id="dateFilter" placeholder="Fecha">
                    </div>
                    <div class="col-md-3">
                        <div class="filter-actions">
                            <button class="btn btn-outline-secondary" id="clearFilters">
                                <i class="fas fa-times me-1"></i> Limpiar
                            </button>
                            <button class="btn btn-primary" id="exportBtn">
                                <i class="fas fa-download me-1"></i> Exportar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Tabs de navegación -->
            <ul class="nav nav-tabs" id="transactionsTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="transactions-tab" data-bs-toggle="tab" data-bs-target="#transactions" type="button" role="tab">
                        <i class="fas fa-list"></i> Transacciones
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="orders-tab" data-bs-toggle="tab" data-bs-target="#orders" type="button" role="tab">
                        <i class="fas fa-shopping-cart"></i> Pedidos
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="timeline-tab" data-bs-toggle="tab" data-bs-target="#timeline" type="button" role="tab">
                        <i class="fas fa-clock"></i> Timeline
                    </button>
                </li>
            </ul>
            
            <!-- Contenido de las tabs -->
            <div class="tab-content" id="transactionsTabContent">
                <!-- Tab de Transacciones -->
                <div class="tab-pane fade show active" id="transactions" role="tabpanel" aria-labelledby="transactions-tab">
                    <div class="transactions-table">
                        <div class="table-header">
                            <h3 class="table-title">
                                <i class="fas fa-list"></i>
                                Historial de Transacciones
                            </h3>
                            <div class="table-actions">
                                <button class="btn btn-sm btn-outline-primary" id="refreshTransactions">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                                <span id="transactionCount" class="badge bg-primary">Mostrando 8 de 42</span>
                            </div>
                        </div>
                        
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Cliente/Proveedor</th>
                                        <th>Tipo</th>
                                        <th>Fecha</th>
                                        <th>Total</th>
                                        <th>Método de Pago</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="transactionsTableBody">
                                    <!-- Los datos se cargarán dinámicamente -->
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="pagination-container">
                            <div class="pagination-info" id="transactionsPaginationInfo">
                                Mostrando 1-8 de 42 transacciones
                            </div>
                            <ul class="pagination" id="transactionsPagination">
                                <!-- La paginación se generará dinámicamente -->
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Tab de Pedidos -->
                <div class="tab-pane fade" id="orders" role="tabpanel" aria-labelledby="orders-tab">
                    <div class="transactions-table">
                        <div class="table-header">
                            <h3 class="table-title">
                                <i class="fas fa-shopping-cart"></i>
                                Gestión de Pedidos
                            </h3>
                            <div class="table-actions">
                                <button class="btn btn-sm btn-outline-primary" id="refreshOrders">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                                <span id="ordersCount" class="badge bg-primary">Mostrando 6 de 16</span>
                            </div>
                        </div>
                        
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Nº Pedido</th>
                                        <th>Cliente</th>
                                        <th>Fecha</th>
                                        <th>Productos</th>
                                        <th>Total</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="ordersTableBody">
                                    <!-- Los datos se cargarán dinámicamente -->
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="pagination-container">
                            <div class="pagination-info" id="ordersPaginationInfo">
                                Mostrando 1-6 de 16 pedidos
                            </div>
                            <ul class="pagination" id="ordersPagination">
                                <!-- La paginación se generará dinámicamente -->
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Tab de Timeline -->
                <div class="tab-pane fade" id="timeline" role="tabpanel" aria-labelledby="timeline-tab">
                    <div class="transactions-table">
                        <div class="table-header">
                            <h3 class="table-title">
                                <i class="fas fa-clock"></i>
                                Línea de Tiempo de Actividad Reciente
                            </h3>
                        </div>
                        <div class="timeline" id="timelineContainer">
                            <!-- El timeline se cargará dinámicamente -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para ver transacción -->
    <div class="modal fade" id="viewTransactionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-eye me-2"></i>
                        Detalles de la Transacción
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <p><strong>ID Transacción:</strong> <span id="viewTransactionId"></span></p>
                            <p><strong>Cliente/Proveedor:</strong> <span id="viewTransactionClient"></span></p>
                            <p><strong>Teléfono:</strong> <span id="viewTransactionPhone"></span></p>
                            <p><strong>Email:</strong> <span id="viewTransactionEmail"></span></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Tipo:</strong> <span id="viewTransactionType"></span></p>
                            <p><strong>Fecha:</strong> <span id="viewTransactionDate"></span></p>
                            <p><strong>Método de Pago:</strong> <span id="viewTransactionPayment"></span></p>
                            <p><strong>Estado:</strong> <span id="viewTransactionStatus" class="badge"></span></p>
                        </div>
                    </div>
                    
                    <h6><i class="fas fa-box me-2"></i>Productos:</h6>
                    <div class="product-list" id="viewTransactionProducts">
                        <!-- Los productos se cargarán aquí dinámicamente -->
                    </div>
                    
                    <div class="transaction-summary">
                        <div class="summary-row">
                            <span>Subtotal:</span>
                            <span id="viewTransactionSubtotal">$0.00</span>
                        </div>
                        <div class="summary-row">
                            <span>Impuestos (10%):</span>
                            <span id="viewTransactionTax">$0.00</span>
                        </div>
                        <div class="summary-row">
                            <span>Descuento:</span>
                            <span id="viewTransactionDiscount">$0.00</span>
                        </div>
                        <div class="summary-row summary-total">
                            <span>TOTAL:</span>
                            <span id="viewTransactionTotal">$0.00</span>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <strong><i class="fas fa-sticky-note me-2"></i>Notas:</strong>
                        <p id="viewTransactionNotes" class="mt-2 p-3 bg-light rounded">Sin notas adicionales</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary" id="btnPrintTransaction">
                        <i class="fas fa-print me-1"></i> Imprimir
                    </button>
                    <button type="button" class="btn btn-success" id="btnNotifyTransaction">
                        <i class="fab fa-whatsapp me-1"></i> Notificar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para ver pedido -->
    <div class="modal fade" id="viewOrderModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-box me-2"></i>
                        Detalles del Pedido
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <p><strong>Nº Pedido:</strong> <span id="viewOrderId"></span></p>
                            <p><strong>Cliente:</strong> <span id="viewOrderClient"></span></p>
                            <p><strong>Email:</strong> <span id="viewOrderEmail"></span></p>
                            <p><strong>Teléfono:</strong> <span id="viewOrderPhone"></span></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Fecha:</strong> <span id="viewOrderDate"></span></p>
                            <p><strong>Estado:</strong> <span id="viewOrderStatus" class="badge"></span></p>
                            <p><strong>Método de Envío:</strong> <span id="viewOrderShipping"></span></p>
                            <p><strong>Dirección:</strong> <span id="viewOrderAddress"></span></p>
                        </div>
                    </div>
                    
                    <h6><i class="fas fa-box me-2"></i>Productos:</h6>
                    <div class="product-list" id="viewOrderProducts">
                        <!-- Los productos se cargarán aquí dinámicamente -->
                    </div>
                    
                    <div class="transaction-summary">
                        <div class="summary-row">
                            <span>Subtotal:</span>
                            <span id="viewOrderSubtotal">$0.00</span>
                        </div>
                        <div class="summary-row">
                            <span>Envío:</span>
                            <span id="viewOrderShippingCost">$0.00</span>
                        </div>
                        <div class="summary-row">
                            <span>Impuestos (10%):</span>
                            <span id="viewOrderTax">$0.00</span>
                        </div>
                        <div class="summary-row summary-total">
                            <span>TOTAL:</span>
                            <span id="viewOrderTotal">$0.00</span>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <strong><i class="fas fa-sticky-note me-2"></i>Notas:</strong>
                        <p id="viewOrderNotes" class="mt-2 p-3 bg-light rounded">Sin notas adicionales</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary" id="btnUpdateOrderStatus">
                        <i class="fas fa-sync me-1"></i> Actualizar Estado
                    </button>
                    <button type="button" class="btn btn-success" id="btnNotifyOrder">
                        <i class="fab fa-whatsapp me-1"></i> Notificar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para agregar transacción -->
    <div class="modal fade" id="addTransactionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus me-2"></i>
                        Nueva Transacción
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addTransactionForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="transactionType" class="form-label">Tipo de Transacción *</label>
                                    <select class="form-select" id="transactionType" required>
                                        <option value="">Seleccionar...</option>
                                        <option value="Venta">Venta</option>
                                        <option value="Compra">Compra</option>
                                        <option value="Devolución">Devolución</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="transactionClient" class="form-label">Cliente/Proveedor *</label>
                                    <input type="text" class="form-control" id="transactionClient" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="transactionPhone" class="form-label">Teléfono</label>
                                    <input type="tel" class="form-control" id="transactionPhone" placeholder="+1234567890">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="transactionEmail" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="transactionEmail" placeholder="cliente@ejemplo.com">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="transactionDate" class="form-label">Fecha *</label>
                                    <input type="date" class="form-control" id="transactionDate" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="transactionPayment" class="form-label">Método de Pago</label>
                                    <select class="form-select" id="transactionPayment">
                                        <option value="Efectivo">Efectivo</option>
                                        <option value="Tarjeta de Crédito">Tarjeta de Crédito</option>
                                        <option value="Tarjeta de Débito">Tarjeta de Débito</option>
                                        <option value="Transferencia">Transferencia</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="transactionStatus" class="form-label">Estado</label>
                                    <select class="form-select" id="transactionStatus">
                                        <option value="Pendiente">Pendiente</option>
                                        <option value="Completado">Completado</option>
                                        <option value="Cancelado">Cancelado</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Productos</label>
                            <div id="transactionProductsList">
                                <!-- Los productos se agregarán aquí dinámicamente -->
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addProductToTransaction">
                                <i class="fas fa-plus me-1"></i>Agregar Producto
                            </button>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="transactionDiscount" class="form-label">Descuento ($)</label>
                                    <input type="number" class="form-control" id="transactionDiscount" value="0" min="0" step="0.01">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="transactionTax" class="form-label">Impuestos (%)</label>
                                    <input type="number" class="form-control" id="transactionTax" value="10" min="0" max="100">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="transactionNotes" class="form-label">Notas</label>
                            <textarea class="form-control" id="transactionNotes" rows="3" placeholder="Notas adicionales..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveTransaction">
                        <i class="fas fa-save me-1"></i> Guardar Transacción
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para enviar notificaciones -->
    <div class="modal fade notification-modal" id="notificationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-bell me-2"></i>
                        Enviar Notificación
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="notification-type" data-type="whatsapp">
                        <i class="fab fa-whatsapp whatsapp-notification"></i>
                        <div>
                            <strong>WhatsApp</strong>
                            <p>Enviar notificación por WhatsApp</p>
                        </div>
                    </div>
                    <div class="notification-type" data-type="sms">
                        <i class="fas fa-sms sms-notification"></i>
                        <div>
                            <strong>SMS</strong>
                            <p>Enviar notificación por mensaje de texto</p>
                        </div>
                    </div>
                    <div class="notification-type" data-type="email">
                        <i class="fas fa-envelope email-notification"></i>
                        <div>
                            <strong>Email</strong>
                            <p>Enviar notificación por correo electrónico</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para actualizar estado de pedido -->
    <div class="modal fade" id="updateOrderStatusModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-sync me-2"></i>
                        Actualizar Estado del Pedido
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="updateOrderId">
                    <div class="mb-3">
                        <label for="newOrderStatus" class="form-label">Nuevo Estado</label>
                        <select class="form-select" id="newOrderStatus">
                            <option value="Nuevo">Nuevo</option>
                            <option value="Procesando">Procesando</option>
                            <option value="Enviado">Enviado</option>
                            <option value="Entregado">Entregado</option>
                            <option value="Cancelado">Cancelado</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="statusNotes" class="form-label">Notas (opcional)</label>
                        <textarea class="form-control" id="statusNotes" rows="3" placeholder="Información adicional sobre el cambio de estado..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-check">
                            <input type="checkbox" class="form-check-input" id="notifyCustomer">
                            <span class="form-check-label">Notificar al cliente sobre este cambio</span>
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="confirmUpdateStatus">
                        <i class="fas fa-check me-1"></i> Actualizar
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============================================
        // CLASE PARA GESTIONAR TRANSACCIONES Y NOTIFICACIONES
        // ============================================
        class EnhancedTransactionManager {
            constructor() {
                this.transactions = JSON.parse(localStorage.getItem('transactions')) || [];
                this.orders = JSON.parse(localStorage.getItem('orders')) || [];
                this.notificationSettings = JSON.parse(localStorage.getItem('notificationSettings')) || {
                    whatsapp: true,
                    sms: false,
                    email: true,
                    stock: true
                };
                this.notifications = JSON.parse(localStorage.getItem('notifications')) || [];
                this.currentPage = {
                    transactions: 1,
                    orders: 1
                };
                this.itemsPerPage = 8;
                this.filteredTransactions = [];
                this.filteredOrders = [];
                this.currentNotificationItem = null;
                this.currentNotificationType = null;
                this.charts = {};
                
                // Inicializar con datos de ejemplo si no hay transacciones
                if (this.transactions.length === 0) {
                    this.initializeSampleData();
                }
                
                // Inicializar notificaciones
                if (this.notifications.length === 0) {
                    this.initializeNotifications();
                }
            }
            
            initializeSampleData() {
                // Datos de ejemplo para transacciones
                this.transactions = [
                    {
                        id: 'TXN-78912',
                        client: 'María García',
                        type: 'Venta',
                        date: '15/06/2023',
                        total: 850.00,
                        payment: 'Tarjeta de Crédito',
                        status: 'Completado',
                        products: [
                            { id: 'PRD-001', name: 'Laptop HP Pavilion', price: 850.00, quantity: 1 }
                        ],
                        subtotal: 850.00,
                        tax: 85.00,
                        discount: 0,
                        notes: '',
                        phone: '+34123456789',
                        email: 'maria.garcia@empresa.com'
                    },
                    {
                        id: 'TXN-78911',
                        client: 'Proveedor TechImport',
                        type: 'Compra',
                        date: '14/06/2023',
                        total: 2150.00,
                        payment: 'Transferencia',
                        status: 'Completado',
                        products: [
                            { id: 'PRD-007', name: 'Tablet Android', price: 299.99, quantity: 5 },
                            { id: 'PRD-004', name: 'Monitor LG 24"', price: 220.00, quantity: 3 }
                        ],
                        subtotal: 2150.00,
                        tax: 0,
                        discount: 0,
                        notes: 'Pedido de reposición de stock',
                        phone: '+34987654321',
                        email: 'contacto@techimport.com'
                    },
                    {
                        id: 'TXN-78910',
                        client: 'Carlos López',
                        type: 'Venta',
                        date: '14/06/2023',
                        total: 299.99,
                        payment: 'Efectivo',
                        status: 'Pendiente',
                        products: [
                            { id: 'PRD-009', name: 'Auriculares Inalámbricos', price: 150.00, quantity: 1 },
                            { id: 'PRD-010', name: 'Mochila Impermeable', price: 45.00, quantity: 1 }
                        ],
                        subtotal: 195.00,
                        tax: 19.50,
                        discount: 0,
                        notes: 'Cliente pagará en efectivo',
                        phone: '+34678901234',
                        email: 'carlos.lopez@email.com'
                    },
                    {
                        id: 'TXN-78909',
                        client: 'Juan Pérez',
                        type: 'Devolución',
                        date: '13/06/2023',
                        total: -120.00,
                        payment: 'Reembolso',
                        status: 'Completado',
                        products: [
                            { id: 'PRD-006', name: 'Silla de Oficina', price: 120.00, quantity: 1, returned: true }
                        ],
                        subtotal: -120.00,
                        tax: 0,
                        discount: 0,
                        notes: 'Producto defectuoso',
                        phone: '+34567890123',
                        email: 'juan.perez@email.com'
                    },
                    {
                        id: 'TXN-78908',
                        client: 'Ana Martínez',
                        type: 'Venta',
                        date: '13/06/2023',
                        total: 458.50,
                        payment: 'Tarjeta de Débito',
                        status: 'Completado',
                        products: [
                            { id: 'PRD-005', name: 'Camiseta Algodón', price: 25.00, quantity: 3 },
                            { id: 'PRD-003', name: 'Zapatillas Deportivas', price: 75.00, quantity: 2 },
                            { id: 'PRD-008', name: 'Set de Herramientas', price: 89.99, quantity: 2 }
                        ],
                        subtotal: 458.50,
                        tax: 45.85,
                        discount: 0,
                        notes: '',
                        phone: '+34789012345',
                        email: 'ana.martinez@email.com'
                    },
                    {
                        id: 'TXN-78907',
                        client: 'Proveedor MobileTech',
                        type: 'Compra',
                        date: '12/06/2023',
                        total: 3745.00,
                        payment: 'Transferencia',
                        status: 'Cancelado',
                        products: [
                            { id: 'PRD-002', name: 'Smartphone Samsung Galaxy', price: 620.00, quantity: 4 },
                            { id: 'PRD-001', name: 'Laptop HP Pavilion', price: 850.00, quantity: 1 }
                        ],
                        subtotal: 3745.00,
                        tax: 0,
                        discount: 0,
                        notes: 'Cancelado por falta de stock',
                        phone: '+34123456789',
                        email: 'ventas@mobiletech.com'
                    },
                    {
                        id: 'TXN-78906',
                        client: 'Laura Rodríguez',
                        type: 'Venta',
                        date: '12/06/2023',
                        total: 620.00,
                        payment: 'Tarjeta de Crédito',
                        status: 'Completado',
                        products: [
                            { id: 'PRD-002', name: 'Smartphone Samsung Galaxy', price: 620.00, quantity: 1 }
                        ],
                        subtotal: 620.00,
                        tax: 62.00,
                        discount: 0,
                        notes: 'Cliente frecuente',
                        phone: '+34654321098',
                        email: 'laura.rodriguez@email.com'
                    },
                    {
                        id: 'TXN-78905',
                        client: 'Roberto Sánchez',
                        type: 'Venta',
                        date: '11/06/2023',
                        total: 175.50,
                        payment: 'Efectivo',
                        status: 'Pendiente',
                        products: [
                            { id: 'PRD-003', name: 'Zapatillas Deportivas', price: 75.00, quantity: 1 },
                            { id: 'PRD-010', name: 'Mochila Impermeable', price: 45.00, quantity: 1 }
                        ],
                        subtotal: 120.00,
                        tax: 12.00,
                        discount: 0,
                        notes: 'Pendiente de confirmación',
                        phone: '+34765432109',
                        email: 'roberto.sanchez@email.com'
                    }
                ];
                
                // Datos de ejemplo para pedidos
                this.orders = [
                    {
                        id: 'ORD-2023-1052',
                        client: 'María García',
                        date: '15/06/2023',
                        status: 'Nuevo',
                        products: [
                            { id: 'PRD-001', name: 'Laptop HP Pavilion', price: 850.00, quantity: 1 }
                        ],
                        subtotal: 850.00,
                        shipping: 0,
                        tax: 85.00,
                        email: 'maria.garcia@empresa.com',
                        phone: '+34123456789',
                        shippingMethod: 'Recogida en tienda',
                        address: 'Calle Mayor 123, Madrid',
                        notes: 'Cliente recogerá en tienda'
                    },
                    {
                        id: 'ORD-2023-1051',
                        client: 'Carlos López',
                        date: '14/06/2023',
                        status: 'Procesando',
                        products: [
                            { id: 'PRD-009', name: 'Auriculares Inalámbricos', price: 150.00, quantity: 1 },
                            { id: 'PRD-010', name: 'Mochila Impermeable', price: 45.00, quantity: 1 }
                        ],
                        subtotal: 195.00,
                        shipping: 5.99,
                        tax: 19.50,
                        email: 'carlos.lopez@email.com',
                        phone: '+34678901234',
                        shippingMethod: 'Correo ordinario',
                        address: 'Av. Constitución 45, Barcelona',
                        notes: 'Incluir factura'
                    },
                    {
                        id: 'ORD-2023-1050',
                        client: 'Ana Martínez',
                        date: '14/06/2023',
                        status: 'Enviado',
                        products: [
                            { id: 'PRD-005', name: 'Camiseta Algodón', price: 25.00, quantity: 3 },
                            { id: 'PRD-003', name: 'Zapatillas Deportivas', price: 75.00, quantity: 2 },
                            { id: 'PRD-008', name: 'Set de Herramientas', price: 89.99, quantity: 2 }
                        ],
                        subtotal: 458.50,
                        shipping: 0,
                        tax: 45.85,
                        email: 'ana.martinez@email.com',
                        phone: '+34789012345',
                        shippingMethod: 'Envío exprés',
                        address: 'Plaza España 7, Valencia',
                        notes: 'Envío exprés garantizado'
                    },
                    {
                        id: 'ORD-2023-1049',
                        client: 'Laura Rodríguez',
                        date: '13/06/2023',
                        status: 'Entregado',
                        products: [
                            { id: 'PRD-002', name: 'Smartphone Samsung Galaxy', price: 620.00, quantity: 1 }
                        ],
                        subtotal: 620.00,
                        shipping: 0,
                        tax: 62.00,
                        email: 'laura.rodriguez@email.com',
                        phone: '+34654321098',
                        shippingMethod: 'Recogida en tienda',
                        address: '',
                        notes: 'Entregado personalmente'
                    },
                    {
                        id: 'ORD-2023-1048',
                        client: 'Roberto Sánchez',
                        date: '12/06/2023',
                        status: 'Enviado',
                        products: [
                            { id: 'PRD-003', name: 'Zapatillas Deportivas', price: 75.00, quantity: 1 },
                            { id: 'PRD-010', name: 'Mochila Impermeable', price: 45.00, quantity: 1 }
                        ],
                        subtotal: 120.00,
                        shipping: 3.99,
                        tax: 12.00,
                        email: 'roberto.sanchez@email.com',
                        phone: '+34765432109',
                        shippingMethod: 'Correo ordinario',
                        address: 'Calle Sol 34, Sevilla',
                        notes: 'Número de seguimiento: SE123456ES'
                    },
                    {
                        id: 'ORD-2023-1047',
                        client: 'Juan Pérez',
                        date: '11/06/2023',
                        status: 'Cancelado',
                        products: [
                            { id: 'PRD-006', name: 'Silla de Oficina', price: 120.00, quantity: 1 }
                        ],
                        subtotal: 120.00,
                        shipping: 15.00,
                        tax: 12.00,
                        email: 'juan.perez@email.com',
                        phone: '+34567890123',
                        shippingMethod: 'Mensajería',
                        address: 'Av. Libertad 56, Bilbao',
                        notes: 'Cancelado por solicitud del cliente'
                    }
                ];
                
                this.saveData();
            }
            
            initializeNotifications() {
                this.notifications = [
                    {
                        id: 1,
                        title: 'Nuevo pedido recibido',
                        message: 'Pedido #ORD-2023-1052 de María García',
                        time: 'Hace 10 minutos',
                        read: false,
                        type: 'order'
                    },
                    {
                        id: 2,
                        title: 'Pago confirmado',
                        message: 'El pago de la transacción #TXN-78912 fue confirmado',
                        time: 'Hace 25 minutos',
                        read: false,
                        type: 'transaction'
                    },
                    {
                        id: 3,
                        title: 'Pedido enviado',
                        message: 'El pedido #ORD-2023-1050 ha sido enviado',
                        time: 'Hace 1 hora',
                        read: false,
                        type: 'order'
                    },
                    {
                        id: 4,
                        title: 'Stock actualizado',
                        message: 'El inventario se actualizó después de las ventas del día',
                        time: 'Ayer a las 18:30',
                        read: true,
                        type: 'inventory'
                    },
                    {
                        id: 5,
                        title: 'Pedido cancelado',
                        message: 'El pedido #ORD-2023-1047 fue cancelado',
                        time: 'Ayer a las 14:15',
                        read: true,
                        type: 'order'
                    }
                ];
                
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
            }
            
            getStatusClass(status) {
                switch(status) {
                    case 'Completado':
                    case 'Entregado': return 'bg-success';
                    case 'Pendiente':
                    case 'Procesando': return 'bg-warning';
                    case 'Nuevo': return 'bg-primary';
                    case 'Enviado': return 'bg-info';
                    case 'Cancelado': return 'bg-danger';
                    default: return 'bg-secondary';
                }
            }
            
            // Métodos para notificaciones
            getUnreadNotifications() {
                return this.notifications.filter(n => !n.read);
            }
            
            markAllNotificationsAsRead() {
                this.notifications.forEach(n => n.read = true);
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
                return this.notifications;
            }
            
            markNotificationAsRead(id) {
                const notification = this.notifications.find(n => n.id === id);
                if (notification) {
                    notification.read = true;
                    localStorage.setItem('notifications', JSON.stringify(this.notifications));
                }
            }
            
            addNotification(title, message, type = 'info') {
                const newNotification = {
                    id: this.notifications.length + 1,
                    title,
                    message,
                    time: 'Ahora',
                    read: false,
                    type
                };
                
                this.notifications.unshift(newNotification);
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
                
                // Mostrar toast
                this.showNotification(message, 'info');
                
                return newNotification;
            }
            
            sendWhatsAppNotification(item, type) {
                let message = '';
                let phone = '';
                
                if (type === 'transaction') {
                    message = `✅ *SmartStock AI - Transacción*\n\n` +
                              `*ID:* ${item.id}\n` +
                              `*Cliente:* ${item.client}\n` +
                              `*Tipo:* ${item.type}\n` +
                              `*Total:* $${item.total.toFixed(2)}\n` +
                              `*Estado:* ${item.status}\n` +
                              `*Fecha:* ${item.date}\n\n` +
                              `Gracias por confiar en SmartStock AI.`;
                    phone = item.phone;
                } else if (type === 'order') {
                    const total = (item.subtotal + item.tax + (item.shipping || 0)).toFixed(2);
                    message = `📦 *SmartStock AI - Actualización de Pedido*\n\n` +
                              `*Pedido:* ${item.id}\n` +
                              `*Cliente:* ${item.client}\n` +
                              `*Estado:* ${item.status}\n` +
                              `*Total:* $${total}\n` +
                              `*Productos:* ${item.products.length}\n` +
                              `*Fecha:* ${item.date}\n\n` +
                              `Puedes hacer seguimiento de tu pedido en nuestra web.`;
                    phone = item.phone;
                }
                
                // Abrir WhatsApp con mensaje predefinido
                const whatsappUrl = `https://wa.me/${phone.replace('+', '')}?text=${encodeURIComponent(message)}`;
                window.open(whatsappUrl, '_blank');
                
                this.addNotification(
                    `Notificación de WhatsApp enviada`,
                    `Mensaje enviado a ${item.client}`,
                    'whatsapp'
                );
            }
            
            sendSMSNotification(item, type) {
                // Simular envío de SMS
                this.addNotification(
                    `SMS enviado`,
                    `Mensaje enviado a ${item.client}`,
                    'sms'
                );
            }
            
            sendEmailNotification(item, type) {
                // Simular envío de email
                this.addNotification(
                    `Email enviado`,
                    `Correo electrónico enviado a ${item.email || item.client}`,
                    'email'
                );
            }
            
            sendNotification(item, type, notificationType) {
                if (!this.notificationSettings[notificationType]) {
                    this.showNotification(`Las notificaciones por ${notificationType.toUpperCase()} están desactivadas`, 'warning');
                    return;
                }
                
                switch(notificationType) {
                    case 'whatsapp':
                        this.sendWhatsAppNotification(item, type);
                        break;
                    case 'sms':
                        this.sendSMSNotification(item, type);
                        break;
                    case 'email':
                        this.sendEmailNotification(item, type);
                        break;
                }
            }
            
            updateNotificationSettings(settings) {
                this.notificationSettings = { ...this.notificationSettings, ...settings };
                localStorage.setItem('notificationSettings', JSON.stringify(this.notificationSettings));
                this.showNotification('Configuración de notificaciones actualizada', 'success');
            }
            
            // Estadísticas
            getStats() {
                const now = new Date();
                const currentMonth = now.getMonth();
                const currentYear = now.getFullYear();
                
                const monthlySales = this.transactions
                    .filter(t => {
                        const [day, month, year] = t.date.split('/').map(Number);
                        return month === currentMonth + 1 && year === currentYear && t.type === 'Venta' && t.status === 'Completado';
                    })
                    .reduce((sum, t) => sum + t.total, 0);
                
                const activeOrders = this.orders.filter(o => 
                    o.status !== 'Entregado' && o.status !== 'Cancelado'
                ).length;
                
                const pendingOrders = this.orders.filter(o => 
                    o.status === 'Nuevo' || o.status === 'Procesando'
                ).length;
                
                const completedToday = this.orders.filter(o => {
                    const [day, month, year] = o.date.split('/').map(Number);
                    return day === now.getDate() && month === now.getMonth() + 1 && year === now.getFullYear() && o.status === 'Entregado';
                }).length;
                
                return {
                    monthlySales,
                    activeOrders,
                    pendingOrders,
                    completedToday,
                    totalTransactions: this.transactions.length,
                    totalOrders: this.orders.length
                };
            }
            
            // Filtros
            filterTransactions(searchTerm = '', type = 'all', status = 'all', date = '') {
                this.filteredTransactions = this.transactions.filter(transaction => {
                    const matchesSearch = transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
                                         transaction.client.toLowerCase().includes(searchTerm.toLowerCase());
                    const matchesType = type === 'all' || transaction.type === type;
                    const matchesStatus = status === 'all' || transaction.status === status;
                    const matchesDate = date === '' || transaction.date === date;
                    
                    return matchesSearch && matchesType && matchesStatus && matchesDate;
                });
                
                return this.filteredTransactions;
            }
            
            filterOrders(searchTerm = '', status = 'all') {
                this.filteredOrders = this.orders.filter(order => {
                    const matchesSearch = order.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
                                         order.client.toLowerCase().includes(searchTerm.toLowerCase());
                    const matchesStatus = status === 'all' || order.status === status;
                    
                    return matchesSearch && matchesStatus;
                });
                
                return this.filteredOrders;
            }
            
            // Paginación
            getPaginatedTransactions(page = 1) {
                const startIndex = (page - 1) * this.itemsPerPage;
                const endIndex = startIndex + this.itemsPerPage;
                return this.filteredTransactions.slice(startIndex, endIndex);
            }
            
            getPaginatedOrders(page = 1) {
                const startIndex = (page - 1) * this.itemsPerPage;
                const endIndex = startIndex + this.itemsPerPage;
                return this.filteredOrders.slice(startIndex, endIndex);
            }
            
            getTotalTransactionPages() {
                return Math.ceil(this.filteredTransactions.length / this.itemsPerPage);
            }
            
            getTotalOrderPages() {
                return Math.ceil(this.filteredOrders.length / this.itemsPerPage);
            }
            
            // CRUD
            getTransactionById(id) {
                return this.transactions.find(t => t.id === id);
            }
            
            getOrderById(id) {
                return this.orders.find(o => o.id === id);
            }
            
            addTransaction(transaction) {
                // Generar ID
                const lastId = this.transactions.length > 0 
                    ? parseInt(this.transactions[this.transactions.length - 1].id.split('-')[1]) 
                    : 78900;
                transaction.id = `TXN-${lastId + 1}`;
                
                // Calcular total
                const subtotal = transaction.products.reduce((sum, p) => sum + (p.price * p.quantity), 0);
                const tax = (subtotal * (transaction.taxRate || 10)) / 100;
                const discount = transaction.discount || 0;
                transaction.total = subtotal + tax - discount;
                transaction.subtotal = subtotal;
                transaction.tax = tax;
                
                this.transactions.push(transaction);
                this.saveData();
                
                this.addNotification(
                    'Nueva transacción creada',
                    `Transacción ${transaction.id} por $${transaction.total.toFixed(2)}`,
                    'transaction'
                );
                
                return transaction.id;
            }
            
            updateOrderStatus(id, newStatus, notes = '', notify = false) {
                const order = this.getOrderById(id);
                if (!order) return false;
                
                const oldStatus = order.status;
                order.status = newStatus;
                
                if (notes) {
                    order.notes = (order.notes ? order.notes + '\n' : '') + 
                                 `[${new Date().toLocaleDateString()}] Estado cambiado de ${oldStatus} a ${newStatus}: ${notes}`;
                }
                
                this.saveData();
                
                this.addNotification(
                    'Estado de pedido actualizado',
                    `Pedido ${id} cambió de ${oldStatus} a ${newStatus}`,
                    'order'
                );
                
                if (notify && this.notificationSettings.whatsapp) {
                    this.sendWhatsAppNotification(order, 'order');
                }
                
                return true;
            }
            
            saveData() {
                localStorage.setItem('transactions', JSON.stringify(this.transactions));
                localStorage.setItem('orders', JSON.stringify(this.orders));
            }
            
            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'}"></i>
                    <span>${message}</span>
                `;
                
                document.getElementById('toastContainer').appendChild(toast);
                
                setTimeout(() => {
                    toast.style.animation = 'slideOutRight 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }
            
            // Datos para gráficos
            getSalesChartData() {
                const days = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
                const sales = [850, 1200, 950, 1100, 1450, 2100, 1800];
                
                return {
                    labels: days,
                    datasets: [{
                        label: 'Ventas ($)',
                        data: sales,
                        backgroundColor: 'rgba(58, 94, 199, 0.5)',
                        borderColor: '#3a5ec7',
                        borderWidth: 2
                    }]
                };
            }
            
            getOrdersChartData() {
                const statusCounts = {
                    'Nuevo': this.orders.filter(o => o.status === 'Nuevo').length,
                    'Procesando': this.orders.filter(o => o.status === 'Procesando').length,
                    'Enviado': this.orders.filter(o => o.status === 'Enviado').length,
                    'Entregado': this.orders.filter(o => o.status === 'Entregado').length,
                    'Cancelado': this.orders.filter(o => o.status === 'Cancelado').length
                };
                
                return {
                    labels: Object.keys(statusCounts),
                    datasets: [{
                        data: Object.values(statusCounts),
                        backgroundColor: [
                            '#3a5ec7',
                            '#ffc107',
                            '#17a2b8',
                            '#28a745',
                            '#dc3545'
                        ]
                    }]
                };
            }
            
            getTimelineData() {
                const now = new Date();
                const timeline = [];
                
                // Agregar transacciones recientes
                this.transactions.slice(0, 5).forEach(t => {
                    timeline.push({
                        type: 'transaction',
                        title: `Transacción ${t.id}`,
                        description: `${t.type} - ${t.client} - $${t.total}`,
                        date: t.date,
                        status: t.status,
                        icon: t.type === 'Venta' ? 'fa-shopping-cart' : 
                              t.type === 'Compra' ? 'fa-truck' : 'fa-undo',
                        color: t.type === 'Venta' ? 'var(--secondary)' : 
                               t.type === 'Compra' ? 'var(--primary)' : 'var(--warning)'
                    });
                });
                
                // Agregar pedidos recientes
                this.orders.slice(0, 5).forEach(o => {
                    timeline.push({
                        type: 'order',
                        title: `Pedido ${o.id}`,
                        description: `${o.client} - ${o.products.length} productos - Estado: ${o.status}`,
                        date: o.date,
                        status: o.status,
                        icon: 'fa-box',
                        color: o.status === 'Entregado' ? 'var(--secondary)' :
                               o.status === 'Enviado' ? 'var(--info)' :
                               o.status === 'Cancelado' ? 'var(--danger)' : 'var(--warning)'
                    });
                });
                
                return timeline.sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 10);
            }
        }

        // ============================================
        // INSTANCIA GLOBAL
        // ============================================
        const transactionManager = new EnhancedTransactionManager();

        // ============================================
        // FUNCIONES DE RENDERIZADO
        // ============================================
        
        // Renderizar tabla de transacciones
        function renderTransactionsTable() {
            const tableBody = document.getElementById('transactionsTableBody');
            if (!tableBody) return;
            
            const searchTerm = document.getElementById('searchInput')?.value || '';
            const type = document.getElementById('typeFilter')?.value || 'all';
            const status = document.getElementById('statusFilter')?.value || 'all';
            const date = document.getElementById('dateFilter')?.value || '';
            
            // Aplicar filtros
            transactionManager.filterTransactions(searchTerm, type, status, date);
            
            // Obtener datos paginados
            const transactions = transactionManager.getPaginatedTransactions(transactionManager.currentPage.transactions);
            const totalPages = transactionManager.getTotalTransactionPages();
            
            tableBody.innerHTML = '';
            
            if (transactions.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <div class="empty-state">
                                <i class="fas fa-inbox"></i>
                                <h4>No hay transacciones</h4>
                                <p>No se encontraron transacciones con los filtros aplicados</p>
                                <button class="btn btn-primary btn-sm mt-2" onclick="clearFilters()">
                                    <i class="fas fa-times me-2"></i>Limpiar filtros
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            } else {
                transactions.forEach(t => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td><span class="badge bg-primary">${t.id}</span></td>
                        <td><strong>${t.client}</strong></td>
                        <td><span class="badge ${t.type === 'Venta' ? 'bg-success' : t.type === 'Compra' ? 'bg-info' : 'bg-warning'}">${t.type}</span></td>
                        <td>${t.date}</td>
                        <td class="fw-bold ${t.total < 0 ? 'text-danger' : ''}">$${Math.abs(t.total).toFixed(2)}</td>
                        <td>${t.payment}</td>
                        <td><span class="badge ${transactionManager.getStatusClass(t.status)}">${t.status}</span></td>
                        <td>
                            <button class="action-btn btn-view" data-id="${t.id}" data-type="transaction" data-tooltip="Ver detalles">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="action-btn btn-edit" data-id="${t.id}" data-tooltip="Editar">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn btn-notify" data-id="${t.id}" data-type="transaction" data-tooltip="Notificar">
                                <i class="fab fa-whatsapp"></i>
                            </button>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });
            }
            
            // Actualizar contador
            document.getElementById('transactionCount').textContent = 
                `Mostrando ${transactions.length} de ${transactionManager.filteredTransactions.length} transacciones`;
            
            document.getElementById('transactionsPaginationInfo').textContent = 
                `Mostrando ${Math.min(transactions.length, transactionManager.filteredTransactions.length)} de ${transactionManager.filteredTransactions.length} transacciones`;
            
            // Renderizar paginación
            renderTransactionsPagination(totalPages);
            
            // Agregar event listeners a los botones
            addTransactionTableListeners();
        }
        
        // Renderizar paginación de transacciones
        function renderTransactionsPagination(totalPages) {
            const pagination = document.getElementById('transactionsPagination');
            if (!pagination) return;
            
            pagination.innerHTML = '';
            
            if (totalPages <= 1) {
                return;
            }
            
            const currentPage = transactionManager.currentPage.transactions;
            
            // Botón anterior
            const prevLi = document.createElement('li');
            prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
            prevLi.innerHTML = `<a class="page-link" href="#"><i class="fas fa-chevron-left"></i></a>`;
            prevLi.addEventListener('click', (e) => {
                e.preventDefault();
                if (currentPage > 1) {
                    transactionManager.currentPage.transactions--;
                    renderTransactionsTable();
                }
            });
            pagination.appendChild(prevLi);
            
            // Números de página
            for (let i = 1; i <= totalPages; i++) {
                const pageLi = document.createElement('li');
                pageLi.className = `page-item ${currentPage === i ? 'active' : ''}`;
                pageLi.innerHTML = `<a class="page-link" href="#">${i}</a>`;
                pageLi.addEventListener('click', (e) => {
                    e.preventDefault();
                    transactionManager.currentPage.transactions = i;
                    renderTransactionsTable();
                });
                pagination.appendChild(pageLi);
            }
            
            // Botón siguiente
            const nextLi = document.createElement('li');
            nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
            nextLi.innerHTML = `<a class="page-link" href="#"><i class="fas fa-chevron-right"></i></a>`;
            nextLi.addEventListener('click', (e) => {
                e.preventDefault();
                if (currentPage < totalPages) {
                    transactionManager.currentPage.transactions++;
                    renderTransactionsTable();
                }
            });
            pagination.appendChild(nextLi);
        }
        
        // Renderizar tabla de pedidos
        function renderOrdersTable() {
            const tableBody = document.getElementById('ordersTableBody');
            if (!tableBody) return;
            
            const searchTerm = document.getElementById('searchInput')?.value || '';
            const status = document.getElementById('statusFilter')?.value || 'all';
            
            // Aplicar filtros
            transactionManager.filterOrders(searchTerm, status);
            
            // Obtener datos paginados
            const orders = transactionManager.getPaginatedOrders(transactionManager.currentPage.orders);
            const totalPages = transactionManager.getTotalOrderPages();
            
            tableBody.innerHTML = '';
            
            if (orders.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="7" class="text-center py-4">
                            <div class="empty-state">
                                <i class="fas fa-inbox"></i>
                                <h4>No hay pedidos</h4>
                                <p>No se encontraron pedidos con los filtros aplicados</p>
                                <button class="btn btn-primary btn-sm mt-2" onclick="clearFilters()">
                                    <i class="fas fa-times me-2"></i>Limpiar filtros
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            } else {
                orders.forEach(o => {
                    const total = (o.subtotal + (o.shipping || 0) + o.tax).toFixed(2);
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td><span class="badge bg-primary">${o.id}</span></td>
                        <td><strong>${o.client}</strong></td>
                        <td>${o.date}</td>
                        <td>${o.products.length} productos</td>
                        <td class="fw-bold">$${total}</td>
                        <td><span class="badge ${transactionManager.getStatusClass(o.status)}">${o.status}</span></td>
                        <td>
                            <button class="action-btn btn-view" data-id="${o.id}" data-type="order" data-tooltip="Ver detalles">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="action-btn btn-process" data-id="${o.id}" data-type="order" data-tooltip="Actualizar estado">
                                <i class="fas fa-sync"></i>
                            </button>
                            <button class="action-btn btn-notify" data-id="${o.id}" data-type="order" data-tooltip="Notificar">
                                <i class="fab fa-whatsapp"></i>
                            </button>
                            <button class="action-btn btn-track" data-id="${o.id}" data-tooltip="Seguimiento">
                                <i class="fas fa-map-marker-alt"></i>
                            </button>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });
            }
            
            // Actualizar contador
            document.getElementById('ordersCount').textContent = 
                `Mostrando ${orders.length} de ${transactionManager.filteredOrders.length} pedidos`;
            
            document.getElementById('ordersPaginationInfo').textContent = 
                `Mostrando ${Math.min(orders.length, transactionManager.filteredOrders.length)} de ${transactionManager.filteredOrders.length} pedidos`;
            
            // Renderizar paginación
            renderOrdersPagination(totalPages);
            
            // Agregar event listeners a los botones
            addOrderTableListeners();
        }
        
        // Renderizar paginación de pedidos
        function renderOrdersPagination(totalPages) {
            const pagination = document.getElementById('ordersPagination');
            if (!pagination) return;
            
            pagination.innerHTML = '';
            
            if (totalPages <= 1) {
                return;
            }
            
            const currentPage = transactionManager.currentPage.orders;
            
            // Botón anterior
            const prevLi = document.createElement('li');
            prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
            prevLi.innerHTML = `<a class="page-link" href="#"><i class="fas fa-chevron-left"></i></a>`;
            prevLi.addEventListener('click', (e) => {
                e.preventDefault();
                if (currentPage > 1) {
                    transactionManager.currentPage.orders--;
                    renderOrdersTable();
                }
            });
            pagination.appendChild(prevLi);
            
            // Números de página
            for (let i = 1; i <= totalPages; i++) {
                const pageLi = document.createElement('li');
                pageLi.className = `page-item ${currentPage === i ? 'active' : ''}`;
                pageLi.innerHTML = `<a class="page-link" href="#">${i}</a>`;
                pageLi.addEventListener('click', (e) => {
                    e.preventDefault();
                    transactionManager.currentPage.orders = i;
                    renderOrdersTable();
                });
                pagination.appendChild(pageLi);
            }
            
            // Botón siguiente
            const nextLi = document.createElement('li');
            nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
            nextLi.innerHTML = `<a class="page-link" href="#"><i class="fas fa-chevron-right"></i></a>`;
            nextLi.addEventListener('click', (e) => {
                e.preventDefault();
                if (currentPage < totalPages) {
                    transactionManager.currentPage.orders++;
                    renderOrdersTable();
                }
            });
            pagination.appendChild(nextLi);
        }
        
        // Renderizar timeline
        function renderTimeline() {
            const container = document.getElementById('timelineContainer');
            if (!container) return;
            
            const timeline = transactionManager.getTimelineData();
            
            if (timeline.length === 0) {
                container.innerHTML = '<p class="text-center text-muted">No hay actividad reciente</p>';
                return;
            }
            
            let html = '<div class="timeline">';
            
            timeline.forEach(item => {
                html += `
                    <div class="timeline-item">
                        <div class="timeline-marker" style="background: ${item.color}"></div>
                        <div class="timeline-content">
                            <div class="timeline-date">${item.date}</div>
                            <div class="timeline-title">
                                <i class="fas ${item.icon}" style="color: ${item.color}"></i>
                                ${item.title}
                            </div>
                            <div class="timeline-desc">${item.description}</div>
                            <span class="badge ${transactionManager.getStatusClass(item.status)}">${item.status}</span>
                        </div>
                    </div>
                `;
            });
            
            html += '</div>';
            container.innerHTML = html;
        }
        
        // Renderizar estadísticas
        function renderStats() {
            const stats = transactionManager.getStats();
            
            document.getElementById('monthlySales').textContent = `$${stats.monthlySales.toFixed(2)}`;
            document.getElementById('activeOrders').textContent = stats.activeOrders;
            document.getElementById('pendingOrders').textContent = stats.pendingOrders;
            document.getElementById('completedToday').textContent = stats.completedToday;
        }
        
        // Renderizar notificaciones
        function renderNotifications() {
            const list = document.getElementById('notificationList');
            const badge = document.getElementById('notificationBadge');
            
            if (!list || !badge) return;
            
            const unreadCount = transactionManager.getUnreadNotifications().length;
            badge.textContent = unreadCount;
            badge.classList.toggle('hidden', unreadCount === 0);
            
            list.innerHTML = '';
            
            transactionManager.notifications.slice(0, 5).forEach(notification => {
                const item = document.createElement('div');
                item.className = `notification-item ${notification.read ? '' : 'unread'}`;
                item.dataset.id = notification.id;
                item.innerHTML = `
                    <strong>${notification.title}</strong>
                    <p>${notification.message}</p>
                    <small>${notification.time}</small>
                `;
                item.addEventListener('click', () => {
                    transactionManager.markNotificationAsRead(notification.id);
                    renderNotifications();
                });
                list.appendChild(item);
            });
        }
        
        // Renderizar gráficos
        function renderCharts() {
            // Gráfico de ventas
            const salesCtx = document.getElementById('salesChart')?.getContext('2d');
            if (salesCtx) {
                if (transactionManager.charts.sales) {
                    transactionManager.charts.sales.destroy();
                }
                
                transactionManager.charts.sales = new Chart(salesCtx, {
                    type: 'bar',
                    data: transactionManager.getSalesChartData(),
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {
                                    color: 'rgba(0,0,0,0.05)'
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                }
                            }
                        }
                    }
                });
            }
            
            // Gráfico de pedidos
            const ordersCtx = document.getElementById('ordersChart')?.getContext('2d');
            if (ordersCtx) {
                if (transactionManager.charts.orders) {
                    transactionManager.charts.orders.destroy();
                }
                
                transactionManager.charts.orders = new Chart(ordersCtx, {
                    type: 'doughnut',
                    data: transactionManager.getOrdersChartData(),
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            }
                        },
                        cutout: '60%'
                    }
                });
            }
        }
        
        // ============================================
        // FUNCIONES DE EVENTOS
        // ============================================
        
        function addTransactionTableListeners() {
            // Botones de ver
            document.querySelectorAll('#transactionsTableBody .btn-view').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    showTransactionDetails(id);
                });
            });
            
            // Botones de notificar
            document.querySelectorAll('#transactionsTableBody .btn-notify').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const type = this.getAttribute('data-type');
                    showNotificationModal(id, type);
                });
            });
            
            // Botones de editar
            document.querySelectorAll('#transactionsTableBody .btn-edit').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    transactionManager.showNotification(`Editando transacción ${id}`, 'info');
                });
            });
        }
        
        function addOrderTableListeners() {
            // Botones de ver
            document.querySelectorAll('#ordersTableBody .btn-view').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    showOrderDetails(id);
                });
            });
            
            // Botones de notificar
            document.querySelectorAll('#ordersTableBody .btn-notify').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const type = this.getAttribute('data-type');
                    showNotificationModal(id, type);
                });
            });
            
            // Botones de actualizar estado
            document.querySelectorAll('#ordersTableBody .btn-process').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    showUpdateOrderStatusModal(id);
                });
            });
            
            // Botones de seguimiento
            document.querySelectorAll('#ordersTableBody .btn-track').forEach(btn => {
                btn.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    transactionManager.showNotification(`Seguimiento del pedido ${id}`, 'info');
                });
            });
        }
        
        function showTransactionDetails(id) {
            const transaction = transactionManager.getTransactionById(id);
            if (!transaction) return;
            
            document.getElementById('viewTransactionId').textContent = transaction.id;
            document.getElementById('viewTransactionClient').textContent = transaction.client;
            document.getElementById('viewTransactionPhone').textContent = transaction.phone || 'No disponible';
            document.getElementById('viewTransactionEmail').textContent = transaction.email || 'No disponible';
            document.getElementById('viewTransactionType').textContent = transaction.type;
            document.getElementById('viewTransactionDate').textContent = transaction.date;
            document.getElementById('viewTransactionPayment').textContent = transaction.payment;
            
            const statusSpan = document.getElementById('viewTransactionStatus');
            statusSpan.textContent = transaction.status;
            statusSpan.className = `badge ${transactionManager.getStatusClass(transaction.status)}`;
            
            // Productos
            const productsDiv = document.getElementById('viewTransactionProducts');
            if (transaction.products && transaction.products.length > 0) {
                let productsHtml = '';
                transaction.products.forEach(p => {
                    productsHtml += `
                        <div class="product-item">
                            <div class="product-info">
                                <div class="product-name">${p.name}</div>
                                <div class="product-meta">Cantidad: ${p.quantity}</div>
                            </div>
                            <div class="product-price">$${(p.price * p.quantity).toFixed(2)}</div>
                        </div>
                    `;
                });
                productsDiv.innerHTML = productsHtml;
            } else {
                productsDiv.innerHTML = '<p class="text-muted p-3">No hay productos en esta transacción</p>';
            }
            
            // Totales
            document.getElementById('viewTransactionSubtotal').textContent = `$${(transaction.subtotal || transaction.total).toFixed(2)}`;
            document.getElementById('viewTransactionTax').textContent = `$${(transaction.tax || 0).toFixed(2)}`;
            document.getElementById('viewTransactionDiscount').textContent = `$${(transaction.discount || 0).toFixed(2)}`;
            document.getElementById('viewTransactionTotal').textContent = `$${transaction.total.toFixed(2)}`;
            document.getElementById('viewTransactionNotes').textContent = transaction.notes || 'Sin notas adicionales';
            
            // Configurar botones
            document.getElementById('btnNotifyTransaction').onclick = () => {
                showNotificationModal(transaction.id, 'transaction');
            };
            
            const modal = new bootstrap.Modal(document.getElementById('viewTransactionModal'));
            modal.show();
        }
        
        function showOrderDetails(id) {
            const order = transactionManager.getOrderById(id);
            if (!order) return;
            
            const total = (order.subtotal + (order.shipping || 0) + order.tax).toFixed(2);
            
            document.getElementById('viewOrderId').textContent = order.id;
            document.getElementById('viewOrderClient').textContent = order.client;
            document.getElementById('viewOrderEmail').textContent = order.email || 'No disponible';
            document.getElementById('viewOrderPhone').textContent = order.phone || 'No disponible';
            document.getElementById('viewOrderDate').textContent = order.date;
            document.getElementById('viewOrderShipping').textContent = order.shippingMethod || 'No especificado';
            document.getElementById('viewOrderAddress').textContent = order.address || 'No especificada';
            
            const statusSpan = document.getElementById('viewOrderStatus');
            statusSpan.textContent = order.status;
            statusSpan.className = `badge ${transactionManager.getStatusClass(order.status)}`;
            
            // Productos
            const productsDiv = document.getElementById('viewOrderProducts');
            if (order.products && order.products.length > 0) {
                let productsHtml = '';
                order.products.forEach(p => {
                    productsHtml += `
                        <div class="product-item">
                            <div class="product-info">
                                <div class="product-name">${p.name}</div>
                                <div class="product-meta">Cantidad: ${p.quantity}</div>
                            </div>
                            <div class="product-price">$${(p.price * p.quantity).toFixed(2)}</div>
                        </div>
                    `;
                });
                productsDiv.innerHTML = productsHtml;
            } else {
                productsDiv.innerHTML = '<p class="text-muted p-3">No hay productos en este pedido</p>';
            }
            
            // Totales
            document.getElementById('viewOrderSubtotal').textContent = `$${(order.subtotal || 0).toFixed(2)}`;
            document.getElementById('viewOrderShippingCost').textContent = `$${(order.shipping || 0).toFixed(2)}`;
            document.getElementById('viewOrderTax').textContent = `$${(order.tax || 0).toFixed(2)}`;
            document.getElementById('viewOrderTotal').textContent = `$${total}`;
            document.getElementById('viewOrderNotes').textContent = order.notes || 'Sin notas adicionales';
            
            // Configurar botones
            document.getElementById('btnUpdateOrderStatus').onclick = () => {
                const modal = bootstrap.Modal.getInstance(document.getElementById('viewOrderModal'));
                modal.hide();
                showUpdateOrderStatusModal(order.id);
            };
            
            document.getElementById('btnNotifyOrder').onclick = () => {
                showNotificationModal(order.id, 'order');
            };
            
            const modal = new bootstrap.Modal(document.getElementById('viewOrderModal'));
            modal.show();
        }
        
        function showNotificationModal(itemId, itemType) {
            let item = null;
            if (itemType === 'transaction') {
                item = transactionManager.getTransactionById(itemId);
            } else if (itemType === 'order') {
                item = transactionManager.getOrderById(itemId);
            }
            
            if (!item) return;
            
            transactionManager.currentNotificationItem = item;
            transactionManager.currentNotificationType = itemType;
            
            const modal = new bootstrap.Modal(document.getElementById('notificationModal'));
            modal.show();
        }
        
        function showUpdateOrderStatusModal(orderId) {
            const order = transactionManager.getOrderById(orderId);
            if (!order) return;
            
            document.getElementById('updateOrderId').value = orderId;
            document.getElementById('newOrderStatus').value = order.status;
            document.getElementById('statusNotes').value = '';
            document.getElementById('notifyCustomer').checked = true;
            
            const modal = new bootstrap.Modal(document.getElementById('updateOrderStatusModal'));
            modal.show();
        }
        
        function clearFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('typeFilter').value = 'all';
            document.getElementById('statusFilter').value = 'all';
            document.getElementById('dateFilter').value = '';
            
            transactionManager.currentPage.transactions = 1;
            transactionManager.currentPage.orders = 1;
            
            renderTransactionsTable();
            renderOrdersTable();
        }
        
        // ============================================
        // INICIALIZACIÓN
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            // Cargar tema guardado
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            }
            
            // Renderizar todo
            renderStats();
            renderNotifications();
            renderTransactionsTable();
            renderOrdersTable();
            renderTimeline();
            renderCharts();
            
            // Configuración de notificaciones
            document.getElementById('whatsappNotifications').checked = transactionManager.notificationSettings.whatsapp;
            document.getElementById('smsNotifications').checked = transactionManager.notificationSettings.sms;
            document.getElementById('emailNotifications').checked = transactionManager.notificationSettings.email;
            document.getElementById('stockNotifications').checked = transactionManager.notificationSettings.stock;
            
            // Event listeners para configuración de notificaciones
            document.getElementById('whatsappNotifications').addEventListener('change', function() {
                transactionManager.updateNotificationSettings({ whatsapp: this.checked });
            });
            
            document.getElementById('smsNotifications').addEventListener('change', function() {
                transactionManager.updateNotificationSettings({ sms: this.checked });
            });
            
            document.getElementById('emailNotifications').addEventListener('change', function() {
                transactionManager.updateNotificationSettings({ email: this.checked });
            });
            
            document.getElementById('stockNotifications').addEventListener('change', function() {
                transactionManager.updateNotificationSettings({ stock: this.checked });
            });
            
            // Event listeners para notificaciones
            document.querySelectorAll('.notification-type').forEach(element => {
                element.addEventListener('click', function() {
                    const notificationType = this.getAttribute('data-type');
                    const item = transactionManager.currentNotificationItem;
                    const itemType = transactionManager.currentNotificationType;
                    
                    if (item && itemType) {
                        transactionManager.sendNotification(item, itemType, notificationType);
                    }
                    
                    const modal = bootstrap.Modal.getInstance(document.getElementById('notificationModal'));
                    modal.hide();
                });
            });
            
            // Event listeners generales
            document.getElementById('themeToggle').addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
                const icon = this.querySelector('i');
                icon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
                localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
            });
            
            document.getElementById('menuToggle').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('open');
            });
            
            document.getElementById('notificationBtn').addEventListener('click', function() {
                document.getElementById('notificationDropdown').classList.toggle('show');
            });
            
            document.getElementById('markAllRead').addEventListener('click', function() {
                transactionManager.markAllNotificationsAsRead();
                renderNotifications();
            });
            
            document.getElementById('searchInput').addEventListener('input', function() {
                transactionManager.currentPage.transactions = 1;
                transactionManager.currentPage.orders = 1;
                renderTransactionsTable();
                renderOrdersTable();
            });
            
            document.getElementById('typeFilter').addEventListener('change', function() {
                transactionManager.currentPage.transactions = 1;
                renderTransactionsTable();
            });
            
            document.getElementById('statusFilter').addEventListener('change', function() {
                transactionManager.currentPage.transactions = 1;
                transactionManager.currentPage.orders = 1;
                renderTransactionsTable();
                renderOrdersTable();
            });
            
            document.getElementById('dateFilter').addEventListener('change', function() {
                transactionManager.currentPage.transactions = 1;
                renderTransactionsTable();
            });
            
            document.getElementById('clearFilters').addEventListener('click', clearFilters);
            
            document.getElementById('exportBtn').addEventListener('click', function() {
                transactionManager.showNotification('Exportando datos...', 'info');
            });
            
            document.getElementById('refreshTransactions').addEventListener('click', function() {
                renderTransactionsTable();
                transactionManager.showNotification('Tabla de transacciones actualizada', 'success');
            });
            
            document.getElementById('refreshOrders').addEventListener('click', function() {
                renderOrdersTable();
                transactionManager.showNotification('Tabla de pedidos actualizada', 'success');
            });
            
            // Event listeners para modales
            document.getElementById('addProductToTransaction').addEventListener('click', function() {
                const list = document.getElementById('transactionProductsList');
                const productCount = list.children.length;
                
                const productHtml = `
                    <div class="row mb-2 product-row">
                        <div class="col-md-5">
                            <input type="text" class="form-control product-name" placeholder="Nombre del producto">
                        </div>
                        <div class="col-md-3">
                            <input type="number" class="form-control product-price" placeholder="Precio" min="0" step="0.01">
                        </div>
                        <div class="col-md-2">
                            <input type="number" class="form-control product-quantity" placeholder="Cantidad" min="1" value="1">
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-sm btn-danger remove-product">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                `;
                
                list.insertAdjacentHTML('beforeend', productHtml);
                
                // Agregar event listener al botón de eliminar
                list.lastElementChild.querySelector('.remove-product').addEventListener('click', function() {
                    this.closest('.product-row').remove();
                });
            });
            
            document.getElementById('saveTransaction').addEventListener('click', function() {
                const form = document.getElementById('addTransactionForm');
                if (!form.checkValidity()) {
                    form.reportValidity();
                    return;
                }
                
                // Recoger productos
                const productRows = document.querySelectorAll('.product-row');
                if (productRows.length === 0) {
                    transactionManager.showNotification('Debe agregar al menos un producto', 'error');
                    return;
                }
                
                const products = [];
                productRows.forEach(row => {
                    const name = row.querySelector('.product-name').value;
                    const price = parseFloat(row.querySelector('.product-price').value);
                    const quantity = parseInt(row.querySelector('.product-quantity').value);
                    
                    if (name && !isNaN(price) && !isNaN(quantity)) {
                        products.push({ name, price, quantity });
                    }
                });
                
                if (products.length === 0) {
                    transactionManager.showNotification('Debe completar los datos de los productos', 'error');
                    return;
                }
                
                const transaction = {
                    client: document.getElementById('transactionClient').value,
                    type: document.getElementById('transactionType').value,
                    date: document.getElementById('transactionDate').value.split('-').reverse().join('/'),
                    payment: document.getElementById('transactionPayment').value,
                    status: document.getElementById('transactionStatus').value,
                    phone: document.getElementById('transactionPhone').value,
                    email: document.getElementById('transactionEmail').value,
                    products: products,
                    discount: parseFloat(document.getElementById('transactionDiscount').value) || 0,
                    taxRate: parseFloat(document.getElementById('transactionTax').value) || 10,
                    notes: document.getElementById('transactionNotes').value
                };
                
                transactionManager.addTransaction(transaction);
                
                // Cerrar modal y actualizar
                const modal = bootstrap.Modal.getInstance(document.getElementById('addTransactionModal'));
                modal.hide();
                
                renderTransactionsTable();
                renderStats();
                
                // Limpiar formulario
                form.reset();
                document.getElementById('transactionProductsList').innerHTML = '';
            });
            
            document.getElementById('confirmUpdateStatus').addEventListener('click', function() {
                const orderId = document.getElementById('updateOrderId').value;
                const newStatus = document.getElementById('newOrderStatus').value;
                const notes = document.getElementById('statusNotes').value;
                const notify = document.getElementById('notifyCustomer').checked;
                
                transactionManager.updateOrderStatus(orderId, newStatus, notes, notify);
                
                const modal = bootstrap.Modal.getInstance(document.getElementById('updateOrderStatusModal'));
                modal.hide();
                
                renderOrdersTable();
            });
            
            document.getElementById('btnPrintTransaction').addEventListener('click', function() {
                window.print();
            });
            
            document.getElementById('viewAllNotifications').addEventListener('click', function(e) {
                e.preventDefault();
                transactionManager.showNotification('Mostrando todas las notificaciones', 'info');
                document.getElementById('notificationDropdown').classList.remove('show');
            });
            
            // Cerrar dropdown de notificaciones al hacer clic fuera
            document.addEventListener('click', function(event) {
                const btn = document.getElementById('notificationBtn');
                const dropdown = document.getElementById('notificationDropdown');
                
                if (btn && dropdown && !btn.contains(event.target) && !dropdown.contains(event.target)) {
                    dropdown.classList.remove('show');
                }
            });
            
            // Actualizar estadísticas y notificaciones cada 30 segundos
            setInterval(() => {
                renderStats();
                renderNotifications();
            }, 30000);
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>