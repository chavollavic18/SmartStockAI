<?php
// login_process.php - VERSIÓN DEBUG COMPLETA
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

try {
    // Verificar que los archivos existan
    $database_file = __DIR__ . '/app/Config/Database.php';
    $usermodel_file = __DIR__ . '/app/Models/UserModel.php';
    $authcontroller_file = __DIR__ . '/app/Controllers/AuthController.php';
    
    if (!file_exists($database_file)) {
        throw new Exception("No existe: app/Config/Database.php");
    }
    if (!file_exists($usermodel_file)) {
        throw new Exception("No existe: app/Models/UserModel.php");
    }
    if (!file_exists($authcontroller_file)) {
        throw new Exception("No existe: app/Controllers/AuthController.php");
    }
    
    // Incluir archivos
    require_once $database_file;
    require_once $usermodel_file;
    require_once $authcontroller_file;
    
    // Verificar que las clases existan
    if (!class_exists('Database')) {
        throw new Exception("Clase Database no existe");
    }
    if (!class_exists('UserModel')) {
        throw new Exception("Clase UserModel no existe");
    }
    if (!class_exists('AuthController')) {
        throw new Exception("Clase AuthController no existe");
    }
    
    echo json_encode(['debug' => '✅ Todos los archivos cargados correctamente']);
    exit;
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Error en configuración: ' . $e->getMessage()
    ]);
    exit;
}
?>