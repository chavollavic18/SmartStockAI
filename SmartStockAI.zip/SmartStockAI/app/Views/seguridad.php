<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Seguridad Avanzada</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- CryptoJS para cifrado avanzado -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 250px;
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #000000;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #000000;
            transition: var(--transition);
            min-height: 100vh;
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--primary);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: var(--transition);
            border-left: 4px solid transparent;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .sidebar-menu i {
            width: 25px;
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: var(--transition);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: #000000;
        }

        .controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: #000000;
            position: relative;
        }

        .theme-switcher:hover, .notifications:hover {
            transform: translateY(-3px);
        }

        /* Sección de Seguridad */
        .security-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .security-tabs {
            display: flex;
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .security-tab {
            padding: 12px 20px;
            background: none;
            border: none;
            border-bottom: 3px solid transparent;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            color: var(--gray);
        }

        .security-tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .security-tab:hover {
            color: var(--primary);
        }

        .security-content {
            display: none;
        }

        .security-content.active {
            display: block;
        }

        .security-group {
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e9ecef;
        }

        .security-group:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }

        .security-group-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary);
            display: flex;
            align-items: center;
        }

        .security-group-title i {
            margin-right: 10px;
            font-size: 20px;
        }

        .security-row {
            display: flex;
            gap: 20px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        .security-item {
            flex: 1;
            min-width: 250px;
        }

        .security-label {
            font-weight: 500;
            margin-bottom: 8px;
            display: block;
        }

        .security-description {
            font-size: 0.85rem;
            color: var(--gray);
            margin-top: 5px;
        }

        .security-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }

        /* Indicadores de Seguridad */
        .security-indicators {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }

        .security-indicator {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            text-align: center;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary);
        }

        .indicator-value {
            font-size: 2rem;
            font-weight: 700;
            margin: 10px 0;
        }

        .indicator-title {
            color: var(--gray);
            font-size: 0.9rem;
        }

        .indicator-good {
            border-left-color: var(--secondary);
        }

        .indicator-warning {
            border-left-color: var(--warning);
        }

        .indicator-danger {
            border-left-color: var(--danger);
        }

        /* Toggle Switch */
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }

        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .toggle-slider {
            background-color: var(--primary);
        }

        input:checked + .toggle-slider:before {
            transform: translateX(30px);
        }

        /* Niveles de Seguridad */
        .security-level {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }

        .level-high {
            background-color: #d4edda;
            color: #155724;
        }

        .level-medium {
            background-color: #fff3cd;
            color: #856404;
        }

        .level-low {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Logs de Seguridad */
        .security-logs {
            max-height: 300px;
            overflow-y: auto;
            border: 1px solid #e9ecef;
            border-radius: var(--border-radius);
            padding: 15px;
        }

        .log-entry {
            padding: 10px;
            border-bottom: 1px solid #f1f1f1;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .log-entry:last-child {
            border-bottom: none;
        }

        .log-info {
            flex: 1;
        }

        .log-time {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .log-action {
            font-weight: 500;
        }

        .log-user {
            color: var(--primary);
        }

        .log-severity {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .severity-high {
            background-color: #f8d7da;
            color: #721c24;
        }

        .severity-medium {
            background-color: #fff3cd;
            color: #856404;
        }

        .severity-low {
            background-color: #d1ecf1;
            color: #0c5460;
        }

        /* Toast de notificaciones */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
        }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s forwards;
            color: #000000;
        }

        .toast.success {
            border-left: 4px solid var(--secondary);
        }

        .toast.error {
            border-left: 4px solid var(--danger);
        }

        .toast.warning {
            border-left: 4px solid var(--warning);
        }

        .toast i {
            margin-right: 10px;
            font-size: 20px;
        }

        .toast.success i {
            color: var(--secondary);
        }

        .toast.error i {
            color: var(--danger);
        }

        .toast.warning i {
            color: var(--warning);
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 0;
            }
            
            .sidebar.open {
                transform: translateX(0);
                width: var(--sidebar-width);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
            }

            .security-row {
                flex-direction: column;
            }

            .security-item {
                min-width: 100%;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .controls {
                margin-top: 15px;
            }
            
            .menu-toggle {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .security-tabs {
                flex-direction: column;
            }

            .security-tab {
                border-bottom: 1px solid #dee2e6;
                border-left: 3px solid transparent;
            }

            .security-tab.active {
                border-left-color: var(--primary);
                border-bottom-color: #dee2e6;
            }

            .security-indicators {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px;
            }
            
            .security-section {
                padding: 15px;
            }
            
            .security-actions {
                flex-direction: column;
            }
            
            .security-actions .btn {
                width: 100%;
                margin-bottom: 10px;
            }
        }

        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 1001;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        /* Asegurar que todos los textos sean negros */
        body, body *:not(.sidebar *):not(.action-btn):not(.security-level):not(.log-severity) {
            color: #000000 !important;
        }

        /* Ajustes para mantener contraste en elementos especiales */
        .sidebar, .action-btn, .security-level, .log-severity {
            color: white !important;
        }

        /* Inputs y selects */
        .form-control, .form-select {
            color: #000000 !important;
            background-color: #ffffff !important;
        }

        .form-control::placeholder {
            color: #666 !important;
        }

        /* Barras de progreso */
        .progress {
            height: 10px;
            margin: 10px 0;
        }

        .password-strength {
            margin-top: 10px;
        }

        .strength-weak { background-color: var(--danger); }
        .strength-fair { background-color: var(--warning); }
        .strength-good { background-color: var(--info); }
        .strength-strong { background-color: var(--secondary); }

        /* Panel de Auditoría */
        .audit-panel {
            background: #f8f9fa;
            border-radius: var(--border-radius);
            padding: 15px;
            margin: 15px 0;
        }

        .encryption-status {
            display: inline-flex;
            align-items: center;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .encryption-active {
            background-color: #d4edda;
            color: #155724;
        }

        .encryption-inactive {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot me-2"></i>SmartStock AI
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <li><a href="http://localhost/SmartStockAI/admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes"></i> Inventario</a></li>
                <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck"></i> Proveedores</a></li>
                <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users"></i> Usuarios</a></li>
                <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-exchange-alt"></i> Transacciones</a></li>
                <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-line"></i> Reportes</a></li>
                <li><a href="http://localhost/SmartStockAI/clientes.php"><i class="fas fa-user-friends"></i> Clientes</a></li>
                <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-user"></i> Mi Perfil</a></li>
                <li><a href="#" class="active"><i class="fas fa-shield-alt"></i> Seguridad</a></li>
                <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-cog"></i> Configuraciones</a></li>
                <li><a href="http://localhost/SmartStockAI/login.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1 class="page-title">Seguridad Avanzada <span class="security-level level-high">ALTA SEGURIDAD</span></h1>
                
                <div class="controls">
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notifications" id="notificationBtn">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge hidden" id="notificationBadge">0</span>
                    </div>
                </div>
            </div>
            
            <!-- Indicadores de Seguridad -->
            <div class="security-indicators">
                <div class="security-indicator indicator-good">
                    <div class="indicator-value" id="securityScore">92%</div>
                    <div class="indicator-title">Puntuación de Seguridad</div>
                </div>
                <div class="security-indicator indicator-good">
                    <div class="indicator-value" id="threatsBlocked">1,247</div>
                    <div class="indicator-title">Amenazas Bloqueadas</div>
                </div>
                <div class="security-indicator indicator-good">
                    <div class="indicator-value" id="encryptionStatus">AES-256</div>
                    <div class="indicator-title">Cifrado Activo</div>
                </div>
                <div class="security-indicator indicator-good">
                    <div class="indicator-value" id="lastBreach">Nunca</div>
                    <div class="indicator-title">Última Brecha</div>
                </div>
            </div>
            
            <!-- Sección de Seguridad -->
            <div class="security-section">
                <div class="security-tabs">
                    <button class="security-tab active" data-tab="autenticacion">
                        <i class="fas fa-fingerprint me-2"></i>Autenticación
                    </button>
                    <button class="security-tab" data-tab="accesos">
                        <i class="fas fa-lock me-2"></i>Control de Accesos
                    </button>
                    <button class="security-tab" data-tab="cifrado">
                        <i class="fas fa-key me-2"></i>Cifrado de Datos
                    </button>
                    <button class="security-tab" data-tab="monitoreo">
                        <i class="fas fa-shield-alt me-2"></i>Monitoreo
                    </button>
                    <button class="security-tab" data-tab="auditoria">
                        <i class="fas fa-clipboard-list me-2"></i>Auditoría
                    </button>
                    <button class="security-tab" data-tab="respuesta">
                        <i class="fas fa-bug me-2"></i>Respuesta a Incidentes
                    </button>
                </div>
                
                <!-- Pestaña Autenticación -->
                <div class="security-content active" id="autenticacion-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-user-shield"></i>Autenticación Multi-Factor
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Autenticación de Dos Factores (2FA)</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="twoFactorAuth" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="twoFactorStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Requerir verificación en dos pasos para todos los usuarios
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Método de 2FA</label>
                                <select class="form-select" id="twoFactorMethod">
                                    <option value="app">Aplicación Authenticator</option>
                                    <option value="sms">SMS</option>
                                    <option value="email">Email</option>
                                    <option value="hardware">Token Hardware</option>
                                </select>
                                <div class="security-description">
                                    Método preferido para autenticación de dos factores
                                </div>
                            </div>
                        </div>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Biometría</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="biometricAuth">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="biometricStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">
                                    Permitir autenticación mediante huella digital o reconocimiento facial
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Tiempo de Sesión</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="sessionTimeout" min="5" max="480" value="30">
                                    <span class="input-group-text">minutos</span>
                                </div>
                                <div class="security-description">
                                    Tiempo máximo de inactividad antes de cerrar sesión automáticamente
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-key"></i>Política de Contraseñas
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Fortaleza Mínima</label>
                                <select class="form-select" id="passwordStrength">
                                    <option value="low">Baja (6 caracteres)</option>
                                    <option value="medium">Media (8 caracteres, letras y números)</option>
                                    <option value="high" selected>Alta (12 caracteres, complejidad)</option>
                                    <option value="very-high">Muy Alta (16 caracteres, máxima complejidad)</option>
                                </select>
                                <div class="security-description">
                                    Nivel de complejidad requerido para las contraseñas
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Caducidad de Contraseñas</label>
                                <select class="form-select" id="passwordExpiration">
                                    <option value="0">Nunca</option>
                                    <option value="30">30 días</option>
                                    <option value="60">60 días</option>
                                    <option value="90" selected>90 días</option>
                                    <option value="180">180 días</option>
                                </select>
                                <div class="security-description">
                                    Tiempo después del cual las contraseñas deben cambiarse
                                </div>
                            </div>
                        </div>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Historial de Contraseñas</label>
                                <input type="number" class="form-control" id="passwordHistory" min="0" max="24" value="5">
                                <div class="security-description">
                                    Número de contraseñas anteriores que no se pueden reutilizar
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Bloqueo por Intentos Fallidos</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="maxLoginAttempts" min="1" max="10" value="5">
                                    <span class="input-group-text">intentos</span>
                                </div>
                                <div class="security-description">
                                    Número máximo de intentos fallidos antes de bloquear la cuenta
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-sync-alt"></i>Rotación de Claves
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Rotación Automática de API Keys</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="apiKeyRotation" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="apiKeyRotationStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Rotar automáticamente las claves API cada 90 días
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Frecuencia de Rotación</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="rotationFrequency" min="7" max="365" value="90">
                                    <span class="input-group-text">días</span>
                                </div>
                                <div class="security-description">
                                    Frecuencia para rotar claves y certificados
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Control de Accesos -->
                <div class="security-content" id="accesos-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-network-wired"></i>Control de Acceso Basado en Roles (RBAC)
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Política de Mínimo Privilegio</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="leastPrivilege" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="leastPrivilegeStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Los usuarios solo tienen acceso a lo estrictamente necesario
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Separación de Duties</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="separationOfDuties" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="separationOfDutiesStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Prevenir conflictos de interés mediante separación de funciones críticas
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-globe"></i>Control de Acceso por IP y Geolocalización
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Lista Blanca de IPs</label>
                                <textarea class="form-control" id="allowedIPs" rows="3" placeholder="Ej: 192.168.1.0/24, 10.0.0.1"></textarea>
                                <div class="security-description">
                                    Solo permitir acceso desde estas IPs o rangos (separados por coma)
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Bloqueo por Geolocalización</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="geoBlocking">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="geoBlockingStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">
                                    Bloquear acceso desde países específicos
                                </div>
                            </div>
                        </div>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Países Permitidos</label>
                                <select class="form-select" id="allowedCountries" multiple>
                                    <option value="MX" selected>México</option>
                                    <option value="US">Estados Unidos</option>
                                    <option value="CA">Canadá</option>
                                    <option value="ES">España</option>
                                </select>
                                <div class="security-description">
                                    Mantener CTRL para seleccionar múltiples países
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-clock"></i>Control de Acceso Temporal
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Horario de Acceso</label>
                                <div class="row">
                                    <div class="col">
                                        <label class="form-label">Desde</label>
                                        <input type="time" class="form-control" id="accessTimeStart" value="08:00">
                                    </div>
                                    <div class="col">
                                        <label class="form-label">Hasta</label>
                                        <input type="time" class="form-control" id="accessTimeEnd" value="18:00">
                                    </div>
                                </div>
                                <div class="security-description">
                                    Horario permitido para acceder al sistema
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Días de Acceso</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="accessMonday" checked>
                                    <label class="form-check-label" for="accessMonday">Lunes</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="accessTuesday" checked>
                                    <label class="form-check-label" for="accessTuesday">Martes</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="accessWednesday" checked>
                                    <label class="form-check-label" for="accessWednesday">Miércoles</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="accessThursday" checked>
                                    <label class="form-check-label" for="accessThursday">Jueves</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="accessFriday" checked>
                                    <label class="form-check-label" for="accessFriday">Viernes</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="accessSaturday">
                                    <label class="form-check-label" for="accessSaturday">Sábado</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="accessSunday">
                                    <label class="form-check-label" for="accessSunday">Domingo</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Cifrado de Datos -->
                <div class="security-content" id="cifrado-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-lock"></i>Cifrado en Reposo
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Algoritmo de Cifrado</label>
                                <select class="form-select" id="encryptionAlgorithm">
                                    <option value="aes-256">AES-256-GCM</option>
                                    <option value="aes-192">AES-192</option>
                                    <option value="aes-128">AES-128</option>
                                    <option value="chacha20">ChaCha20-Poly1305</option>
                                </select>
                                <div class="security-description">
                                    Algoritmo utilizado para cifrar datos en la base de datos
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Cifrado de Base de Datos</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="databaseEncryption" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="databaseEncryptionStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Cifrar toda la base de datos en reposo
                                </div>
                            </div>
                        </div>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Cifrado a Nivel de Campo</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="fieldLevelEncryption">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="fieldLevelEncryptionStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">
                                    Cifrar campos sensibles individualmente (ej: contraseñas, datos personales)
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Rotación de Claves de Cifrado</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="keyRotationDays" min="30" max="365" value="90">
                                    <span class="input-group-text">días</span>
                                </div>
                                <div class="security-description">
                                    Frecuencia para rotar las claves de cifrado
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-exchange-alt"></i>Cifrado en Tránsito
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Protocolo TLS</label>
                                <select class="form-select" id="tlsVersion">
                                    <option value="1.3">TLS 1.3</option>
                                    <option value="1.2">TLS 1.2</option>
                                    <option value="1.1">TLS 1.1 (No recomendado)</option>
                                </select>
                                <div class="security-description">
                                    Versión de TLS para comunicaciones seguras
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Perfect Forward Secrecy</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="forwardSecrecy" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="forwardSecrecyStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Garantizar que las sesiones pasadas no puedan ser descifradas si la clave privada es comprometida
                                </div>
                            </div>
                        </div>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">HSTS (HTTP Strict Transport Security)</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="hstsEnabled" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="hstsEnabledStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Forzar siempre conexiones HTTPS
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Certificados SSL</label>
                                <div class="audit-panel">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span>Certificado Actual: Let's Encrypt RSA-2048</span>
                                        <span class="encryption-status encryption-active">Válido</span>
                                    </div>
                                    <div class="mt-2">
                                        <small>Expira: 2024-12-31</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-mask"></i>Enmascaramiento de Datos
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Enmascaramiento Dinámico</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="dataMasking" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="dataMaskingStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Enmascarar datos sensibles en interfaces según permisos de usuario
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Tokenización de Datos</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="dataTokenization">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="dataTokenizationStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">
                                    Reemplazar datos sensibles con tokens no sensibles equivalentes
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Monitoreo -->
                <div class="security-content" id="monitoreo-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-radar"></i>Detección de Intrusos (IDS)
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Sistema de Detección de Intrusos</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="intrusionDetection" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="intrusionDetectionStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Monitorear y analizar actividad sospechosa en tiempo real
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Umbral de Alerta</label>
                                <select class="form-select" id="alertThreshold">
                                    <option value="low">Bajo (más alertas)</option>
                                    <option value="medium" selected>Medio</option>
                                    <option value="high">Alto (solo amenazas críticas)</option>
                                </select>
                                <div class="security-description">
                                    Sensibilidad del sistema de detección
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-shield-alt"></i>Prevención de Intrusos (IPS)
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Sistema de Prevención de Intrusos</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="intrusionPrevention" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="intrusionPreventionStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Bloquear automáticamente actividades maliciosas detectadas
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Modo de Operación</label>
                                <select class="form-select" id="ipsMode">
                                    <option value="prevention">Prevención (bloquear)</option>
                                    <option value="detection">Detección (solo alertar)</option>
                                </select>
                                <div class="security-description">
                                    Comportamiento del sistema cuando detecta amenazas
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-brain"></i>Machine Learning para Seguridad
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Detección de Anomalías con IA</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="aiAnomalyDetection" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="aiAnomalyDetectionStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Usar machine learning para detectar comportamientos anómalos
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Análisis de Comportamiento de Usuarios</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="userBehaviorAnalysis">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="userBehaviorAnalysisStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">
                                    Analizar patrones de comportamiento para detectar cuentas comprometidas
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Auditoría -->
                <div class="security-content" id="auditoria-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-clipboard-check"></i>Registro de Auditoría
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Registro Completo de Actividad</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="fullActivityLogging" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="fullActivityLoggingStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Registrar todas las actividades del sistema y usuarios
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Retención de Logs</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="logRetention" min="30" max="1095" value="365">
                                    <span class="input-group-text">días</span>
                                </div>
                                <div class="security-description">
                                    Tiempo que se mantienen los registros de auditoría
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-history"></i>Logs de Seguridad Recientes
                        </h3>
                        
                        <div class="security-logs" id="securityLogs">
                            <!-- Los logs se cargarán aquí dinámicamente -->
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-file-export"></i>Reportes de Auditoría
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Reportes Automáticos</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="autoReports" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoReportsStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Generar reportes de seguridad automáticamente
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Frecuencia de Reportes</label>
                                <select class="form-select" id="reportFrequency">
                                    <option value="daily">Diario</option>
                                    <option value="weekly" selected>Semanal</option>
                                    <option value="monthly">Mensual</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Respuesta a Incidentes -->
                <div class="security-content" id="respuesta-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-first-aid"></i>Plan de Respuesta a Incidentes
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Respuesta Automática</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="autoIncidentResponse" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoIncidentResponseStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Ejecutar automáticamente acciones predefinidas ante incidentes
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Umbral de Activación</label>
                                <select class="form-select" id="incidentThreshold">
                                    <option value="low">Bajo (respuesta temprana)</option>
                                    <option value="medium" selected>Medio</option>
                                    <option value="high">Alto (solo amenazas confirmadas)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-user-slash"></i>Contención de Amenazas
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Aislamiento Automático</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="autoIsolation" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoIsolationStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Aislar automáticamente sistemas o usuarios comprometidos
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Bloqueo de Cuentas</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="autoAccountLock" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoAccountLockStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Bloquear automáticamente cuentas comprometidas
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-database"></i>Recuperación de Desastres
                        </h3>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Backups Automáticos</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="autoBackups" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoBackupsStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Realizar backups automáticos regulares
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Frecuencia de Backup</label>
                                <select class="form-select" id="backupFrequency">
                                    <option value="hourly">Cada hora</option>
                                    <option value="daily" selected>Diario</option>
                                    <option value="weekly">Semanal</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Backups Cifrados</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="encryptedBackups" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="encryptedBackupsStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">
                                    Cifrar todos los backups para proteger datos sensibles
                                </div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">RTO (Recovery Time Objective)</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="rto" min="1" max="72" value="4">
                                    <span class="input-group-text">horas</span>
                                </div>
                                <div class="security-description">
                                    Tiempo máximo aceptable para restaurar operaciones
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="security-actions">
                    <button type="button" class="btn btn-secondary" id="testSecurityBtn">
                        <i class="fas fa-vial me-2"></i>Probar Configuración
                    </button>
                    <button type="button" class="btn btn-warning" id="resetSecurityBtn">
                        <i class="fas fa-undo me-2"></i>Restablecer
                    </button>
                    <button type="button" class="btn btn-primary" id="saveSecurityBtn">
                        <i class="fas fa-save me-2"></i>Guardar Configuración de Seguridad
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Clase para gestión de seguridad avanzada
        class AdvancedSecurityManager {
            constructor() {
                this.securityConfig = JSON.parse(localStorage.getItem('securityConfig')) || this.getDefaultConfig();
                this.encryptionKey = this.generateEncryptionKey();
                this.securityLogs = JSON.parse(localStorage.getItem('securityLogs')) || [];
                this.threatIntelligence = new Set();
                this.applySecurityConfig();
            }
            
            getDefaultConfig() {
                return {
                    // Autenticación
                    twoFactorAuth: true,
                    twoFactorMethod: 'app',
                    biometricAuth: false,
                    sessionTimeout: 30,
                    passwordStrength: 'high',
                    passwordExpiration: 90,
                    passwordHistory: 5,
                    maxLoginAttempts: 5,
                    apiKeyRotation: true,
                    rotationFrequency: 90,
                    
                    // Control de Accesos
                    leastPrivilege: true,
                    separationOfDuties: true,
                    allowedIPs: '',
                    geoBlocking: false,
                    allowedCountries: ['MX'],
                    accessTimeStart: '08:00',
                    accessTimeEnd: '18:00',
                    accessDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
                    
                    // Cifrado
                    encryptionAlgorithm: 'aes-256',
                    databaseEncryption: true,
                    fieldLevelEncryption: false,
                    keyRotationDays: 90,
                    tlsVersion: '1.3',
                    forwardSecrecy: true,
                    hstsEnabled: true,
                    dataMasking: true,
                    dataTokenization: false,
                    
                    // Monitoreo
                    intrusionDetection: true,
                    alertThreshold: 'medium',
                    intrusionPrevention: true,
                    ipsMode: 'prevention',
                    aiAnomalyDetection: true,
                    userBehaviorAnalysis: false,
                    
                    // Auditoría
                    fullActivityLogging: true,
                    logRetention: 365,
                    autoReports: true,
                    reportFrequency: 'weekly',
                    
                    // Respuesta a Incidentes
                    autoIncidentResponse: true,
                    incidentThreshold: 'medium',
                    autoIsolation: true,
                    autoAccountLock: true,
                    autoBackups: true,
                    backupFrequency: 'daily',
                    encryptedBackups: true,
                    rto: 4
                };
            }
            
            generateEncryptionKey() {
                // Generar una clave de cifrado segura
                const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?';
                let key = '';
                for (let i = 0; i < 64; i++) {
                    key += chars.charAt(Math.floor(Math.random() * chars.length));
                }
                return CryptoJS.SHA256(key).toString();
            }
            
            encryptData(data) {
                try {
                    return CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptionKey).toString();
                } catch (error) {
                    this.logSecurityEvent('ERROR', 'Cifrado fallido', 'System', 'high');
                    return null;
                }
            }
            
            decryptData(encryptedData) {
                try {
                    const bytes = CryptoJS.AES.decrypt(encryptedData, this.encryptionKey);
                    return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
                } catch (error) {
                    this.logSecurityEvent('ERROR', 'Descifrado fallido', 'System', 'high');
                    return null;
                }
            }
            
            getSecurityConfig() {
                return this.securityConfig;
            }
            
            updateSecurityConfig(newConfig) {
                const oldConfig = {...this.securityConfig};
                this.securityConfig = { ...this.securityConfig, ...newConfig };
                
                // Cifrar y guardar configuración
                const encryptedConfig = this.encryptData(this.securityConfig);
                if (encryptedConfig) {
                    localStorage.setItem('securityConfig', JSON.stringify(encryptedConfig));
                }
                
                this.applySecurityConfig();
                this.logSecurityEvent('CONFIGURATION', 'Configuración de seguridad actualizada', 'Administrator', 'medium');
                
                return this.securityConfig;
            }
            
            resetSecurityConfig() {
                this.securityConfig = this.getDefaultConfig();
                const encryptedConfig = this.encryptData(this.securityConfig);
                if (encryptedConfig) {
                    localStorage.setItem('securityConfig', JSON.stringify(encryptedConfig));
                }
                
                this.applySecurityConfig();
                this.logSecurityEvent('CONFIGURATION', 'Configuración de seguridad restablecida', 'Administrator', 'high');
                
                return this.securityConfig;
            }
            
            applySecurityConfig() {
                // Aplicar políticas de seguridad en tiempo real
                this.enforceSessionTimeout();
                this.enforcePasswordPolicy();
                this.monitorSuspiciousActivity();
            }
            
            enforceSessionTimeout() {
                // Implementar timeout de sesión
                let timeout = this.securityConfig.sessionTimeout * 60 * 1000;
                setTimeout(() => {
                    this.logSecurityEvent('SESSION', 'Sesión expirada por inactividad', 'System', 'low');
                    // En una implementación real, aquí se cerraría la sesión
                }, timeout);
            }
            
            enforcePasswordPolicy() {
                // Validar política de contraseñas
                // Esta función se llamaría cuando los usuarios cambien sus contraseñas
            }
            
            monitorSuspiciousActivity() {
                // Monitorear actividad sospechosa en tiempo real
                // Esta es una implementación básica - en producción sería más compleja
                setInterval(() => {
                    this.detectAnomalies();
                }, 30000); // Revisar cada 30 segundos
            }
            
            detectAnomalies() {
                // Detectar actividad anómala usando reglas simples
                // En producción, esto usaría machine learning
                const recentLogs = this.securityLogs.slice(-10);
                const failedLogins = recentLogs.filter(log => 
                    log.action.includes('LOGIN_FAILED')
                ).length;
                
                if (failedLogins > 3) {
                    this.logSecurityEvent('THREAT', 'Múltiples intentos de login fallidos detectados', 'System', 'high');
                }
            }
            
            logSecurityEvent(type, action, user, severity) {
                const logEntry = {
                    timestamp: new Date().toISOString(),
                    type: type,
                    action: action,
                    user: user,
                    severity: severity,
                    ip: '192.168.1.1', // En producción, obtener IP real
                    userAgent: navigator.userAgent
                };
                
                this.securityLogs.push(logEntry);
                
                // Mantener solo los logs de los últimos 1000 eventos
                if (this.securityLogs.length > 1000) {
                    this.securityLogs = this.securityLogs.slice(-1000);
                }
                
                // Guardar logs cifrados
                const encryptedLogs = this.encryptData(this.securityLogs);
                if (encryptedLogs) {
                    localStorage.setItem('securityLogs', JSON.stringify(encryptedLogs));
                }
                
                // Actualizar UI si es necesario
                if (typeof updateSecurityLogsUI === 'function') {
                    updateSecurityLogsUI();
                }
                
                return logEntry;
            }
            
            getSecurityLogs(limit = 50) {
                return this.securityLogs.slice(-limit).reverse();
            }
            
            testSecurityConfiguration() {
                const tests = [
                    { name: 'Cifrado de datos', result: this.testEncryption() },
                    { name: 'Política de contraseñas', result: this.testPasswordPolicy() },
                    { name: 'Configuración TLS', result: this.testTLSConfig() },
                    { name: 'Control de accesos', result: this.testAccessControl() },
                    { name: 'Detección de intrusiones', result: this.testIntrusionDetection() }
                ];
                
                const passed = tests.filter(test => test.result).length;
                const total = tests.length;
                const score = Math.round((passed / total) * 100);
                
                this.logSecurityEvent('TEST', `Prueba de seguridad completada: ${score}%`, 'System', 'medium');
                
                return {
                    score: score,
                    tests: tests,
                    passed: passed,
                    total: total
                };
            }
            
            testEncryption() {
                try {
                    const testData = { test: 'security_test_data' };
                    const encrypted = this.encryptData(testData);
                    const decrypted = this.decryptData(encrypted);
                    return decrypted && decrypted.test === testData.test;
                } catch (error) {
                    return false;
                }
            }
            
            testPasswordPolicy() {
                return this.securityConfig.passwordStrength === 'high' || 
                       this.securityConfig.passwordStrength === 'very-high';
            }
            
            testTLSConfig() {
                return this.securityConfig.tlsVersion === '1.3' && 
                       this.securityConfig.forwardSecrecy;
            }
            
            testAccessControl() {
                return this.securityConfig.leastPrivilege && 
                       this.securityConfig.twoFactorAuth;
            }
            
            testIntrusionDetection() {
                return this.securityConfig.intrusionDetection && 
                       this.securityConfig.intrusionPrevention;
            }
            
            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
                    <span>${message}</span>
                `;
                
                document.getElementById('toastContainer').appendChild(toast);
                
                setTimeout(() => {
                    toast.style.animation = 'slideOut 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 5000);
            }
        }

        // Instancia global del administrador de seguridad
        const securityManager = new AdvancedSecurityManager();

        // Función para cargar configuración en el formulario
        function loadSecurityConfigToForm() {
            const config = securityManager.getSecurityConfig();
            
            // Actualizar estados de toggles
            updateAllToggleStatuses(config);
            
            // Cargar valores específicos
            document.getElementById('twoFactorMethod').value = config.twoFactorMethod;
            document.getElementById('sessionTimeout').value = config.sessionTimeout;
            document.getElementById('passwordStrength').value = config.passwordStrength;
            document.getElementById('passwordExpiration').value = config.passwordExpiration;
            document.getElementById('passwordHistory').value = config.passwordHistory;
            document.getElementById('maxLoginAttempts').value = config.maxLoginAttempts;
            document.getElementById('rotationFrequency').value = config.rotationFrequency;
            
            // Control de Accesos
            document.getElementById('allowedIPs').value = config.allowedIPs;
            document.getElementById('accessTimeStart').value = config.accessTimeStart;
            document.getElementById('accessTimeEnd').value = config.accessTimeEnd;
            
            // Días de acceso
            const accessDays = config.accessDays || [];
            document.getElementById('accessMonday').checked = accessDays.includes('monday');
            document.getElementById('accessTuesday').checked = accessDays.includes('tuesday');
            document.getElementById('accessWednesday').checked = accessDays.includes('wednesday');
            document.getElementById('accessThursday').checked = accessDays.includes('thursday');
            document.getElementById('accessFriday').checked = accessDays.includes('friday');
            document.getElementById('accessSaturday').checked = accessDays.includes('saturday');
            document.getElementById('accessSunday').checked = accessDays.includes('sunday');
            
            // Países permitidos
            const allowedCountries = config.allowedCountries || [];
            document.querySelectorAll('#allowedCountries option').forEach(option => {
                option.selected = allowedCountries.includes(option.value);
            });
            
            // Cifrado
            document.getElementById('encryptionAlgorithm').value = config.encryptionAlgorithm;
            document.getElementById('keyRotationDays').value = config.keyRotationDays;
            document.getElementById('tlsVersion').value = config.tlsVersion;
            
            // Monitoreo
            document.getElementById('alertThreshold').value = config.alertThreshold;
            document.getElementById('ipsMode').value = config.ipsMode;
            
            // Auditoría
            document.getElementById('logRetention').value = config.logRetention;
            document.getElementById('reportFrequency').value = config.reportFrequency;
            
            // Respuesta a Incidentes
            document.getElementById('incidentThreshold').value = config.incidentThreshold;
            document.getElementById('backupFrequency').value = config.backupFrequency;
            document.getElementById('rto').value = config.rto;
            
            // Actualizar logs
            updateSecurityLogsUI();
        }
        
        // Función para actualizar todos los estados de toggles
        function updateAllToggleStatuses(config) {
            const toggleMap = {
                'twoFactorAuth': 'twoFactorStatus',
                'biometricAuth': 'biometricStatus',
                'apiKeyRotation': 'apiKeyRotationStatus',
                'leastPrivilege': 'leastPrivilegeStatus',
                'separationOfDuties': 'separationOfDutiesStatus',
                'geoBlocking': 'geoBlockingStatus',
                'databaseEncryption': 'databaseEncryptionStatus',
                'fieldLevelEncryption': 'fieldLevelEncryptionStatus',
                'forwardSecrecy': 'forwardSecrecyStatus',
                'hstsEnabled': 'hstsEnabledStatus',
                'dataMasking': 'dataMaskingStatus',
                'dataTokenization': 'dataTokenizationStatus',
                'intrusionDetection': 'intrusionDetectionStatus',
                'intrusionPrevention': 'intrusionPreventionStatus',
                'aiAnomalyDetection': 'aiAnomalyDetectionStatus',
                'userBehaviorAnalysis': 'userBehaviorAnalysisStatus',
                'fullActivityLogging': 'fullActivityLoggingStatus',
                'autoReports': 'autoReportsStatus',
                'autoIncidentResponse': 'autoIncidentResponseStatus',
                'autoIsolation': 'autoIsolationStatus',
                'autoAccountLock': 'autoAccountLockStatus',
                'autoBackups': 'autoBackupsStatus',
                'encryptedBackups': 'encryptedBackupsStatus'
            };
            
            Object.keys(toggleMap).forEach(configKey => {
                const checkbox = document.getElementById(configKey);
                const statusSpan = document.getElementById(toggleMap[configKey]);
                
                if (checkbox && statusSpan) {
                    checkbox.checked = config[configKey];
                    statusSpan.textContent = config[configKey] ? 'Activado' : 'Desactivado';
                    statusSpan.className = `encryption-status ${config[configKey] ? 'encryption-active' : 'encryption-inactive'}`;
                }
            });
        }
        
        // Función para actualizar logs de seguridad en la UI
        function updateSecurityLogsUI() {
            const logsContainer = document.getElementById('securityLogs');
            const logs = securityManager.getSecurityLogs(20);
            
            let html = '';
            logs.forEach(log => {
                const time = new Date(log.timestamp).toLocaleString();
                const severityClass = `severity-${log.severity}`;
                
                html += `
                    <div class="log-entry">
                        <div class="log-info">
                            <div class="log-action">${log.action}</div>
                            <div class="log-time">${time} • ${log.user}</div>
                        </div>
                        <span class="log-severity ${severityClass}">${log.severity.toUpperCase()}</span>
                    </div>
                `;
            });
            
            logsContainer.innerHTML = html || '<div class="log-entry">No hay registros de seguridad</div>';
        }
        
        // Función para guardar configuración desde el formulario
        function saveSecurityConfigFromForm() {
            const config = {};
            
            // Autenticación
            config.twoFactorAuth = document.getElementById('twoFactorAuth').checked;
            config.twoFactorMethod = document.getElementById('twoFactorMethod').value;
            config.biometricAuth = document.getElementById('biometricAuth').checked;
            config.sessionTimeout = parseInt(document.getElementById('sessionTimeout').value);
            config.passwordStrength = document.getElementById('passwordStrength').value;
            config.passwordExpiration = parseInt(document.getElementById('passwordExpiration').value);
            config.passwordHistory = parseInt(document.getElementById('passwordHistory').value);
            config.maxLoginAttempts = parseInt(document.getElementById('maxLoginAttempts').value);
            config.apiKeyRotation = document.getElementById('apiKeyRotation').checked;
            config.rotationFrequency = parseInt(document.getElementById('rotationFrequency').value);
            
            // Control de Accesos
            config.leastPrivilege = document.getElementById('leastPrivilege').checked;
            config.separationOfDuties = document.getElementById('separationOfDuties').checked;
            config.allowedIPs = document.getElementById('allowedIPs').value;
            config.geoBlocking = document.getElementById('geoBlocking').checked;
            config.accessTimeStart = document.getElementById('accessTimeStart').value;
            config.accessTimeEnd = document.getElementById('accessTimeEnd').value;
            
            // Días de acceso
            config.accessDays = [];
            if (document.getElementById('accessMonday').checked) config.accessDays.push('monday');
            if (document.getElementById('accessTuesday').checked) config.accessDays.push('tuesday');
            if (document.getElementById('accessWednesday').checked) config.accessDays.push('wednesday');
            if (document.getElementById('accessThursday').checked) config.accessDays.push('thursday');
            if (document.getElementById('accessFriday').checked) config.accessDays.push('friday');
            if (document.getElementById('accessSaturday').checked) config.accessDays.push('saturday');
            if (document.getElementById('accessSunday').checked) config.accessDays.push('sunday');
            
            // Países permitidos
            config.allowedCountries = Array.from(document.getElementById('allowedCountries').selectedOptions)
                .map(option => option.value);
            
            // Cifrado
            config.encryptionAlgorithm = document.getElementById('encryptionAlgorithm').value;
            config.databaseEncryption = document.getElementById('databaseEncryption').checked;
            config.fieldLevelEncryption = document.getElementById('fieldLevelEncryption').checked;
            config.keyRotationDays = parseInt(document.getElementById('keyRotationDays').value);
            config.tlsVersion = document.getElementById('tlsVersion').value;
            config.forwardSecrecy = document.getElementById('forwardSecrecy').checked;
            config.hstsEnabled = document.getElementById('hstsEnabled').checked;
            config.dataMasking = document.getElementById('dataMasking').checked;
            config.dataTokenization = document.getElementById('dataTokenization').checked;
            
            // Monitoreo
            config.intrusionDetection = document.getElementById('intrusionDetection').checked;
            config.alertThreshold = document.getElementById('alertThreshold').value;
            config.intrusionPrevention = document.getElementById('intrusionPrevention').checked;
            config.ipsMode = document.getElementById('ipsMode').value;
            config.aiAnomalyDetection = document.getElementById('aiAnomalyDetection').checked;
            config.userBehaviorAnalysis = document.getElementById('userBehaviorAnalysis').checked;
            
            // Auditoría
            config.fullActivityLogging = document.getElementById('fullActivityLogging').checked;
            config.logRetention = parseInt(document.getElementById('logRetention').value);
            config.autoReports = document.getElementById('autoReports').checked;
            config.reportFrequency = document.getElementById('reportFrequency').value;
            
            // Respuesta a Incidentes
            config.autoIncidentResponse = document.getElementById('autoIncidentResponse').checked;
            config.incidentThreshold = document.getElementById('incidentThreshold').value;
            config.autoIsolation = document.getElementById('autoIsolation').checked;
            config.autoAccountLock = document.getElementById('autoAccountLock').checked;
            config.autoBackups = document.getElementById('autoBackups').checked;
            config.backupFrequency = document.getElementById('backupFrequency').value;
            config.encryptedBackups = document.getElementById('encryptedBackups').checked;
            config.rto = parseInt(document.getElementById('rto').value);
            
            // Actualizar configuración
            securityManager.updateSecurityConfig(config);
            securityManager.showNotification('Configuración de seguridad guardada y aplicada', 'success');
            
            // Actualizar puntuación de seguridad
            updateSecurityScore();
        }
        
        // Función para actualizar la puntuación de seguridad
        function updateSecurityScore() {
            const testResults = securityManager.testSecurityConfiguration();
            document.getElementById('securityScore').textContent = `${testResults.score}%`;
            
            // Actualizar otros indicadores
            document.getElementById('threatsBlocked').textContent = '1,247';
            document.getElementById('encryptionStatus').textContent = 'AES-256';
            document.getElementById('lastBreach').textContent = 'Nunca';
        }
        
        // Función para cambiar tema
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            const themeIcon = document.querySelector('#themeToggle i');
            themeIcon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
            
            // Guardar preferencia
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }
        
        // Función para toggle del menú en móviles
        function toggleMenu() {
            document.getElementById('sidebar').classList.toggle('open');
        }
        
        // Inicialización cuando el DOM está listo
        document.addEventListener('DOMContentLoaded', function() {
            // Cargar configuración en el formulario
            loadSecurityConfigToForm();
            
            // Actualizar puntuación de seguridad
            updateSecurityScore();
            
            // Event listeners
            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            document.getElementById('menuToggle').addEventListener('click', toggleMenu);
            
            // Navegación entre pestañas
            document.querySelectorAll('.security-tab').forEach(tab => {
                tab.addEventListener('click', function() {
                    // Remover clase active de todas las pestañas y contenidos
                    document.querySelectorAll('.security-tab').forEach(t => t.classList.remove('active'));
                    document.querySelectorAll('.security-content').forEach(c => c.classList.remove('active'));
                    
                    // Agregar clase active a la pestaña clickeada
                    this.classList.add('active');
                    
                    // Mostrar el contenido correspondiente
                    const tabId = this.getAttribute('data-tab');
                    document.getElementById(`${tabId}-tab`).classList.add('active');
                });
            });
            
            // Actualizar estados de toggles
            document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const statusSpanId = this.id + 'Status';
                    const statusSpan = document.getElementById(statusSpanId);
                    if (statusSpan) {
                        statusSpan.textContent = this.checked ? 'Activado' : 'Desactivado';
                        statusSpan.className = `encryption-status ${this.checked ? 'encryption-active' : 'encryption-inactive'}`;
                    }
                });
            });
            
            // Guardar configuración
            document.getElementById('saveSecurityBtn').addEventListener('click', saveSecurityConfigFromForm);
            
            // Probar configuración
            document.getElementById('testSecurityBtn').addEventListener('click', function() {
                const results = securityManager.testSecurityConfiguration();
                securityManager.showNotification(`Prueba de seguridad completada: ${results.score}% de efectividad`, 
                    results.score >= 80 ? 'success' : results.score >= 60 ? 'warning' : 'error');
                
                updateSecurityScore();
            });
            
            // Restablecer configuración
            document.getElementById('resetSecurityBtn').addEventListener('click', function() {
                if (confirm('¿Estás seguro de que deseas restablecer toda la configuración de seguridad a los valores predeterminados? Esta acción no se puede deshacer.')) {
                    securityManager.resetSecurityConfig();
                    loadSecurityConfigToForm();
                    updateSecurityScore();
                    securityManager.showNotification('Configuración de seguridad restablecida', 'success');
                }
            });
            
            // Simular algunos logs de seguridad para demostración
            setTimeout(() => {
                securityManager.logSecurityEvent('LOGIN_SUCCESS', 'Inicio de sesión exitoso', 'admin', 'low');
                securityManager.logSecurityEvent('CONFIGURATION', 'Política de contraseñas actualizada', 'admin', 'medium');
                securityManager.logSecurityEvent('BACKUP', 'Backup automático completado', 'System', 'low');
            }, 1000);
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>