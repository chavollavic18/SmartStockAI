<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Reportes Avanzados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <!-- TensorFlow.js -->
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.10.0/dist/tf.min.js"></script>
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 250px;
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #000000;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #000000;
            transition: var(--transition);
            min-height: 100vh;
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--primary);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: var(--transition);
            border-left: 4px solid transparent;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .sidebar-menu i {
            width: 25px;
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: var(--transition);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: #000000;
        }

        .controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: #000000;
            position: relative;
        }

        .theme-switcher:hover, .notifications:hover {
            transform: translateY(-3px);
        }

        /* Sección de Reportes */
        .reports-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .advanced-filters {
            background: #f8f9fa;
            border-radius: var(--border-radius);
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #e9ecef;
        }

        .filter-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 10px;
        }

        .report-controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .report-type-selector {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .report-type-btn {
            padding: 10px 20px;
            border: 1px solid var(--primary);
            background: white;
            color: var(--primary);
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: var(--transition);
        }

        .report-type-btn.active {
            background: var(--primary);
            color: white;
        }

        .report-type-btn:hover {
            background: var(--primary);
            color: white;
        }

        .report-actions {
            display: flex;
            gap: 10px;
            margin-left: auto;
            flex-wrap: wrap;
        }

        .report-content {
            min-height: 400px;
            border: 1px solid var(--gray);
            border-radius: var(--border-radius);
            padding: 20px;
            background: white;
            margin-bottom: 20px;
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
        }

        .report-table th, .report-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .report-table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }

        .report-table tr:hover {
            background-color: #f5f5f5;
        }

        .chart-container {
            height: 300px;
            margin: 20px 0;
            position: relative;
        }

        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin: 10px 0;
        }

        .stat-title {
            color: var(--gray);
            font-size: 0.9rem;
        }

        .trend-up {
            color: var(--secondary);
        }

        .trend-down {
            color: var(--danger);
        }

        .insights-section {
            background: #f8f9fa;
            border-radius: var(--border-radius);
            padding: 20px;
            margin: 20px 0;
        }

        .insight-item {
            margin-bottom: 15px;
            padding: 10px;
            border-left: 4px solid var(--primary);
            background: white;
            border-radius: 0 var(--border-radius) var(--border-radius) 0;
        }

        .saved-reports {
            margin-top: 30px;
        }

        .saved-reports-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }

        .saved-report-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary);
        }

        .saved-report-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            display: none;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 0;
            }
            
            .sidebar.open {
                transform: translateX(0);
                width: var(--sidebar-width);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
            }

            .report-controls {
                flex-direction: column;
            }

            .report-actions {
                margin-left: 0;
                justify-content: flex-end;
            }

            .filter-row {
                flex-direction: column;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .controls {
                margin-top: 15px;
            }
            
            .menu-toggle {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .stats-cards {
                grid-template-columns: 1fr;
            }

            .saved-reports-list {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px;
            }
            
            .reports-section {
                padding: 15px;
            }
            
            .report-type-selector {
                flex-direction: column;
            }
            
            .report-type-btn {
                width: 100%;
                text-align: center;
            }
            
            .filter-group {
                min-width: 100%;
            }
            
            .report-actions {
                flex-direction: column;
                width: 100%;
            }
            
            .report-actions .btn {
                width: 100%;
                margin-bottom: 10px;
            }
            
            .filter-actions {
                flex-direction: column;
            }
            
            .filter-actions .btn {
                width: 100%;
                margin-bottom: 10px;
            }
        }

        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 1001;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        /* Toast de notificaciones */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
        }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s forwards;
            color: #000000;
        }

        .toast.success {
            border-left: 4px solid var(--secondary);
        }

        .toast.error {
            border-left: 4px solid var(--danger);
        }

        .toast.warning {
            border-left: 4px solid var(--warning);
        }

        .toast i {
            margin-right: 10px;
            font-size: 20px;
        }

        .toast.success i {
            color: var(--secondary);
        }

        .toast.error i {
            color: var(--danger);
        }

        .toast.warning i {
            color: var(--warning);
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* Badges para estados */
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }

        .badge.bg-success {
            background-color: var(--secondary);
        }

        .badge.bg-warning {
            background-color: var(--warning);
        }

        .badge.bg-danger {
            background-color: var(--danger);
        }

        .badge.bg-info {
            background-color: #17a2b8;
        }

        /* Asegurar que todos los textos sean negros */
        body, body *:not(.sidebar *):not(.modal-header *):not(.action-btn):not(.badge):not(.page-link:hover):not(.page-item.active .page-link) {
            color: #000000 !important;
        }

        /* Ajustes para mantener contraste en elementos especiales */
        .sidebar, .modal-header, .action-btn, .badge, .page-link:hover, .page-item.active .page-link {
            color: white !important;
        }

        /* Inputs y selects */
        .form-control, .form-select {
            color: #000000 !important;
            background-color: #ffffff !important;
        }

        .form-control::placeholder {
            color: #666 !important;
        }

        /* Estilos para reportes */
        .report-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid var(--primary);
            padding-bottom: 15px;
        }

        .report-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 5px;
        }

        .report-subtitle {
            color: var(--gray);
            font-size: 16px;
        }

        .report-footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: var(--gray);
            border-top: 1px solid #ddd;
            padding-top: 15px;
        }

        .no-print {
            display: block;
        }

        @media print {
            .no-print {
                display: none !important;
            }
            
            .report-content {
                border: none;
                box-shadow: none;
                padding: 0;
            }
            
            body {
                background: white;
            }
            
            .sidebar, .header, .report-controls, .advanced-filters {
                display: none;
            }
            
            .main-content {
                margin-left: 0;
                padding: 0;
            }
        }

        .tab-content {
            margin-top: 20px;
        }

        .nav-tabs .nav-link.active {
            background-color: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .comparison-table {
            width: 100%;
            border-collapse: collapse;
        }

        .comparison-table th, .comparison-table td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .comparison-table th {
            background-color: #f8f9fa;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: var(--gray);
        }

        /* Estilos para notificaciones */
        .notification-container {
            position: relative;
        }

        .notification-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            width: 320px;
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            z-index: 1000;
            display: none;
            color: #000000;
        }

        .notification-dropdown.show {
            display: block;
        }

        .notification-header {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            font-weight: 600;
        }

        .notification-list {
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-item {
            padding: 12px 15px;
            border-bottom: 1px solid #f1f1f1;
        }

        .notification-item.unread {
            background-color: rgba(58, 94, 199, 0.05);
        }

        .notification-item:last-child {
            border-bottom: none;
        }

        .notification-item strong {
            display: block;
            margin-bottom: 5px;
        }

        .notification-item p {
            margin-bottom: 5px;
            font-size: 0.9rem;
        }

        .notification-item small {
            color: var(--gray);
            font-size: 0.8rem;
        }

        /* Badge de notificaciones */
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 0.7rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        .notification-badge.hidden {
            display: none;
        }

        /* Estilos para TensorFlow.js */
        .tensorflow-section {
            background: #f8f9fa;
            border-radius: var(--border-radius);
            padding: 20px;
            margin: 20px 0;
        }

        .tensorflow-chart {
            height: 300px;
            margin: 20px 0;
        }

        .prediction-results {
            margin-top: 20px;
        }

        .prediction-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        .training-status {
            padding: 10px;
            border-radius: var(--border-radius);
            margin-bottom: 15px;
            font-weight: 500;
        }

        .training-status.training {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .training-status.completed {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .training-status.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .model-controls {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        .tensorflow-insight {
            background: white;
            border-left: 4px solid var(--primary);
            padding: 15px;
            margin: 15px 0;
            border-radius: 0 var(--border-radius) var(--border-radius) 0;
        }

        .progress-bar {
            height: 20px;
            background-color: #e9ecef;
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }

        .progress-fill {
            height: 100%;
            background-color: var(--primary);
            transition: width 0.3s ease;
        }

        .external-data-section {
            background: #e8f4fd;
            border-radius: var(--border-radius);
            padding: 15px;
            margin: 15px 0;
            border-left: 4px solid #17a2b8;
        }

        .sentiment-indicator {
            display: inline-flex;
            align-items: center;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .sentiment-positive {
            background-color: #d4edda;
            color: #155724;
        }

        .sentiment-negative {
            background-color: #f8d7da;
            color: #721c24;
        }

        .sentiment-neutral {
            background-color: #fff3cd;
            color: #856404;
        }

        .market-trends {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin: 15px 0;
        }

        .market-trend-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .market-trend-value {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 5px 0;
        }

        .external-data-source {
            font-size: 0.8rem;
            color: var(--gray);
            margin-top: 5px;
        }

        .ai-recommendation {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: var(--border-radius);
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .ai-recommendation h5 {
            color: white;
            margin-bottom: 15px;
        }

        .recommendation-list {
            list-style: none;
            padding: 0;
        }

        .recommendation-list li {
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }

        .recommendation-list li:last-child {
            border-bottom: none;
        }

        .recommendation-list li i {
            margin-right: 10px;
        }

        .real-time-badge {
            background: #dc3545;
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.7rem;
            margin-left: 5px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
        }

        .data-freshness {
            font-size: 0.8rem;
            color: var(--gray);
            text-align: center;
            margin-top: 10px;
        }

        .api-status {
            display: inline-flex;
            align-items: center;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .api-status.online {
            background-color: #d4edda;
            color: #155724;
        }

        .api-status.offline {
            background-color: #f8d7da;
            color: #721c24;
        }

        .api-status i {
            margin-right: 4px;
        }

        /* Nuevos estilos para tendencias mejoradas */
        .category-trends-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }

        .category-trend-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border-top: 4px solid var(--primary);
        }

        .category-trend-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .category-trend-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--primary);
        }

        .category-trend-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-bottom: 15px;
        }

        .category-stat {
            text-align: center;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 8px;
        }

        .category-stat-value {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .category-stat-label {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .trend-indicator {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .trend-indicator.up {
            background-color: #d4edda;
            color: #155724;
        }

        .trend-indicator.down {
            background-color: #f8d7da;
            color: #721c24;
        }

        .trend-indicator.neutral {
            background-color: #fff3cd;
            color: #856404;
        }

        .seasonality-indicator {
            display: inline-flex;
            align-items: center;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
            margin-left: 5px;
        }

        .seasonality-high {
            background-color: #d4edda;
            color: #155724;
        }

        .seasonality-medium {
            background-color: #fff3cd;
            color: #856404;
        }

        .seasonality-low {
            background-color: #f8d7da;
            color: #721c24;
        }

        .performance-comparison {
            margin: 20px 0;
        }

        .performance-metrics {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin: 15px 0;
        }

        .performance-metric {
            background: white;
            border-radius: var(--border-radius);
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .metric-value {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 5px 0;
        }

        .metric-label {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .projection-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: var(--border-radius);
            padding: 20px;
            margin: 20px 0;
        }

        .projection-title {
            color: white;
            margin-bottom: 15px;
            font-size: 1.2rem;
        }

        .projection-value {
            font-size: 2rem;
            font-weight: 700;
            margin: 10px 0;
        }

        .projection-subtitle {
            opacity: 0.9;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="loading-overlay" id="loadingOverlay">
        <div class="spinner"></div>
    </div>

    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot me-2"></i>SmartStock AI
                </div>
            </div>
            
            <ul class="sidebar-menu">
    <li><a href="http://localhost/SmartStockAI/admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes"></i> Inventario</a></li>
                <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck"></i> Proveedores</a></li>
                <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users"></i> Usuarios</a></li>
                <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-exchange-alt"></i> Transacciones</a></li>
                <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-line"></i> Reportes</a></li>
                <li><a href="#" class="active"><i class="fas fa-user-friends"></i> Clientes</a></li>
                <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-user"></i> Mi Perfil</a></li>
                <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-alt"></i> Seguridad</a></li>
                <li><a href="http://localhost/SmartStockAI/login.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a></li>
                <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-cog"></i> Configuración</a></li>
</ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1 class="page-title">Reportes de Inventario Avanzados <span class="real-time-badge" id="realTimeBadge">TIEMPO REAL</span></h1>
                
                <div class="controls">
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notification-container">
                        <div class="notifications" id="notificationBtn">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge hidden" id="notificationBadge">0</span>
                        </div>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-header">
                                Notificaciones
                            </div>
                            <div class="notification-list" id="notificationList">
                                <!-- Las notificaciones se cargarán aquí dinámicamente -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Filtros Avanzados -->
            <div class="advanced-filters no-print">
                <h5><i class="fas fa-filter me-2"></i>Filtros Avanzados</h5>
                <div class="filter-row">
                    <div class="filter-group">
                        <label class="form-label">Categoría</label>
                        <select class="form-select" id="categoryFilter">
                            <option value="all">Todas las categorías</option>
                            <option value="Electrónicos">Electrónicos</option>
                            <option value="Ropa">Ropa</option>
                            <option value="Hogar">Hogar</option>
                            <option value="Deportes">Deportes</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Estado de Stock</label>
                        <select class="form-select" id="stockStatusFilter">
                            <option value="all">Todos los estados</option>
                            <option value="En stock">En stock</option>
                            <option value="Stock bajo">Stock bajo</option>
                            <option value="Stock crítico">Stock crítico</option>
                            <option value="Agotado">Agotado</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Rango de Precios</label>
                        <div class="input-group">
                            <input type="number" class="form-control" id="minPrice" placeholder="Mínimo">
                            <span class="input-group-text">a</span>
                            <input type="number" class="form-control" id="maxPrice" placeholder="Máximo">
                        </div>
                    </div>
                </div>
                <div class="filter-row">
                    <div class="filter-group">
                        <label class="form-label">Rango de Stock</label>
                        <div class="input-group">
                            <input type="number" class="form-control" id="minStock" placeholder="Mínimo">
                            <span class="input-group-text">a</span>
                            <input type="number" class="form-control" id="maxStock" placeholder="Máximo">
                        </div>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Ordenar por</label>
                        <select class="form-select" id="sortBy">
                            <option value="name">Nombre (A-Z)</option>
                            <option value="name_desc">Nombre (Z-A)</option>
                            <option value="price">Precio (Menor a Mayor)</option>
                            <option value="price_desc">Precio (Mayor a Menor)</option>
                            <option value="stock">Stock (Menor a Mayor)</option>
                            <option value="stock_desc">Stock (Mayor a Menor)</option>
                            <option value="value">Valor Total (Menor a Mayor)</option>
                            <option value="value_desc">Valor Total (Mayor a Menor)</option>
                        </select>
                    </div>
                </div>
                <div class="filter-actions">
                    <button class="btn btn-outline-secondary" id="resetFilters">
                        <i class="fas fa-redo me-2"></i>Restablecer
                    </button>
                    <button class="btn btn-primary" id="applyFilters">
                        <i class="fas fa-check me-2"></i>Aplicar Filtros
                    </button>
                </div>
            </div>
            
            <!-- Sección de Reportes -->
            <div class="reports-section">
                <div class="report-controls">
                    <div class="report-type-selector">
                        <button class="report-type-btn active" data-type="inventory">Inventario General</button>
                        <button class="report-type-btn" data-type="stock">Niveles de Stock</button>
                        <button class="report-type-btn" data-type="categories">Por Categorías</button>
                        <button class="report-type-btn" data-type="valuation">Valoración</button>
                        <button class="report-type-btn" data-type="trends">Tendencias</button>
                        <button class="report-type-btn" data-type="comparison">Comparación</button>
                        <button class="report-type-btn" data-type="ai">Análisis IA</button>
                    </div>
                    
                    <div class="report-actions no-print">
                        <div class="btn-group">
                            <button class="btn btn-outline-primary" id="saveReport">
                                <i class="fas fa-save me-2"></i>Guardar Reporte
                            </button>
                        </div>
                        
                        <button class="btn btn-outline-primary" id="printReport">
                            <i class="fas fa-print me-2"></i>Imprimir
                        </button>
                        
                        <div class="btn-group" id="exportDropdown">
                            <button class="btn btn-primary" id="exportMain">
                                <i class="fas fa-file-export me-2"></i>Exportar
                            </button>
                            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#" data-format="pdf"><i class="fas fa-file-pdf me-2"></i>PDF</a></li>
                                <li><a class="dropdown-item" href="#" data-format="excel"><i class="fas fa-file-excel me-2"></i>Excel</a></li>
                                <li><a class="dropdown-item" href="#" data-format="csv"><i class="fas fa-file-csv me-2"></i>CSV</a></li>
                                <li><a class="dropdown-item" href="#" data-format="json"><i class="fas fa-file-code me-2"></i>JSON</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="report-content" id="reportContent">
                    <!-- El contenido del reporte se cargará aquí dinámicamente -->
                </div>
            </div>
            
            <!-- Reportes Guardados -->
            <div class="saved-reports no-print">
                <h4><i class="fas fa-bookmark me-2"></i>Reportes Guardados</h4>
                <div class="saved-reports-list" id="savedReportsList">
                    <!-- Los reportes guardados se cargarán aquí dinámicamente -->
                </div>
            </div>
        </div>
    </div>
    
    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Clase para gestionar productos
        class ProductManager {
            constructor() {
                this.products = JSON.parse(localStorage.getItem('products')) || [];
                
                // Inicializar con datos de ejemplo si no hay productos
                if (this.products.length === 0) {
                    this.initializeSampleData();
                }
            }
            
            initializeSampleData() {
                this.products = [
                    {
                        id: 'PRD-001',
                        name: 'Laptop HP Pavilion',
                        category: 'Electrónicos',
                        price: 850.00,
                        stock: 5,
                        description: 'Laptop HP Pavilion con procesador Intel i5, 8GB RAM, 256GB SSD',
                        image: 'https://via.placeholder.com/300x200?text=Laptop+HP',
                        lastUpdated: '2023-10-15'
                    },
                    {
                        id: 'PRD-002',
                        name: 'Smartphone Samsung Galaxy',
                        category: 'Electrónicos',
                        price: 620.00,
                        stock: 42,
                        description: 'Smartphone Samsung Galaxy con pantalla AMOLED de 6.5", 128GB almacenamiento',
                        image: 'https://via.placeholder.com/300x200?text=Samsung+Galaxy',
                        lastUpdated: '2023-11-20'
                    },
                    {
                        id: 'PRD-003',
                        name: 'Zapatillas Deportivas',
                        category: 'Deportes',
                        price: 75.00,
                        stock: 12,
                        description: 'Zapatillas deportivas para running, tallas disponibles del 38 al 45',
                        image: 'https://via.placeholder.com/300x200?text=Zapatillas',
                        lastUpdated: '2023-12-05'
                    },
                    {
                        id: 'PRD-004',
                        name: 'Monitor LG 24"',
                        category: 'Electrónicos',
                        price: 220.00,
                        stock: 28,
                        description: 'Monitor LG 24 pulgadas, resolución Full HD, conexión HDMI y VGA',
                        image: 'https://via.placeholder.com/300x200?text=Monitor+LG',
                        lastUpdated: '2023-10-28'
                    },
                    {
                        id: 'PRD-005',
                        name: 'Camiseta Algodón',
                        category: 'Ropa',
                        price: 25.00,
                        stock: 3,
                        description: 'Camiseta de algodón 100%, disponible en varios colores',
                        image: 'https://via.placeholder.com/300x200?text=Camiseta',
                        lastUpdated: '2023-11-10'
                    },
                    {
                        id: 'PRD-006',
                        name: 'Silla de Oficina',
                        category: 'Hogar',
                        price: 120.00,
                        stock: 15,
                        description: 'Silla ergonómica para oficina, ajustable en altura',
                        image: 'https://via.placeholder.com/300x200?text=Silla+Oficina',
                        lastUpdated: '2023-12-15'
                    },
                    {
                        id: 'PRD-007',
                        name: 'Tablet Android',
                        category: 'Electrónicos',
                        price: 299.99,
                        stock: 8,
                        description: 'Tablet Android con pantalla de 10", 64GB almacenamiento',
                        image: 'https://via.placeholder.com/300x200?text=Tablet+Android',
                        lastUpdated: '2023-11-30'
                    },
                    {
                        id: 'PRD-008',
                        name: 'Set de Herramientas',
                        category: 'Hogar',
                        price: 89.99,
                        stock: 20,
                        description: 'Set completo de herramientas para el hogar con 50 piezas',
                        image: 'https://via.placeholder.com/300x200?text=Herramientas',
                        lastUpdated: '2023-10-05'
                    },
                    {
                        id: 'PRD-009',
                        name: 'Auriculares Inalámbricos',
                        category: 'Electrónicos',
                        price: 150.00,
                        stock: 25,
                        description: 'Auriculares Bluetooth con cancelación de ruido',
                        image: 'https://via.placeholder.com/300x200?text=Auriculares',
                        lastUpdated: '2023-12-10'
                    },
                    {
                        id: 'PRD-010',
                        name: 'Mochila Impermeable',
                        category: 'Deportes',
                        price: 45.00,
                        stock: 18,
                        description: 'Mochila resistente al agua para actividades al aire libre',
                        image: 'https://via.placeholder.com/300x200?text=Mochila',
                        lastUpdated: '2023-11-25'
                    }
                ];
                this.saveProducts();
            }
            
            getProductStatus(stock) {
                if (stock === 0) return 'Agotado';
                if (stock <= 5) return 'Stock crítico';
                if (stock <= 15) return 'Stock bajo';
                return 'En stock';
            }
            
            getStatusClass(stock) {
                if (stock === 0) return 'bg-danger';
                if (stock <= 5) return 'bg-danger';
                if (stock <= 15) return 'bg-warning';
                return 'bg-success';
            }
            
            getAllProducts() {
                return this.products;
            }
            
            getProductsByCategory() {
                const categories = {};
                this.products.forEach(product => {
                    if (!categories[product.category]) {
                        categories[product.category] = [];
                    }
                    categories[product.category].push(product);
                });
                return categories;
            }
            
            getStockSummary() {
                const summary = {
                    totalProducts: this.products.length,
                    totalValue: 0,
                    lowStock: 0,
                    outOfStock: 0,
                    byCategory: {}
                };
                
                this.products.forEach(product => {
                    summary.totalValue += product.price * product.stock;
                    
                    if (product.stock === 0) {
                        summary.outOfStock++;
                    } else if (product.stock <= 5) {
                        summary.lowStock++;
                    }
                    
                    if (!summary.byCategory[product.category]) {
                        summary.byCategory[product.category] = {
                            count: 0,
                            value: 0
                        };
                    }
                    
                    summary.byCategory[product.category].count++;
                    summary.byCategory[product.category].value += product.price * product.stock;
                });
                
                return summary;
            }
            
            getHistoricalData() {
                // Datos históricos simulados para tendencias
                const currentDate = new Date();
                const months = [];
                
                // Generar últimos 12 meses
                for (let i = 11; i >= 0; i--) {
                    const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
                    const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                    months.push(monthKey);
                }
                
                const historicalData = {};
                let baseValue = 15000;
                
                months.forEach(month => {
                    // Variación aleatoria entre -5% y +10%
                    const variation = (Math.random() * 0.15) - 0.05;
                    const value = baseValue * (1 + variation);
                    baseValue = value;
                    
                    historicalData[month] = {
                        totalValue: Math.round(value),
                        totalProducts: Math.floor(25 + (Math.random() * 20)),
                        lowStock: Math.floor(2 + (Math.random() * 6))
                    };
                });
                
                return historicalData;
            }
            
            // Nuevo método para obtener datos históricos por categoría
            getHistoricalDataByCategory() {
                const currentDate = new Date();
                const months = [];
                
                // Generar últimos 12 meses
                for (let i = 11; i >= 0; i--) {
                    const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
                    const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                    months.push(monthKey);
                }
                
                const categories = ['Electrónicos', 'Ropa', 'Hogar', 'Deportes'];
                const historicalDataByCategory = {};
                
                categories.forEach(category => {
                    historicalDataByCategory[category] = {};
                    let baseValue = category === 'Electrónicos' ? 8000 : 
                                   category === 'Ropa' ? 3000 :
                                   category === 'Hogar' ? 2500 : 2000;
                    
                    months.forEach(month => {
                        // Variación específica por categoría
                        let variation;
                        if (category === 'Electrónicos') {
                            variation = (Math.random() * 0.2) - 0.05; // Mayor volatilidad
                        } else if (category === 'Ropa') {
                            // Patrón estacional para ropa
                            const monthNum = parseInt(month.split('-')[1]);
                            variation = monthNum >= 3 && monthNum <= 5 ? (Math.random() * 0.15) + 0.05 : 
                                       monthNum >= 9 && monthNum <= 11 ? (Math.random() * 0.1) + 0.02 :
                                       (Math.random() * 0.1) - 0.05;
                        } else if (category === 'Hogar') {
                            variation = (Math.random() * 0.1) - 0.03; // Menor volatilidad
                        } else { // Deportes
                            // Patrón estacional para deportes
                            const monthNum = parseInt(month.split('-')[1]);
                            variation = monthNum >= 5 && monthNum <= 8 ? (Math.random() * 0.15) + 0.05 :
                                       (Math.random() * 0.1) - 0.03;
                        }
                        
                        const value = baseValue * (1 + variation);
                        baseValue = value;
                        
                        historicalDataByCategory[category][month] = {
                            totalValue: Math.round(value),
                            totalProducts: Math.floor(5 + (Math.random() * 10)),
                            lowStock: Math.floor(1 + (Math.random() * 3))
                        };
                    });
                });
                
                return historicalDataByCategory;
            }
            
            saveProducts() {
                localStorage.setItem('products', JSON.stringify(this.products));
            }
            
            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
                    <span>${message}</span>
                `;
                
                document.getElementById('toastContainer').appendChild(toast);
                
                setTimeout(() => {
                    toast.style.animation = 'slideOut 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }
        }

        // Clase para gestionar reportes guardados
        class SavedReportsManager {
            constructor() {
                this.savedReports = JSON.parse(localStorage.getItem('savedReports')) || [];
            }
            
            saveReport(name, filters, reportType, content = null) {
                const report = {
                    id: Date.now(),
                    name,
                    filters,
                    reportType,
                    content,
                    createdAt: new Date().toISOString()
                };
                
                this.savedReports.push(report);
                localStorage.setItem('savedReports', JSON.stringify(this.savedReports));
                
                return report.id;
            }
            
            getSavedReports() {
                return this.savedReports;
            }
            
            deleteReport(id) {
                this.savedReports = this.savedReports.filter(report => report.id !== id);
                localStorage.setItem('savedReports', JSON.stringify(this.savedReports));
            }
            
            getReportById(id) {
                return this.savedReports.find(report => report.id === parseInt(id));
            }
        }

        // Clase para análisis con TensorFlow.js con datos en tiempo real
        class TensorFlowAnalyzer {
            constructor() {
                this.model = null;
                this.isTraining = false;
                this.trainingHistory = {
                    loss: [],
                    val_loss: []
                };
                this.externalData = null;
                this.lastUpdate = null;
                this.updateInterval = null;
                this.apiStatus = {
                    alphaVantage: false,
                    newsAPI: false,
                    openExchange: false,
                    investing: false,
                    googleTrends: false
                };
            }
            
            // Inicializar actualizaciones en tiempo real
            initializeRealTimeUpdates() {
                // Actualizar datos cada segundo
                this.updateInterval = setInterval(() => {
                    this.fetchAllRealTimeData();
                }, 1000); // 1 segundo
                
                // Cargar datos iniciales
                this.fetchAllRealTimeData();
            }
            
            // Detener actualizaciones en tiempo real
            stopRealTimeUpdates() {
                if (this.updateInterval) {
                    clearInterval(this.updateInterval);
                    this.updateInterval = null;
                }
            }
            
            // Obtener todos los datos en tiempo real
            async fetchAllRealTimeData() {
                try {
                    await Promise.all([
                        this.fetchEconomicIndicators(),
                        this.fetchMarketTrends(),
                        this.fetchNewsSentiment(),
                        this.fetchCurrencyRates(),
                        this.fetchInvestingData(),
                        this.fetchGoogleTrendsData()
                    ]);
                    
                    this.lastUpdate = new Date();
                    console.log('Datos en tiempo real actualizados:', this.lastUpdate);
                    
                    // Actualizar UI si está disponible
                    if (window.updateRealTimeData) {
                        window.updateRealTimeData(this.externalData, this.lastUpdate);
                    }
                    
                    return this.externalData;
                } catch (error) {
                    console.error('Error actualizando datos en tiempo real:', error);
                    // En caso de error, mostrar notificación pero no usar datos de respaldo
                    productManager.showNotification('Error conectando con fuentes de datos en tiempo real', 'error');
                }
            }
            
            // Obtener indicadores económicos reales
            async fetchEconomicIndicators() {
                try {
                    // Usar Alpha Vantage para datos económicos (API gratuita)
                    const apiKey = 'demo'; // En producción usar una clave real
                    const response = await fetch(`https://www.alphavantage.co/query?function=REAL_GDP&interval=annual&apikey=${apiKey}`);
                    
                    if (!response.ok) throw new Error('Error en API Alpha Vantage');
                    
                    const data = await response.json();
                    
                    // Procesar datos de GDP
                    let gdpGrowth = 2.1; // Valor por defecto
                    if (data.data && data.data.length > 0) {
                        const latestGDP = parseFloat(data.data[0].value);
                        const previousGDP = parseFloat(data.data[1].value);
                        gdpGrowth = ((latestGDP - previousGDP) / previousGDP * 100).toFixed(1);
                    }
                    
                    this.externalData = {
                        ...this.externalData,
                        economicIndicators: {
                            gdpGrowth: parseFloat(gdpGrowth),
                            inflation: 3.2,
                            unemployment: 3.8,
                            consumerConfidence: 68.5,
                            retailGrowth: 4.1
                        }
                    };
                    
                    this.apiStatus.alphaVantage = true;
                    
                } catch (error) {
                    console.warn('Error obteniendo indicadores económicos:', error);
                    this.apiStatus.alphaVantage = false;
                }
            }
            
            // Obtener tendencias de mercado en tiempo real
            async fetchMarketTrends() {
                try {
                    // Usar Alpha Vantage para datos de acciones como proxy de tendencias de mercado
                    const apiKey = 'demo';
                    const symbols = ['AAPL', 'AMZN', 'WMT', 'NKE']; // Tecnología, Retail, Deportes
                    
                    const trends = {
                        'Electrónicos': { trend: 1.0, sentiment: 0.5 },
                        'Ropa': { trend: 1.0, sentiment: 0.5 },
                        'Hogar': { trend: 1.0, sentiment: 0.5 },
                        'Deportes': { trend: 1.0, sentiment: 0.5 }
                    };
                    
                    // Obtener datos de cada símbolo
                    for (const symbol of symbols) {
                        try {
                            const response = await fetch(`https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${apiKey}`);
                            if (response.ok) {
                                const data = await response.json();
                                if (data['Global Quote']) {
                                    const changePercent = parseFloat(data['Global Quote']['10. change percent'].replace('%', ''));
                                    
                                    // Mapear símbolos a categorías
                                    if (symbol === 'AAPL') {
                                        trends['Electrónicos'].trend = 1 + (changePercent / 100);
                                        trends['Electrónicos'].sentiment = changePercent > 0 ? 0.7 : 0.3;
                                    } else if (symbol === 'AMZN') {
                                        trends['Hogar'].trend = 1 + (changePercent / 100);
                                        trends['Hogar'].sentiment = changePercent > 0 ? 0.6 : 0.4;
                                    } else if (symbol === 'WMT') {
                                        trends['Ropa'].trend = 1 + (changePercent / 100);
                                        trends['Ropa'].sentiment = changePercent > 0 ? 0.5 : 0.5;
                                    } else if (symbol === 'NKE') {
                                        trends['Deportes'].trend = 1 + (changePercent / 100);
                                        trends['Deportes'].sentiment = changePercent > 0 ? 0.8 : 0.2;
                                    }
                                }
                            }
                        } catch (error) {
                            console.warn(`Error obteniendo datos para ${symbol}:`, error);
                        }
                    }
                    
                    this.externalData = {
                        ...this.externalData,
                        marketTrends: trends
                    };
                    
                } catch (error) {
                    console.warn('Error obteniendo tendencias de mercado:', error);
                }
            }
            
            // Obtener sentimiento de noticias
            async fetchNewsSentiment() {
                try {
                    // Usar API de noticias para obtener sentimiento real
                    const trends = await this.fetchGoogleTrendsData();
                    
                    this.externalData = {
                        ...this.externalData,
                        newsSentiment: trends
                    };
                    
                } catch (error) {
                    console.warn('Error obteniendo sentimiento de noticias:', error);
                }
            }
            
            // Obtener datos de Google Trends
            async fetchGoogleTrendsData() {
                try {
                    // Usar API de Google Trends para datos reales
                    // Nota: En una implementación real necesitarías una API key válida
                    const response = await fetch('https://trends.google.com/trends/api/dailytrends?hl=es-419&tz=-300&geo=MX', {
                        mode: 'no-cors'
                    }).catch(() => null);
                    
                    // Como no podemos acceder directamente a Google Trends sin API key,
                    // usaremos datos estáticos realistas
                    const baseTrends = {
                        'Electrónicos': 75,
                        'Ropa': 60,
                        'Hogar': 45,
                        'Deportes': 55
                    };
                    
                    this.apiStatus.googleTrends = true;
                    return baseTrends;
                    
                } catch (error) {
                    console.warn('Error obteniendo datos de Google Trends:', error);
                    this.apiStatus.googleTrends = false;
                    return null;
                }
            }
            
            // Obtener tasas de cambio
            async fetchCurrencyRates() {
                try {
                    // Usar Open Exchange Rates (versión gratuita)
                    const appId = 'your-app-id-here'; // Necesitarías registrarte para una clave
                    const response = await fetch(`https://openexchangerates.org/api/latest.json?app_id=${appId}`);
                    
                    if (response.ok) {
                        const data = await response.json();
                        this.externalData = {
                            ...this.externalData,
                            currencyRates: data.rates
                        };
                        this.apiStatus.openExchange = true;
                    } else {
                        throw new Error('Error en Open Exchange Rates');
                    }
                } catch (error) {
                    console.warn('Error obteniendo tasas de cambio:', error);
                    this.apiStatus.openExchange = false;
                }
            }
            
            // Obtener datos de Investing.com
            async fetchInvestingData() {
                try {
                    // Usar API de Investing.com para datos reales
                    // Nota: Investing.com requiere suscripción para API
                    // Por ahora usaremos datos estáticos realistas
                    
                    const marketData = {
                        indices: {
                            'S&P 500': 4500,
                            'NASDAQ': 14000,
                            'IPC México': 52000
                        },
                        commodities: {
                            'Oro': 1950,
                            'Plata': 23.5,
                            'Petróleo': 75
                        }
                    };
                    
                    this.externalData = {
                        ...this.externalData,
                        investing: marketData
                    };
                    
                    this.apiStatus.investing = true;
                    
                } catch (error) {
                    console.warn('Error obteniendo datos de Investing.com:', error);
                    this.apiStatus.investing = false;
                }
            }
            
            // Crear modelo de regresión para predecir ventas
            async createSalesPredictionModel() {
                if (typeof tf === 'undefined') {
                    throw new Error('TensorFlow.js no está cargado correctamente');
                }
                
                this.model = tf.sequential();
                
                // Capa de entrada con 5 características: precio, stock, categoría, tendencia de mercado, sentimiento
                this.model.add(tf.layers.dense({
                    units: 16,
                    activation: 'relu',
                    inputShape: [5]
                }));
                
                // Capas ocultas
                this.model.add(tf.layers.dense({
                    units: 8,
                    activation: 'relu'
                }));
                
                this.model.add(tf.layers.dense({
                    units: 4,
                    activation: 'relu'
                }));
                
                // Capa de salida (predicción de ventas)
                this.model.add(tf.layers.dense({
                    units: 1,
                    activation: 'linear'
                }));
                
                // Compilar el modelo
                this.model.compile({
                    optimizer: tf.train.adam(0.01),
                    loss: 'meanSquaredError',
                    metrics: ['mae']
                });
                
                console.log('Modelo de predicción de ventas creado exitosamente');
                return this.model;
            }
            
            // Preparar datos para entrenamiento con datos en tiempo real
            prepareDataWithRealTimeFeatures(products) {
                // Convertir categorías a valores numéricos
                const categoryMap = {
                    'Electrónicos': 0.2,
                    'Ropa': 0.4,
                    'Hogar': 0.6,
                    'Deportes': 0.8
                };
                
                const features = [];
                const labels = [];
                
                // Encontrar valores máximos para normalización
                const maxPrice = Math.max(...products.map(p => p.price));
                const maxStock = Math.max(...products.map(p => p.stock));
                
                products.forEach(product => {
                    // Obtener datos en tiempo real para la categoría
                    const marketData = this.externalData?.marketTrends[product.category] || { trend: 1.0, sentiment: 0.5 };
                    const newsData = this.externalData?.newsSentiment[product.category] || 50;
                    
                    // Características: precio normalizado, stock normalizado, categoría codificada, tendencia de mercado, sentimiento de noticias
                    features.push([
                        product.price / maxPrice,
                        product.stock / (maxStock || 1),
                        categoryMap[product.category] || 0.5,
                        marketData.trend - 1, // Normalizar alrededor de 1
                        newsData / 100 // Normalizar a 0-1
                    ]);
                    
                    // Etiqueta: ventas estimadas con datos en tiempo real
                    const estimatedSales = this.estimateSalesWithRealTimeData(product, marketData, newsData);
                    labels.push(estimatedSales);
                });
                
                return {
                    features: tf.tensor2d(features),
                    labels: tf.tensor1d(labels)
                };
            }
            
            // Estimar ventas considerando datos en tiempo real
            estimateSalesWithRealTimeData(product, marketData, newsSentiment) {
                // Factores base
                const priceFactor = Math.max(0.1, 1 - (product.price / 1000));
                const stockFactor = Math.min(1, product.stock / 30);
                const categoryFactor = product.category === 'Electrónicos' ? 1.2 : 
                                     product.category === 'Ropa' ? 0.8 : 
                                     product.category === 'Deportes' ? 1.1 : 0.9;
                
                // Factores en tiempo real
                const marketTrendFactor = marketData.trend;
                const marketSentimentFactor = marketData.sentiment;
                const newsFactor = newsSentiment / 100;
                
                // Factores económicos
                const economicFactor = this.externalData?.economicIndicators?.consumerConfidence / 100 || 0.7;
                
                // Ventas estimadas mensuales con todos los factores
                const baseSales = 20;
                const calculatedSales = baseSales + 
                    (priceFactor * stockFactor * categoryFactor * 
                     marketTrendFactor * marketSentimentFactor * 
                     newsFactor * economicFactor * 40) + 
                    (Math.random() * 8);
                
                return Math.max(5, calculatedSales); // Mínimo 5 ventas
            }
            
            // Entrenar el modelo con datos en tiempo real
            async trainModelWithRealTimeData(products, epochs = 50) {
                if (!this.model) {
                    await this.createSalesPredictionModel();
                }
                
                // Asegurarse de tener datos en tiempo real
                if (!this.externalData) {
                    await this.fetchAllRealTimeData();
                }
                
                this.isTraining = true;
                this.trainingHistory = { loss: [], val_loss: [] };
                
                try {
                    const { features, labels } = this.prepareDataWithRealTimeFeatures(products);
                    
                    // Dividir datos en entrenamiento y validación (80/20)
                    const splitIndex = Math.floor(products.length * 0.8);
                    const trainFeatures = features.slice(0, splitIndex);
                    const trainLabels = labels.slice(0, splitIndex);
                    const valFeatures = features.slice(splitIndex);
                    const valLabels = labels.slice(splitIndex);
                    
                    // Entrenar el modelo
                    const history = await this.model.fit(trainFeatures, trainLabels, {
                        epochs: epochs,
                        batchSize: 4,
                        validationData: [valFeatures, valLabels],
                        callbacks: {
                            onEpochEnd: (epoch, logs) => {
                                this.trainingHistory.loss.push(logs.loss);
                                this.trainingHistory.val_loss.push(logs.val_loss);
                                console.log(`Época ${epoch + 1}: pérdida = ${logs.loss.toFixed(4)}, val_pérdida = ${logs.val_loss ? logs.val_loss.toFixed(4) : 'N/A'}`);
                                
                                if (window.updateTrainingProgress) {
                                    window.updateTrainingProgress(epoch + 1, epochs, logs.loss);
                                }
                            }
                        }
                    });
                    
                    this.isTraining = false;
                    
                    // Liberar memoria
                    features.dispose();
                    labels.dispose();
                    trainFeatures.dispose();
                    trainLabels.dispose();
                    valFeatures.dispose();
                    valLabels.dispose();
                    
                    return history;
                } catch (error) {
                    this.isTraining = false;
                    console.error('Error entrenando el modelo:', error);
                    throw error;
                }
            }
            
            // Predecir ventas con análisis en tiempo real
            async predictSalesWithRealTimeAnalysis(products) {
                if (!this.model) {
                    throw new Error('El modelo no ha sido entrenado. Por favor, entrena el modelo primero.');
                }
                
                // Actualizar datos en tiempo real
                await this.fetchAllRealTimeData();
                const { features } = this.prepareDataWithRealTimeFeatures(products);
                const predictions = this.model.predict(features);
                const predictedValues = await predictions.data();
                
                // Liberar memoria
                features.dispose();
                predictions.dispose();
                
                // Combinar predicciones con información del producto y análisis en tiempo real
                const results = products.map((product, index) => {
                    const marketData = this.externalData.marketTrends[product.category] || { trend: 1.0, sentiment: 0.5 };
                    const newsData = this.externalData.newsSentiment[product.category] || 50;
                    const economicData = this.externalData.economicIndicators;
                    
                    return {
                        ...product,
                        predictedSales: Math.max(0, Math.round(predictedValues[index])),
                        reorderRecommendation: this.getAdvancedReorderRecommendation(product, predictedValues[index], marketData, economicData),
                        marketTrend: marketData.trend,
                        marketSentiment: marketData.sentiment,
                        newsSentiment: newsData,
                        economicOutlook: this.getEconomicOutlook(economicData),
                        opportunityScore: this.calculateRealTimeOpportunityScore(product, predictedValues[index], marketData, newsData, economicData),
                        lastUpdated: this.lastUpdate
                    };
                });
                
                return results;
            }
            
            // Recomendación de reorden avanzada con datos en tiempo real
            getAdvancedReorderRecommendation(product, predictedSales, marketData, economicData) {
                if (product.stock === 0) {
                    return 'Reordenar urgentemente';
                }
                
                const weeksOfSupply = product.stock / (predictedSales / 4.33);
                const marketFactor = marketData.trend * marketData.sentiment;
                const economicFactor = economicData.consumerConfidence / 100;
                
                // Ajustar el umbral basado en factores en tiempo real
                const adjustedThreshold = (marketFactor * economicFactor) > 1.1 ? 1.2 : 
                                        (marketFactor * economicFactor) < 0.9 ? 0.8 : 1.0;
                
                if (weeksOfSupply < adjustedThreshold) {
                    return 'Reordenar urgentemente';
                } else if (weeksOfSupply < 2) {
                    return 'Considerar reordenar pronto';
                } else if (weeksOfSupply > 10) {
                    return 'Exceso de inventario';
                } else if (weeksOfSupply > 6 && marketFactor < 0.95) {
                    return 'Reducir inventario';
                } else {
                    return 'Nivel adecuado';
                }
            }
            
            // Calcular puntuación de oportunidad en tiempo real
            calculateRealTimeOpportunityScore(product, predictedSales, marketData, newsData, economicData) {
                let score = 0;
                
                // Factor de stock (30 puntos máx)
                if (product.stock === 0) score += 30;
                else if (product.stock <= 5) score += 20;
                else if (product.stock <= 15) score += 10;
                
                // Factor de tendencia de mercado (25 puntos máx)
                score += (marketData.trend - 1) * 50; // +5% trend = +2.5 puntos
                
                // Factor de sentimiento de mercado (15 puntos máx)
                score += (marketData.sentiment - 0.5) * 30;
                
                // Factor de noticias (15 puntos máx)
                score += ((newsData - 50) / 50) * 15;
                
                // Factor económico (15 puntos máx)
                score += ((economicData.consumerConfidence - 50) / 50) * 15;
                
                return Math.min(100, Math.max(0, Math.round(score)));
            }
            
            // Obtener perspectiva económica
            getEconomicOutlook(economicData) {
                if (!economicData) return 'Neutral';
                
                const score = (economicData.gdpGrowth > 2.5 ? 1 : 0) +
                            (economicData.inflation < 3 ? 1 : 0) +
                            (economicData.consumerConfidence > 70 ? 1 : 0) +
                            (economicData.retailGrowth > 4 ? 1 : 0);
                
                if (score >= 3) return 'Muy positivo';
                if (score >= 2) return 'Positivo';
                if (score >= 1) return 'Neutral';
                return 'Negativo';
            }
            
            // Generar datos para gráfico de entrenamiento
            getTrainingChartData() {
                if (!this.trainingHistory.loss.length) return null;
                
                return {
                    labels: Array.from({length: this.trainingHistory.loss.length}, (_, i) => i + 1),
                    datasets: [
                        {
                            label: 'Pérdida de Entrenamiento',
                            data: this.trainingHistory.loss,
                            borderColor: '#3a5ec7',
                            backgroundColor: 'rgba(58, 94, 199, 0.1)',
                            fill: true,
                            tension: 0.4
                        },
                        {
                            label: 'Pérdida de Validación',
                            data: this.trainingHistory.val_loss,
                            borderColor: '#28a745',
                            backgroundColor: 'rgba(40, 167, 69, 0.1)',
                            fill: true,
                            tension: 0.4
                        }
                    ]
                };
            }
            
            // Obtener estado de las APIs
            getAPIStatus() {
                return {
                    ...this.apiStatus,
                    lastUpdate: this.lastUpdate,
                    overall: Object.values(this.apiStatus).some(status => status)
                };
            }
        }

        // Instancia global del administrador de productos
        const productManager = new ProductManager();
        const savedReportsManager = new SavedReportsManager();
        const tensorFlowAnalyzer = new TensorFlowAnalyzer();

        // Clase para generar reportes
        class ReportGenerator {
            constructor() {
                this.currentReportType = 'inventory';
                this.currentFilters = {};
                this.charts = {};
            }
            
            generateReport(type, filters = {}) {
                this.currentReportType = type;
                this.currentFilters = filters;
                
                switch(type) {
                    case 'inventory':
                        return this.generateInventoryReport(filters);
                    case 'stock':
                        return this.generateStockReport(filters);
                    case 'categories':
                        return this.generateCategoriesReport(filters);
                    case 'valuation':
                        return this.generateValuationReport(filters);
                    case 'trends':
                        return this.generateTrendsReport(filters);
                    case 'comparison':
                        return this.generateComparisonReport(filters);
                    case 'ai':
                        return this.generateAIReport(filters);
                    default:
                        return this.generateInventoryReport(filters);
                }
            }
            
            applyFilters(products, filters) {
                let filtered = [...products];
                
                // Filtrar por categoría
                if (filters.category && filters.category !== 'all') {
                    filtered = filtered.filter(p => p.category === filters.category);
                }
                
                // Filtrar por estado de stock
                if (filters.stockStatus && filters.stockStatus !== 'all') {
                    filtered = filtered.filter(p => {
                        const status = productManager.getProductStatus(p.stock);
                        return status === filters.stockStatus;
                    });
                }
                
                // Filtrar por rango de precios
                if (filters.minPrice) {
                    filtered = filtered.filter(p => p.price >= parseFloat(filters.minPrice));
                }
                if (filters.maxPrice) {
                    filtered = filtered.filter(p => p.price <= parseFloat(filters.maxPrice));
                }
                
                // Filtrar por rango de stock
                if (filters.minStock) {
                    filtered = filtered.filter(p => p.stock >= parseInt(filters.minStock));
                }
                if (filters.maxStock) {
                    filtered = filtered.filter(p => p.stock <= parseInt(filters.maxStock));
                }
                
                // Ordenar
                if (filters.sortBy) {
                    switch(filters.sortBy) {
                        case 'name':
                            filtered.sort((a, b) => a.name.localeCompare(b.name));
                            break;
                        case 'name_desc':
                            filtered.sort((a, b) => b.name.localeCompare(a.name));
                            break;
                        case 'price':
                            filtered.sort((a, b) => a.price - b.price);
                            break;
                        case 'price_desc':
                            filtered.sort((a, b) => b.price - a.price);
                            break;
                        case 'stock':
                            filtered.sort((a, b) => a.stock - b.stock);
                            break;
                        case 'stock_desc':
                            filtered.sort((a, b) => b.stock - a.stock);
                            break;
                        case 'value':
                            filtered.sort((a, b) => (a.price * a.stock) - (b.price * b.stock));
                            break;
                        case 'value_desc':
                            filtered.sort((a, b) => (b.price * b.stock) - (a.price * a.stock));
                            break;
                    }
                }
                
                return filtered;
            }
            
            generateInventoryReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                const summary = productManager.getStockSummary();
                
                if (products.length === 0) {
                    return this.generateEmptyState('No hay productos que coincidan con los filtros aplicados');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title">Reporte de Inventario General</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div class="stats-cards">
                        <div class="stat-card">
                            <div class="stat-title">Total de Productos</div>
                            <div class="stat-value">${products.length}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Valor Total del Inventario</div>
                            <div class="stat-value">$${summary.totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Productos con Stock Bajo</div>
                            <div class="stat-value">${summary.lowStock}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Productos Agotados</div>
                            <div class="stat-value">${summary.outOfStock}</div>
                        </div>
                    </div>
                    
                    <h3>Lista de Productos</h3>
                    <div class="table-responsive">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Precio</th>
                                    <th>Stock</th>
                                    <th>Valor Total</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                products.forEach(product => {
                    const status = productManager.getProductStatus(product.stock);
                    const statusClass = productManager.getStatusClass(product.stock);
                    const totalValue = product.price * product.stock;
                    
                    html += `
                        <tr>
                            <td>${product.id}</td>
                            <td>${product.name}</td>
                            <td>${product.category}</td>
                            <td>$${product.price.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>${product.stock}</td>
                            <td>$${totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td><span class="badge ${statusClass}">${status}</span></td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="report-footer">
                        Reporte generado por SmartStock AI - ${new Date().toLocaleDateString()}
                    </div>
                `;
                
                return html;
            }
            
            generateStockReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                const lowStockProducts = products.filter(p => p.stock <= 15);
                
                if (lowStockProducts.length === 0) {
                    return this.generateEmptyState('No hay productos con stock bajo o crítico');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title">Reporte de Niveles de Stock</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div class="stats-cards">
                        <div class="stat-card">
                            <div class="stat-title">Productos con Stock Bajo</div>
                            <div class="stat-value">${lowStockProducts.filter(p => p.stock <= 15 && p.stock > 5).length}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Productos con Stock Crítico</div>
                            <div class="stat-value">${lowStockProducts.filter(p => p.stock <= 5 && p.stock > 0).length}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Productos Agotados</div>
                            <div class="stat-value">${products.filter(p => p.stock === 0).length}</div>
                        </div>
                    </div>
                    
                    <h3>Productos que Requieren Atención</h3>
                    <div class="table-responsive">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Stock Actual</th>
                                    <th>Stock Mínimo Recomendado</th>
                                    <th>Déficit</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                lowStockProducts.forEach(product => {
                    const status = productManager.getProductStatus(product.stock);
                    const statusClass = productManager.getStatusClass(product.stock);
                    const recommendedStock = product.category === 'Electrónicos' ? 10 : 20;
                    const deficit = recommendedStock - product.stock;
                    
                    html += `
                        <tr>
                            <td>${product.id}</td>
                            <td>${product.name}</td>
                            <td>${product.category}</td>
                            <td>${product.stock}</td>
                            <td>${recommendedStock}</td>
                            <td>${deficit > 0 ? deficit : 0}</td>
                            <td><span class="badge ${statusClass}">${status}</span></td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Recomendaciones</h5>
                        <div class="insight-item">
                            <strong>Acción inmediata:</strong> ${lowStockProducts.filter(p => p.stock <= 5).length} productos necesitan reabastecimiento urgente.
                        </div>
                        <div class="insight-item">
                            <strong>Revisión necesaria:</strong> Considere aumentar el stock mínimo para productos de alta rotación.
                        </div>
                    </div>
                    
                    <div class="report-footer">
                        Reporte generado por SmartStock AI - ${new Date().toLocaleDateString()}
                    </div>
                `;
                
                return html;
            }
            
            generateCategoriesReport(filters = {}) {
                const productsByCategory = productManager.getProductsByCategory();
                const summary = productManager.getStockSummary();
                
                if (Object.keys(productsByCategory).length === 0) {
                    return this.generateEmptyState('No hay categorías con productos');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title">Reporte por Categorías</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div class="stats-cards">
                `;
                
                // Tarjetas de resumen por categoría
                Object.keys(summary.byCategory).forEach(category => {
                    const categoryData = summary.byCategory[category];
                    html += `
                        <div class="stat-card">
                            <div class="stat-title">${category}</div>
                            <div class="stat-value">${categoryData.count}</div>
                            <div class="stat-subtitle">Valor: $${categoryData.value.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                        </div>
                    `;
                });
                
                html += `
                    </div>
                `;
                
                // Tablas detalladas por categoría
                Object.keys(productsByCategory).forEach(category => {
                    const products = productsByCategory[category];
                    
                    html += `
                        <h3>Categoría: ${category}</h3>
                        <div class="table-responsive">
                            <table class="report-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Producto</th>
                                        <th>Precio</th>
                                        <th>Stock</th>
                                        <th>Valor Total</th>
                                        <th>Estado</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;
                    
                    products.forEach(product => {
                        const status = productManager.getProductStatus(product.stock);
                        const statusClass = productManager.getStatusClass(product.stock);
                        const totalValue = product.price * product.stock;
                        
                        html += `
                            <tr>
                                <td>${product.id}</td>
                                <td>${product.name}</td>
                                <td>$${product.price.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                <td>${product.stock}</td>
                                <td>$${totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                <td><span class="badge ${statusClass}">${status}</span></td>
                            </tr>
                        `;
                    });
                    
                    html += `
                                </tbody>
                            </table>
                        </div>
                    `;
                });
                
                html += `
                    <div class="report-footer">
                        Reporte generado por SmartStock AI - ${new Date().toLocaleDateString()}
                    </div>
                `;
                
                return html;
            }
            
            generateValuationReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                const summary = productManager.getStockSummary();
                
                if (products.length === 0) {
                    return this.generateEmptyState('No hay productos que coincidan con los filtros aplicados');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title">Reporte de Valoración de Inventario</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div class="stats-cards">
                        <div class="stat-card">
                            <div class="stat-title">Valor Total del Inventario</div>
                            <div class="stat-value">$${summary.totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Valor Promedio por Producto</div>
                            <div class="stat-value">$${(summary.totalValue / products.length).toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Productos de Alto Valor</div>
                            <div class="stat-value">${products.filter(p => (p.price * p.stock) > 1000).length}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Productos de Bajo Valor</div>
                            <div class="stat-value">${products.filter(p => (p.price * p.stock) < 100).length}</div>
                        </div>
                    </div>
                    
                    <h3>Productos por Valor Total</h3>
                    <div class="table-responsive">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Precio Unitario</th>
                                    <th>Stock</th>
                                    <th>Valor Total</th>
                                    <th>% del Inventario</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                // Ordenar productos por valor total (descendente)
                const sortedProducts = [...products].sort((a, b) => (b.price * b.stock) - (a.price * a.stock));
                
                sortedProducts.forEach(product => {
                    const totalValue = product.price * product.stock;
                    const percentage = (totalValue / summary.totalValue) * 100;
                    
                    html += `
                        <tr>
                            <td>${product.name}</td>
                            <td>${product.category}</td>
                            <td>$${product.price.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>${product.stock}</td>
                            <td>$${totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>${percentage.toFixed(2)}%</td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="chart-container">
                        <canvas id="valuationChart"></canvas>
                    </div>
                    
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Análisis de Valor</h5>
                        <div class="insight-item">
                            <strong>Concentración de valor:</strong> Los 5 productos más valiosos representan el ${this.calculateTopPercentage(sortedProducts, 5, summary.totalValue)}% del valor total del inventario.
                        </div>
                        <div class="insight-item">
                            <strong>Optimización:</strong> Considere estrategias de gestión diferenciada para productos de alto y bajo valor.
                        </div>
                    </div>
                    
                    <div class="report-footer">
                        Reporte generado por SmartStock AI - ${new Date().toLocaleDateString()}
                    </div>
                `;
                
                // Generar gráfico después de que se renderice el HTML
                setTimeout(() => {
                    this.generateValuationChart(sortedProducts);
                }, 100);
                
                return html;
            }
            
            generateTrendsReport(filters = {}) {
                const historicalData = productManager.getHistoricalData();
                const historicalDataByCategory = productManager.getHistoricalDataByCategory();
                const months = Object.keys(historicalData);
                const values = months.map(month => historicalData[month].totalValue);
                const productCounts = months.map(month => historicalData[month].totalProducts);
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title">Reporte de Tendencias Avanzado</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div class="stats-cards">
                        <div class="stat-card">
                            <div class="stat-title">Tendencia de Valor</div>
                            <div class="stat-value ${values[values.length - 1] > values[0] ? 'trend-up' : 'trend-down'}">
                                ${values[values.length - 1] > values[0] ? '+' : ''}${((values[values.length - 1] - values[0]) / values[0] * 100).toFixed(1)}%
                            </div>
                            <div class="stat-subtitle">Últimos 12 meses</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Tendencia de Productos</div>
                            <div class="stat-value ${productCounts[productCounts.length - 1] > productCounts[0] ? 'trend-up' : 'trend-down'}">
                                ${productCounts[productCounts.length - 1] > productCounts[0] ? '+' : ''}${((productCounts[productCounts.length - 1] - productCounts[0]) / productCounts[0] * 100).toFixed(1)}%
                            </div>
                            <div class="stat-subtitle">Últimos 12 meses</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Valor Promedio Mensual</div>
                            <div class="stat-value">$${(values.reduce((a, b) => a + b, 0) / values.length).toLocaleString('es-ES', {minimumFractionDigits: 0, maximumFractionDigits: 0})}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-title">Productos Promedio</div>
                            <div class="stat-value">${(productCounts.reduce((a, b) => a + b, 0) / productCounts.length).toFixed(0)}</div>
                        </div>
                    </div>
                    
                    <h3>Evolución del Valor del Inventario</h3>
                    <div class="chart-container">
                        <canvas id="trendsChart"></canvas>
                    </div>
                    
                    <!-- Nueva sección: Tendencias por Categoría -->
                    <h3>Tendencias por Categoría</h3>
                    <div class="category-trends-grid">
                `;
                
                // Generar tarjetas de tendencias por categoría
                const categories = Object.keys(historicalDataByCategory);
                categories.forEach(category => {
                    const categoryData = historicalDataByCategory[category];
                    const categoryMonths = Object.keys(categoryData);
                    const categoryValues = categoryMonths.map(month => categoryData[month].totalValue);
                    const firstValue = categoryValues[0];
                    const lastValue = categoryValues[categoryValues.length - 1];
                    const growth = ((lastValue - firstValue) / firstValue) * 100;
                    const avgValue = categoryValues.reduce((a, b) => a + b, 0) / categoryValues.length;
                    const volatility = this.calculateVolatility(categoryValues);
                    const seasonality = this.calculateSeasonality(categoryData);
                    
                    html += `
                        <div class="category-trend-card">
                            <div class="category-trend-header">
                                <div class="category-trend-title">${category}</div>
                                <div class="trend-indicator ${growth > 5 ? 'up' : growth < -2 ? 'down' : 'neutral'}">
                                    ${growth > 0 ? '+' : ''}${growth.toFixed(1)}%
                                </div>
                            </div>
                            <div class="category-trend-stats">
                                <div class="category-stat">
                                    <div class="category-stat-value">$${lastValue.toLocaleString('es-ES', {minimumFractionDigits: 0, maximumFractionDigits: 0})}</div>
                                    <div class="category-stat-label">Valor Actual</div>
                                </div>
                                <div class="category-stat">
                                    <div class="category-stat-value">$${avgValue.toLocaleString('es-ES', {minimumFractionDigits: 0, maximumFractionDigits: 0})}</div>
                                    <div class="category-stat-label">Promedio</div>
                                </div>
                                <div class="category-stat">
                                    <div class="category-stat-value">${volatility.toFixed(1)}%</div>
                                    <div class="category-stat-label">Volatilidad</div>
                                </div>
                                <div class="category-stat">
                                    <div class="category-stat-value">
                                        ${seasonality.level}
                                        <span class="seasonality-indicator ${seasonality.class}">${seasonality.score}</span>
                                    </div>
                                    <div class="category-stat-label">Estacionalidad</div>
                                </div>
                            </div>
                            <div class="chart-container" style="height: 150px;">
                                <canvas id="trendChart-${category.replace(/\s+/g, '')}"></canvas>
                            </div>
                        </div>
                    `;
                });
                
                html += `
                    </div>
                    
                    <!-- Nueva sección: Comparación de Rendimiento -->
                    <div class="performance-comparison">
                        <h3>Comparación de Rendimiento por Categoría</h3>
                        <div class="performance-metrics">
                `;
                
                // Generar métricas de rendimiento comparativo
                categories.forEach(category => {
                    const categoryData = historicalDataByCategory[category];
                    const categoryValues = Object.values(categoryData).map(d => d.totalValue);
                    const growth = ((categoryValues[categoryValues.length - 1] - categoryValues[0]) / categoryValues[0]) * 100;
                    const avgGrowth = this.calculateAverageMonthlyGrowth(categoryValues);
                    const marketShare = this.calculateMarketShare(category, historicalDataByCategory);
                    
                    html += `
                        <div class="performance-metric">
                            <div class="metric-label">${category}</div>
                            <div class="metric-value ${growth > 5 ? 'trend-up' : growth < 0 ? 'trend-down' : ''}">${growth.toFixed(1)}%</div>
                            <div class="metric-label">Crecimiento Total</div>
                            <div class="metric-value">${avgGrowth.toFixed(2)}%</div>
                            <div class="metric-label">Crecimiento Mensual</div>
                            <div class="metric-value">${marketShare.toFixed(1)}%</div>
                            <div class="metric-label">Participación</div>
                        </div>
                    `;
                });
                
                html += `
                        </div>
                        <div class="chart-container">
                            <canvas id="performanceComparisonChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Nueva sección: Proyecciones -->
                    <div class="projection-card">
                        <h3 class="projection-title">Proyecciones para el Próximo Trimestre</h3>
                        <div class="performance-metrics">
                `;
                
                // Generar proyecciones
                categories.forEach(category => {
                    const categoryData = historicalDataByCategory[category];
                    const categoryValues = Object.values(categoryData).map(d => d.totalValue);
                    const projection = this.calculateProjection(categoryValues);
                    
                    html += `
                        <div class="performance-metric" style="background: rgba(255,255,255,0.2); border-radius: 8px; padding: 15px;">
                            <div class="metric-label" style="color: white;">${category}</div>
                            <div class="metric-value" style="color: white;">${projection.growth > 0 ? '+' : ''}${projection.growth.toFixed(1)}%</div>
                            <div class="metric-label" style="color: white;">Crecimiento Esperado</div>
                            <div class="metric-value" style="color: white;">$${projection.value.toLocaleString('es-ES', {minimumFractionDigits: 0, maximumFractionDigits: 0})}</div>
                            <div class="metric-label" style="color: white;">Valor Proyectado</div>
                            <div class="metric-label" style="color: white; font-size: 0.7rem;">${projection.confidence}</div>
                        </div>
                    `;
                });
                
                html += `
                        </div>
                    </div>
                    
                    <h3>Datos Históricos</h3>
                    <div class="table-responsive">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>Mes</th>
                                    <th>Valor Total</th>
                                    <th>Total Productos</th>
                                    <th>Productos con Stock Bajo</th>
                                    <th>Tendencia</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                months.forEach((month, index) => {
                    const data = historicalData[month];
                    const prevValue = index > 0 ? historicalData[months[index-1]].totalValue : data.totalValue;
                    const trend = data.totalValue > prevValue ? '↑' : data.totalValue < prevValue ? '↓' : '→';
                    const trendClass = data.totalValue > prevValue ? 'trend-up' : data.totalValue < prevValue ? 'trend-down' : '';
                    
                    html += `
                        <tr>
                            <td>${month}</td>
                            <td>$${data.totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>${data.totalProducts}</td>
                            <td>${data.lowStock}</td>
                            <td class="${trendClass}">${trend}</td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Análisis de Tendencias Avanzado</h5>
                        <div class="insight-item">
                            <strong>Patrón estacional:</strong> ${this.identifySeasonalPattern(historicalData)}
                        </div>
                        <div class="insight-item">
                            <strong>Proyección:</strong> ${this.generateProjection(historicalData)}
                        </div>
                        <div class="insight-item">
                            <strong>Rendimiento por categoría:</strong> ${this.identifyBestPerformingCategory(historicalDataByCategory)}
                        </div>
                        <div class="insight-item">
                            <strong>Recomendaciones estratégicas:</strong> ${this.generateStrategicRecommendations(historicalDataByCategory)}
                        </div>
                    </div>
                    
                    <div class="report-footer">
                        Reporte generado por SmartStock AI - ${new Date().toLocaleDateString()}
                    </div>
                `;
                
                // Generar gráficos después de que se renderice el HTML
                setTimeout(() => {
                    this.generateTrendsChart(months, values, productCounts);
                    this.generateCategoryTrendsCharts(historicalDataByCategory);
                    this.generatePerformanceComparisonChart(historicalDataByCategory);
                }, 100);
                
                return html;
            }
            
            generateComparisonReport(filters = {}) {
                const productsByCategory = productManager.getProductsByCategory();
                const categories = Object.keys(productsByCategory);
                
                if (categories.length === 0) {
                    return this.generateEmptyState('No hay categorías para comparar');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title">Reporte de Comparación por Categorías</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <h3>Resumen por Categoría</h3>
                    <div class="table-responsive">
                        <table class="comparison-table">
                            <thead>
                                <tr>
                                    <th>Categoría</th>
                                    <th>Número de Productos</th>
                                    <th>Valor Total</th>
                                    <th>Valor Promedio</th>
                                    <th>Stock Promedio</th>
                                    <th>Productos con Stock Bajo</th>
                                    <th>% del Inventario</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                const totalValue = productManager.getStockSummary().totalValue;
                
                categories.forEach(category => {
                    const products = productsByCategory[category];
                    const categoryValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0);
                    const avgValue = categoryValue / products.length;
                    const avgStock = products.reduce((sum, p) => sum + p.stock, 0) / products.length;
                    const lowStockCount = products.filter(p => p.stock <= 15).length;
                    const percentage = (categoryValue / totalValue) * 100;
                    
                    html += `
                        <tr>
                            <td>${category}</td>
                            <td>${products.length}</td>
                            <td>$${categoryValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>$${avgValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>${avgStock.toFixed(1)}</td>
                            <td>${lowStockCount}</td>
                            <td>${percentage.toFixed(2)}%</td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="chart-container">
                        <canvas id="comparisonChart"></canvas>
                    </div>
                    
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Análisis Comparativo</h5>
                        <div class="insight-item">
                            <strong>Categoría líder:</strong> ${this.identifyLeadingCategory(productsByCategory)}
                        </div>
                        <div class="insight-item">
                            <strong>Oportunidades:</strong> ${this.identifyOpportunities(productsByCategory)}
                        </div>
                    </div>
                    
                    <div class="report-footer">
                        Reporte generado por SmartStock AI - ${new Date().toLocaleDateString()}
                    </div>
                `;
                
                // Generar gráfico después de que se renderice el HTML
                setTimeout(() => {
                    this.generateComparisonChart(productsByCategory);
                }, 100);
                
                return html;
            }
            
            generateAIReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                
                if (products.length === 0) {
                    return this.generateEmptyState('No hay productos que coincidan con los filtros aplicados');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title">Análisis Predictivo con IA en Tiempo Real</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div class="tensorflow-section">
                        <h4><i class="fas fa-brain me-2"></i>Modelo de Predicción con Datos en Tiempo Real</h4>
                        <p>Este análisis utiliza TensorFlow.js y datos en tiempo real de fuentes externas para entrenar modelos de machine learning que predicen ventas y ofrecen recomendaciones inteligentes.</p>
                        
                        <div class="external-data-section">
                            <h5><i class="fas fa-satellite-dish me-2"></i>Datos en Tiempo Real</h5>
                            <div class="market-trends">
                                <div class="market-trend-card">
                                    <div class="stat-title">Estado APIs</div>
                                    <div class="market-trend-value">
                                        <span class="api-status ${tensorFlowAnalyzer.getAPIStatus().overall ? 'online' : 'offline'}">
                                            <i class="fas ${tensorFlowAnalyzer.getAPIStatus().overall ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
                                            ${tensorFlowAnalyzer.getAPIStatus().overall ? 'Conectado' : 'Sin conexión'}
                                        </span>
                                    </div>
                                    <div class="external-data-source">Actualizado segundo a segundo</div>
                                </div>
                                <div class="market-trend-card">
                                    <div class="stat-title">Última Actualización</div>
                                    <div class="market-trend-value" id="lastUpdateTime">Cargando...</div>
                                    <div class="external-data-source" id="dataSourceInfo">Conectando a fuentes...</div>
                                </div>
                            </div>
                            <div class="data-freshness" id="dataFreshness">
                                Los datos se actualizan automáticamente segundo a segundo
                            </div>
                        </div>
                        
                        <div class="model-controls">
                            <button class="btn btn-primary" id="trainModelBtn">
                                <i class="fas fa-robot me-2"></i>Entrenar Modelo con Datos en Tiempo Real
                            </button>
                            <button class="btn btn-outline-primary" id="predictSalesBtn" disabled>
                                <i class="fas fa-chart-line me-2"></i>Predecir Ventas con Análisis en Tiempo Real
                            </button>
                            <button class="btn btn-outline-info" id="refreshDataBtn">
                                <i class="fas fa-sync-alt me-2"></i>Actualizar Datos Ahora
                            </button>
                        </div>
                        
                        <div id="trainingStatus"></div>
                        <div id="trainingProgress" style="display: none;">
                            <div class="progress-bar">
                                <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                            </div>
                            <div id="progressText">Progreso: 0%</div>
                        </div>
                        <div id="trainingChartContainer" style="display: none;">
                            <h5>Progreso del Entrenamiento</h5>
                            <div class="chart-container">
                                <canvas id="trainingChart"></canvas>
                            </div>
                        </div>
                        
                        <div id="realTimeInsights" style="display: none;"></div>
                        <div id="predictionResults" class="prediction-results" style="display: none;"></div>
                    </div>
                    
                    <div class="tensorflow-insight">
                        <h5><i class="fas fa-lightbulb me-2"></i>¿Cómo funciona el análisis en tiempo real?</h5>
                        <p>El sistema se conecta automáticamente a múltiples fuentes de datos:</p>
                        <ul>
                            <li><strong>Alpha Vantage:</strong> Indicadores económicos y tendencias de mercado</li>
                            <li><strong>Google Trends:</strong> Popularidad de búsquedas por categoría</li>
                            <li><strong>Open Exchange Rates:</strong> Tasas de cambio para análisis internacional</li>
                            <li><strong>Investing.com:</strong> Datos de mercado en tiempo real</li>
                        </ul>
                        <p>Todos los datos se actualizan automáticamente segundo a segundo para garantizar la máxima precisión.</p>
                    </div>
                    
                    <div class="report-footer">
                        Reporte generado por SmartStock AI con TensorFlow.js y datos en tiempo real - ${new Date().toLocaleDateString()}
                    </div>
                `;
                
                // Agregar event listeners después de que se renderice el HTML
                setTimeout(() => {
                    document.getElementById('trainModelBtn').addEventListener('click', () => this.trainModelWithRealTimeData(products));
                    document.getElementById('predictSalesBtn').addEventListener('click', () => this.predictSalesWithRealTimeAnalysis(products));
                    document.getElementById('refreshDataBtn').addEventListener('click', () => this.refreshRealTimeData());
                    
                    // Actualizar información de datos en tiempo real
                    this.updateRealTimeInfo();
                }, 100);
                
                return html;
            }
            
            // Nuevos métodos para análisis de tendencias mejorado
            
            calculateVolatility(values) {
                if (values.length < 2) return 0;
                
                const mean = values.reduce((a, b) => a + b, 0) / values.length;
                const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length;
                return Math.sqrt(variance) / mean * 100;
            }
            
            calculateSeasonality(historicalData) {
                const values = Object.values(historicalData).map(d => d.totalValue);
                if (values.length < 6) return { level: 'Baja', score: 'B', class: 'seasonality-low' };
                
                // Calcular coeficiente de variación estacional
                const quarterlyGroups = [];
                for (let i = 0; i < values.length; i += 3) {
                    quarterlyGroups.push(values.slice(i, i + 3));
                }
                
                const quarterlyAverages = quarterlyGroups.map(group => 
                    group.reduce((a, b) => a + b, 0) / group.length
                );
                
                const overallAverage = quarterlyAverages.reduce((a, b) => a + b, 0) / quarterlyAverages.length;
                const seasonalVariance = quarterlyAverages.reduce((a, b) => a + Math.pow(b - overallAverage, 2), 0) / quarterlyAverages.length;
                const seasonalIndex = Math.sqrt(seasonalVariance) / overallAverage;
                
                if (seasonalIndex > 0.15) return { level: 'Alta', score: 'A', class: 'seasonality-high' };
                if (seasonalIndex > 0.08) return { level: 'Media', score: 'M', class: 'seasonality-medium' };
                return { level: 'Baja', score: 'B', class: 'seasonality-low' };
            }
            
            calculateAverageMonthlyGrowth(values) {
                if (values.length < 2) return 0;
                
                let totalGrowth = 0;
                for (let i = 1; i < values.length; i++) {
                    const growth = (values[i] - values[i-1]) / values[i-1] * 100;
                    totalGrowth += growth;
                }
                
                return totalGrowth / (values.length - 1);
            }
            
            calculateMarketShare(category, historicalDataByCategory) {
                const categories = Object.keys(historicalDataByCategory);
                const currentValues = categories.map(cat => {
                    const data = historicalDataByCategory[cat];
                    const values = Object.values(data).map(d => d.totalValue);
                    return values[values.length - 1];
                });
                
                const totalValue = currentValues.reduce((a, b) => a + b, 0);
                const categoryValue = currentValues[categories.indexOf(category)];
                
                return (categoryValue / totalValue) * 100;
            }
            
            calculateProjection(values) {
                if (values.length < 3) {
                    return {
                        growth: 0,
                        value: values[values.length - 1] || 0,
                        confidence: 'Baja confianza - datos insuficientes'
                    };
                }
                
                // Regresión lineal simple para proyección
                const n = values.length;
                let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
                
                for (let i = 0; i < n; i++) {
                    sumX += i;
                    sumY += values[i];
                    sumXY += i * values[i];
                    sumX2 += i * i;
                }
                
                const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
                const intercept = (sumY - slope * sumX) / n;
                
                const nextValue = slope * n + intercept;
                const lastValue = values[values.length - 1];
                const growth = ((nextValue - lastValue) / lastValue) * 100;
                
                // Calcular R² para confianza
                const yMean = sumY / n;
                let ssTot = 0, ssRes = 0;
                
                for (let i = 0; i < n; i++) {
                    ssTot += Math.pow(values[i] - yMean, 2);
                    const predicted = slope * i + intercept;
                    ssRes += Math.pow(values[i] - predicted, 2);
                }
                
                const rSquared = 1 - (ssRes / ssTot);
                
                let confidence;
                if (rSquared > 0.8) confidence = 'Alta confianza';
                else if (rSquared > 0.5) confidence = 'Media confianza';
                else confidence = 'Baja confianza';
                
                return {
                    growth: growth,
                    value: Math.max(0, nextValue),
                    confidence: confidence
                };
            }
            
            identifyBestPerformingCategory(historicalDataByCategory) {
                const categories = Object.keys(historicalDataByCategory);
                let bestCategory = '';
                let bestGrowth = -Infinity;
                
                categories.forEach(category => {
                    const data = historicalDataByCategory[category];
                    const values = Object.values(data).map(d => d.totalValue);
                    const growth = ((values[values.length - 1] - values[0]) / values[0]) * 100;
                    
                    if (growth > bestGrowth) {
                        bestGrowth = growth;
                        bestCategory = category;
                    }
                });
                
                return `${bestCategory} con un crecimiento del ${bestGrowth.toFixed(1)}% en los últimos 12 meses`;
            }
            
            generateStrategicRecommendations(historicalDataByCategory) {
                const categories = Object.keys(historicalDataByCategory);
                const recommendations = [];
                
                categories.forEach(category => {
                    const data = historicalDataByCategory[category];
                    const values = Object.values(data).map(d => d.totalValue);
                    const growth = ((values[values.length - 1] - values[0]) / values[0]) * 100;
                    const volatility = this.calculateVolatility(values);
                    const seasonality = this.calculateSeasonality(data);
                    
                    if (growth > 10 && volatility < 15) {
                        recommendations.push(`Incrementar inversión en ${category} (crecimiento alto y estable)`);
                    } else if (growth < 0 && volatility > 20) {
                        recommendations.push(`Reconsiderar estrategia para ${category} (decrecimiento y alta volatilidad)`);
                    } else if (seasonality.level === 'Alta') {
                        recommendations.push(`Planificar inventario estacional para ${category}`);
                    }
                });
                
                return recommendations.length > 0 ? recommendations.join('; ') : 'Todas las categorías muestran comportamiento estable';
            }
            
            generateCategoryTrendsCharts(historicalDataByCategory) {
                const categories = Object.keys(historicalDataByCategory);
                
                categories.forEach(category => {
                    const data = historicalDataByCategory[category];
                    const months = Object.keys(data);
                    const values = months.map(month => data[month].totalValue);
                    
                    const ctx = document.getElementById(`trendChart-${category.replace(/\s+/g, '')}`).getContext('2d');
                    
                    // Destruir gráfico anterior si existe
                    if (this.charts[`trendChart-${category}`]) {
                        this.charts[`trendChart-${category}`].destroy();
                    }
                    
                    this.charts[`trendChart-${category}`] = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: months,
                            datasets: [{
                                label: 'Valor ($)',
                                data: values,
                                borderColor: '#3a5ec7',
                                backgroundColor: 'rgba(58, 94, 199, 0.1)',
                                fill: true,
                                tension: 0.4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: false
                                }
                            },
                            plugins: {
                                legend: {
                                    display: false
                                }
                            }
                        }
                    });
                });
            }
            
            generatePerformanceComparisonChart(historicalDataByCategory) {
                const ctx = document.getElementById('performanceComparisonChart').getContext('2d');
                const categories = Object.keys(historicalDataByCategory);
                
                // Destruir gráfico anterior si existe
                if (this.charts.performanceComparisonChart) {
                    this.charts.performanceComparisonChart.destroy();
                }
                
                const datasets = categories.map((category, index) => {
                    const data = historicalDataByCategory[category];
                    const values = Object.values(data).map(d => d.totalValue);
                    const growthRates = [];
                    
                    for (let i = 1; i < values.length; i++) {
                        growthRates.push(((values[i] - values[i-1]) / values[i-1]) * 100);
                    }
                    
                    const colors = ['#3a5ec7', '#28a745', '#ffc107', '#dc3545'];
                    
                    return {
                        label: category,
                        data: growthRates,
                        borderColor: colors[index % colors.length],
                        backgroundColor: colors[index % colors.length] + '20',
                        fill: false,
                        tension: 0.4
                    };
                });
                
                const months = Object.keys(historicalDataByCategory[categories[0]]).slice(1);
                
                this.charts.performanceComparisonChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: months,
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                title: {
                                    display: true,
                                    text: 'Crecimiento Mensual (%)'
                                }
                            }
                        }
                    }
                });
            }
            
            // Métodos existentes continuan...
            
            async trainModelWithRealTimeData(products) {
                const trainBtn = document.getElementById('trainModelBtn');
                const predictBtn = document.getElementById('predictSalesBtn');
                const statusDiv = document.getElementById('trainingStatus');
                const progressDiv = document.getElementById('trainingProgress');
                const chartContainer = document.getElementById('trainingChartContainer');
                const insightsDiv = document.getElementById('realTimeInsights');
                
                trainBtn.disabled = true;
                trainBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Obteniendo datos en tiempo real...';
                statusDiv.innerHTML = '<div class="training-status training">Conectando con fuentes de datos en tiempo real...</div>';
                
                try {
                    // Obtener datos en tiempo real primero
                    await tensorFlowAnalyzer.fetchAllRealTimeData();
                    
                    trainBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Entrenando con datos en tiempo real...';
                    statusDiv.innerHTML = '<div class="training-status training">Datos en tiempo real cargados. Iniciando entrenamiento...</div>';
                    progressDiv.style.display = 'block';
                    
                    // Función global para actualizar progreso
                    window.updateTrainingProgress = (epoch, totalEpochs, loss) => {
                        const progress = (epoch / totalEpochs) * 100;
                        document.getElementById('progressFill').style.width = `${progress}%`;
                        document.getElementById('progressText').textContent = `Progreso: ${Math.round(progress)}% - Época ${epoch}/${totalEpochs} - Pérdida: ${loss.toFixed(4)}`;
                    };
                    
                    await tensorFlowAnalyzer.trainModelWithRealTimeData(products, 50);
                    
                    statusDiv.innerHTML = '<div class="training-status completed">Modelo entrenado exitosamente con datos en tiempo real</div>';
                    predictBtn.disabled = false;
                    trainBtn.disabled = false;
                    trainBtn.innerHTML = '<i class="fas fa-robot me-2"></i>Reentrenar Modelo';
                    progressDiv.style.display = 'none';
                    
                    // Mostrar gráfico de entrenamiento
                    chartContainer.style.display = 'block';
                    this.showTrainingChart();
                    
                    // Mostrar insights en tiempo real
                    this.showRealTimeInsights(insightsDiv);
                    
                    productManager.showNotification('Modelo entrenado exitosamente con datos en tiempo real', 'success');
                } catch (error) {
                    statusDiv.innerHTML = `<div class="training-status error">Error en el entrenamiento: ${error.message}</div>`;
                    trainBtn.disabled = false;
                    trainBtn.innerHTML = '<i class="fas fa-robot me-2"></i>Entrenar Modelo';
                    progressDiv.style.display = 'none';
                    productManager.showNotification('Error entrenando el modelo: ' + error.message, 'error');
                }
            }
            
            async predictSalesWithRealTimeAnalysis(products) {
                const predictBtn = document.getElementById('predictSalesBtn');
                const resultsDiv = document.getElementById('predictionResults');
                
                predictBtn.disabled = true;
                predictBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Analizando en tiempo real...';
                
                try {
                    const predictions = await tensorFlowAnalyzer.predictSalesWithRealTimeAnalysis(products);
                    
                    let html = `
                        <h5>Predicciones de Ventas con Análisis en Tiempo Real</h5>
                        <div class="table-responsive">
                            <table class="report-table">
                                <thead>
                                    <tr>
                                        <th>Producto</th>
                                        <th>Categoría</th>
                                        <th>Precio</th>
                                        <th>Stock</th>
                                        <th>Ventas Previstas</th>
                                        <th>Tendencia Mercado</th>
                                        <th>Sentimiento</th>
                                        <th>Perspectiva Econ.</th>
                                        <th>Oportunidad</th>
                                        <th>Recomendación</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;
                    
                    predictions.forEach(product => {
                        const recommendationClass = product.reorderRecommendation === 'Reordenar urgentemente' ? 'bg-danger' :
                                                  product.reorderRecommendation === 'Considerar reordenar pronto' ? 'bg-warning' :
                                                  product.reorderRecommendation === 'Exceso de inventario' ? 'bg-info' : 
                                                  product.reorderRecommendation === 'Reducir inventario' ? 'bg-secondary' : 'bg-success';
                        
                        const sentimentClass = product.marketSentiment > 0.6 ? 'sentiment-positive' : 
                                             product.marketSentiment < 0.4 ? 'sentiment-negative' : 'sentiment-neutral';
                        
                        const opportunityClass = product.opportunityScore > 70 ? 'sentiment-positive' :
                                               product.opportunityScore < 30 ? 'sentiment-negative' : 'sentiment-neutral';
                        
                        html += `
                            <tr>
                                <td>${product.name}</td>
                                <td>${product.category}</td>
                                <td>$${product.price.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                <td>${product.stock}</td>
                                <td>${product.predictedSales}</td>
                                <td><span class="sentiment-indicator ${sentimentClass}">${(product.marketTrend * 100 - 100).toFixed(1)}%</span></td>
                                <td>${(product.marketSentiment * 100).toFixed(0)}%</td>
                                <td>${product.economicOutlook}</td>
                                <td><span class="sentiment-indicator ${opportunityClass}">${product.opportunityScore}%</span></td>
                                <td><span class="badge ${recommendationClass}">${product.reorderRecommendation}</span></td>
                            </tr>
                        `;
                    });
                    
                    html += `
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="ai-recommendation mt-3">
                            <h5><i class="fas fa-robot me-2"></i>Recomendaciones de IA Basadas en Análisis en Tiempo Real</h5>
                            <ul class="recommendation-list">
                                <li><i class="fas fa-bullseye"></i> <strong>Enfóquese en oportunidades altas:</strong> Productos con puntuación de oportunidad >70% representan las mejores inversiones</li>
                                <li><i class="fas fa-chart-line"></i> <strong>Aproveche tendencias positivas:</strong> Categorías con crecimiento superior al 5% merecen atención prioritaria</li>
                                <li><i class="fas fa-exclamation-triangle"></i> <strong>Gestión de riesgo:</strong> Reduzca exposición en categorías con perspectiva económica negativa</li>
                                <li><i class="fas fa-sync-alt"></i> <strong>Actualización continua:</strong> Los datos se actualizan segundo a segundo para decisiones precisas</li>
                            </ul>
                        </div>
                        
                        <div class="data-freshness mt-3">
                            <i class="fas fa-clock me-2"></i>Última actualización de datos: ${predictions[0]?.lastUpdated ? new Date(predictions[0].lastUpdated).toLocaleString() : 'N/A'}
                        </div>
                    `;
                    
                    resultsDiv.innerHTML = html;
                    resultsDiv.style.display = 'block';
                    
                    predictBtn.disabled = false;
                    predictBtn.innerHTML = '<i class="fas fa-chart-line me-2"></i>Predecir Ventas con Análisis en Tiempo Real';
                    
                    productManager.showNotification('Análisis en tiempo real completado exitosamente', 'success');
                } catch (error) {
                    resultsDiv.innerHTML = `<div class="training-status error">Error generando predicciones: ${error.message}</div>`;
                    resultsDiv.style.display = 'block';
                    predictBtn.disabled = false;
                    predictBtn.innerHTML = '<i class="fas fa-chart-line me-2"></i>Predecir Ventas con Análisis en Tiempo Real';
                    productManager.showNotification('Error generando predicciones: ' + error.message, 'error');
                }
            }
            
            async refreshRealTimeData() {
                const refreshBtn = document.getElementById('refreshDataBtn');
                refreshBtn.disabled = true;
                refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Actualizando...';
                
                try {
                    await tensorFlowAnalyzer.fetchAllRealTimeData();
                    this.updateRealTimeInfo();
                    productManager.showNotification('Datos en tiempo real actualizados correctamente', 'success');
                } catch (error) {
                    productManager.showNotification('Error actualizando datos: ' + error.message, 'error');
                } finally {
                    refreshBtn.disabled = false;
                    refreshBtn.innerHTML = '<i class="fas fa-sync-alt me-2"></i>Actualizar Datos Ahora';
                }
            }
            
            updateRealTimeInfo() {
                const apiStatus = tensorFlowAnalyzer.getAPIStatus();
                const lastUpdateTime = document.getElementById('lastUpdateTime');
                const dataSourceInfo = document.getElementById('dataSourceInfo');
                const dataFreshness = document.getElementById('dataFreshness');
                
                if (lastUpdateTime) {
                    lastUpdateTime.textContent = apiStatus.lastUpdate ? 
                        new Date(apiStatus.lastUpdate).toLocaleTimeString() : 'No disponible';
                }
                
                if (dataSourceInfo) {
                    const connectedAPIs = [];
                    
                    if (apiStatus.alphaVantage) connectedAPIs.push('Alpha Vantage');
                    if (apiStatus.googleTrends) connectedAPIs.push('Google Trends');
                    if (apiStatus.openExchange) connectedAPIs.push('Open Exchange');
                    if (apiStatus.investing) connectedAPIs.push('Investing.com');
                    
                    dataSourceInfo.textContent = connectedAPIs.length > 0 ? 
                        `Fuentes conectadas: ${connectedAPIs.join(', ')}` : 'Sin conexión a fuentes externas';
                }
                
                if (dataFreshness) {
                    dataFreshness.innerHTML = apiStatus.lastUpdate ? 
                        `Última actualización: ${new Date(apiStatus.lastUpdate).toLocaleString()} | <i class="fas fa-sync-alt"></i> Actualizando segundo a segundo` :
                        'Los datos se actualizan automáticamente segundo a segundo';
                }
            }
            
            showRealTimeInsights(container) {
                const apiStatus = tensorFlowAnalyzer.getAPIStatus();
                const externalData = tensorFlowAnalyzer.externalData;
                
                if (!externalData) {
                    container.innerHTML = '<div class="training-status warning">No hay datos en tiempo real disponibles</div>';
                    return;
                }
                
                let html = `
                    <h5><i class="fas fa-chart-line me-2"></i>Insights en Tiempo Real</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="prediction-card">
                                <h6>Perspectiva Económica</h6>
                                <div class="stat-value ${externalData.economicIndicators.gdpGrowth > 2 ? 'trend-up' : 'trend-down'}">
                                    ${externalData.economicIndicators.gdpGrowth}%
                                </div>
                                <p>Crecimiento del PIB | Inflación: ${externalData.economicIndicators.inflation}%</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="prediction-card">
                                <h6>Confianza del Consumidor</h6>
                                <div class="stat-value ${externalData.economicIndicators.consumerConfidence > 70 ? 'trend-up' : externalData.economicIndicators.consumerConfidence < 60 ? 'trend-down' : ''}">
                                    ${externalData.economicIndicators.consumerConfidence}
                                </div>
                                <p>Índice de confianza (0-100)</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="prediction-card mt-3">
                        <h6>Tendencias por Categoría</h6>
                        <div class="row">
                `;
                
                Object.entries(externalData.marketTrends).forEach(([category, data]) => {
                    const trendClass = data.trend > 1.05 ? 'trend-up' : data.trend < 0.95 ? 'trend-down' : '';
                    const sentimentClass = data.sentiment > 0.6 ? 'sentiment-positive' : data.sentiment < 0.4 ? 'sentiment-negative' : 'sentiment-neutral';
                    
                    html += `
                        <div class="col-md-3">
                            <strong>${category}</strong>
                            <div class="${trendClass}">${(data.trend * 100 - 100).toFixed(1)}%</div>
                            <span class="sentiment-indicator ${sentimentClass}">${(data.sentiment * 100).toFixed(0)}%</span>
                        </div>
                    `;
                });
                
                html += `
                        </div>
                    </div>
                    
                    <div class="data-freshness mt-3">
                        <i class="fas fa-info-circle me-2"></i>Estado de APIs: 
                        ${apiStatus.alphaVantage ? '<span class="api-status online"><i class="fas fa-check-circle"></i>Alpha Vantage</span>' : '<span class="api-status offline"><i class="fas fa-exclamation-circle"></i>Alpha Vantage</span>'}
                        ${apiStatus.googleTrends ? '<span class="api-status online"><i class="fas fa-check-circle"></i>Google Trends</span>' : '<span class="api-status offline"><i class="fas fa-exclamation-circle"></i>Google Trends</span>'}
                        ${apiStatus.openExchange ? '<span class="api-status online"><i class="fas fa-check-circle"></i>Open Exchange</span>' : '<span class="api-status offline"><i class="fas fa-exclamation-circle"></i>Open Exchange</span>'}
                        ${apiStatus.investing ? '<span class="api-status online"><i class="fas fa-check-circle"></i>Investing.com</span>' : '<span class="api-status offline"><i class="fas fa-exclamation-circle"></i>Investing.com</span>'}
                    </div>
                `;
                
                container.innerHTML = html;
                container.style.display = 'block';
            }
            
            showTrainingChart() {
                const trainingData = tensorFlowAnalyzer.getTrainingChartData();
                if (!trainingData) return;
                
                const ctx = document.getElementById('trainingChart').getContext('2d');
                
                // Destruir gráfico anterior si existe
                if (this.charts.trainingChart) {
                    this.charts.trainingChart.destroy();
                }
                
                this.charts.trainingChart = new Chart(ctx, {
                    type: 'line',
                    data: trainingData,
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Pérdida'
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Época'
                                }
                            }
                        }
                    }
                });
            }
            
            generateValuationChart(products) {
                const ctx = document.getElementById('valuationChart').getContext('2d');
                
                // Destruir gráfico anterior si existe
                if (this.charts.valuationChart) {
                    this.charts.valuationChart.destroy();
                }
                
                // Tomar los 10 productos más valiosos para el gráfico
                const topProducts = products.slice(0, 10);
                const labels = topProducts.map(p => p.name);
                const data = topProducts.map(p => p.price * p.stock);
                
                this.charts.valuationChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Valor Total ($)',
                            data: data,
                            backgroundColor: '#3a5ec7',
                            borderColor: '#2a4bb0',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Valor ($)'
                                }
                            }
                        }
                    }
                });
            }
            
            generateTrendsChart(months, values, productCounts) {
                const ctx = document.getElementById('trendsChart').getContext('2d');
                
                // Destruir gráfico anterior si existe
                if (this.charts.trendsChart) {
                    this.charts.trendsChart.destroy();
                }
                
                this.charts.trendsChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: months,
                        datasets: [
                            {
                                label: 'Valor del Inventario ($)',
                                data: values,
                                borderColor: '#3a5ec7',
                                backgroundColor: 'rgba(58, 94, 199, 0.1)',
                                fill: true,
                                tension: 0.4
                            },
                            {
                                label: 'Número de Productos',
                                data: productCounts,
                                borderColor: '#28a745',
                                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                                fill: true,
                                tension: 0.4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: false
                            }
                        }
                    }
                });
            }
            
            generateComparisonChart(productsByCategory) {
                const ctx = document.getElementById('comparisonChart').getContext('2d');
                const categories = Object.keys(productsByCategory);
                
                // Destruir gráfico anterior si existe
                if (this.charts.comparisonChart) {
                    this.charts.comparisonChart.destroy();
                }
                
                const data = categories.map(category => {
                    const products = productsByCategory[category];
                    return products.reduce((sum, p) => sum + (p.price * p.stock), 0);
                });
                
                this.charts.comparisonChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: categories,
                        datasets: [{
                            data: data,
                            backgroundColor: [
                                '#3a5ec7',
                                '#28a745',
                                '#ffc107',
                                '#dc3545',
                                '#6f42c1',
                                '#e83e8c'
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            }
                        }
                    }
                });
            }
            
            calculateTopPercentage(products, count, totalValue) {
                const topValue = products.slice(0, count).reduce((sum, p) => sum + (p.price * p.stock), 0);
                return ((topValue / totalValue) * 100).toFixed(1);
            }
            
            identifySeasonalPattern(historicalData) {
                const values = Object.values(historicalData).map(d => d.totalValue);
                const avg = values.reduce((a, b) => a + b, 0) / values.length;
                const variance = values.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / values.length;
                
                if (variance / avg > 0.1) {
                    return 'Se observa variabilidad significativa que podría indicar patrones estacionales.';
                } else {
                    return 'La variabilidad es baja, no se detectan patrones estacionales marcados.';
                }
            }
            
            generateProjection(historicalData) {
                const values = Object.values(historicalData).map(d => d.totalValue);
                const lastValue = values[values.length - 1];
                const avgGrowth = (values[values.length - 1] - values[0]) / (values.length - 1);
                
                if (avgGrowth > 0) {
                    return `Tendencia alcista. Proyección para el próximo mes: $${(lastValue + avgGrowth).toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
                } else if (avgGrowth < 0) {
                    return `Tendencia bajista. Proyección para el próximo mes: $${(lastValue + avgGrowth).toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
                } else {
                    return `Tendencia estable. Se espera un valor similar al actual: $${lastValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
                }
            }
            
            identifyLeadingCategory(productsByCategory) {
                let leadingCategory = '';
                let maxValue = 0;
                
                Object.keys(productsByCategory).forEach(category => {
                    const value = productsByCategory[category].reduce((sum, p) => sum + (p.price * p.stock), 0);
                    if (value > maxValue) {
                        maxValue = value;
                        leadingCategory = category;
                    }
                });
                
                return `${leadingCategory} con un valor de $${maxValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
            }
            
            identifyOpportunities(productsByCategory) {
                const opportunities = [];
                
                Object.keys(productsByCategory).forEach(category => {
                    const products = productsByCategory[category];
                    const lowStockCount = products.filter(p => p.stock <= 5).length;
                    
                    if (lowStockCount > products.length * 0.3) {
                        opportunities.push(`${category} tiene un alto porcentaje de productos con stock bajo`);
                    }
                });
                
                return opportunities.length > 0 ? opportunities.join('; ') : 'Todas las categorías muestran niveles de stock adecuados';
            }
            
            printReport() {
                window.print();
            }
            
            exportToPDF() {
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();
                
                // Obtener el contenido del reporte
                const reportContent = document.getElementById('reportContent');
                
                // Usar html2canvas para capturar el contenido como imagen
                html2canvas(reportContent).then(canvas => {
                    const imgData = canvas.toDataURL('image/png');
                    const imgWidth = doc.internal.pageSize.getWidth();
                    const imgHeight = canvas.height * imgWidth / canvas.width;
                    
                    doc.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
                    doc.save('reporte_inventario.pdf');
                    productManager.showNotification('Reporte exportado a PDF', 'success');
                });
            }
            
            exportToExcel() {
                const products = productManager.getAllProducts();
                const worksheet = XLSX.utils.json_to_sheet(products.map(p => ({
                    ID: p.id,
                    Producto: p.name,
                    Categoría: p.category,
                    Precio: p.price,
                    Stock: p.stock,
                    'Valor Total': p.price * p.stock,
                    Estado: productManager.getProductStatus(p.stock)
                })));
                
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, 'Inventario');
                XLSX.writeFile(workbook, 'reporte_inventario.xlsx');
                productManager.showNotification('Reporte exportado a Excel', 'success');
            }
            
            exportToCSV() {
                const products = productManager.getAllProducts();
                const csvContent = [
                    ['ID', 'Producto', 'Categoría', 'Precio', 'Stock', 'Valor Total', 'Estado'],
                    ...products.map(p => [
                        p.id,
                        p.name,
                        p.category,
                        p.price,
                        p.stock,
                        p.price * p.stock,
                        productManager.getProductStatus(p.stock)
                    ])
                ].map(row => row.join(',')).join('\n');
                
                const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                const link = document.createElement('a');
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', 'reporte_inventario.csv');
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                productManager.showNotification('Reporte exportado a CSV', 'success');
            }
            
            exportToJSON() {
                const products = productManager.getAllProducts();
                const data = {
                    fecha: new Date().toISOString(),
                    totalProductos: products.length,
                    valorTotal: products.reduce((sum, p) => sum + (p.price * p.stock), 0),
                    productos: products
                };
                
                const jsonContent = JSON.stringify(data, null, 2);
                const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
                const link = document.createElement('a');
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', 'reporte_inventario.json');
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                productManager.showNotification('Reporte exportado a JSON', 'success');
            }
            
            generateEmptyState(message) {
                return `
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h4>No hay datos para mostrar</h4>
                        <p>${message}</p>
                        <button class="btn btn-primary mt-3" onclick="resetFilters()">
                            <i class="fas fa-redo me-2"></i>Restablecer Filtros
                        </button>
                    </div>
                `;
            }
        }

        // Instancia global del generador de reportes
        const reportGenerator = new ReportGenerator();

        // Función global para actualizar datos en tiempo real
        window.updateRealTimeData = function(externalData, lastUpdate) {
            // Actualizar información en la UI si está visible
            if (document.getElementById('realTimeInsights') && 
                document.getElementById('realTimeInsights').style.display !== 'none') {
                reportGenerator.updateRealTimeInfo();
            }
        };

        // Función para cargar reportes guardados
        function loadSavedReports() {
            const savedReports = savedReportsManager.getSavedReports();
            const savedReportsList = document.getElementById('savedReportsList');
            
            savedReportsList.innerHTML = '';
            
            if (savedReports.length === 0) {
                savedReportsList.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-bookmark"></i>
                        <h4>No hay reportes guardados</h4>
                        <p>Guarda un reporte para verlo aquí</p>
                    </div>
                `;
                return;
            }
            
            savedReports.forEach(report => {
                const reportCard = document.createElement('div');
                reportCard.className = 'saved-report-card';
                reportCard.innerHTML = `
                    <h6>${report.name}</h6>
                    <p><small>Tipo: ${report.reportType}</small></p>
                    <p><small>Creado: ${new Date(report.createdAt).toLocaleDateString()}</small></p>
                    <div class="saved-report-actions">
                        <button class="btn btn-sm btn-outline-primary load-report" data-id="${report.id}">
                            <i class="fas fa-eye me-1"></i>Cargar
                        </button>
                        <button class="btn btn-sm btn-outline-danger delete-report" data-id="${report.id}">
                            <i class="fas fa-trash me-1"></i>Eliminar
                        </button>
                    </div>
                `;
                
                savedReportsList.appendChild(reportCard);
            });
            
            // Agregar event listeners a los botones
            document.querySelectorAll('.load-report').forEach(btn => {
                btn.addEventListener('click', function() {
                    const reportId = this.getAttribute('data-id');
                    const report = savedReportsManager.getReportById(reportId);
                    
                    if (report) {
                        // Si el reporte tiene contenido guardado, cargarlo directamente
                        if (report.content) {
                            document.getElementById('reportContent').innerHTML = report.content;
                        } else {
                            // Si no, aplicar filtros y generar el reporte
                            applyFiltersFromSavedReport(report.filters);
                            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(report.reportType, report.filters);
                        }
                        
                        // Activar el botón del tipo de reporte correspondiente
                        document.querySelectorAll('.report-type-btn').forEach(b => b.classList.remove('active'));
                        document.querySelector(`.report-type-btn[data-type="${report.reportType}"]`).classList.add('active');
                        
                        productManager.showNotification(`Reporte "${report.name}" cargado`, 'success');
                    }
                });
            });
            
            document.querySelectorAll('.delete-report').forEach(btn => {
                btn.addEventListener('click', function() {
                    const reportId = this.getAttribute('data-id');
                    if (confirm('¿Estás seguro de que deseas eliminar este reporte guardado?')) {
                        savedReportsManager.deleteReport(parseInt(reportId));
                        loadSavedReports();
                        productManager.showNotification('Reporte eliminado', 'success');
                    }
                });
            });
        }
        
        // Función para aplicar filtros desde un reporte guardado
        function applyFiltersFromSavedReport(filters) {
            if (filters.category) {
                document.getElementById('categoryFilter').value = filters.category;
            }
            if (filters.stockStatus) {
                document.getElementById('stockStatusFilter').value = filters.stockStatus;
            }
            if (filters.minPrice) {
                document.getElementById('minPrice').value = filters.minPrice;
            }
            if (filters.maxPrice) {
                document.getElementById('maxPrice').value = filters.maxPrice;
            }
            if (filters.minStock) {
                document.getElementById('minStock').value = filters.minStock;
            }
            if (filters.maxStock) {
                document.getElementById('maxStock').value = filters.maxStock;
            }
            if (filters.sortBy) {
                document.getElementById('sortBy').value = filters.sortBy;
            }
        }
        
        // Función para obtener los filtros actuales
        function getCurrentFilters() {
            return {
                category: document.getElementById('categoryFilter').value,
                stockStatus: document.getElementById('stockStatusFilter').value,
                minPrice: document.getElementById('minPrice').value,
                maxPrice: document.getElementById('maxPrice').value,
                minStock: document.getElementById('minStock').value,
                maxStock: document.getElementById('maxStock').value,
                sortBy: document.getElementById('sortBy').value
            };
        }
        
        // Función para cambiar tema
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            const themeIcon = document.querySelector('#themeToggle i');
            themeIcon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
            
            // Guardar preferencia
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }
        
        // Función para toggle del menú en móviles
        function toggleMenu() {
            document.getElementById('sidebar').classList.toggle('open');
        }
        
        // Función para toggle de notificaciones
        function toggleNotifications() {
            document.getElementById('notificationDropdown').classList.toggle('show');
        }
        
        // Cerrar dropdown de notificaciones al hacer clic fuera
        document.addEventListener('click', function(event) {
            const notificationBtn = document.getElementById('notificationBtn');
            const notificationDropdown = document.getElementById('notificationDropdown');
            
            if (!notificationBtn.contains(event.target) && !notificationDropdown.contains(event.target)) {
                notificationDropdown.classList.remove('show');
            }
        });
        
        // Inicialización cuando el DOM está listo
        document.addEventListener('DOMContentLoaded', function() {
            // Cargar tema guardado
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            }
            
            // Generar reporte inicial
            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport('inventory');
            
            // Cargar reportes guardados
            loadSavedReports();
            
            // Iniciar actualizaciones en tiempo real
            tensorFlowAnalyzer.initializeRealTimeUpdates();
            
            // Event listeners
            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            document.getElementById('menuToggle').addEventListener('click', toggleMenu);
            document.getElementById('notificationBtn').addEventListener('click', toggleNotifications);
            document.getElementById('printReport').addEventListener('click', () => reportGenerator.printReport());
            document.getElementById('applyFilters').addEventListener('click', applyFilters);
            document.getElementById('resetFilters').addEventListener('click', resetFilters);
            document.getElementById('saveReport').addEventListener('click', saveReport);
            
            // Exportación por tipo de formato
            document.querySelectorAll('.dropdown-item[data-format]').forEach(item => {
                item.addEventListener('click', function(e) {
                    e.preventDefault();
                    const format = this.getAttribute('data-format');
                    
                    switch(format) {
                        case 'pdf':
                            reportGenerator.exportToPDF();
                            break;
                        case 'excel':
                            reportGenerator.exportToExcel();
                            break;
                        case 'csv':
                            reportGenerator.exportToCSV();
                            break;
                        case 'json':
                            reportGenerator.exportToJSON();
                            break;
                    }
                });
            });
            
            // Cambiar tipo de reporte
            document.querySelectorAll('.report-type-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    // Remover clase active de todos los botones
                    document.querySelectorAll('.report-type-btn').forEach(b => b.classList.remove('active'));
                    
                    // Agregar clase active al botón clickeado
                    this.classList.add('active');
                    
                    // Generar el reporte correspondiente
                    const reportType = this.getAttribute('data-type');
                    const filters = getCurrentFilters();
                    document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(reportType, filters);
                });
            });
            
            // Notificaciones de stock bajo
            updateStockNotifications();
        });
        
        // Función para aplicar filtros
        function applyFilters() {
            const filters = getCurrentFilters();
            const activeReportType = document.querySelector('.report-type-btn.active').getAttribute('data-type');
            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(activeReportType, filters);
            productManager.showNotification('Filtros aplicados correctamente', 'success');
        }
        
        // Función para restablecer filtros
        function resetFilters() {
            document.getElementById('categoryFilter').value = 'all';
            document.getElementById('stockStatusFilter').value = 'all';
            document.getElementById('minPrice').value = '';
            document.getElementById('maxPrice').value = '';
            document.getElementById('minStock').value = '';
            document.getElementById('maxStock').value = '';
            document.getElementById('sortBy').value = 'name';
            
            const activeReportType = document.querySelector('.report-type-btn.active').getAttribute('data-type');
            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(activeReportType);
            productManager.showNotification('Filtros restablecidos', 'info');
        }
        
        // Función para guardar reporte
        function saveReport() {
            const reportName = prompt('Ingresa un nombre para el reporte:');
            if (reportName) {
                const filters = getCurrentFilters();
                const reportType = document.querySelector('.report-type-btn.active').getAttribute('data-type');
                const content = document.getElementById('reportContent').innerHTML;
                
                savedReportsManager.saveReport(reportName, filters, reportType, content);
                loadSavedReports();
                productManager.showNotification('Reporte guardado correctamente', 'success');
            }
        }
        
        // Función para actualizar notificaciones de stock
        function updateStockNotifications() {
            const lowStockProducts = productManager.getAllProducts().filter(p => p.stock <= 5);
            const notificationBadge = document.getElementById('notificationBadge');
            
            if (lowStockProducts.length > 0) {
                notificationBadge.textContent = lowStockProducts.length;
                notificationBadge.classList.remove('hidden');
            } else {
                notificationBadge.classList.add('hidden');
            }
            
            const notificationList = document.getElementById('notificationList');
            notificationList.innerHTML = '';
            
            if (lowStockProducts.length > 0) {
                lowStockProducts.forEach(product => {
                    const notificationItem = document.createElement('div');
                    notificationItem.className = 'notification-item unread';
                    notificationItem.innerHTML = `
                        <strong>Stock bajo: ${product.name}</strong>
                        <p>Solo quedan ${product.stock} unidades</p>
                        <small>${new Date().toLocaleDateString()}</small>
                    `;
                    notificationList.appendChild(notificationItem);
                });
            } else {
                notificationList.innerHTML = `
                    <div class="notification-item">
                        <p>No hay notificaciones</p>
                    </div>
                `;
            }
        }
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>