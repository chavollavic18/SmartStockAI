<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Panel de Control Inteligente</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Variables Dinámicas Modificables */
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --primary-light: rgba(58, 94, 199, 0.12);
            --primary-glow: rgba(58, 94, 199, 0.35);

            --secondary: #10b981;
            --secondary-light: rgba(16, 185, 129, 0.12);
            --dark: #0f172a;
            --light: #f8fafc;
            --gray: #64748b;
            --gray-light: #f1f5f9;
            --danger: #ef4444;
            --danger-light: rgba(239, 68, 68, 0.12);
            --warning: #f59e0b;
            --warning-light: rgba(245, 158, 11, 0.12);
            --info: #06b6d4;
            --info-light: rgba(6, 182, 212, 0.12);
            
            --bg: #f3f4f6;
            --card-bg: #ffffff;
            --card-border: #e2e8f0;
            --text-main: #1e293b;
            --text-muted: #64748b;
            
            --border-radius-sm: 8px;
            --border-radius: 16px;
            --border-radius-lg: 24px;
            --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            --sidebar-width: 270px;
            --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.02);
            --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
            --shadow-lg: 0 20px 35px -10px rgba(0, 0, 0, 0.12);
            --font-main: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        .dark-mode {
            --bg: #0b0f19;
            --card-bg: #151c2c;
            --card-border: #232d42;
            --text-main: #f1f5f9;
            --text-muted: #94a3b8;
            --gray-light: #1e293b;
            --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-main);
        }

        body {
            background-color: var(--bg);
            color: var(--text-main);
            transition: var(--transition);
            min-height: 100vh;
            overflow-x: hidden;
        }

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: transparent;
        }
        ::-webkit-scrollbar-thumb {
            background: var(--gray);
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            color: #ffffff;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 24px 16px;
            transition: var(--transition);
            z-index: 1050;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 25px rgba(0,0,0,0.15);
        }

        .sidebar-header {
            padding: 0 12px 24px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -0.5px;
            color: #ffffff;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px var(--primary-glow);
            transition: var(--transition);
        }

        .sidebar-nav-container {
            flex: 1;
            overflow-y: auto;
            padding-right: 4px;
        }

        .menu-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #64748b;
            font-weight: 700;
            margin: 16px 12px 8px 12px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li {
            margin-bottom: 4px;
        }

        .sidebar-menu a {
            color: #94a3b8;
            text-decoration: none;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            font-weight: 500;
            font-size: 14px;
            cursor: pointer;
            gap: 12px;
        }

        .sidebar-menu a:hover {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.06);
            transform: translateX(3px);
        }

        .sidebar-menu a.active {
            color: #ffffff;
            background: var(--primary);
            font-weight: 600;
            box-shadow: 0 4px 15px var(--primary-glow);
        }

        .sidebar-menu i {
            font-size: 18px;
            width: 22px;
            text-align: center;
        }

        .sidebar-footer {
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .logout-btn {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
            width: 100%;
            padding: 12px 16px;
            border-radius: var(--border-radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: var(--transition);
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
        }

        .logout-btn:hover {
            background: var(--danger);
            color: white;
            border-color: var(--danger);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        /* --- MAIN CONTENT LAYOUT --- */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 30px;
            transition: var(--transition);
            min-width: 0;
        }

        /* --- TOP HEADER --- */
        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: var(--card-bg);
            padding: 16px 28px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            border: 1px solid var(--card-border);
        }

        .user-profile-summary {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .avatar-wrapper {
            position: relative;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            box-shadow: 0 4px 10px var(--primary-glow);
            transition: var(--transition);
        }

        .status-indicator {
            width: 14px;
            height: 14px;
            background-color: var(--secondary);
            border: 2.5px solid var(--card-bg);
            border-radius: 50%;
            position: absolute;
            bottom: 0;
            right: 0;
        }

        .user-details h5 {
            margin: 0;
            font-weight: 700;
            font-size: 16px;
            color: var(--text-main);
        }

        .user-details p {
            margin: 0;
            color: var(--text-muted);
            font-size: 13px;
        }

        .user-badge {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: 4px;
        }

        .badge-admin { background: var(--warning-light); color: #d97706; }
        .badge-employee { background: var(--secondary-light); color: var(--secondary); }

        .header-controls {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .global-search {
            position: relative;
            width: 280px;
        }

        .global-search input {
            width: 100%;
            padding: 10px 40px 10px 16px;
            border: 1px solid var(--card-border);
            border-radius: 30px;
            background: var(--bg);
            color: var(--text-main);
            font-size: 13px;
            transition: var(--transition);
        }

        .global-search input:focus {
            outline: none;
            border-color: var(--primary);
            background: var(--card-bg);
            box-shadow: 0 0 0 4px var(--primary-light);
        }

        .global-search i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 14px;
        }

        .control-btn {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: var(--bg);
            border: 1px solid var(--card-border);
            color: var(--text-main);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
        }

        .control-btn:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px var(--primary-glow);
        }

        .btn-badge {
            position: absolute;
            top: -2px;
            right: -2px;
            background: var(--danger);
            color: white;
            font-size: 10px;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--card-bg);
        }

        /* --- QUICK ACTIONS BAR --- */
        .section-title-sm {
            font-size: 14px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: var(--text-muted);
            margin-bottom: 14px;
        }

        .quick-actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }

        .action-card {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius);
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: var(--shadow-sm);
            text-align: center;
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow);
            border-color: var(--primary);
        }

        .action-icon-box {
            width: 52px;
            height: 52px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            transition: var(--transition);
        }

        .action-card:hover .action-icon-box {
            transform: scale(1.1) rotate(4deg);
        }

        .action-title {
            font-size: 14px;
            font-weight: 700;
            color: var(--text-main);
        }

        /* Dynamic primary style helpers */
        .bg-primary-light { background: var(--primary-light) !important; }
        .text-primary-dynamic { color: var(--primary) !important; }

        /* --- METRIC CARDS --- */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .metric-card {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius);
            padding: 24px;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .metric-card:hover {
            transform: translateY(-4px);
        }

        .metric-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }

        .metric-title {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .metric-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: var(--transition);
        }

        .metric-value {
            font-size: 32px;
            font-weight: 800;
            color: var(--text-main);
            line-height: 1.1;
            margin-bottom: 12px;
        }

        .metric-footer {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
        }

        .trend-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 700;
        }

        .trend-up { background: var(--secondary-light); color: var(--secondary); }
        .trend-down { background: var(--danger-light); color: var(--danger); }

        /* --- CHARTS & CONTENT GRID --- */
        .dashboard-content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            margin-bottom: 30px;
        }

        .panel-box {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius);
            padding: 24px;
            box-shadow: var(--shadow);
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--card-border);
        }

        .panel-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .chart-controls {
            display: flex;
            gap: 6px;
            background: var(--bg);
            padding: 4px;
            border-radius: 20px;
        }

        .chart-filter-btn {
            border: none;
            background: transparent;
            color: var(--text-muted);
            padding: 4px 14px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
        }

        .chart-filter-btn.active {
            background: var(--card-bg);
            color: var(--primary);
            box-shadow: var(--shadow-sm);
        }

        .canvas-container {
            position: relative;
            width: 100%;
            height: 300px;
        }

        /* Activities List */
        .activity-feed {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .activity-feed-item {
            display: flex;
            align-items: flex-start;
            gap: 14px;
            padding: 12px 0;
            border-bottom: 1px solid var(--card-border);
            transition: var(--transition);
            cursor: pointer;
        }

        .activity-feed-item:last-child {
            border-bottom: none;
        }

        .feed-icon {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            flex-shrink: 0;
            margin-top: 2px;
            transition: var(--transition);
        }

        .feed-info {
            flex: 1;
        }

        .feed-title {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-main);
            margin-bottom: 2px;
        }

        .feed-time {
            font-size: 11px;
            color: var(--text-muted);
        }

        /* --- MODULE SECTIONS --- */
        .modules-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .module-item-card {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            cursor: pointer;
            transition: var(--transition);
        }

        .module-item-card:hover {
            transform: translateX(6px);
            border-color: var(--primary);
            box-shadow: var(--shadow);
        }

        .module-icon-wrapper {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: var(--primary-light);
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
            transition: var(--transition);
        }

        .module-text h6 {
            margin: 0 0 4px 0;
            font-weight: 700;
            color: var(--text-main);
            font-size: 15px;
        }

        .module-text p {
            margin: 0;
            color: var(--text-muted);
            font-size: 12px;
            line-height: 1.4;
        }

        /* Restricted Notice */
        .restricted-banner {
            background: var(--danger-light);
            border: 1px dashed var(--danger);
            border-radius: var(--border-radius);
            padding: 24px;
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .restricted-banner i {
            font-size: 36px;
            color: var(--danger);
        }

        /* --- NOTIFICATION DROPDOWN PANEL --- */
        .notifications-flyout {
            position: absolute;
            top: 75px;
            right: 30px;
            width: 380px;
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            z-index: 1100;
            display: none;
            overflow: hidden;
            animation: fadeInDown 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .notifications-flyout.active {
            display: block;
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .flyout-header {
            padding: 16px 20px;
            background: var(--bg);
            border-bottom: 1px solid var(--card-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .flyout-header h6 {
            margin: 0;
            font-weight: 700;
        }

        .flyout-body {
            max-height: 350px;
            overflow-y: auto;
        }

        .flyout-item {
            padding: 14px 20px;
            border-bottom: 1px solid var(--card-border);
            cursor: pointer;
            transition: var(--transition);
        }

        .flyout-item:hover {
            background: var(--bg);
        }

        .flyout-item.unread {
            border-left: 4px solid var(--primary);
            background: var(--primary-light);
        }

        .flyout-item p {
            margin: 2px 0 0 0;
            font-size: 12px;
            color: var(--text-muted);
        }

        /* --- MODALS STYLING --- */
        .modal-custom-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            padding: 20px;
        }

        .modal-custom-overlay.active {
            display: flex;
        }

        .modal-custom-card {
            background: var(--card-bg);
            border-radius: var(--border-radius-lg);
            border: 1px solid var(--card-border);
            width: 100%;
            max-width: 650px;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            animation: modalPop 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        @keyframes modalPop {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }

        .modal-custom-header {
            padding: 20px 28px;
            border-bottom: 1px solid var(--card-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-custom-header h5 {
            margin: 0;
            font-weight: 800;
            color: var(--text-main);
        }

        .modal-custom-body {
            padding: 28px;
            max-height: 75vh;
            overflow-y: auto;
        }

        .modal-custom-footer {
            padding: 16px 28px;
            border-top: 1px solid var(--card-border);
            background: var(--bg);
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }

        /* Dynamic Bootstrap Buttons Override */
        .btn-primary {
            background-color: var(--primary) !important;
            border-color: var(--primary) !important;
        }
        .btn-primary:hover {
            background-color: var(--primary-dark) !important;
            border-color: var(--primary-dark) !important;
        }

        /* Mobile Nav Toggle */
        .mobile-nav-toggle {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            border: none;
            box-shadow: var(--shadow-lg);
            z-index: 1100;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            cursor: pointer;
        }

        /* --- RESPONSIVE MEDIA QUERIES --- */
        @media (max-width: 1100px) {
            .dashboard-content-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.mobile-open {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            .mobile-nav-toggle {
                display: flex;
            }
            .top-header {
                flex-direction: column;
                align-items: stretch;
                gap: 16px;
            }
            .header-controls {
                justify-content: space-between;
            }
            .global-search {
                width: 100%;
            }
        }
    </style>
</head>
<body>

    <div class="app-container">
        
        <!-- ================= SIDEBAR NAV ================= -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-brain"></i></div>
                    <span>SmartStock AI</span>
                </div>
            </div>

            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a data-page="admin" class="active"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                    <li><a data-page="inventario"><i class="fas fa-boxes-stacked"></i> Inventario</a></li>
                    <li><a data-page="Transacciones"><i class="fas fa-right-left"></i> Transacciones</a></li>
                    <li><a data-page="Reportes"><i class="fas fa-chart-column"></i> Reportes</a></li>
                </ul>

                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a data-page="clientes"><i class="fas fa-address-book"></i> Clientes</a></li>
                    <li><a data-page="proveedores"><i class="fas fa-truck-field"></i> Proveedores</a></li>
                </ul>

                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a data-page="usuarios"><i class="fas fa-users-gear"></i> Usuarios</a></li>
                    <li><a data-page="seguridad"><i class="fas fa-shield-halved"></i> Seguridad</a></li>
                    <li><a data-page="perfil"><i class="fas fa-circle-user"></i> Mi Perfil</a></li>
                    <li><a data-page="configuracion"><i class="fas fa-sliders"></i> Configuración</a></li>
                </ul>
            </div>

            <div class="sidebar-footer">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    <span>Cerrar Sesión</span>
                </button>
            </div>
        </aside>

        <!-- ================= MAIN CONTENT AREA ================= -->
        <main class="main-content">
            
            <!-- TOP BAR -->
            <header class="top-header">
                <div class="user-profile-summary">
                    <div class="avatar-wrapper">
                        <div class="user-avatar" id="userAvatar">--</div>
                        <div class="status-indicator"></div>
                    </div>
                    <div class="user-details">
                        <h5 id="userName">Cargando usuario...</h5>
                        <p id="userEmail">cargando@smartstock.ai</p>
                        <span class="user-badge" id="userRoleBadge">Rol</span>
                    </div>
                </div>

                <div class="header-controls">
                    <div class="global-search">
                        <input type="text" id="globalSearchInput" placeholder="Buscar en el sistema...">
                        <i class="fas fa-magnifying-glass"></i>
                    </div>

                    <button class="control-btn" id="themeToggleBtn" title="Cambiar Tema Visual">
                        <i class="fas fa-moon"></i>
                    </button>

                    <button class="control-btn" id="notificationsBtn" title="Notificaciones">
                        <i class="fas fa-bell"></i>
                        <span class="btn-badge" id="notifBadge">3</span>
                    </button>
                </div>
            </header>

            <!-- NOTIFICATIONS FLYOUT PANEL -->
            <div class="notifications-flyout" id="notificationsFlyout">
                <div class="flyout-header">
                    <h6>Centro de Notificaciones</h6>
                    <button class="btn btn-sm btn-link text-decoration-none p-0 text-primary-dynamic" id="markAllReadBtn">Marcar leídas</button>
                </div>
                <div class="flyout-body" id="notifListContainer">
                    <div class="flyout-item unread">
                        <strong>Alerta de Almacén: Stock Crítico</strong>
                        <p>5 productos han caído por debajo del margen de seguridad.</p>
                    </div>
                    <div class="flyout-item unread">
                        <strong>Venta Grande Detectada</strong>
                        <p>Se registró una venta por $1,250.00 USD por Cliente Corp.</p>
                    </div>
                    <div class="flyout-item">
                        <strong>Sincronización Completada</strong>
                        <p>La base de datos se actualizó correctamente con el servidor.</p>
                    </div>
                </div>
            </div>

            <!-- QUICK ACTIONS SECTION -->
            <div class="section-title-sm">Acciones Rápidas</div>
            <div class="quick-actions-grid">
                <div class="action-card" id="btnQuickSale">
                    <div class="action-icon-box bg-primary-light text-primary-dynamic">
                        <i class="fas fa-cash-register"></i>
                    </div>
                    <span class="action-title">Venta Rápida</span>
                </div>

                <div class="action-card" id="btnAddProduct">
                    <div class="action-icon-box" style="background: var(--secondary-light); color: var(--secondary);">
                        <i class="fas fa-folder-plus"></i>
                    </div>
                    <span class="action-title">Nuevo Producto</span>
                </div>

                <div class="action-card" id="btnGenerateReport">
                    <div class="action-icon-box" style="background: var(--warning-light); color: var(--warning);">
                        <i class="fas fa-file-invoice-dollar"></i>
                    </div>
                    <span class="action-title">Generar Reporte</span>
                </div>

                <div class="action-card" id="btnCheckInventory">
                    <div class="action-icon-box" style="background: var(--info-light); color: var(--info);">
                        <i class="fas fa-boxes-packing"></i>
                    </div>
                    <span class="action-title">Audit. Stock</span>
                </div>

                <div class="action-card" id="btnAIAdvisor">
                    <div class="action-icon-box" style="background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white;">
                        <i class="fas fa-wand-magic-sparkles"></i>
                    </div>
                    <span class="action-title">Asistente IA</span>
                </div>
            </div>

            <!-- METRIC CARDS -->
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-header">
                        <span class="metric-title">Ventas de Hoy</span>
                        <div class="metric-icon bg-primary-light text-primary-dynamic">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                    </div>
                    <div class="metric-value">$3,840.50</div>
                    <div class="metric-footer">
                        <span class="trend-badge trend-up"><i class="fas fa-arrow-up"></i> +14.2%</span>
                        <span class="text-muted">vs ayer</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-header">
                        <span class="metric-title">Stock Almacenado</span>
                        <div class="metric-icon" style="background: var(--secondary-light); color: var(--secondary);">
                            <i class="fas fa-cubes"></i>
                        </div>
                    </div>
                    <div class="metric-value">1,420</div>
                    <div class="metric-footer">
                        <span class="trend-badge trend-up"><i class="fas fa-check"></i> Óptimo</span>
                        <span class="text-muted">82% Capacidad</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-header">
                        <span class="metric-title">Alertas Bajo Stock</span>
                        <div class="metric-icon" style="background: var(--danger-light); color: var(--danger);">
                            <i class="fas fa-triangle-exclamation"></i>
                        </div>
                    </div>
                    <div class="metric-value">08</div>
                    <div class="metric-footer">
                        <span class="trend-badge trend-down"><i class="fas fa-arrow-down"></i> Crítico</span>
                        <span class="text-muted">Requiere Reorden</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-header">
                        <span class="metric-title">Clientes Activos</span>
                        <div class="metric-icon" style="background: var(--info-light); color: var(--info);">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    <div class="metric-value">342</div>
                    <div class="metric-footer">
                        <span class="trend-badge trend-up"><i class="fas fa-arrow-up"></i> +5</span>
                        <span class="text-muted">Esta semana</span>
                    </div>
                </div>
            </div>

            <!-- CHARTS & ACTIVITIES SECTION -->
            <div class="dashboard-content-grid">
                <!-- Interactive Chart Canvas Panel -->
                <div class="panel-box">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="fas fa-chart-line text-primary-dynamic"></i> Rendimiento de Ventas
                        </div>
                        <div class="chart-controls">
                            <button class="chart-filter-btn active" onclick="updateChartData('week')">Semana</button>
                            <button class="chart-filter-btn" onclick="updateChartData('month')">Mes</button>
                            <button class="chart-filter-btn" onclick="updateChartData('year')">Año</button>
                        </div>
                    </div>
                    <div class="canvas-container">
                        <canvas id="salesCanvas"></canvas>
                    </div>
                </div>

                <!-- Live Activity Feed Panel -->
                <div class="panel-box">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="fas fa-clock-rotate-left text-primary-dynamic"></i> Actividad Reciente
                        </div>
                    </div>
                    <ul class="activity-feed">
                        <li class="activity-feed-item" onclick="openActivityDetails('Venta Directa #4021', 'Cobro procesado por $340.00 en efectivo.')">
                            <div class="feed-icon" style="background: var(--secondary-light); color: var(--secondary);">
                                <i class="fas fa-cart-shopping"></i>
                            </div>
                            <div class="feed-info">
                                <div class="feed-title">Nueva Venta #4021</div>
                                <div class="feed-time">Hace 4 minutos</div>
                            </div>
                        </li>

                        <li class="activity-feed-item" onclick="openActivityDetails('Reabastecimiento', 'Ingresaron 50 unidades de Teclado Mecánico RGB.')">
                            <div class="feed-icon bg-primary-light text-primary-dynamic">
                                <i class="fas fa-truck-ramp-box"></i>
                            </div>
                            <div class="feed-info">
                                <div class="feed-title">Stock Actualizado</div>
                                <div class="feed-time">Hace 32 minutos</div>
                            </div>
                        </li>

                        <li class="activity-feed-item" onclick="openActivityDetails('Alerta de Sistema', 'El producto Mouse Inalámbrico cayó a 2 unidades.')">
                            <div class="feed-icon" style="background: var(--danger-light); color: var(--danger);">
                                <i class="fas fa-circle-exclamation"></i>
                            </div>
                            <div class="feed-info">
                                <div class="feed-title">Alerta: Stock Mínimo</div>
                                <div class="feed-time">Hace 2 horas</div>
                            </div>
                        </li>

                        <li class="activity-feed-item" onclick="openActivityDetails('Nuevo Registro', 'Se ha dado de alta al cliente Comercializadora del Norte.')">
                            <div class="feed-icon" style="background: var(--info-light); color: var(--info);">
                                <i class="fas fa-user-plus"></i>
                            </div>
                            <div class="feed-info">
                                <div class="feed-title">Cliente Registrado</div>
                                <div class="feed-time">Hace 4 horas</div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- ADMIN ONLY MODULES -->
            <div id="adminModulesSection">
                <div class="section-title-sm">Administración Avanzada del Sistema</div>
                <div class="modules-grid">
                    <div class="module-item-card" data-page="usuarios">
                        <div class="module-icon-wrapper">
                            <i class="fas fa-user-gear"></i>
                        </div>
                        <div class="module-text">
                            <h6>Gestión de Usuarios</h6>
                            <p>Administra permisos, roles y acceso del personal.</p>
                        </div>
                    </div>

                    <div class="module-item-card" data-page="seguridad">
                        <div class="module-icon-wrapper" style="background: var(--warning-light); color: var(--warning);">
                            <i class="fas fa-shield-cat"></i>
                        </div>
                        <div class="module-text">
                            <h6>Seguridad & Auditoría</h6>
                            <p>Revisa logs de acceso y políticas de contraseñas.</p>
                        </div>
                    </div>

                    <div class="module-item-card" data-page="configuracion">
                        <div class="module-icon-wrapper" style="background: var(--info-light); color: var(--info);">
                            <i class="fas fa-sliders"></i>
                        </div>
                        <div class="module-text">
                            <h6>Parámetros Globales</h6>
                            <p>Personaliza moneda, impuestos e integración IA.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RESTRICTED ACCESS WARNING (FOR NON-ADMINS) -->
            <div id="restrictedAccessBanner" class="restricted-banner" style="display: none;">
                <i class="fas fa-lock"></i>
                <div>
                    <h5 class="m-0 font-weight-bold">Modo Empleado Activado</h5>
                    <p class="m-0 text-muted fs-6">Las funciones avanzadas de administración están ocultas para tu rol actual.</p>
                </div>
            </div>

            <!-- COMMON SYSTEM MODULES -->
            <div class="section-title-sm">Módulos Operativos</div>
            <div class="modules-grid">
                <div class="module-item-card" data-page="inventario">
                    <div class="module-icon-wrapper" style="background: var(--secondary-light); color: var(--secondary);">
                        <i class="fas fa-warehouse"></i>
                    </div>
                    <div class="module-text">
                        <h6>Control de Inventarios</h6>
                        <p>Catálogo general de productos, precios y almacenes.</p>
                    </div>
                </div>

                <div class="module-item-card" data-page="Reportes">
                    <div class="module-icon-wrapper">
                        <i class="fas fa-file-chart-column"></i>
                    </div>
                    <div class="module-text">
                        <h6>Centro de Reportes</h6>
                        <p>Exportación de balances y métricas de rendimiento.</p>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <!-- MOBILE NAVIGATION TOGGLE -->
    <button class="mobile-nav-toggle" id="mobileNavToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- ================= MODALS ================= -->

    <!-- QUICK SALE MODAL -->
    <div class="modal-custom-overlay" id="quickSaleModal">
        <div class="modal-custom-card">
            <div class="modal-custom-header">
                <h5><i class="fas fa-cash-register text-primary-dynamic me-2"></i> Módulo de Venta Rápida</h5>
                <button class="btn-close" onclick="closeModal('quickSaleModal')"></button>
            </div>
            <div class="modal-custom-body">
                <div class="mb-3">
                    <label class="form-label fw-bold">Buscar Producto</label>
                    <select class="form-select" id="saleProductSelect" onchange="addSaleItem()">
                        <option value="">-- Seleccionar Producto --</option>
                        <option value="150|Laptop Gamer XT">Laptop Gamer XT - $150.00</option>
                        <option value="25|Mouse Inalámbrico Pro">Mouse Inalámbrico Pro - $25.00</option>
                        <option value="80|Teclado Mecánico RGB">Teclado Mecánico RGB - $80.00</option>
                        <option value="210|Monitor 27 Pulgadas 144Hz">Monitor 27" 144Hz - $210.00</option>
                    </select>
                </div>

                <table class="table align-middle mt-3">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th style="width: 80px;">Cant.</th>
                            <th>Precio</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody id="quickSaleTableBody">
                        <tr>
                            <td colspan="4" class="text-center text-muted py-3">No hay productos en el carrito</td>
                        </tr>
                    </tbody>
                </table>

                <div class="p-3 bg-light rounded-3 mt-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span>Subtotal:</span>
                        <span id="saleSubtotal">$0.00</span>
                    </div>
                    <div class="d-flex justify-content-between mb-1">
                        <span>IVA (16%):</span>
                        <span id="saleTax">$0.00</span>
                    </div>
                    <div class="d-flex justify-content-between fw-bold fs-5 text-primary-dynamic">
                        <span>Total a Pagar:</span>
                        <span id="saleTotal">$0.00</span>
                    </div>
                </div>

                <div class="mt-3">
                    <label class="form-label fw-bold">Paga con ($)</label>
                    <input type="number" class="form-input form-control" id="cashReceived" placeholder="0.00" oninput="calculateChange()">
                    <div class="mt-2 fw-bold text-success" id="changeAmountText">Cambio: $0.00</div>
                </div>
            </div>
            <div class="modal-custom-footer">
                <button class="btn btn-secondary" onclick="closeModal('quickSaleModal')">Cancelar</button>
                <button class="btn btn-primary" onclick="processQuickSale()"><i class="fas fa-check me-1"></i> Procesar Venta</button>
            </div>
        </div>
    </div>

    <!-- AI ADVISOR MODAL -->
    <div class="modal-custom-overlay" id="aiAdvisorModal">
        <div class="modal-custom-card">
            <div class="modal-custom-header" style="background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white;">
                <h5 class="text-white"><i class="fas fa-wand-magic-sparkles me-2"></i> SmartStock Brain - IA Predictiva</h5>
                <button class="btn-close btn-close-white" onclick="closeModal('aiAdvisorModal')"></button>
            </div>
            <div class="modal-custom-body">
                <div class="d-flex align-items-center gap-3 p-3 bg-light rounded-3 mb-3">
                    <i class="fas fa-brain fs-1" style="color: #a855f7;"></i>
                    <div>
                        <h6 class="m-0 fw-bold">Análisis del Algoritmo en Tiempo Real</h6>
                        <small class="text-muted">Basado en tendencias de ventas e inventario actual</small>
                    </div>
                </div>

                <div id="aiAnalysisOutput">
                    <div class="alert alert-info">
                        <h6><i class="fas fa-lightbulb me-2"></i> Sugerencia de Reabastecimiento</h6>
                        <p class="m-0 fs-6">Se pronostica un incremento del 35% en la demanda de <strong>Teclados Mecánicos RGB</strong> durante los próximos 15 días. Se recomienda generar una orden de compra hoy.</p>
                    </div>

                    <div class="alert alert-warning">
                        <h6><i class="fas fa-triangle-exclamation me-2"></i> Exceso de Stock Detectado</h6>
                        <p class="m-0 fs-6">El producto <strong>Cables HDMI 2m</strong> no ha registrado movimiento en los últimos 45 días. Se sugiere aplicar un descuento del 15% para liberar liquidez.</p>
                    </div>
                </div>
            </div>
            <div class="modal-custom-footer">
                <button class="btn btn-primary" onclick="closeModal('aiAdvisorModal')">Entendido</button>
            </div>
        </div>
    </div>

    <!-- GENERIC INFO MODAL -->
    <div class="modal-custom-overlay" id="genericInfoModal">
        <div class="modal-custom-card">
            <div class="modal-custom-header">
                <h5 id="genericModalTitle">Información</h5>
                <button class="btn-close" onclick="closeModal('genericInfoModal')"></button>
            </div>
            <div class="modal-custom-body" id="genericModalBody">
                ...
            </div>
            <div class="modal-custom-footer">
                <button class="btn btn-primary" onclick="closeModal('genericInfoModal')">Cerrar</button>
            </div>
        </div>
    </div>

    <!-- ================= JAVASCRIPT ENGINE ================= -->
    <script>
        const SYSTEM_ROUTES = {
            'admin': 'http://localhost/SmartStockAI/admin.php',
            'inventario': 'http://localhost/SmartStockAI/inventario1.php',
            'Reportes': 'http://localhost/SmartStockAI/Reportes.php',
            'Transacciones': 'http://localhost/SmartStockAI/Trassanciones.php',
            'clientes': 'http://localhost/SmartStockAI/clientes.php',
            'proveedores': 'http://localhost/SmartStockAI/proveedores.php',
            'usuarios': 'http://localhost/SmartStockAI/usuarios.php',
            'seguridad': 'http://localhost/SmartStockAI/seguridad.php',
            'perfil': 'http://localhost/SmartStockAI/perfil.php',
            'configuracion': 'http://localhost/SmartStockAI/configuracion.php'
        };

        const USER_DATABASE_SIMULATION = {
            "admin@smartstock.ai": { name: "Ana García", role: "admin", avatar: "AG" },
            "empleado@smartstock.ai": { name: "Carlos López", role: "empleado", avatar: "CL" }
        };

        // Convierte HEX a formato RGBA para opacidades y degradados
        function hexToRgba(hex, alpha) {
            let c;
            if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
                c = hex.substring(1).split('');
                if (c.length === 3) {
                    c = [c[0], c[0], c[1], c[1], c[2], c[2]];
                }
                c = '0x' + c.join('');
                return `rgba(${[(c >> 16) & 255, (c >> 8) & 255, c & 255].join(',')},${alpha})`;
            }
            return hex;
        }

        // Aplica el color guardado calculando opacidades
        function applyDynamicColors(primaryColor) {
            if (!primaryColor) return;
            const root = document.documentElement;
            root.style.setProperty('--primary', primaryColor);
            root.style.setProperty('--primary-dark', hexToRgba(primaryColor, 0.85));
            root.style.setProperty('--primary-light', hexToRgba(primaryColor, 0.12));
            root.style.setProperty('--primary-glow', hexToRgba(primaryColor, 0.35));
        }

        document.addEventListener('DOMContentLoaded', function() {
            applyGlobalConfig();
            setupUserSession();
            setupNavigationListeners();
            setupNotificationsEngine();
            initSalesChartCanvas();
            setupGlobalSearch();

            // Sincronización en tiempo real de cambios en localStorage
            window.addEventListener('storage', function(e) {
                if (e.key === 'appSettings' || e.key === 'theme') {
                    applyGlobalConfig();
                    initSalesChartCanvas();
                }
            });

            document.getElementById('mobileNavToggle').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('mobile-open');
            });

            document.getElementById('logoutBtn').addEventListener('click', function() {
                if (confirm('¿Desea cerrar la sesión actual?')) {
                    localStorage.removeItem('currentUser');
                    window.location.href = 'http://localhost/SmartStockAI/login.php';
                }
            });

            document.getElementById('themeToggleBtn').addEventListener('click', function() {
                const isDark = document.body.classList.toggle('dark-mode');
                const newTheme = isDark ? 'dark' : 'light';
                localStorage.setItem('theme', newTheme);
                
                const settings = JSON.parse(localStorage.getItem('appSettings')) || {};
                settings.theme = newTheme;
                localStorage.setItem('appSettings', JSON.stringify(settings));

                this.querySelector('i').className = isDark ? 'fas fa-sun' : 'fas fa-moon';
                initSalesChartCanvas();
            });

            document.getElementById('btnQuickSale').addEventListener('click', () => openModal('quickSaleModal'));
            document.getElementById('btnAddProduct').addEventListener('click', () => navigateTo('inventario'));
            document.getElementById('btnGenerateReport').addEventListener('click', () => navigateTo('Reportes'));
            document.getElementById('btnCheckInventory').addEventListener('click', () => navigateTo('inventario'));
            document.getElementById('btnAIAdvisor').addEventListener('click', () => openModal('aiAdvisorModal'));
        });

        function applyGlobalConfig() {
            const settings = JSON.parse(localStorage.getItem('appSettings')) || {};
            const savedTheme = localStorage.getItem('theme') || settings.theme || 'light';

            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggleBtn i').className = 'fas fa-sun';
            } else {
                document.body.classList.remove('dark-mode');
                document.querySelector('#themeToggleBtn i').className = 'fas fa-moon';
            }

            // Aplicación del color dinámico
            const primaryColor = settings.primaryColor || '#3a5ec7';
            applyDynamicColors(primaryColor);

            if (settings.fontSize) {
                document.body.style.fontSize = settings.fontSize === 'small' ? '13px' : (settings.fontSize === 'large' ? '16px' : '14px');
            }
        }

        function setupUserSession() {
            let user = JSON.parse(localStorage.getItem('currentUser'));

            if (!user) {
                const urlParams = new URLSearchParams(window.location.search);
                const emailParam = urlParams.get('email') || "admin@smartstock.ai";
                const foundUser = USER_DATABASE_SIMULATION[emailParam] || { name: "Usuario Demo", role: "admin", avatar: "UD" };

                user = {
                    email: emailParam,
                    name: foundUser.name,
                    role: foundUser.role,
                    avatar: foundUser.avatar
                };
                localStorage.setItem('currentUser', JSON.stringify(user));
            }

            document.getElementById('userName').textContent = user.name;
            document.getElementById('userEmail').textContent = user.email;
            document.getElementById('userAvatar').textContent = user.avatar;

            const roleBadge = document.getElementById('userRoleBadge');
            const adminSection = document.getElementById('adminModulesSection');
            const restrictedBanner = document.getElementById('restrictedAccessBanner');

            if (user.role === 'admin') {
                roleBadge.textContent = 'Administrador';
                roleBadge.className = 'user-badge badge-admin';
                adminSection.style.display = 'block';
                restrictedBanner.style.display = 'none';
            } else {
                roleBadge.textContent = 'Empleado';
                roleBadge.className = 'user-badge badge-employee';
                adminSection.style.display = 'none';
                restrictedBanner.style.display = 'flex';
            }
        }

        function navigateTo(pageKey) {
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            const restrictedAdminPages = ['usuarios', 'seguridad', 'configuracion'];

            if (restrictedAdminPages.includes(pageKey) && currentUser.role !== 'admin') {
                alert('Acceso Denegado: Esta sección requiere privilegios de Administrador.');
                return;
            }

            const targetUrl = SYSTEM_ROUTES[pageKey];
            if (targetUrl) {
                window.location.href = targetUrl;
            } else {
                console.warn('Ruta no encontrada:', pageKey);
            }
        }

        function setupNavigationListeners() {
            document.querySelectorAll('[data-page]').forEach(element => {
                element.addEventListener('click', function(e) {
                    e.preventDefault();
                    const page = this.getAttribute('data-page');
                    navigateTo(page);
                });
            });
        }

        function setupNotificationsEngine() {
            const btn = document.getElementById('notificationsBtn');
            const flyout = document.getElementById('notificationsFlyout');
            const markReadBtn = document.getElementById('markAllReadBtn');

            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                flyout.classList.toggle('active');
            });

            document.addEventListener('click', (e) => {
                if (!flyout.contains(e.target) && !btn.contains(e.target)) {
                    flyout.classList.remove('active');
                }
            });

            markReadBtn.addEventListener('click', () => {
                document.querySelectorAll('.flyout-item.unread').forEach(item => item.classList.remove('unread'));
                document.getElementById('notifBadge').textContent = '0';
            });
        }

        // DIBUJO DINÁMICO EN CANVAS LEYENDO EL COLOR COMPUTADO
        let chartDataset = [1200, 1900, 1500, 2200, 2800, 2400, 3840];
        let chartLabels = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

        function initSalesChartCanvas() {
            const canvas = document.getElementById('salesCanvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');

            canvas.width = canvas.parentElement.clientWidth;
            canvas.height = canvas.parentElement.clientHeight;

            const width = canvas.width;
            const height = canvas.height;
            const isDark = document.body.classList.contains('dark-mode');

            // Lee el color primario configurado en tiempo de ejecución
            const activePrimaryColor = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim() || '#3a5ec7';

            ctx.clearRect(0, 0, width, height);

            const padding = 40;
            const graphWidth = width - padding * 2;
            const graphHeight = height - padding * 2;
            const maxValue = Math.max(...chartDataset) * 1.2;

            ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)';
            ctx.lineWidth = 1;
            for (let i = 0; i <= 4; i++) {
                const y = padding + (graphHeight / 4) * i;
                ctx.beginPath();
                ctx.moveTo(padding, y);
                ctx.lineTo(width - padding, y);
                ctx.stroke();
            }

            const points = chartDataset.map((val, index) => {
                const x = padding + (graphWidth / (chartDataset.length - 1)) * index;
                const y = height - padding - (val / maxValue) * graphHeight;
                return { x, y };
            });

            const fillGradient = ctx.createLinearGradient(0, 0, 0, height);
            fillGradient.addColorStop(0, hexToRgba(activePrimaryColor, 0.35));
            fillGradient.addColorStop(1, hexToRgba(activePrimaryColor, 0.0));

            ctx.beginPath();
            ctx.moveTo(points[0].x, height - padding);
            points.forEach(pt => ctx.lineTo(pt.x, pt.y));
            ctx.lineTo(points[points.length - 1].x, height - padding);
            ctx.closePath();
            ctx.fillStyle = fillGradient;
            ctx.fill();

            ctx.beginPath();
            ctx.strokeStyle = activePrimaryColor;
            ctx.lineWidth = 3;
            points.forEach((pt, idx) => {
                if (idx === 0) ctx.moveTo(pt.x, pt.y);
                else ctx.lineTo(pt.x, pt.y);
            });
            ctx.stroke();

            points.forEach((pt, idx) => {
                ctx.beginPath();
                ctx.arc(pt.x, pt.y, 6, 0, Math.PI * 2);
                ctx.fillStyle = activePrimaryColor;
                ctx.fill();

                ctx.beginPath();
                ctx.arc(pt.x, pt.y, 3, 0, Math.PI * 2);
                ctx.fillStyle = '#ffffff';
                ctx.fill();

                ctx.fillStyle = isDark ? '#94a3b8' : '#64748b';
                ctx.font = '12px Plus Jakarta Sans';
                ctx.textAlign = 'center';
                ctx.fillText(chartLabels[idx], pt.x, height - 10);
            });
        }

        function updateChartData(filter) {
            document.querySelectorAll('.chart-filter-btn').forEach(b => b.classList.remove('active'));
            event.target.classList.add('active');

            if (filter === 'week') {
                chartDataset = [1200, 1900, 1500, 2200, 2800, 2400, 3840];
                chartLabels = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
            } else if (filter === 'month') {
                chartDataset = [8000, 12000, 15000, 24000];
                chartLabels = ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4'];
            } else {
                chartDataset = [45000, 52000, 61000, 80000];
                chartLabels = ['Q1', 'Q2', 'Q3', 'Q4'];
            }
            initSalesChartCanvas();
        }

        let cartItems = [];

        function addSaleItem() {
            const select = document.getElementById('saleProductSelect');
            if (!select.value) return;

            const [price, name] = select.value.split('|');
            const numericPrice = parseFloat(price);

            const existing = cartItems.find(i => i.name === name);
            if (existing) {
                existing.qty++;
            } else {
                cartItems.push({ name, price: numericPrice, qty: 1 });
            }

            select.value = '';
            renderSaleCart();
        }

        function renderSaleCart() {
            const tbody = document.getElementById('quickSaleTableBody');
            if (cartItems.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-3">No hay productos en el carrito</td></tr>';
                updateSaleTotals(0);
                return;
            }

            let html = '';
            let subtotal = 0;

            cartItems.forEach((item, index) => {
                const itemTotal = item.price * item.qty;
                subtotal += itemTotal;
                html += `
                    <tr>
                        <td>${item.name}</td>
                        <td>
                            <input type="number" min="1" class="form-control form-control-sm" value="${item.qty}" onchange="updateQty(${index}, this.value)">
                        </td>
                        <td>$${item.price.toFixed(2)}</td>
                        <td class="fw-bold">$${itemTotal.toFixed(2)}</td>
                    </tr>
                `;
            });

            tbody.innerHTML = html;
            updateSaleTotals(subtotal);
        }

        function updateQty(index, newQty) {
            cartItems[index].qty = parseInt(newQty) || 1;
            renderSaleCart();
        }

        function updateSaleTotals(subtotal) {
            const tax = subtotal * 0.16;
            const total = subtotal + tax;

            document.getElementById('saleSubtotal').textContent = `$${subtotal.toFixed(2)}`;
            document.getElementById('saleTax').textContent = `$${tax.toFixed(2)}`;
            document.getElementById('saleTotal').textContent = `$${total.toFixed(2)}`;
            calculateChange();
        }

        function calculateChange() {
            const totalText = document.getElementById('saleTotal').textContent.replace('$', '');
            const total = parseFloat(totalText) || 0;
            const cash = parseFloat(document.getElementById('cashReceived').value) || 0;
            const change = cash - total;

            const changeEl = document.getElementById('changeAmountText');
            if (change >= 0) {
                changeEl.textContent = `Cambio: $${change.toFixed(2)}`;
                changeEl.className = 'mt-2 fw-bold text-success';
            } else {
                changeEl.textContent = `Faltante: $${Math.abs(change).toFixed(2)}`;
                changeEl.className = 'mt-2 fw-bold text-danger';
            }
        }

        function processQuickSale() {
            if (cartItems.length === 0) {
                alert('El carrito se encuentra vacío.');
                return;
            }
            alert('Venta procesada exitosamente.');
            cartItems = [];
            renderSaleCart();
            closeModal('quickSaleModal');
        }

        function setupGlobalSearch() {
            const input = document.getElementById('globalSearchInput');
            input.addEventListener('keyup', function() {
                const query = this.value.toLowerCase();
                const cards = document.querySelectorAll('.module-item-card, .action-card');

                cards.forEach(card => {
                    const text = card.textContent.toLowerCase();
                    if (text.includes(query)) {
                        card.style.display = '';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        }

        function openModal(id) {
            document.getElementById(id).classList.add('active');
        }

        function closeModal(id) {
            document.getElementById(id).classList.remove('active');
        }

        function openActivityDetails(title, description) {
            document.getElementById('genericModalTitle').textContent = title;
            document.getElementById('genericModalBody').innerHTML = `<p class="fs-6 m-0">${description}</p>`;
            openModal('genericInfoModal');
        }
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>