<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Configuraciones Globales</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 250px;
            --font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            --font-size: 14px;
            --header-height: 60px;
            --footer-height: 50px;
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #000000;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            font-family: var(--font-family);
            font-size: var(--font-size);
            color: #000000;
            transition: var(--transition);
            min-height: 100vh;
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--primary);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: var(--transition);
            border-left: 4px solid transparent;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .sidebar-menu i {
            width: 25px;
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: var(--transition);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: #000000;
        }

        .controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: #000000;
            position: relative;
        }

        .theme-switcher:hover, .notifications:hover {
            transform: translateY(-3px);
        }

        /* Sección de Configuraciones */
        .settings-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .settings-tabs {
            display: flex;
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .settings-tab {
            padding: 12px 20px;
            background: none;
            border: none;
            border-bottom: 3px solid transparent;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            color: var(--gray);
        }

        .settings-tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .settings-tab:hover {
            color: var(--primary);
        }

        .settings-content {
            display: none;
        }

        .settings-content.active {
            display: block;
        }

        .settings-group {
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e9ecef;
        }

        .settings-group:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }

        .settings-group-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary);
            display: flex;
            align-items: center;
        }

        .settings-group-title i {
            margin-right: 10px;
            font-size: 20px;
        }

        .settings-row {
            display: flex;
            gap: 20px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        .settings-item {
            flex: 1;
            min-width: 250px;
        }

        .settings-label {
            font-weight: 500;
            margin-bottom: 8px;
            display: block;
        }

        .settings-description {
            font-size: 0.85rem;
            color: var(--gray);
            margin-top: 5px;
        }

        .settings-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }

        /* Toggle Switch */
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }

        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .toggle-slider {
            background-color: var(--primary);
        }

        input:checked + .toggle-slider:before {
            transform: translateX(30px);
        }

        /* Color Picker */
        .color-picker {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .color-option {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            cursor: pointer;
            border: 2px solid transparent;
            transition: var(--transition);
        }

        .color-option.active {
            border-color: #000;
            transform: scale(1.1);
        }

        /* Toast de notificaciones */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
        }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s forwards;
            color: #000000;
        }

        .toast.success {
            border-left: 4px solid var(--secondary);
        }

        .toast.error {
            border-left: 4px solid var(--danger);
        }

        .toast.warning {
            border-left: 4px solid var(--warning);
        }

        .toast i {
            margin-right: 10px;
            font-size: 20px;
        }

        .toast.success i {
            color: var(--secondary);
        }

        .toast.error i {
            color: var(--danger);
        }

        .toast.warning i {
            color: var(--warning);
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* Modal de Instrucciones */
        .instructions-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        }

        .instructions-modal.active {
            display: flex;
        }

        .instructions-content {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            width: 90%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .instructions-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #dee2e6;
        }

        .instructions-title {
            font-size: 24px;
            font-weight: 600;
            color: var(--primary);
        }

        .instructions-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--gray);
        }

        .instructions-section {
            margin-bottom: 25px;
        }

        .instructions-section-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary);
            display: flex;
            align-items: center;
        }

        .instructions-section-title i {
            margin-right: 10px;
        }

        .instructions-item {
            margin-bottom: 15px;
            padding: 15px;
            background: rgba(0,0,0,0.03);
            border-radius: 8px;
        }

        .instructions-item-title {
            font-weight: 600;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
        }

        .instructions-item-title i {
            margin-right: 8px;
            color: var(--primary);
        }

        .instructions-item-description {
            color: var(--gray);
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 0;
            }
            
            .sidebar.open {
                transform: translateX(0);
                width: var(--sidebar-width);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
            }

            .settings-row {
                flex-direction: column;
            }

            .settings-item {
                min-width: 100%;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .controls {
                margin-top: 15px;
            }
            
            .menu-toggle {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .settings-tabs {
                flex-direction: column;
            }

            .settings-tab {
                border-bottom: 1px solid #dee2e6;
                border-left: 3px solid transparent;
            }

            .settings-tab.active {
                border-left-color: var(--primary);
                border-bottom-color: #dee2e6;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px;
            }
            
            .settings-section {
                padding: 15px;
            }
            
            .settings-actions {
                flex-direction: column;
            }
            
            .settings-actions .btn {
                width: 100%;
                margin-bottom: 10px;
            }
        }

        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 1001;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        /* Asegurar que todos los textos sean negros */
        body, body *:not(.sidebar *):not(.action-btn) {
            color: #000000 !important;
        }

        /* Ajustes para mantener contraste en elementos especiales */
        .sidebar, .action-btn {
            color: white !important;
        }

        /* Inputs y selects */
        .form-control, .form-select {
            color: #000000 !important;
            background-color: #ffffff !important;
        }

        .form-control::placeholder {
            color: #666 !important;
        }

        /* Badges para estados */
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }

        .badge.bg-success {
            background-color: var(--secondary);
        }

        .badge.bg-warning {
            background-color: var(--warning);
        }

        .badge.bg-danger {
            background-color: var(--danger);
        }

        .badge.bg-info {
            background-color: #17a2b8;
        }

        /* Botón de instrucciones */
        .instructions-btn {
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            cursor: pointer;
            transition: var(--transition);
        }

        .instructions-btn:hover {
            transform: scale(1.1);
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot me-2"></i>SmartStock AI
                </div>
            </div>
            
            <ul class="sidebar-menu">
               <li><a href="http://localhost/SmartStockAI/principal.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes"></i> Inventario</a></li>
                <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck"></i> Proveedores</a></li>
                <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users"></i> Usuarios</a></li>
                <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-exchange-alt"></i> Transacciones</a></li>
                <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-line"></i> Reportes</a></li>
                <li><a href="#" class="active"><i class="fas fa-user-friends"></i> Clientes</a></li>
                <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-user"></i> Mi Perfil</a></li>
                <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-alt"></i> Seguridad</a></li>
                <li><a href="http://localhost/SmartStockAI/login.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a></li>
                <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-cog"></i> Configuración</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1 class="page-title">Configuraciones Globales</h1>
                
                <div class="controls">
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notifications" id="notificationBtn">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge hidden" id="notificationBadge">0</span>
                    </div>
                </div>
            </div>
            
            <!-- Sección de Configuraciones -->
            <div class="settings-section">
                <div class="settings-tabs">
                    <button class="settings-tab active" data-tab="general">
                        <i class="fas fa-cog me-2"></i>General
                    </button>
                    <button class="settings-tab" data-tab="empresa">
                        <i class="fas fa-building me-2"></i>Empresa
                    </button>
                    <button class="settings-tab" data-tab="sistema">
                        <i class="fas fa-desktop me-2"></i>Sistema
                    </button>
                    <button class="settings-tab" data-tab="seguridad">
                        <i class="fas fa-shield-alt me-2"></i>Seguridad
                    </button>
                    <button class="settings-tab" data-tab="notificaciones">
                        <i class="fas fa-bell me-2"></i>Notificaciones
                    </button>
                    <button class="settings-tab" data-tab="apariencia">
                        <i class="fas fa-palette me-2"></i>Apariencia
                    </button>
                    <button class="settings-tab" data-tab="avanzado">
                        <i class="fas fa-sliders-h me-2"></i>Avanzado
                    </button>
                </div>
                
                <!-- Pestaña General -->
                <div class="settings-content active" id="general-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-info-circle"></i>Información Básica
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Nombre del Sistema</label>
                                <input type="text" class="form-control" id="systemName" placeholder="SmartStock AI">
                                <div class="settings-description">
                                    Nombre que se mostrará en todas las páginas del sistema
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Idioma del Sistema</label>
                                <select class="form-select" id="systemLanguage">
                                    <option value="es">Español</option>
                                    <option value="en">English</option>
                                    <option value="pt">Português</option>
                                    <option value="fr">Français</option>
                                </select>
                                <div class="settings-description">
                                    Idioma principal de la interfaz
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Zona Horaria</label>
                                <select class="form-select" id="systemTimezone">
                                    <option value="America/Mexico_City">Ciudad de México (UTC-6)</option>
                                    <option value="America/New_York">New York (UTC-5)</option>
                                    <option value="America/Los_Angeles">Los Angeles (UTC-8)</option>
                                    <option value="Europe/Madrid">Madrid (UTC+1)</option>
                                    <option value="UTC">UTC</option>
                                </select>
                                <div class="settings-description">
                                    Zona horaria para fechas y horas del sistema
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Formato de Fecha</label>
                                <select class="form-select" id="dateFormat">
                                    <option value="dd/mm/yyyy">DD/MM/YYYY</option>
                                    <option value="mm/dd/yyyy">MM/DD/YYYY</option>
                                    <option value="yyyy-mm-dd">YYYY-MM-DD</option>
                                </select>
                                <div class="settings-description">
                                    Formato para mostrar fechas en todo el sistema
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-database"></i>Configuración de Datos
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Límite de Registros por Página</label>
                                <input type="number" class="form-control" id="recordsPerPage" min="5" max="100" value="10">
                                <div class="settings-description">
                                    Número máximo de registros a mostrar en tablas
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Auto-guardado</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="autoSave" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoSaveStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Guardar automáticamente los cambios en formularios
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Empresa -->
                <div class="settings-content" id="empresa-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-building"></i>Información de la Empresa
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Nombre de la Empresa</label>
                                <input type="text" class="form-control" id="companyName" placeholder="Mi Empresa S.A. de C.V.">
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">RFC / Identificación Fiscal</label>
                                <input type="text" class="form-control" id="companyTaxId" placeholder="ABC123456789">
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Dirección</label>
                                <textarea class="form-control" id="companyAddress" rows="3" placeholder="Dirección completa de la empresa"></textarea>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Teléfono</label>
                                <input type="text" class="form-control" id="companyPhone" placeholder="+52 55 1234 5678">
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Email</label>
                                <input type="email" class="form-control" id="companyEmail" placeholder="info@miempresa.com">
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Sitio Web</label>
                                <input type="url" class="form-control" id="companyWebsite" placeholder="https://miempresa.com">
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Industria</label>
                                <select class="form-select" id="companyIndustry">
                                    <option value="">Seleccionar industria</option>
                                    <option value="retail">Retail</option>
                                    <option value="manufactura">Manufactura</option>
                                    <option value="tecnologia">Tecnología</option>
                                    <option value="servicios">Servicios</option>
                                    <option value="distribucion">Distribución</option>
                                    <option value="otro">Otro</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-file-invoice"></i>Configuración Fiscal
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Moneda Principal</label>
                                <select class="form-select" id="companyCurrency">
                                    <option value="MXN">Peso Mexicano (MXN)</option>
                                    <option value="USD">Dólar Americano (USD)</option>
                                    <option value="EUR">Euro (EUR)</option>
                                    <option value="CAD">Dólar Canadiense (CAD)</option>
                                </select>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Símbolo de Moneda</label>
                                <input type="text" class="form-control" id="currencySymbol" placeholder="$" maxlength="3">
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">IVA / Impuesto</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="taxRate" min="0" max="100" step="0.1" value="16">
                                    <span class="input-group-text">%</span>
                                </div>
                                <div class="settings-description">
                                    Tasa de impuesto aplicable por defecto
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Formato de Precios</label>
                                <select class="form-select" id="priceFormat">
                                    <option value="1,234.56">1,234.56</option>
                                    <option value="1.234,56">1.234,56</option>
                                    <option value="1234.56">1234.56</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Sistema -->
                <div class="settings-content" id="sistema-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-server"></i>Configuración del Sistema
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Mantenimiento del Sistema</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="maintenanceMode">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="maintenanceStatus">Desactivado</span>
                                </div>
                                <div class="settings-description">
                                    Activar modo mantenimiento (solo administradores podrán acceder)
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Límite de Backup Automático</label>
                                <input type="number" class="form-control" id="backupLimit" min="1" max="30" value="7">
                                <div class="settings-description">
                                    Número de días para mantener backups automáticos
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Tiempo de Espera de Sesión</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="sessionTimeout" min="5" max="480" value="30">
                                    <span class="input-group-text">minutos</span>
                                </div>
                                <div class="settings-description">
                                    Tiempo de inactividad antes de cerrar sesión automáticamente
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Límite de Intentos de Login</label>
                                <input type="number" class="form-control" id="loginAttempts" min="1" max="10" value="5">
                                <div class="settings-description">
                                    Número máximo de intentos fallidos antes de bloquear cuenta
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-sync-alt"></i>Automatización
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Backup Automático</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="autoBackup" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoBackupStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Crear backups automáticos de la base de datos
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Frecuencia de Backup</label>
                                <select class="form-select" id="backupFrequency">
                                    <option value="daily">Diario</option>
                                    <option value="weekly">Semanal</option>
                                    <option value="monthly">Mensual</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Notificaciones de Stock Bajo</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="lowStockAlerts" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="lowStockStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Enviar alertas cuando el stock esté por debajo del mínimo
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Umbral de Stock Bajo</label>
                                <input type="number" class="form-control" id="lowStockThreshold" min="1" max="100" value="10">
                                <div class="settings-description">
                                    Cantidad mínima para considerar stock bajo
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Seguridad -->
                <div class="settings-content" id="seguridad-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-lock"></i>Configuración de Seguridad
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Autenticación de Dos Factores</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="twoFactorAuth">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="twoFactorStatus">Desactivado</span>
                                </div>
                                <div class="settings-description">
                                    Requerir verificación en dos pasos para acceder al sistema
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Política de Contraseñas</label>
                                <select class="form-select" id="passwordPolicy">
                                    <option value="low">Baja (mínimo 6 caracteres)</option>
                                    <option value="medium" selected>Media (mínimo 8 caracteres, letras y números)</option>
                                    <option value="high">Alta (mínimo 10 caracteres, mayúsculas, minúsculas, números y símbolos)</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Caducidad de Contraseñas</label>
                                <select class="form-select" id="passwordExpiration">
                                    <option value="0">Nunca</option>
                                    <option value="30">30 días</option>
                                    <option value="60">60 días</option>
                                    <option value="90" selected>90 días</option>
                                    <option value="180">180 días</option>
                                </select>
                                <div class="settings-description">
                                    Tiempo después del cual las contraseñas deben cambiarse
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Registro de Actividad</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="activityLogging" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="activityLogStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Registrar todas las actividades importantes del sistema
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-user-shield"></i>Control de Accesos
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">IPs Permitidas</label>
                                <textarea class="form-control" id="allowedIPs" rows="3" placeholder="Ej: 192.168.1.1, 10.0.0.0/24"></textarea>
                                <div class="settings-description">
                                    Lista de IPs o rangos permitidos (separados por coma). Dejar vacío para permitir todas.
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Horario de Acceso</label>
                                <div class="row">
                                    <div class="col">
                                        <label class="form-label">Desde</label>
                                        <input type="time" class="form-control" id="accessTimeStart" value="08:00">
                                    </div>
                                    <div class="col">
                                        <label class="form-label">Hasta</label>
                                        <input type="time" class="form-control" id="accessTimeEnd" value="18:00">
                                    </div>
                                </div>
                                <div class="settings-description">
                                    Horario permitido para acceder al sistema
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Días de Acceso</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="monday" checked>
                                    <label class="form-check-label" for="monday">Lunes</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="tuesday" checked>
                                    <label class="form-check-label" for="tuesday">Martes</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="wednesday" checked>
                                    <label class="form-check-label" for="wednesday">Miércoles</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="thursday" checked>
                                    <label class="form-check-label" for="thursday">Jueves</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="friday" checked>
                                    <label class="form-check-label" for="friday">Viernes</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="saturday">
                                    <label class="form-check-label" for="saturday">Sábado</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="sunday">
                                    <label class="form-check-label" for="sunday">Domingo</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Notificaciones -->
                <div class="settings-content" id="notificaciones-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-bell"></i>Configuración de Notificaciones
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Notificaciones por Email</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="emailNotifications" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="emailNotificationsStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Recibir notificaciones importantes por correo electrónico
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Notificaciones en Sistema</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="systemNotifications" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="systemNotificationsStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Mostrar notificaciones dentro del sistema
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Email para Notificaciones</label>
                                <input type="email" class="form-control" id="notificationEmail" placeholder="notificaciones@miempresa.com">
                                <div class="settings-description">
                                    Dirección de email para recibir notificaciones del sistema
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Frecuencia de Reportes</label>
                                <select class="form-select" id="reportFrequency">
                                    <option value="daily">Diario</option>
                                    <option value="weekly" selected>Semanal</option>
                                    <option value="monthly">Mensual</option>
                                    <option value="never">Nunca</option>
                                </select>
                                <div class="settings-description">
                                    Frecuencia para enviar reportes automáticos por email
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-exclamation-triangle"></i>Alertas y Recordatorios
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Alertas de Stock Bajo</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="stockAlerts" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="stockAlertsStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Recibir alertas cuando productos tengan stock bajo
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Recordatorios de Vencimiento</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="expirationReminders" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="expirationRemindersStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Alertar sobre productos próximos a vencer
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Días Antes de Alerta</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="alertDaysBefore" min="1" max="30" value="7">
                                    <span class="input-group-text">días</span>
                                </div>
                                <div class="settings-description">
                                    Días de anticipación para alertas de vencimiento
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Notificaciones de Backup</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="backupNotifications" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="backupNotificationsStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Notificar sobre éxito/fallo de backups automáticos
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Apariencia -->
                <div class="settings-content" id="apariencia-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-paint-brush"></i>Personalización de la Interfaz
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Tema de Color</label>
                                <div class="color-picker">
                                    <div class="color-option active" style="background-color: #3a5ec7;" data-color="blue"></div>
                                    <div class="color-option" style="background-color: #28a745;" data-color="green"></div>
                                    <div class="color-option" style="background-color: #dc3545;" data-color="red"></div>
                                    <div class="color-option" style="background-color: #6f42c1;" data-color="purple"></div>
                                    <div class="color-option" style="background-color: #fd7e14;" data-color="orange"></div>
                                </div>
                                <div class="settings-description">
                                    Color principal de la interfaz del sistema
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Modo Oscuro</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="darkMode">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="darkModeStatus">Desactivado</span>
                                </div>
                                <div class="settings-description">
                                    Activar interfaz en modo oscuro
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Densidad de la Interfaz</label>
                                <select class="form-select" id="uiDensity">
                                    <option value="comfortable">Cómoda</option>
                                    <option value="compact" selected>Compacta</option>
                                    <option value="spacious">Espaciosa</option>
                                </select>
                                <div class="settings-description">
                                    Espaciado entre elementos de la interfaz
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Animaciones</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="animations" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="animationsStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Mostrar animaciones y transiciones en la interfaz
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-columns"></i>Personalización del Dashboard
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Widgets del Dashboard</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="widgetSales" checked>
                                    <label class="form-check-label" for="widgetSales">Resumen de Ventas</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="widgetInventory" checked>
                                    <label class="form-check-label" for="widgetInventory">Estado del Inventario</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="widgetRecent" checked>
                                    <label class="form-check-label" for="widgetRecent">Actividad Reciente</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="widgetStats" checked>
                                    <label class="form-check-label" for="widgetStats">Estadísticas</label>
                                </div>
                                <div class="settings-description">
                                    Seleccionar qué widgets mostrar en el dashboard
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Orden de Widgets</label>
                                <select class="form-select" id="widgetOrder">
                                    <option value="default">Predeterminado</option>
                                    <option value="custom">Personalizado</option>
                                </select>
                                <div class="settings-description">
                                    Orden de visualización de los widgets
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Pestaña Avanzado -->
                <div class="settings-content" id="avanzado-tab">
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-tachometer-alt"></i>Configuración de Rendimiento
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Cache del Navegador</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="browserCache" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="browserCacheStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Utilizar cache del navegador para mejorar el rendimiento
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Compresión de Datos</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="dataCompression" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="dataCompressionStatus">Activado</span>
                                </div>
                                <div class="settings-description">
                                    Comprimir datos para reducir el uso de ancho de banda
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Límite de Consultas Simultáneas</label>
                                <input type="number" class="form-control" id="concurrentQueries" min="1" max="20" value="5">
                                <div class="settings-description">
                                    Número máximo de consultas a la base de datos que pueden ejecutarse simultáneamente
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Tiempo de Espera de Consultas</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="queryTimeout" min="5" max="60" value="30">
                                    <span class="input-group-text">segundos</span>
                                </div>
                                <div class="settings-description">
                                    Tiempo máximo de espera para consultas a la base de datos
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-code"></i>Configuración de Desarrollo
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Modo Desarrollador</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="developerMode">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="developerModeStatus">Desactivado</span>
                                </div>
                                <div class="settings-description">
                                    Activar herramientas de desarrollo y depuración
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Registro de Errores Detallado</label>
                                <div class="d-flex align-items-center">
                                    <label class="toggle-switch me-3">
                                        <input type="checkbox" id="detailedErrorLogging">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="detailedErrorLoggingStatus">Desactivado</span>
                                </div>
                                <div class="settings-description">
                                    Registrar información detallada de errores para depuración
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">Nivel de Log</label>
                                <select class="form-select" id="logLevel">
                                    <option value="error">Solo Errores</option>
                                    <option value="warning" selected>Advertencias y Errores</option>
                                    <option value="info">Información Completa</option>
                                    <option value="debug">Depuración (Detallado)</option>
                                </select>
                                <div class="settings-description">
                                    Nivel de detalle para los registros del sistema
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">API Rate Limiting</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="apiRateLimit" min="10" max="1000" value="100">
                                    <span class="input-group-text">solicitudes/min</span>
                                </div>
                                <div class="settings-description">
                                    Límite de solicitudes por minuto para la API del sistema
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h3 class="settings-group-title">
                            <i class="fas fa-plug"></i>Integraciones
                        </h3>
                        
                        <div class="settings-row">
                            <div class="settings-item">
                                <label class="settings-label">API Key</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="apiKey" placeholder="Clave de API" readonly>
                                    <button class="btn btn-outline-secondary" type="button" id="generateApiKey">
                                        <i class="fas fa-sync-alt"></i>
                                    </button>
                                </div>
                                <div class="settings-description">
                                    Clave para acceder a la API del sistema
                                </div>
                            </div>
                            <div class="settings-item">
                                <label class="settings-label">Webhooks</label>
                                <textarea class="form-control" id="webhookUrls" rows="3" placeholder="URLs de webhooks (una por línea)"></textarea>
                                <div class="settings-description">
                                    URLs para enviar notificaciones automáticas a sistemas externos
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="settings-actions">
                    <button type="button" class="btn btn-secondary" id="resetSettingsBtn">
                        <i class="fas fa-undo me-2"></i>Restablecer
                    </button>
                    <button type="button" class="btn btn-primary" id="saveSettingsBtn">
                        <i class="fas fa-save me-2"></i>Guardar Configuraciones
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Botón de Instrucciones -->
    <button class="instructions-btn" id="instructionsBtn">
        <i class="fas fa-question"></i>
    </button>
    
    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Modal de Instrucciones -->
    <div class="instructions-modal" id="instructionsModal">
        <div class="instructions-content">
            <div class="instructions-header">
                <h2 class="instructions-title">Instrucciones de Configuración</h2>
                <button class="instructions-close" id="instructionsClose">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="instructions-section">
                <h3 class="instructions-section-title">
                    <i class="fas fa-cog"></i>Configuración General
                </h3>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-info-circle"></i>Nombre del Sistema
                    </div>
                    <div class="instructions-item-description">
                        Define el nombre que aparecerá en todas las páginas del sistema. Este nombre se mostrará en la barra de título del navegador y en el encabezado de todas las páginas.
                    </div>
                </div>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-language"></i>Idioma del Sistema
                    </div>
                    <div class="instructions-item-description">
                        Selecciona el idioma principal de la interfaz. Esto afectará a todos los textos, mensajes y etiquetas en todo el sistema.
                    </div>
                </div>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-clock"></i>Zona Horaria
                    </div>
                    <div class="instructions-item-description">
                        Configura la zona horaria para que todas las fechas y horas se muestren correctamente según tu ubicación geográfica.
                    </div>
                </div>
            </div>
            
            <div class="instructions-section">
                <h3 class="instructions-section-title">
                    <i class="fas fa-building"></i>Configuración de Empresa
                </h3>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-file-invoice"></i>Información Fiscal
                    </div>
                    <div class="instructions-item-description">
                        Esta información se utilizará en todos los documentos generados por el sistema (facturas, reportes, etc.). Asegúrate de que sea correcta.
                    </div>
                </div>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-money-bill-wave"></i>Configuración Monetaria
                    </div>
                    <div class="instructions-item-description">
                        Define la moneda principal, símbolo monetario y tasas de impuesto que se aplicarán en todo el sistema para cálculos y reportes financieros.
                    </div>
                </div>
            </div>
            
            <div class="instructions-section">
                <h3 class="instructions-section-title">
                    <i class="fas fa-shield-alt"></i>Configuración de Seguridad
                </h3>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-lock"></i>Autenticación de Dos Factores
                    </div>
                    <div class="instructions-item-description">
                        Cuando está activada, los usuarios deberán verificar su identidad mediante un código enviado a su dispositivo además de su contraseña.
                    </div>
                </div>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-key"></i>Política de Contraseñas
                    </div>
                    <div class="instructions-item-description">
                        Define los requisitos de complejidad para las contraseñas de los usuarios. Una política más estricta mejora la seguridad pero puede ser menos conveniente.
                    </div>
                </div>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-network-wired"></i>Control de Acceso por IP
                    </div>
                    <div class="instructions-item-description">
                        Restringe el acceso al sistema solo desde direcciones IP específicas. Útil para limitar el acceso a redes corporativas.
                    </div>
                </div>
            </div>
            
            <div class="instructions-section">
                <h3 class="instructions-section-title">
                    <i class="fas fa-tachometer-alt"></i>Configuración de Rendimiento
                </h3>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-database"></i>Límite de Consultas Simultáneas
                    </div>
                    <div class="instructions-item-description">
                        Controla cuántas consultas a la base de datos pueden ejecutarse al mismo tiempo. Un número más alto mejora el rendimiento pero consume más recursos.
                    </div>
                </div>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-compress-arrows-alt"></i>Compresión de Datos
                    </div>
                    <div class="instructions-item-description">
                        Reduce el tamaño de los datos transferidos entre el servidor y el cliente, mejorando los tiempos de carga especialmente en conexiones lentas.
                    </div>
                </div>
            </div>
            
            <div class="instructions-section">
                <h3 class="instructions-section-title">
                    <i class="fas fa-exclamation-triangle"></i>Configuraciones Avanzadas
                </h3>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-bug"></i>Modo Desarrollador
                    </div>
                    <div class="instructions-item-description">
                        Activa herramientas de depuración y registro detallado de errores. Solo debe activarse para solucionar problemas.
                    </div>
                </div>
                
                <div class="instructions-item">
                    <div class="instructions-item-title">
                        <i class="fas fa-plug"></i>Integraciones y API
                    </div>
                    <div class="instructions-item-description">
                        Configura webhooks y claves de API para integrar el sistema con otras aplicaciones y servicios externos.
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Clase para gestionar configuraciones globales
        class GlobalSettingsManager {
            constructor() {
                this.settings = JSON.parse(localStorage.getItem('globalSettings')) || this.getDefaultSettings();
                this.applySettings();
            }
            
            getDefaultSettings() {
                return {
                    // Configuración General
                    systemName: 'SmartStock AI',
                    systemLanguage: 'es',
                    systemTimezone: 'America/Mexico_City',
                    dateFormat: 'dd/mm/yyyy',
                    recordsPerPage: 10,
                    autoSave: true,
                    
                    // Configuración de Empresa
                    companyName: '',
                    companyTaxId: '',
                    companyAddress: '',
                    companyPhone: '',
                    companyEmail: '',
                    companyWebsite: '',
                    companyIndustry: '',
                    companyCurrency: 'MXN',
                    currencySymbol: '$',
                    taxRate: 16,
                    priceFormat: '1,234.56',
                    
                    // Configuración del Sistema
                    maintenanceMode: false,
                    backupLimit: 7,
                    sessionTimeout: 30,
                    loginAttempts: 5,
                    autoBackup: true,
                    backupFrequency: 'daily',
                    lowStockAlerts: true,
                    lowStockThreshold: 10,
                    
                    // Configuración de Seguridad
                    twoFactorAuth: false,
                    passwordPolicy: 'medium',
                    passwordExpiration: 90,
                    activityLogging: true,
                    allowedIPs: '',
                    accessTimeStart: '08:00',
                    accessTimeEnd: '18:00',
                    accessDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
                    
                    // Configuración de Notificaciones
                    emailNotifications: true,
                    systemNotifications: true,
                    notificationEmail: '',
                    reportFrequency: 'weekly',
                    stockAlerts: true,
                    expirationReminders: true,
                    alertDaysBefore: 7,
                    backupNotifications: true,
                    
                    // Configuración de Apariencia
                    themeColor: 'blue',
                    darkMode: false,
                    uiDensity: 'compact',
                    animations: true,
                    dashboardWidgets: ['widgetSales', 'widgetInventory', 'widgetRecent', 'widgetStats'],
                    widgetOrder: 'default',
                    
                    // Configuración Avanzada
                    browserCache: true,
                    dataCompression: true,
                    concurrentQueries: 5,
                    queryTimeout: 30,
                    developerMode: false,
                    detailedErrorLogging: false,
                    logLevel: 'warning',
                    apiRateLimit: 100,
                    apiKey: this.generateApiKey(),
                    webhookUrls: ''
                };
            }
            
            generateApiKey() {
                return 'sk_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
            }
            
            getSettings() {
                return this.settings;
            }
            
            updateSettings(newSettings) {
                this.settings = { ...this.settings, ...newSettings };
                localStorage.setItem('globalSettings', JSON.stringify(this.settings));
                this.applySettings();
                return this.settings;
            }
            
            resetSettings() {
                this.settings = this.getDefaultSettings();
                localStorage.setItem('globalSettings', JSON.stringify(this.settings));
                this.applySettings();
                return this.settings;
            }
            
            applySettings() {
                // Aplicar configuración de tema
                this.applyThemeSettings();
                
                // Aplicar configuración de idioma
                this.applyLanguageSettings();
                
                // Aplicar configuración de apariencia
                this.applyAppearanceSettings();
                
                // Aplicar otras configuraciones globales
                this.applyOtherSettings();
            }
            
            applyThemeSettings() {
                // Aplicar modo oscuro
                if (this.settings.darkMode) {
                    document.body.classList.add('dark-mode');
                    document.querySelector('#themeToggle i').className = 'fas fa-sun';
                } else {
                    document.body.classList.remove('dark-mode');
                    document.querySelector('#themeToggle i').className = 'fas fa-moon';
                }
                
                // Aplicar color del tema
                this.applyThemeColor();
            }
            
            applyThemeColor() {
                const root = document.documentElement;
                let primaryColor = '#3a5ec7'; // Azul por defecto
                
                switch(this.settings.themeColor) {
                    case 'green':
                        primaryColor = '#28a745';
                        break;
                    case 'red':
                        primaryColor = '#dc3545';
                        break;
                    case 'purple':
                        primaryColor = '#6f42c1';
                        break;
                    case 'orange':
                        primaryColor = '#fd7e14';
                        break;
                }
                
                root.style.setProperty('--primary', primaryColor);
                root.style.setProperty('--primary-dark', this.darkenColor(primaryColor, 20));
            }
            
            darkenColor(color, percent) {
                const num = parseInt(color.replace("#", ""), 16);
                const amt = Math.round(2.55 * percent);
                const R = (num >> 16) - amt;
                const G = (num >> 8 & 0x00FF) - amt;
                const B = (num & 0x0000FF) - amt;
                return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
                    (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
                    (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
            }
            
            applyLanguageSettings() {
                // En una implementación real, aquí cargaríamos los textos en el idioma seleccionado
                console.log('Aplicando configuración de idioma:', this.settings.systemLanguage);
            }
            
            applyAppearanceSettings() {
                // Aplicar densidad de interfaz
                const root = document.documentElement;
                switch(this.settings.uiDensity) {
                    case 'comfortable':
                        root.style.setProperty('--font-size', '16px');
                        break;
                    case 'compact':
                        root.style.setProperty('--font-size', '14px');
                        break;
                    case 'spacious':
                        root.style.setProperty('--font-size', '18px');
                        break;
                }
                
                // Aplicar animaciones
                if (!this.settings.animations) {
                    document.body.style.setProperty('--transition', 'none');
                } else {
                    document.body.style.setProperty('--transition', 'all 0.3s ease');
                }
            }
            
            applyOtherSettings() {
                // Aplicar otras configuraciones que afecten a todas las páginas
                console.log('Aplicando otras configuraciones globales');
                
                // Aplicar límite de registros por página
                if (typeof window.applyRecordsPerPage === 'function') {
                    window.applyRecordsPerPage(this.settings.recordsPerPage);
                }
                
                // Aplicar configuración de sesión
                if (typeof window.applySessionSettings === 'function') {
                    window.applySessionSettings(this.settings.sessionTimeout);
                }
            }
            
            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
                    <span>${message}</span>
                `;
                
                document.getElementById('toastContainer').appendChild(toast);
                
                setTimeout(() => {
                    toast.style.animation = 'slideOut 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }
        }

        // Instancia global del administrador de configuraciones
        const settingsManager = new GlobalSettingsManager();

        // Función para cargar configuraciones en el formulario
        function loadSettingsToForm() {
            const settings = settingsManager.getSettings();
            
            // Pestaña General
            document.getElementById('systemName').value = settings.systemName;
            document.getElementById('systemLanguage').value = settings.systemLanguage;
            document.getElementById('systemTimezone').value = settings.systemTimezone;
            document.getElementById('dateFormat').value = settings.dateFormat;
            document.getElementById('recordsPerPage').value = settings.recordsPerPage;
            document.getElementById('autoSave').checked = settings.autoSave;
            updateToggleStatus('autoSave', 'autoSaveStatus');
            
            // Pestaña Empresa
            document.getElementById('companyName').value = settings.companyName;
            document.getElementById('companyTaxId').value = settings.companyTaxId;
            document.getElementById('companyAddress').value = settings.companyAddress;
            document.getElementById('companyPhone').value = settings.companyPhone;
            document.getElementById('companyEmail').value = settings.companyEmail;
            document.getElementById('companyWebsite').value = settings.companyWebsite;
            document.getElementById('companyIndustry').value = settings.companyIndustry;
            document.getElementById('companyCurrency').value = settings.companyCurrency;
            document.getElementById('currencySymbol').value = settings.currencySymbol;
            document.getElementById('taxRate').value = settings.taxRate;
            document.getElementById('priceFormat').value = settings.priceFormat;
            
            // Pestaña Sistema
            document.getElementById('maintenanceMode').checked = settings.maintenanceMode;
            updateToggleStatus('maintenanceMode', 'maintenanceStatus');
            document.getElementById('backupLimit').value = settings.backupLimit;
            document.getElementById('sessionTimeout').value = settings.sessionTimeout;
            document.getElementById('loginAttempts').value = settings.loginAttempts;
            document.getElementById('autoBackup').checked = settings.autoBackup;
            updateToggleStatus('autoBackup', 'autoBackupStatus');
            document.getElementById('backupFrequency').value = settings.backupFrequency;
            document.getElementById('lowStockAlerts').checked = settings.lowStockAlerts;
            updateToggleStatus('lowStockAlerts', 'lowStockStatus');
            document.getElementById('lowStockThreshold').value = settings.lowStockThreshold;
            
            // Pestaña Seguridad
            document.getElementById('twoFactorAuth').checked = settings.twoFactorAuth;
            updateToggleStatus('twoFactorAuth', 'twoFactorStatus');
            document.getElementById('passwordPolicy').value = settings.passwordPolicy;
            document.getElementById('passwordExpiration').value = settings.passwordExpiration;
            document.getElementById('activityLogging').checked = settings.activityLogging;
            updateToggleStatus('activityLogging', 'activityLogStatus');
            document.getElementById('allowedIPs').value = settings.allowedIPs;
            document.getElementById('accessTimeStart').value = settings.accessTimeStart;
            document.getElementById('accessTimeEnd').value = settings.accessTimeEnd;
            
            // Días de acceso
            const accessDays = settings.accessDays || [];
            document.getElementById('monday').checked = accessDays.includes('monday');
            document.getElementById('tuesday').checked = accessDays.includes('tuesday');
            document.getElementById('wednesday').checked = accessDays.includes('wednesday');
            document.getElementById('thursday').checked = accessDays.includes('thursday');
            document.getElementById('friday').checked = accessDays.includes('friday');
            document.getElementById('saturday').checked = accessDays.includes('saturday');
            document.getElementById('sunday').checked = accessDays.includes('sunday');
            
            // Pestaña Notificaciones
            document.getElementById('emailNotifications').checked = settings.emailNotifications;
            updateToggleStatus('emailNotifications', 'emailNotificationsStatus');
            document.getElementById('systemNotifications').checked = settings.systemNotifications;
            updateToggleStatus('systemNotifications', 'systemNotificationsStatus');
            document.getElementById('notificationEmail').value = settings.notificationEmail;
            document.getElementById('reportFrequency').value = settings.reportFrequency;
            document.getElementById('stockAlerts').checked = settings.stockAlerts;
            updateToggleStatus('stockAlerts', 'stockAlertsStatus');
            document.getElementById('expirationReminders').checked = settings.expirationReminders;
            updateToggleStatus('expirationReminders', 'expirationRemindersStatus');
            document.getElementById('alertDaysBefore').value = settings.alertDaysBefore;
            document.getElementById('backupNotifications').checked = settings.backupNotifications;
            updateToggleStatus('backupNotifications', 'backupNotificationsStatus');
            
            // Pestaña Apariencia
            // Color del tema
            document.querySelectorAll('.color-option').forEach(option => {
                option.classList.remove('active');
                if (option.getAttribute('data-color') === settings.themeColor) {
                    option.classList.add('active');
                }
            });
            
            document.getElementById('darkMode').checked = settings.darkMode;
            updateToggleStatus('darkMode', 'darkModeStatus');
            document.getElementById('uiDensity').value = settings.uiDensity;
            document.getElementById('animations').checked = settings.animations;
            updateToggleStatus('animations', 'animationsStatus');
            
            // Widgets del dashboard
            const dashboardWidgets = settings.dashboardWidgets || [];
            document.getElementById('widgetSales').checked = dashboardWidgets.includes('widgetSales');
            document.getElementById('widgetInventory').checked = dashboardWidgets.includes('widgetInventory');
            document.getElementById('widgetRecent').checked = dashboardWidgets.includes('widgetRecent');
            document.getElementById('widgetStats').checked = dashboardWidgets.includes('widgetStats');
            
            document.getElementById('widgetOrder').value = settings.widgetOrder;
            
            // Pestaña Avanzado
            document.getElementById('browserCache').checked = settings.browserCache;
            updateToggleStatus('browserCache', 'browserCacheStatus');
            document.getElementById('dataCompression').checked = settings.dataCompression;
            updateToggleStatus('dataCompression', 'dataCompressionStatus');
            document.getElementById('concurrentQueries').value = settings.concurrentQueries;
            document.getElementById('queryTimeout').value = settings.queryTimeout;
            document.getElementById('developerMode').checked = settings.developerMode;
            updateToggleStatus('developerMode', 'developerModeStatus');
            document.getElementById('detailedErrorLogging').checked = settings.detailedErrorLogging;
            updateToggleStatus('detailedErrorLogging', 'detailedErrorLoggingStatus');
            document.getElementById('logLevel').value = settings.logLevel;
            document.getElementById('apiRateLimit').value = settings.apiRateLimit;
            document.getElementById('apiKey').value = settings.apiKey;
            document.getElementById('webhookUrls').value = settings.webhookUrls;
        }
        
        // Función para actualizar el estado de los toggles
        function updateToggleStatus(checkboxId, statusSpanId) {
            const checkbox = document.getElementById(checkboxId);
            const statusSpan = document.getElementById(statusSpanId);
            if (checkbox && statusSpan) {
                statusSpan.textContent = checkbox.checked ? 'Activado' : 'Desactivado';
            }
        }
        
        // Función para guardar configuraciones desde el formulario
        function saveSettingsFromForm() {
            const settings = {};
            
            // Pestaña General
            settings.systemName = document.getElementById('systemName').value;
            settings.systemLanguage = document.getElementById('systemLanguage').value;
            settings.systemTimezone = document.getElementById('systemTimezone').value;
            settings.dateFormat = document.getElementById('dateFormat').value;
            settings.recordsPerPage = parseInt(document.getElementById('recordsPerPage').value);
            settings.autoSave = document.getElementById('autoSave').checked;
            
            // Pestaña Empresa
            settings.companyName = document.getElementById('companyName').value;
            settings.companyTaxId = document.getElementById('companyTaxId').value;
            settings.companyAddress = document.getElementById('companyAddress').value;
            settings.companyPhone = document.getElementById('companyPhone').value;
            settings.companyEmail = document.getElementById('companyEmail').value;
            settings.companyWebsite = document.getElementById('companyWebsite').value;
            settings.companyIndustry = document.getElementById('companyIndustry').value;
            settings.companyCurrency = document.getElementById('companyCurrency').value;
            settings.currencySymbol = document.getElementById('currencySymbol').value;
            settings.taxRate = parseFloat(document.getElementById('taxRate').value);
            settings.priceFormat = document.getElementById('priceFormat').value;
            
            // Pestaña Sistema
            settings.maintenanceMode = document.getElementById('maintenanceMode').checked;
            settings.backupLimit = parseInt(document.getElementById('backupLimit').value);
            settings.sessionTimeout = parseInt(document.getElementById('sessionTimeout').value);
            settings.loginAttempts = parseInt(document.getElementById('loginAttempts').value);
            settings.autoBackup = document.getElementById('autoBackup').checked;
            settings.backupFrequency = document.getElementById('backupFrequency').value;
            settings.lowStockAlerts = document.getElementById('lowStockAlerts').checked;
            settings.lowStockThreshold = parseInt(document.getElementById('lowStockThreshold').value);
            
            // Pestaña Seguridad
            settings.twoFactorAuth = document.getElementById('twoFactorAuth').checked;
            settings.passwordPolicy = document.getElementById('passwordPolicy').value;
            settings.passwordExpiration = parseInt(document.getElementById('passwordExpiration').value);
            settings.activityLogging = document.getElementById('activityLogging').checked;
            settings.allowedIPs = document.getElementById('allowedIPs').value;
            settings.accessTimeStart = document.getElementById('accessTimeStart').value;
            settings.accessTimeEnd = document.getElementById('accessTimeEnd').value;
            
            // Días de acceso
            settings.accessDays = [];
            if (document.getElementById('monday').checked) settings.accessDays.push('monday');
            if (document.getElementById('tuesday').checked) settings.accessDays.push('tuesday');
            if (document.getElementById('wednesday').checked) settings.accessDays.push('wednesday');
            if (document.getElementById('thursday').checked) settings.accessDays.push('thursday');
            if (document.getElementById('friday').checked) settings.accessDays.push('friday');
            if (document.getElementById('saturday').checked) settings.accessDays.push('saturday');
            if (document.getElementById('sunday').checked) settings.accessDays.push('sunday');
            
            // Pestaña Notificaciones
            settings.emailNotifications = document.getElementById('emailNotifications').checked;
            settings.systemNotifications = document.getElementById('systemNotifications').checked;
            settings.notificationEmail = document.getElementById('notificationEmail').value;
            settings.reportFrequency = document.getElementById('reportFrequency').value;
            settings.stockAlerts = document.getElementById('stockAlerts').checked;
            settings.expirationReminders = document.getElementById('expirationReminders').checked;
            settings.alertDaysBefore = parseInt(document.getElementById('alertDaysBefore').value);
            settings.backupNotifications = document.getElementById('backupNotifications').checked;
            
            // Pestaña Apariencia
            const activeColor = document.querySelector('.color-option.active');
            settings.themeColor = activeColor ? activeColor.getAttribute('data-color') : 'blue';
            settings.darkMode = document.getElementById('darkMode').checked;
            settings.uiDensity = document.getElementById('uiDensity').value;
            settings.animations = document.getElementById('animations').checked;
            
            // Widgets del dashboard
            settings.dashboardWidgets = [];
            if (document.getElementById('widgetSales').checked) settings.dashboardWidgets.push('widgetSales');
            if (document.getElementById('widgetInventory').checked) settings.dashboardWidgets.push('widgetInventory');
            if (document.getElementById('widgetRecent').checked) settings.dashboardWidgets.push('widgetRecent');
            if (document.getElementById('widgetStats').checked) settings.dashboardWidgets.push('widgetStats');
            
            settings.widgetOrder = document.getElementById('widgetOrder').value;
            
            // Pestaña Avanzado
            settings.browserCache = document.getElementById('browserCache').checked;
            settings.dataCompression = document.getElementById('dataCompression').checked;
            settings.concurrentQueries = parseInt(document.getElementById('concurrentQueries').value);
            settings.queryTimeout = parseInt(document.getElementById('queryTimeout').value);
            settings.developerMode = document.getElementById('developerMode').checked;
            settings.detailedErrorLogging = document.getElementById('detailedErrorLogging').checked;
            settings.logLevel = document.getElementById('logLevel').value;
            settings.apiRateLimit = parseInt(document.getElementById('apiRateLimit').value);
            settings.apiKey = document.getElementById('apiKey').value;
            settings.webhookUrls = document.getElementById('webhookUrls').value;
            
            // Actualizar configuraciones
            settingsManager.updateSettings(settings);
            settingsManager.showNotification('Configuraciones guardadas correctamente', 'success');
        }
        
        // Función para cambiar tema
        function toggleTheme() {
            const currentDarkMode = settingsManager.getSettings().darkMode;
            settingsManager.updateSettings({ darkMode: !currentDarkMode });
            loadSettingsToForm();
        }
        
        // Función para toggle del menú en móviles
        function toggleMenu() {
            document.getElementById('sidebar').classList.toggle('open');
        }
        
        // Función para abrir/cerrar modal de instrucciones
        function toggleInstructions() {
            document.getElementById('instructionsModal').classList.toggle('active');
        }
        
        // Función para generar nueva API Key
        function generateApiKey() {
            const newApiKey = settingsManager.generateApiKey();
            document.getElementById('apiKey').value = newApiKey;
            settingsManager.showNotification('Nueva API Key generada', 'success');
        }
        
        // Inicialización cuando el DOM está listo
        document.addEventListener('DOMContentLoaded', function() {
            // Cargar configuraciones en el formulario
            loadSettingsToForm();
            
            // Event listeners
            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            document.getElementById('menuToggle').addEventListener('click', toggleMenu);
            document.getElementById('instructionsBtn').addEventListener('click', toggleInstructions);
            document.getElementById('instructionsClose').addEventListener('click', toggleInstructions);
            document.getElementById('generateApiKey').addEventListener('click', generateApiKey);
            
            // Navegación entre pestañas
            document.querySelectorAll('.settings-tab').forEach(tab => {
                tab.addEventListener('click', function() {
                    // Remover clase active de todas las pestañas y contenidos
                    document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
                    document.querySelectorAll('.settings-content').forEach(c => c.classList.remove('active'));
                    
                    // Agregar clase active a la pestaña clickeada
                    this.classList.add('active');
                    
                    // Mostrar el contenido correspondiente
                    const tabId = this.getAttribute('data-tab');
                    document.getElementById(`${tabId}-tab`).classList.add('active');
                });
            });
            
            // Actualizar estados de toggles
            document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const statusSpanId = this.id + 'Status';
                    updateToggleStatus(this.id, statusSpanId);
                });
            });
            
            // Selectores de color
            document.querySelectorAll('.color-option').forEach(option => {
                option.addEventListener('click', function() {
                    document.querySelectorAll('.color-option').forEach(o => o.classList.remove('active'));
                    this.classList.add('active');
                });
            });
            
            // Guardar configuraciones
            document.getElementById('saveSettingsBtn').addEventListener('click', saveSettingsFromForm);
            
            // Restablecer configuraciones
            document.getElementById('resetSettingsBtn').addEventListener('click', function() {
                if (confirm('¿Estás seguro de que deseas restablecer todas las configuraciones a sus valores predeterminados?')) {
                    settingsManager.resetSettings();
                    loadSettingsToForm();
                    settingsManager.showNotification('Configuraciones restablecidas correctamente', 'success');
                }
            });
            
            // Cerrar modal al hacer clic fuera
            document.getElementById('instructionsModal').addEventListener('click', function(e) {
                if (e.target === this) {
                    toggleInstructions();
                }
            });
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>