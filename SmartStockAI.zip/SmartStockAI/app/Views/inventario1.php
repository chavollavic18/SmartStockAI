<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Dashboard Inteligente</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Chart.js para gráficos -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- jsPDF para exportar PDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <!-- SheetJS para Excel -->
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <!-- QR Code -->
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js"></script>
    <!-- Barcode -->
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <!-- Canvas Confetti -->
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1"></script>
    <style>
        /* ============================================
           VARIABLES CSS PARA TEMAS
           ============================================ */
        :root {
            /* Tema claro (por defecto) */
            --primary: #3a5ec7;
            --primary-light: #5a7ed7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --secondary-light: #48c765;
            --secondary-dark: #218838;
            --danger: #dc3545;
            --danger-light: #e55a6a;
            --danger-dark: #c82333;
            --warning: #ffc107;
            --warning-light: #ffd145;
            --warning-dark: #e0a800;
            --info: #17a2b8;
            --info-light: #3ab7cc;
            --info-dark: #138496;
            --dark: #2c3e50;
            --darker: #1a252f;
            --light: #f8f9fa;
            --lighter: #ffffff;
            --gray-100: #f8f9fa;
            --gray-200: #e9ecef;
            --gray-300: #dee2e6;
            --gray-400: #ced4da;
            --gray-500: #adb5bd;
            --gray-600: #6c757d;
            --gray-700: #495057;
            --gray-800: #343a40;
            --gray-900: #212529;
            
            /* Variables de fondo y texto - TEMA CLARO */
            --bg-primary: #f5f7fb;
            --bg-secondary: #ffffff;
            --bg-card: #ffffff;
            --bg-sidebar: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            --text-primary: #000000;
            --text-secondary: #6c757d;
            --text-muted: #6c757d;
            --border-color: rgba(0,0,0,0.1);
            --shadow-color: rgba(0,0,0,0.05);
            --shadow-hover: rgba(0,0,0,0.1);
            --input-bg: #ffffff;
            --input-border: #ced4da;
            --input-focus: rgba(58, 94, 199, 0.25);
            
            /* Estados */
            --success-bg: rgba(40, 167, 69, 0.1);
            --success-text: #28a745;
            --warning-bg: rgba(255, 193, 7, 0.1);
            --warning-text: #856404;
            --danger-bg: rgba(220, 53, 69, 0.1);
            --danger-text: #dc3545;
            --info-bg: rgba(23, 162, 184, 0.1);
            --info-text: #17a2b8;
            
            /* Dimensiones */
            --border-radius: 12px;
            --border-radius-sm: 8px;
            --border-radius-lg: 16px;
            --transition: all 0.3s ease;
            --sidebar-width: 250px;
            --sidebar-collapsed: 80px;
        }

        /* ============================================
           TEMA OSCURO (cuando se activa dark-mode)
           ============================================ */
        body.dark-mode {
            --bg-primary: #1a1f2e;
            --bg-secondary: #242a3a;
            --bg-card: #2c3345;
            --text-primary: #ffffff;
            --text-secondary: #a0a8b8;
            --text-muted: #7a8395;
            --border-color: rgba(255,255,255,0.1);
            --shadow-color: rgba(0,0,0,0.3);
            --shadow-hover: rgba(0,0,0,0.4);
            --input-bg: #2c3345;
            --input-border: #40485a;
            --input-focus: rgba(58, 94, 199, 0.5);
            
            --success-bg: rgba(40, 167, 69, 0.2);
            --success-text: #6fcf97;
            --warning-bg: rgba(255, 193, 7, 0.2);
            --warning-text: #f9ca7f;
            --danger-bg: rgba(220, 53, 69, 0.2);
            --danger-text: #f28b82;
            --info-bg: rgba(23, 162, 184, 0.2);
            --info-text: #7fd1e0;
            
            /* Sidebar en modo oscuro */
            --bg-sidebar: linear-gradient(135deg, #1e2b4a 0%, #152238 100%);
        }

        /* ============================================
           ESTILOS GENERALES
           ============================================ */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg-primary);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-primary);
            transition: var(--transition);
            min-height: 100vh;
        }

        /* Scrollbar personalizado */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-secondary);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--primary);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary-dark);
        }

        /* Firefox */
        * {
            scrollbar-width: thin;
            scrollbar-color: var(--primary) var(--bg-secondary);
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* ============================================
           SIDEBAR
           ============================================ */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--bg-sidebar);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 3px 0 20px var(--shadow-color);
            overflow-y: auto;
        }

        .sidebar.collapsed {
            width: var(--sidebar-collapsed);
        }

        .sidebar.collapsed .sidebar-header .logo span,
        .sidebar.collapsed .sidebar-menu a span,
        .sidebar.collapsed .sidebar-footer span {
            display: none;
        }

        .sidebar.collapsed .sidebar-menu a {
            text-align: center;
            padding: 12px;
        }

        .sidebar.collapsed .sidebar-menu i {
            margin: 0;
            font-size: 20px;
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo {
            font-size: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo i {
            font-size: 24px;
        }

        .sidebar-toggle {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
        }

        .sidebar-toggle:hover {
            background: rgba(255,255,255,0.3);
            transform: scale(1.1);
        }

        .sidebar-menu {
            list-style: none;
            padding: 0 15px;
            margin-bottom: 20px;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            padding: 12px 15px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: var(--transition);
            border-radius: 8px;
            font-weight: 500;
            font-size: 14px;
        }

        .sidebar-menu a:hover, 
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.15);
            transform: translateX(5px);
        }

        .sidebar-menu i {
            width: 20px;
            font-size: 16px;
        }

        .sidebar-footer {
            position: absolute;
            bottom: 20px;
            left: 0;
            right: 0;
            padding: 0 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px;
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255,255,255,0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .user-details {
            flex: 1;
            overflow: hidden;
        }

        .user-name {
            font-weight: 600;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 14px;
        }

        .user-role {
            font-size: 11px;
            opacity: 0.7;
        }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: var(--transition);
        }

        .main-content.expanded {
            margin-left: var(--sidebar-collapsed);
        }

        /* ============================================
           HEADER
           ============================================ */
        .header {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px 30px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 5px 20px var(--shadow-color);
        }

        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }

        .page-title i {
            color: var(--primary);
            margin-right: 10px;
        }

        .header-controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .search-box {
            position: relative;
            width: 280px;
        }

        .search-box input {
            width: 100%;
            padding: 10px 15px 10px 40px;
            border: 1px solid var(--input-border);
            border-radius: 30px;
            background: var(--input-bg);
            color: var(--text-primary);
            transition: var(--transition);
            font-size: 14px;
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px var(--input-focus);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 12px;
            color: var(--text-muted);
            font-size: 14px;
        }

        .search-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--bg-card);
            border-radius: 0 0 var(--border-radius-sm) var(--border-radius-sm);
            box-shadow: 0 5px 15px var(--shadow-hover);
            z-index: 1000;
            max-height: 250px;
            overflow-y: auto;
            display: none;
        }

        .search-suggestions.show {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        .suggestion-item {
            padding: 10px 15px;
            cursor: pointer;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            gap: 10px;
            transition: var(--transition);
            font-size: 13px;
        }

        .suggestion-item:hover {
            background: var(--bg-secondary);
        }

        .suggestion-item i {
            color: var(--primary);
            width: 18px;
            font-size: 14px;
        }

        .suggestion-item small {
            color: var(--text-muted);
            margin-left: auto;
            font-size: 11px;
        }

        .theme-switcher, 
        .notification-btn {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--bg-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            color: var(--text-primary);
            position: relative;
            border: 1px solid var(--border-color);
            font-size: 16px;
        }

        .theme-switcher:hover, 
        .notification-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px var(--shadow-hover);
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        /* ============================================
           NOTIFICATION DROPDOWN
           ============================================ */
        .notification-container {
            position: relative;
        }

        .notification-dropdown {
            position: absolute;
            top: 45px;
            right: 0;
            width: 320px;
            background: var(--bg-card);
            border-radius: var(--border-radius);
            box-shadow: 0 10px 30px var(--shadow-hover);
            z-index: 1000;
            display: none;
            border: 1px solid var(--border-color);
        }

        .notification-dropdown.show {
            display: block;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .notification-header {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            font-weight: 600;
            background: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 14px;
        }

        .notification-header button {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            cursor: pointer;
            transition: var(--transition);
        }

        .notification-header button:hover {
            background: rgba(255,255,255,0.3);
        }

        .notification-list {
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-item {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            transition: var(--transition);
            cursor: pointer;
        }

        .notification-item:hover {
            background: var(--bg-secondary);
        }

        .notification-item.unread {
            background: var(--info-bg);
            border-left: 3px solid var(--primary);
        }

        .notification-item strong {
            display: block;
            margin-bottom: 3px;
            color: var(--text-primary);
            font-size: 13px;
        }

        .notification-item p {
            margin-bottom: 3px;
            font-size: 12px;
            color: var(--text-secondary);
        }

        .notification-item small {
            color: var(--text-muted);
            font-size: 10px;
        }

        .notification-footer {
            padding: 8px;
            text-align: center;
            border-top: 1px solid var(--border-color);
        }

        .notification-footer a {
            color: var(--primary);
            text-decoration: none;
            font-size: 12px;
        }

        /* ============================================
           QUICK ACTIONS
           ============================================ */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 12px;
            margin-bottom: 25px;
        }

        .action-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 15px 10px;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
            border: 1px solid var(--border-color);
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px var(--shadow-hover);
            border-color: var(--primary);
        }

        .action-card i {
            font-size: 24px;
            color: var(--primary);
            margin-bottom: 8px;
        }

        .action-card span {
            display: block;
            font-weight: 500;
            color: var(--text-primary);
            font-size: 13px;
        }

        .action-card small {
            color: var(--text-muted);
            font-size: 11px;
        }

        /* ============================================
           DASHBOARD CARDS
           ============================================ */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 18px;
            box-shadow: 0 5px 15px var(--shadow-color);
            transition: var(--transition);
            border-left: 4px solid transparent;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px var(--shadow-hover);
        }

        .stat-card.primary {
            border-left-color: var(--primary);
        }

        .stat-card.success {
            border-left-color: var(--secondary);
        }

        .stat-card.warning {
            border-left-color: var(--warning);
        }

        .stat-card.danger {
            border-left-color: var(--danger);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .stat-card.primary .stat-icon {
            background: var(--info-bg);
            color: var(--primary);
        }

        .stat-card.success .stat-icon {
            background: var(--success-bg);
            color: var(--secondary);
        }

        .stat-card.warning .stat-icon {
            background: var(--warning-bg);
            color: var(--warning);
        }

        .stat-card.danger .stat-icon {
            background: var(--danger-bg);
            color: var(--danger);
        }

        .stat-content {
            flex: 1;
        }

        .stat-label {
            color: var(--text-muted);
            font-size: 13px;
            margin-bottom: 3px;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1.2;
        }

        .stat-change {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            margin-top: 3px;
        }

        .stat-change.positive {
            color: var(--secondary);
        }

        .stat-change.negative {
            color: var(--danger);
        }

        /* ============================================
           CHARTS SECTION
           ============================================ */
        .charts-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .chart-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 18px;
            box-shadow: 0 5px 15px var(--shadow-color);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }

        .chart-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }

        .chart-title i {
            color: var(--primary);
            margin-right: 6px;
        }

        .chart-period {
            padding: 4px 8px;
            border: 1px solid var(--border-color);
            border-radius: 20px;
            background: transparent;
            color: var(--text-primary);
            cursor: pointer;
            transition: var(--transition);
            font-size: 12px;
        }

        .chart-period:hover {
            background: var(--bg-secondary);
        }

        .chart-container {
            position: relative;
            height: 220px;
        }

        /* ============================================
           TABLAS
           ============================================ */
        .table-container {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 18px;
            box-shadow: 0 5px 15px var(--shadow-color);
            margin-bottom: 25px;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .table-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }

        .table-title i {
            color: var(--primary);
            margin-right: 6px;
        }

        .table-actions {
            display: flex;
            gap: 8px;
        }

        .btn {
            padding: 6px 12px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3);
        }

        .btn-success {
            background: var(--secondary);
            color: white;
        }

        .btn-success:hover {
            background: var(--secondary-dark);
            transform: translateY(-2px);
        }

        .btn-warning {
            background: var(--warning);
            color: #212529;
        }

        .btn-warning:hover {
            background: var(--warning-dark);
            transform: translateY(-2px);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-primary);
        }

        .btn-outline:hover {
            background: var(--bg-secondary);
        }

        .table-responsive {
            overflow-x: auto;
            margin-bottom: 15px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 12px;
            font-weight: 600;
            color: var(--text-primary);
            background: var(--bg-secondary);
            border-bottom: 2px solid var(--border-color);
            font-size: 13px;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
            font-size: 13px;
        }

        tr:hover {
            background: var(--bg-secondary);
        }

        .product-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .product-thumb {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            object-fit: cover;
            border: 1px solid var(--border-color);
        }

        .badge {
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
            display: inline-block;
        }

        .badge-success {
            background: var(--success-bg);
            color: var(--success-text);
        }

        .badge-warning {
            background: var(--warning-bg);
            color: var(--warning-text);
        }

        .badge-danger {
            background: var(--danger-bg);
            color: var(--danger-text);
        }

        .badge-info {
            background: var(--info-bg);
            color: var(--info-text);
        }

        .stock-indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 5px;
        }

        .stock-critical {
            background: var(--danger);
            box-shadow: 0 0 0 2px var(--danger-bg);
        }

        .stock-low {
            background: var(--warning);
            box-shadow: 0 0 0 2px var(--warning-bg);
        }

        .stock-good {
            background: var(--secondary);
            box-shadow: 0 0 0 2px var(--success-bg);
        }

        .stock-normal {
            background: var(--primary);
            box-shadow: 0 0 0 2px var(--info-bg);
        }

        .action-buttons {
            display: flex;
            gap: 4px;
        }

        .icon-btn {
            width: 28px;
            height: 28px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
        }

        .icon-btn.view {
            background: var(--info);
        }

        .icon-btn.edit {
            background: var(--primary);
        }

        .icon-btn.delete {
            background: var(--danger);
        }

        .icon-btn.qr {
            background: #6f42c1;
        }

        .icon-btn:hover {
            transform: translateY(-2px);
            filter: brightness(1.1);
        }

        /* ============================================
           PAGINACIÓN
           ============================================ */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid var(--border-color);
        }

        .pagination-info {
            color: var(--text-muted);
            font-size: 13px;
        }

        .pagination {
            display: flex;
            gap: 4px;
        }

        .page-item {
            list-style: none;
        }

        .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 6px;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            font-size: 13px;
        }

        .page-link:hover,
        .page-item.active .page-link {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.disabled .page-link {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* ============================================
           MODALES
           ============================================ */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            backdrop-filter: blur(5px);
        }

        .modal-overlay.show {
            display: flex;
            animation: fadeIn 0.3s ease;
        }

        .modal {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            width: 90%;
            max-width: 550px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 20px 40px var(--shadow-hover);
            animation: slideUp 0.3s ease;
        }

        .modal-lg {
            max-width: 700px;
        }

        .modal-sm {
            max-width: 350px;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            padding: 15px 18px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
        }

        .modal-header h5 {
            margin: 0;
            display: flex;
            align-items: center;
            gap: 8px;
            color: white;
            font-size: 16px;
        }

        .modal-close {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            font-size: 14px;
        }

        .modal-close:hover {
            background: rgba(255,255,255,0.3);
            transform: rotate(90deg);
        }

        .modal-body {
            padding: 18px;
            color: var(--text-primary);
        }

        .modal-footer {
            padding: 15px 18px;
            border-top: 1px solid var(--border-color);
            display: flex;
            justify-content: flex-end;
            gap: 8px;
        }

        /* ============================================
           FORMULARIOS
           ============================================ */
        .form-group {
            margin-bottom: 12px;
        }

        .form-label {
            display: block;
            margin-bottom: 4px;
            font-weight: 500;
            color: var(--text-primary);
            font-size: 13px;
        }

        .form-control {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid var(--input-border);
            border-radius: 6px;
            background: var(--input-bg);
            color: var(--text-primary);
            transition: var(--transition);
            font-size: 13px;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px var(--input-focus);
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
        }

        /* ============================================
           TOAST NOTIFICATIONS
           ============================================ */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 3000;
        }

        .toast {
            background: var(--bg-card);
            border-radius: var(--border-radius-sm);
            padding: 12px 15px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 5px 15px var(--shadow-hover);
            border-left: 4px solid;
            min-width: 250px;
            animation: slideInRight 0.3s ease;
            color: var(--text-primary);
        }

        .toast.success {
            border-left-color: var(--secondary);
        }

        .toast.error {
            border-left-color: var(--danger);
        }

        .toast.warning {
            border-left-color: var(--warning);
        }

        .toast.info {
            border-left-color: var(--primary);
        }

        .toast i {
            font-size: 18px;
        }

        .toast.success i {
            color: var(--secondary);
        }

        .toast.error i {
            color: var(--danger);
        }

        .toast.warning i {
            color: var(--warning);
        }

        .toast.info i {
            color: var(--primary);
        }

        .toast-content {
            flex: 1;
        }

        .toast-title {
            font-weight: 600;
            margin-bottom: 2px;
            font-size: 13px;
        }

        .toast-message {
            font-size: 12px;
            color: var(--text-muted);
        }

        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* ============================================
           QR Y CÓDIGO DE BARRAS
           ============================================ */
        .code-container {
            text-align: center;
            padding: 15px;
        }

        .code-container svg,
        .code-container canvas {
            max-width: 100%;
            height: auto;
            max-height: 150px;
        }

        .code-actions {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin-top: 15px;
        }

        /* ============================================
           LOADING OVERLAY
           ============================================ */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 4000;
        }

        .loading-spinner {
            width: 40px;
            height: 40px;
            border: 3px solid var(--bg-card);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* ============================================
           EMPTY STATE
           ============================================ */
        .empty-state {
            text-align: center;
            padding: 30px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 40px;
            margin-bottom: 12px;
        }

        .empty-state h4 {
            margin-bottom: 8px;
            font-size: 16px;
        }

        .empty-state p {
            font-size: 13px;
        }

        /* ============================================
           TOOLTIPS
           ============================================ */
        [data-tooltip] {
            position: relative;
        }

        [data-tooltip]:before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 4px 8px;
            background: var(--darker);
            color: white;
            border-radius: 4px;
            font-size: 11px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 1000;
            pointer-events: none;
        }

        [data-tooltip]:hover:before {
            opacity: 1;
            visibility: visible;
            bottom: 120%;
        }

        /* ============================================
           RESPONSIVE
           ============================================ */
        @media (max-width: 1200px) {
            .charts-section {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 250px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: flex;
            }

            .search-box {
                width: 200px;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 12px;
            }

            .header-controls {
                width: 100%;
                justify-content: space-between;
            }

            .search-box {
                width: 160px;
            }

            .dashboard-cards {
                grid-template-columns: 1fr;
            }

            .quick-actions {
                grid-template-columns: repeat(2, 1fr);
            }

            .notification-dropdown {
                width: 280px;
                right: -60px;
            }

            .table-header {
                flex-direction: column;
                gap: 12px;
            }

            .table-actions {
                flex-wrap: wrap;
                justify-content: center;
            }

            .pagination-container {
                flex-direction: column;
                gap: 12px;
                align-items: center;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px;
            }

            .quick-actions {
                grid-template-columns: 1fr;
            }

            .modal {
                width: 95%;
            }

            .toast {
                min-width: 220px;
            }
        }

        .menu-toggle {
            display: none;
            position: fixed;
            bottom: 20px;
            left: 20px;
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            border: none;
            cursor: pointer;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            z-index: 1001;
            box-shadow: 0 5px 15px var(--shadow-hover);
            transition: var(--transition);
        }

        .menu-toggle:hover {
            transform: scale(1.1);
            background: var(--primary-dark);
        }

        /* ============================================
           EXPORT OPTIONS
           ============================================ */
        .export-options {
            position: absolute;
            top: 100%;
            right: 0;
            background: var(--bg-card);
            border-radius: var(--border-radius-sm);
            box-shadow: 0 5px 15px var(--shadow-hover);
            z-index: 100;
            min-width: 130px;
            margin-top: 5px;
            border: 1px solid var(--border-color);
        }

        .export-option {
            padding: 8px 12px;
            cursor: pointer;
            border-bottom: 1px solid var(--border-color);
            transition: var(--transition);
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .export-option:last-child {
            border-bottom: none;
        }

        .export-option:hover {
            background: var(--bg-secondary);
        }

        .export-option i {
            width: 16px;
            color: var(--primary);
        }
    </style>
</head>
<body>
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner"></div>
    </div>

    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot"></i>
                    <span>SmartStock AI</span>
                </div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
             <ul class="sidebar-menu">
    <li><a href="http://localhost/SmartStockAI/admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
    <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes"></i> Inventario</a></li>
    <li><a href="http://localhost/SmartStockAI/Reportes.php" class="active"><i class="fas fa-chart-line"></i> Reportes</a></li>
    <li><a href="http://localhost/SmartStockAI/clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
    <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck"></i> Proveedores</a></li>
    <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-user"></i> Usuarios</a></li>
    <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-exchange-alt"></i> Transacciones</a></li>
    <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-user-circle"></i> Mi Perfil</a></li>
    <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-alt"></i> Seguridad</a></li>
    <li><a href="http://localhost/SmartStockAI/login.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a></li>
    <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-cog"></i> Configuración</a></li>
</ul>

            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="user-details">
                        <div class="user-name">Ana García</div>
                        <div class="user-role">Administradora</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content" id="mainContent">
            <div class="header">
                <h1 class="page-title" id="pageTitle">
                    <i class="fas fa-home"></i>
                    Dashboard
                </h1>
                
                <div class="header-controls">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" id="globalSearch" placeholder="Buscar productos...">
                        <div class="search-suggestions" id="searchSuggestions"></div>
                    </div>
                    <div class="theme-switcher" id="themeToggle">
                        <!-- Luna = modo oscuro, Sol = modo claro -->
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notification-container">
                        <div class="notification-btn" id="notificationBtn">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge" id="notificationCount">0</span>
                        </div>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-header">
                                <span>Notificaciones</span>
                                <button id="markAllRead">Marcar todas</button>
                            </div>
                            <div class="notification-list" id="notificationList"></div>
                            <div class="notification-footer">
                                <a href="#" id="viewAllNotifications">Ver todas</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dashboard View -->
            <div id="dashboardView">
                <!-- Quick Actions -->
                <div class="quick-actions">
                    <div class="action-card" id="quickAddProduct">
                        <i class="fas fa-plus-circle"></i>
                        <span>Nuevo Producto</span>
                        <small>Agregar al inventario</small>
                    </div>
                    <div class="action-card" id="quickScanQR">
                        <i class="fas fa-qrcode"></i>
                        <span>Escanear QR</span>
                        <small>Buscar producto</small>
                    </div>
                    <div class="action-card" id="quickGenerateReport">
                        <i class="fas fa-file-pdf"></i>
                        <span>Generar Reporte</span>
                        <small>Exportar datos</small>
                    </div>
                    <div class="action-card" id="quickCheckStock">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>Ver Stock Bajo</span>
                        <small>Revisar alertas</small>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="dashboard-cards">
                    <div class="stat-card primary">
                        <div class="stat-icon">
                            <i class="fas fa-boxes"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Total Productos</div>
                            <div class="stat-value" id="totalProducts">0</div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+12% este mes</span>
                            </div>
                        </div>
                    </div>
                    <div class="stat-card success">
                        <div class="stat-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">En Stock</div>
                            <div class="stat-value" id="inStockCount">0</div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+8% vs ayer</span>
                            </div>
                        </div>
                    </div>
                    <div class="stat-card warning">
                        <div class="stat-icon">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Stock Bajo</div>
                            <div class="stat-value" id="lowStockCount">0</div>
                            <div class="stat-change negative">
                                <i class="fas fa-arrow-up"></i>
                                <span>+3 nuevos</span>
                            </div>
                        </div>
                    </div>
                    <div class="stat-card danger">
                        <div class="stat-icon">
                            <i class="fas fa-times-circle"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-label">Agotados</div>
                            <div class="stat-value" id="outOfStockCount">0</div>
                            <div class="stat-change">
                                <i class="fas fa-minus"></i>
                                <span>Sin cambios</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts -->
                <div class="charts-section">
                    <div class="chart-card">
                        <div class="chart-header">
                            <h5 class="chart-title">
                                <i class="fas fa-chart-pie"></i>
                                Distribución por Categoría
                            </h5>
                            <select class="chart-period" id="categoryPeriod">
                                <option value="all">Todos</option>
                                <option value="month">Este mes</option>
                                <option value="year">Este año</option>
                            </select>
                        </div>
                        <div class="chart-container">
                            <canvas id="categoryChart"></canvas>
                        </div>
                    </div>
                    <div class="chart-card">
                        <div class="chart-header">
                            <h5 class="chart-title">
                                <i class="fas fa-chart-line"></i>
                                Movimiento de Stock
                            </h5>
                            <select class="chart-period" id="movementPeriod">
                                <option value="7">7 días</option>
                                <option value="30">30 días</option>
                                <option value="90">90 días</option>
                            </select>
                        </div>
                        <div class="chart-container">
                            <canvas id="movementChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Recent Products -->
                <div class="table-container">
                    <div class="table-header">
                        <h5 class="table-title">
                            <i class="fas fa-clock"></i>
                            Productos Recientes
                        </h5>
                        <div class="table-actions">
                            <button class="btn btn-outline" id="refreshRecent">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Precio</th>
                                    <th>Stock</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="recentProductsTable"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Inventory View -->
            <div id="inventoryView" style="display: none;">
                <div class="table-container">
                    <div class="table-header">
                        <h5 class="table-title">
                            <i class="fas fa-boxes"></i>
                            Inventario Completo
                        </h5>
                        <div class="table-actions">
                            <button class="btn btn-success" id="importBtn">
                                <i class="fas fa-file-import"></i> Importar
                            </button>
                            <div class="position-relative">
                                <button class="btn btn-warning" id="exportDropdownBtn">
                                    <i class="fas fa-download"></i> Exportar
                                </button>
                                <div class="export-options" id="exportOptions" style="display: none;">
                                    <div class="export-option" data-format="pdf">
                                        <i class="fas fa-file-pdf"></i> PDF
                                    </div>
                                    <div class="export-option" data-format="excel">
                                        <i class="fas fa-file-excel"></i> Excel
                                    </div>
                                    <div class="export-option" data-format="csv">
                                        <i class="fas fa-file-csv"></i> CSV
                                    </div>
                                    <div class="export-option" data-format="json">
                                        <i class="fas fa-file-code"></i> JSON
                                    </div>
                                </div>
                            </div>
                            <button class="btn btn-primary" id="newProductBtn">
                                <i class="fas fa-plus"></i> Nuevo Producto
                            </button>
                        </div>
                    </div>

                    <!-- Filters -->
                    <div style="margin-bottom: 15px;">
                        <div class="form-row">
                            <div class="form-group">
                                <input type="text" class="form-control" id="inventorySearch" placeholder="Buscar productos...">
                            </div>
                            <div class="form-group">
                                <select class="form-control" id="inventoryCategoryFilter">
                                    <option value="all">Todas las categorías</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control" id="inventoryStatusFilter">
                                    <option value="all">Todos los estados</option>
                                    <option value="En stock">En stock</option>
                                    <option value="Stock bajo">Stock bajo</option>
                                    <option value="Stock crítico">Stock crítico</option>
                                    <option value="Agotado">Agotado</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-outline w-100" id="clearInventoryFilters">
                                    <i class="fas fa-times"></i> Limpiar
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Products Table -->
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Precio</th>
                                    <th>Stock</th>
                                    <th>Ubicación</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="inventoryTableBody"></tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="pagination-container">
                        <div class="pagination-info" id="inventoryPaginationInfo"></div>
                        <ul class="pagination" id="inventoryPagination"></ul>
                    </div>
                </div>
            </div>

            <!-- Suppliers View -->
            <div id="suppliersView" style="display: none;">
                <div class="table-container">
                    <div class="table-header">
                        <h5 class="table-title">
                            <i class="fas fa-truck"></i>
                            Proveedores
                        </h5>
                        <div class="table-actions">
                            <button class="btn btn-primary" id="newSupplierBtn">
                                <i class="fas fa-plus"></i> Nuevo Proveedor
                            </button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Contacto</th>
                                    <th>Teléfono</th>
                                    <th>Email</th>
                                    <th>Productos</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="suppliersTableBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Reports View -->
            <div id="reportsView" style="display: none;">
                <div class="charts-section">
                    <div class="chart-card">
                        <div class="chart-header">
                            <h5 class="chart-title">
                                <i class="fas fa-chart-bar"></i>
                                Valor por Categoría
                            </h5>
                        </div>
                        <div class="chart-container">
                            <canvas id="valueCategoryChart"></canvas>
                        </div>
                    </div>
                    <div class="chart-card">
                        <div class="chart-header">
                            <h5 class="chart-title">
                                <i class="fas fa-chart-line"></i>
                                Tendencia de Ventas
                            </h5>
                        </div>
                        <div class="chart-container">
                            <canvas id="salesTrendChart"></canvas>
                        </div>
                    </div>
                </div>

                <div class="quick-stats">
                    <div class="stat-card">
                        <div class="stat-value" id="reportTotalValue">$0</div>
                        <div class="stat-label">Valor Total</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" id="reportAvgPrice">$0</div>
                        <div class="stat-label">Precio Promedio</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" id="reportTotalItems">0</div>
                        <div class="stat-label">Total Items</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value" id="reportLowStock">0</div>
                        <div class="stat-label">Stock Bajo</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para producto -->
    <div class="modal-overlay" id="productModal">
        <div class="modal modal-lg">
            <div class="modal-header">
                <h5 id="productModalTitle">
                    <i class="fas fa-plus-circle"></i>
                    Nuevo Producto
                </h5>
                <button class="modal-close" onclick="closeModal('productModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="productForm">
                    <input type="hidden" id="productId">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Nombre del Producto *</label>
                            <input type="text" class="form-control" id="productName" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">SKU</label>
                            <input type="text" class="form-control" id="productSKU">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Categoría *</label>
                            <select class="form-control" id="productCategory" required>
                                <option value="">Seleccionar</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Proveedor</label>
                            <select class="form-control" id="productSupplier">
                                <option value="">Seleccionar</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Precio *</label>
                            <input type="number" class="form-control" id="productPrice" step="0.01" min="0" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Costo</label>
                            <input type="number" class="form-control" id="productCost" step="0.01" min="0">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Stock *</label>
                            <input type="number" class="form-control" id="productStock" min="0" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Stock Mínimo</label>
                            <input type="number" class="form-control" id="productMinStock" min="0" value="5">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Ubicación</label>
                            <select class="form-control" id="productLocation">
                                <option value="">Seleccionar</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Descripción</label>
                        <textarea class="form-control" id="productDescription" rows="2"></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Imagen URL</label>
                        <input type="url" class="form-control" id="productImage" placeholder="https://...">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="closeModal('productModal')">Cancelar</button>
                <button class="btn btn-primary" id="saveProduct">Guardar Producto</button>
            </div>
        </div>
    </div>

    <!-- Modal para proveedor -->
    <div class="modal-overlay" id="supplierModal">
        <div class="modal">
            <div class="modal-header">
                <h5 id="supplierModalTitle">
                    <i class="fas fa-truck"></i>
                    Nuevo Proveedor
                </h5>
                <button class="modal-close" onclick="closeModal('supplierModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="supplierForm">
                    <input type="hidden" id="supplierId">
                    
                    <div class="form-group">
                        <label class="form-label">Nombre *</label>
                        <input type="text" class="form-control" id="supplierName" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Contacto</label>
                        <input type="text" class="form-control" id="supplierContact">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Teléfono</label>
                            <input type="text" class="form-control" id="supplierPhone">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" id="supplierEmail">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Dirección</label>
                        <textarea class="form-control" id="supplierAddress" rows="2"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="closeModal('supplierModal')">Cancelar</button>
                <button class="btn btn-primary" id="saveSupplier">Guardar Proveedor</button>
            </div>
        </div>
    </div>

    <!-- Modal para QR -->
    <div class="modal-overlay" id="qrModal">
        <div class="modal modal-sm">
            <div class="modal-header">
                <h5>
                    <i class="fas fa-qrcode"></i>
                    Código QR
                </h5>
                <button class="modal-close" onclick="closeModal('qrModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="code-container">
                    <div id="qrcode"></div>
                    <p id="qrProductName" class="fw-bold mt-2"></p>
                    <div class="code-actions">
                        <button class="btn btn-primary" id="downloadQR">
                            <i class="fas fa-download"></i> Descargar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para código de barras -->
    <div class="modal-overlay" id="barcodeModal">
        <div class="modal modal-sm">
            <div class="modal-header">
                <h5>
                    <i class="fas fa-barcode"></i>
                    Código de Barras
                </h5>
                <button class="modal-close" onclick="closeModal('barcodeModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="code-container">
                    <svg id="barcode"></svg>
                    <p id="barcodeProductName" class="fw-bold mt-2"></p>
                    <div class="code-actions">
                        <button class="btn btn-success" id="downloadBarcode">
                            <i class="fas fa-download"></i> Descargar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Botón menú móvil -->
    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Toast container -->
    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============================================
        // CLASE PRINCIPAL DE GESTIÓN
        // ============================================
        class SmartStockManager {
            constructor() {
                this.products = JSON.parse(localStorage.getItem('products')) || [];
                this.suppliers = JSON.parse(localStorage.getItem('suppliers')) || [];
                this.categories = JSON.parse(localStorage.getItem('categories')) || ['Electrónicos', 'Ropa', 'Hogar', 'Deportes', 'Alimentos', 'Juguetes'];
                this.locations = JSON.parse(localStorage.getItem('locations')) || ['Almacén A', 'Almacén B', 'Tienda Central', 'Sucursal Norte'];
                this.notifications = JSON.parse(localStorage.getItem('notifications')) || [];
                this.currentPage = 1;
                this.itemsPerPage = 8;
                this.filteredProducts = [];
                this.charts = {};
                
                // Inicializar con datos de ejemplo si no hay productos
                if (this.products.length === 0) {
                    this.initializeSampleProducts();
                }
                
                // Inicializar con datos de ejemplo si no hay proveedores
                if (this.suppliers.length === 0) {
                    this.initializeSampleSuppliers();
                }
                
                // Inicializar productos filtrados
                this.filterProducts();
                
                // Verificar stock bajo para notificaciones
                this.checkStockAlerts();
            }

            // ============================================
            // DATOS DE EJEMPLO (50+ PRODUCTOS)
            // ============================================
            initializeSampleProducts() {
                this.products = [
                    // Electrónicos (15 productos)
                    { id: 'PRD-001', name: 'Laptop HP Pavilion 15', category: 'Electrónicos', price: 850.00, cost: 700.00, stock: 15, minStock: 5, location: 'Almacén A', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=HP', createdAt: '2024-01-15' },
                    { id: 'PRD-002', name: 'Smartphone Samsung Galaxy S23', category: 'Electrónicos', price: 899.99, cost: 750.00, stock: 8, minStock: 10, location: 'Tienda Central', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=S23', createdAt: '2024-01-20' },
                    { id: 'PRD-003', name: 'Tablet iPad Air', category: 'Electrónicos', price: 699.00, cost: 550.00, stock: 12, minStock: 5, location: 'Almacén A', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=iPad', createdAt: '2024-02-01' },
                    { id: 'PRD-004', name: 'Monitor LG 27" 4K', category: 'Electrónicos', price: 349.99, cost: 280.00, stock: 5, minStock: 3, location: 'Almacén B', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=LG', createdAt: '2024-02-05' },
                    { id: 'PRD-005', name: 'Auriculares Sony WH-1000XM4', category: 'Electrónicos', price: 299.99, cost: 220.00, stock: 20, minStock: 8, location: 'Tienda Central', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=Sony', createdAt: '2024-02-10' },
                    { id: 'PRD-006', name: 'Teclado Mecánico Logitech', category: 'Electrónicos', price: 89.99, cost: 60.00, stock: 25, minStock: 10, location: 'Almacén A', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=Logi', createdAt: '2024-02-12' },
                    { id: 'PRD-007', name: 'Mouse Inalámbrico Logitech', category: 'Electrónicos', price: 29.99, cost: 18.00, stock: 40, minStock: 15, location: 'Almacén A', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=Mouse', createdAt: '2024-02-15' },
                    { id: 'PRD-008', name: 'Disco Duro Externo 1TB', category: 'Electrónicos', price: 59.99, cost: 40.00, stock: 18, minStock: 8, location: 'Almacén B', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=HDD', createdAt: '2024-02-18' },
                    { id: 'PRD-009', name: 'Cámara Web Logitech C920', category: 'Electrónicos', price: 79.99, cost: 55.00, stock: 12, minStock: 5, location: 'Almacén A', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=Web', createdAt: '2024-02-20' },
                    { id: 'PRD-010', name: 'Router WiFi 6 TP-Link', category: 'Electrónicos', price: 129.99, cost: 90.00, stock: 7, minStock: 4, location: 'Almacén B', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=Router', createdAt: '2024-02-22' },
                    { id: 'PRD-011', name: 'Smart TV Samsung 55" 4K', category: 'Electrónicos', price: 699.99, cost: 550.00, stock: 4, minStock: 2, location: 'Almacén A', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=TV', createdAt: '2024-02-25' },
                    { id: 'PRD-012', name: 'Consola PS5', category: 'Electrónicos', price: 499.99, cost: 400.00, stock: 2, minStock: 3, location: 'Almacén A', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=PS5', createdAt: '2024-02-28' },
                    { id: 'PRD-013', name: 'Consola Xbox Series X', category: 'Electrónicos', price: 499.99, cost: 400.00, stock: 0, minStock: 3, location: 'Almacén A', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=Xbox', createdAt: '2024-03-01' },
                    { id: 'PRD-014', name: 'Nintendo Switch OLED', category: 'Electrónicos', price: 349.99, cost: 280.00, stock: 6, minStock: 4, location: 'Almacén A', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=Switch', createdAt: '2024-03-02' },
                    { id: 'PRD-015', name: 'Tablet Samsung Tab S9', category: 'Electrónicos', price: 799.99, cost: 650.00, stock: 3, minStock: 2, location: 'Tienda Central', supplier: 'SUP-001', image: 'https://via.placeholder.com/40?text=Tab', createdAt: '2024-03-03' },
                    
                    // Ropa (12 productos)
                    { id: 'PRD-016', name: 'Camiseta Algodón M/C', category: 'Ropa', price: 19.99, cost: 10.00, stock: 50, minStock: 20, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Camiseta', createdAt: '2024-01-10' },
                    { id: 'PRD-017', name: 'Jeans Hombre Slim Fit', category: 'Ropa', price: 39.99, cost: 22.00, stock: 35, minStock: 15, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Jeans', createdAt: '2024-01-12' },
                    { id: 'PRD-018', name: 'Vestido Mujer Floral', category: 'Ropa', price: 29.99, cost: 16.00, stock: 20, minStock: 10, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Vestido', createdAt: '2024-01-15' },
                    { id: 'PRD-019', name: 'Chaqueta de Cuero', category: 'Ropa', price: 89.99, cost: 55.00, stock: 8, minStock: 5, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Chaqueta', createdAt: '2024-01-18' },
                    { id: 'PRD-020', name: 'Sudadera con Capucha', category: 'Ropa', price: 34.99, cost: 20.00, stock: 25, minStock: 12, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Sudadera', createdAt: '2024-01-20' },
                    { id: 'PRD-021', name: 'Pantalón Deportivo', category: 'Ropa', price: 24.99, cost: 14.00, stock: 30, minStock: 15, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Pantalon', createdAt: '2024-01-22' },
                    { id: 'PRD-022', name: 'Zapatos Casuales Hombre', category: 'Ropa', price: 49.99, cost: 30.00, stock: 18, minStock: 8, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Zapatos', createdAt: '2024-01-25' },
                    { id: 'PRD-023', name: 'Botas de Invierno', category: 'Ropa', price: 79.99, cost: 50.00, stock: 10, minStock: 5, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Botas', createdAt: '2024-01-28' },
                    { id: 'PRD-024', name: 'Gorra Deportiva', category: 'Ropa', price: 14.99, cost: 8.00, stock: 45, minStock: 20, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Gorra', createdAt: '2024-02-01' },
                    { id: 'PRD-025', name: 'Bufanda de Lana', category: 'Ropa', price: 12.99, cost: 6.00, stock: 28, minStock: 12, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Bufanda', createdAt: '2024-02-05' },
                    { id: 'PRD-026', name: 'Guantes de Invierno', category: 'Ropa', price: 9.99, cost: 5.00, stock: 32, minStock: 15, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Guantes', createdAt: '2024-02-08' },
                    { id: 'PRD-027', name: 'Calcetines (Pack 3)', category: 'Ropa', price: 8.99, cost: 4.00, stock: 60, minStock: 25, location: 'Almacén B', supplier: 'SUP-003', image: 'https://via.placeholder.com/40?text=Calcetines', createdAt: '2024-02-10' },
                    
                    // Hogar (12 productos)
                    { id: 'PRD-028', name: 'Silla de Oficina Ergonómica', category: 'Hogar', price: 149.99, cost: 100.00, stock: 8, minStock: 4, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Silla', createdAt: '2024-01-05' },
                    { id: 'PRD-029', name: 'Mesa de Centro', category: 'Hogar', price: 89.99, cost: 55.00, stock: 6, minStock: 3, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Mesa', createdAt: '2024-01-08' },
                    { id: 'PRD-030', name: 'Lámpara de Pie', category: 'Hogar', price: 39.99, cost: 22.00, stock: 12, minStock: 5, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Lampara', createdAt: '2024-01-12' },
                    { id: 'PRD-031', name: 'Juego de Sábanas', category: 'Hogar', price: 29.99, cost: 16.00, stock: 25, minStock: 10, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Sabanas', createdAt: '2024-01-15' },
                    { id: 'PRD-032', name: 'Cojines Decorativos (2 uds)', category: 'Hogar', price: 19.99, cost: 10.00, stock: 30, minStock: 12, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Cojines', createdAt: '2024-01-18' },
                    { id: 'PRD-033', name: 'Cortinas Blackout', category: 'Hogar', price: 34.99, cost: 20.00, stock: 15, minStock: 6, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Cortinas', createdAt: '2024-01-20' },
                    { id: 'PRD-034', name: 'Juego de Toallas', category: 'Hogar', price: 24.99, cost: 14.00, stock: 22, minStock: 8, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Toallas', createdAt: '2024-01-22' },
                    { id: 'PRD-035', name: 'Set de Cocina (5 piezas)', category: 'Hogar', price: 44.99, cost: 28.00, stock: 14, minStock: 6, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Cocina', createdAt: '2024-01-25' },
                    { id: 'PRD-036', name: 'Organizador de Escritorio', category: 'Hogar', price: 14.99, cost: 8.00, stock: 28, minStock: 12, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Organizador', createdAt: '2024-01-28' },
                    { id: 'PRD-037', name: 'Espejo de Pared', category: 'Hogar', price: 39.99, cost: 22.00, stock: 9, minStock: 4, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Espejo', createdAt: '2024-02-01' },
                    { id: 'PRD-038', name: 'Alfombra Moderna', category: 'Hogar', price: 59.99, cost: 35.00, stock: 7, minStock: 3, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Alfombra', createdAt: '2024-02-05' },
                    { id: 'PRD-039', name: 'Estantería 5 niveles', category: 'Hogar', price: 79.99, cost: 48.00, stock: 5, minStock: 2, location: 'Almacén A', supplier: 'SUP-004', image: 'https://via.placeholder.com/40?text=Estanteria', createdAt: '2024-02-08' },
                    
                    // Deportes (11 productos)
                    { id: 'PRD-040', name: 'Zapatillas Running Nike', category: 'Deportes', price: 89.99, cost: 60.00, stock: 14, minStock: 6, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Nike', createdAt: '2024-01-05' },
                    { id: 'PRD-041', name: 'Balón de Fútbol Profesional', category: 'Deportes', price: 29.99, cost: 18.00, stock: 22, minStock: 10, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Futbol', createdAt: '2024-01-08' },
                    { id: 'PRD-042', name: 'Raqueta de Tenis', category: 'Deportes', price: 49.99, cost: 32.00, stock: 12, minStock: 5, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Tenis', createdAt: '2024-01-12' },
                    { id: 'PRD-043', name: 'Pesas 2kg (Par)', category: 'Deportes', price: 19.99, cost: 12.00, stock: 35, minStock: 15, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Pesas', createdAt: '2024-01-15' },
                    { id: 'PRD-044', name: 'Esterilla de Yoga', category: 'Deportes', price: 14.99, cost: 8.00, stock: 28, minStock: 12, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Yoga', createdAt: '2024-01-18' },
                    { id: 'PRD-045', name: 'Bicicleta Estática', category: 'Deportes', price: 249.99, cost: 180.00, stock: 4, minStock: 2, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Bici', createdAt: '2024-01-20' },
                    { id: 'PRD-046', name: 'Cinta de Correr', category: 'Deportes', price: 399.99, cost: 300.00, stock: 2, minStock: 1, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Cinta', createdAt: '2024-01-22' },
                    { id: 'PRD-047', name: 'Kit de Boxeo', category: 'Deportes', price: 59.99, cost: 40.00, stock: 8, minStock: 4, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Boxeo', createdAt: '2024-01-25' },
                    { id: 'PRD-048', name: 'Guantes de Boxeo', category: 'Deportes', price: 24.99, cost: 15.00, stock: 15, minStock: 6, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Guantes', createdAt: '2024-01-28' },
                    { id: 'PRD-049', name: 'Rodilleras Deportivas', category: 'Deportes', price: 12.99, cost: 7.00, stock: 20, minStock: 8, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Rodilleras', createdAt: '2024-02-01' },
                    { id: 'PRD-050', name: 'Botella de Agua Deportiva', category: 'Deportes', price: 8.99, cost: 4.00, stock: 45, minStock: 20, location: 'Sucursal Norte', supplier: 'SUP-002', image: 'https://via.placeholder.com/40?text=Botella', createdAt: '2024-02-05' },
                    
                    // Alimentos (5 productos)
                    { id: 'PRD-051', name: 'Café Molido Premium 500g', category: 'Alimentos', price: 12.99, cost: 8.00, stock: 30, minStock: 15, location: 'Almacén B', supplier: 'SUP-005', image: 'https://via.placeholder.com/40?text=Cafe', createdAt: '2024-02-10' },
                    { id: 'PRD-052', name: 'Aceite de Oliva 1L', category: 'Alimentos', price: 9.99, cost: 6.00, stock: 25, minStock: 12, location: 'Almacén B', supplier: 'SUP-005', image: 'https://via.placeholder.com/40?text=Oliva', createdAt: '2024-02-12' },
                    { id: 'PRD-053', name: 'Arroz Integral 5kg', category: 'Alimentos', price: 7.99, cost: 5.00, stock: 40, minStock: 20, location: 'Almacén B', supplier: 'SUP-005', image: 'https://via.placeholder.com/40?text=Arroz', createdAt: '2024-02-15' },
                    { id: 'PRD-054', name: 'Lentejas 1kg', category: 'Alimentos', price: 2.99, cost: 1.80, stock: 55, minStock: 25, location: 'Almacén B', supplier: 'SUP-005', image: 'https://via.placeholder.com/40?text=Lentejas', createdAt: '2024-02-18' },
                    { id: 'PRD-055', name: 'Miel Pura 500g', category: 'Alimentos', price: 6.99, cost: 4.00, stock: 22, minStock: 10, location: 'Almacén B', supplier: 'SUP-005', image: 'https://via.placeholder.com/40?text=Miel', createdAt: '2024-02-20' }
                ];
                
                this.saveProducts();
            }

            initializeSampleSuppliers() {
                this.suppliers = [
                    { id: 'SUP-001', name: 'TecnoImport S.A.', contact: 'Juan Pérez', phone: '+123456789', email: 'juan@tecnoimport.com', address: 'Av. Tecnología 123' },
                    { id: 'SUP-002', name: 'DeportesMax', contact: 'María García', phone: '+987654321', email: 'maria@deportesmax.com', address: 'Calle Deportiva 456' },
                    { id: 'SUP-003', name: 'Textiles del Norte', contact: 'Carlos Rodríguez', phone: '+456123789', email: 'carlos@textiles.com', address: 'Zona Industrial Norte' },
                    { id: 'SUP-004', name: 'Hogar y Más', contact: 'Ana Martínez', phone: '+789456123', email: 'ana@hogarymas.com', address: 'Centro Comercial Plaza' },
                    { id: 'SUP-005', name: 'Alimentos Naturales', contact: 'Roberto Sánchez', phone: '+321654987', email: 'roberto@alimentos.com', address: 'Av. Salud 789' }
                ];
                this.saveSuppliers();
            }

            // ============================================
            // MÉTODOS DE UTILIDAD
            // ============================================
            generateId(prefix) {
                const items = prefix === 'PRD' ? this.products : this.suppliers;
                const lastId = items.length > 0 ? Math.max(...items.map(i => parseInt(i.id.split('-')[1]))) : 0;
                return `${prefix}-${String(lastId + 1).padStart(3, '0')}`;
            }

            saveProducts() {
                localStorage.setItem('products', JSON.stringify(this.products));
            }

            saveSuppliers() {
                localStorage.setItem('suppliers', JSON.stringify(this.suppliers));
            }

            saveCategories() {
                localStorage.setItem('categories', JSON.stringify(this.categories));
            }

            saveLocations() {
                localStorage.setItem('locations', JSON.stringify(this.locations));
            }

            saveNotifications() {
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
            }

            getProductStatus(stock, minStock) {
                if (stock === 0) return 'Agotado';
                if (stock <= minStock * 0.2) return 'Stock crítico';
                if (stock <= minStock) return 'Stock bajo';
                return 'En stock';
            }

            getStatusClass(status) {
                switch(status) {
                    case 'En stock': return 'badge-success';
                    case 'Stock bajo': return 'badge-warning';
                    case 'Stock crítico': return 'badge-danger';
                    case 'Agotado': return 'badge-danger';
                    default: return 'badge-info';
                }
            }

            getStockIndicator(stock, minStock) {
                if (stock === 0) return 'stock-critical';
                if (stock <= minStock * 0.2) return 'stock-critical';
                if (stock <= minStock) return 'stock-low';
                if (stock <= minStock * 2) return 'stock-good';
                return 'stock-normal';
            }

            // ============================================
            // NOTIFICACIONES
            // ============================================
            checkStockAlerts() {
                this.products.forEach(product => {
                    const status = this.getProductStatus(product.stock, product.minStock);
                    if (status !== 'En stock') {
                        const existingAlert = this.notifications.find(n => 
                            n.productId === product.id && n.type === 'stock' && !n.read
                        );
                        
                        if (!existingAlert) {
                            this.addNotification({
                                title: 'Alerta de Stock',
                                message: `${product.name} tiene stock ${status.toLowerCase()}`,
                                type: 'stock',
                                productId: product.id
                            });
                        }
                    }
                });
            }

            addNotification(notification) {
                const newNotification = {
                    id: this.notifications.length + 1,
                    ...notification,
                    time: new Date().toLocaleString(),
                    read: false
                };
                this.notifications.unshift(newNotification);
                
                // Limitar a 20 notificaciones
                if (this.notifications.length > 20) {
                    this.notifications = this.notifications.slice(0, 20);
                }
                
                this.saveNotifications();
                this.showNotification(notification.message, notification.type === 'stock' ? 'warning' : 'info');
            }

            markNotificationAsRead(id) {
                const notification = this.notifications.find(n => n.id === id);
                if (notification) {
                    notification.read = true;
                    this.saveNotifications();
                }
            }

            markAllNotificationsAsRead() {
                this.notifications.forEach(n => n.read = true);
                this.saveNotifications();
            }

            getUnreadCount() {
                return this.notifications.filter(n => !n.read).length;
            }

            // ============================================
            // PRODUCTOS
            // ============================================
            addProduct(product) {
                product.id = this.generateId('PRD');
                product.createdAt = new Date().toISOString().split('T')[0];
                this.products.push(product);
                this.saveProducts();
                this.filterProducts();
                this.checkStockAlerts();
                return product.id;
            }

            updateProduct(id, updatedProduct) {
                const index = this.products.findIndex(p => p.id === id);
                if (index !== -1) {
                    this.products[index] = { ...updatedProduct, id, createdAt: this.products[index].createdAt };
                    this.saveProducts();
                    this.filterProducts();
                    this.checkStockAlerts();
                    return true;
                }
                return false;
            }

            deleteProduct(id) {
                const index = this.products.findIndex(p => p.id === id);
                if (index !== -1) {
                    this.products.splice(index, 1);
                    this.saveProducts();
                    this.filterProducts();
                    this.showNotification('Producto eliminado', 'success');
                    return true;
                }
                return false;
            }

            getProductById(id) {
                return this.products.find(p => p.id === id);
            }

            filterProducts(search = '', category = 'all', status = 'all') {
                this.filteredProducts = this.products.filter(product => {
                    const matchesSearch = search === '' || 
                        product.name.toLowerCase().includes(search.toLowerCase()) ||
                        product.id.toLowerCase().includes(search.toLowerCase());
                    
                    const matchesCategory = category === 'all' || product.category === category;
                    
                    let matchesStatus = true;
                    if (status !== 'all') {
                        const productStatus = this.getProductStatus(product.stock, product.minStock);
                        matchesStatus = productStatus === status;
                    }
                    
                    return matchesSearch && matchesCategory && matchesStatus;
                });
                
                return this.filteredProducts;
            }

            getPaginatedProducts(page = this.currentPage) {
                const start = (page - 1) * this.itemsPerPage;
                return this.filteredProducts.slice(start, start + this.itemsPerPage);
            }

            getTotalPages() {
                return Math.ceil(this.filteredProducts.length / this.itemsPerPage);
            }

            getRecentProducts(limit = 5) {
                return [...this.products]
                    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
                    .slice(0, limit);
            }

            // ============================================
            // PROVEEDORES
            // ============================================
            addSupplier(supplier) {
                supplier.id = this.generateId('SUP');
                this.suppliers.push(supplier);
                this.saveSuppliers();
                this.showNotification('Proveedor agregado', 'success');
                return supplier.id;
            }

            updateSupplier(id, updatedSupplier) {
                const index = this.suppliers.findIndex(s => s.id === id);
                if (index !== -1) {
                    this.suppliers[index] = { ...updatedSupplier, id };
                    this.saveSuppliers();
                    this.showNotification('Proveedor actualizado', 'success');
                    return true;
                }
                return false;
            }

            deleteSupplier(id) {
                const index = this.suppliers.findIndex(s => s.id === id);
                if (index !== -1) {
                    this.suppliers.splice(index, 1);
                    this.saveSuppliers();
                    this.showNotification('Proveedor eliminado', 'success');
                    return true;
                }
                return false;
            }

            getSupplierById(id) {
                return this.suppliers.find(s => s.id === id);
            }

            getSupplierName(id) {
                const supplier = this.getSupplierById(id);
                return supplier ? supplier.name : 'No asignado';
            }

            // ============================================
            // ESTADÍSTICAS
            // ============================================
            getStats() {
                const total = this.products.length;
                let inStock = 0, lowStock = 0, outOfStock = 0;
                let totalValue = 0;

                this.products.forEach(p => {
                    const status = this.getProductStatus(p.stock, p.minStock);
                    if (status === 'En stock') inStock++;
                    else if (status === 'Stock bajo' || status === 'Stock crítico') lowStock++;
                    else if (status === 'Agotado') outOfStock++;
                    
                    totalValue += p.price * p.stock;
                });

                return {
                    total,
                    inStock,
                    lowStock,
                    outOfStock,
                    totalValue,
                    avgPrice: total > 0 ? totalValue / total : 0,
                    categories: [...new Set(this.products.map(p => p.category))].length,
                    suppliers: this.suppliers.length
                };
            }

            getCategoryData() {
                const data = {};
                this.products.forEach(p => {
                    data[p.category] = (data[p.category] || 0) + 1;
                });
                return {
                    labels: Object.keys(data),
                    values: Object.values(data)
                };
            }

            getCategoryValueData() {
                const data = {};
                this.products.forEach(p => {
                    data[p.category] = (data[p.category] || 0) + (p.price * p.stock);
                });
                return {
                    labels: Object.keys(data),
                    values: Object.values(data)
                };
            }

            getMovementData(days = 7) {
                // Simular datos de movimiento
                const labels = [];
                const entradas = [];
                const salidas = [];

                for (let i = days - 1; i >= 0; i--) {
                    const date = new Date();
                    date.setDate(date.getDate() - i);
                    labels.push(`${date.getDate()}/${date.getMonth() + 1}`);
                    
                    entradas.push(Math.floor(Math.random() * 15) + 5);
                    salidas.push(Math.floor(Math.random() * 12) + 3);
                }

                return { labels, entradas, salidas };
            }

            // ============================================
            // UI
            // ============================================
            showNotification(message, type = 'info') {
                const container = document.getElementById('toastContainer');
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                
                const icons = {
                    success: 'fa-check-circle',
                    error: 'fa-exclamation-circle',
                    warning: 'fa-exclamation-triangle',
                    info: 'fa-info-circle'
                };

                toast.innerHTML = `
                    <i class="fas ${icons[type] || icons.info}"></i>
                    <div class="toast-content">
                        <div class="toast-title">${type.charAt(0).toUpperCase() + type.slice(1)}</div>
                        <div class="toast-message">${message}</div>
                    </div>
                `;

                container.appendChild(toast);

                setTimeout(() => {
                    toast.style.animation = 'slideOutRight 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }

            toggleTheme() {
                document.body.classList.toggle('dark-mode');
                const icon = document.querySelector('#themeToggle i');
                
                // Luna = modo oscuro, Sol = modo claro
                if (document.body.classList.contains('dark-mode')) {
                    icon.className = 'fas fa-sun'; // Sol para modo oscuro (cambia a claro)
                } else {
                    icon.className = 'fas fa-moon'; // Luna para modo claro (cambia a oscuro)
                }
                
                localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
                this.updateCharts();
            }

            toggleSidebar() {
                const sidebar = document.getElementById('sidebar');
                const mainContent = document.getElementById('mainContent');
                const toggleIcon = document.querySelector('#sidebarToggle i');
                
                sidebar.classList.toggle('collapsed');
                mainContent.classList.toggle('expanded');
                
                if (sidebar.classList.contains('collapsed')) {
                    toggleIcon.className = 'fas fa-chevron-right';
                } else {
                    toggleIcon.className = 'fas fa-chevron-left';
                }
            }
        }

        // ============================================
        // INSTANCIA GLOBAL
        // ============================================
        const app = new SmartStockManager();

        // ============================================
        // FUNCIONES DE RENDERIZADO
        // ============================================
        function renderDashboard() {
            const stats = app.getStats();
            
            document.getElementById('totalProducts').textContent = stats.total;
            document.getElementById('inStockCount').textContent = stats.inStock;
            document.getElementById('lowStockCount').textContent = stats.lowStock;
            document.getElementById('outOfStockCount').textContent = stats.outOfStock;

            // Productos recientes
            const recentProducts = app.getRecentProducts(5);
            const tbody = document.getElementById('recentProductsTable');
            tbody.innerHTML = '';

            if (recentProducts.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="6" class="text-center empty-state">
                            <i class="fas fa-box-open"></i>
                            <p>No hay productos recientes</p>
                        </td>
                    </tr>
                `;
            } else {
                recentProducts.forEach(product => {
                    const status = app.getProductStatus(product.stock, product.minStock);
                    const statusClass = app.getStatusClass(status);
                    const indicator = app.getStockIndicator(product.stock, product.minStock);

                    tbody.innerHTML += `
                        <tr>
                            <td>
                                <div class="product-info">
                                    <img src="${product.image || 'https://via.placeholder.com/40'}" class="product-thumb" onerror="this.src='https://via.placeholder.com/40'">
                                    <span>${product.name}</span>
                                </div>
                            </td>
                            <td>${product.category}</td>
                            <td>$${product.price.toFixed(2)}</td>
                            <td>
                                <span class="stock-indicator ${indicator}"></span>
                                ${product.stock}
                            </td>
                            <td><span class="badge ${statusClass}">${status}</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="icon-btn view" onclick="viewProduct('${product.id}')" data-tooltip="Ver">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="icon-btn edit" onclick="editProduct('${product.id}')" data-tooltip="Editar">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            }

            updateCharts();
        }

        function renderInventory() {
            const search = document.getElementById('inventorySearch')?.value || '';
            const category = document.getElementById('inventoryCategoryFilter')?.value || 'all';
            const status = document.getElementById('inventoryStatusFilter')?.value || 'all';
            
            app.filterProducts(search, category, status);
            
            const products = app.getPaginatedProducts(app.currentPage);
            const tbody = document.getElementById('inventoryTableBody');
            tbody.innerHTML = '';

            if (products.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="8" class="text-center empty-state">
                            <i class="fas fa-box-open"></i>
                            <p>No se encontraron productos</p>
                        </td>
                    </tr>
                `;
            } else {
                products.forEach(product => {
                    const productStatus = app.getProductStatus(product.stock, product.minStock);
                    const statusClass = app.getStatusClass(productStatus);
                    const indicator = app.getStockIndicator(product.stock, product.minStock);

                    tbody.innerHTML += `
                        <tr>
                            <td><span class="badge badge-info">${product.id}</span></td>
                            <td>
                                <div class="product-info">
                                    <img src="${product.image || 'https://via.placeholder.com/40'}" class="product-thumb" onerror="this.src='https://via.placeholder.com/40'">
                                    <span>${product.name}</span>
                                </div>
                            </td>
                            <td>${product.category}</td>
                            <td>$${product.price.toFixed(2)}</td>
                            <td>
                                <span class="stock-indicator ${indicator}"></span>
                                ${product.stock}
                            </td>
                            <td>${product.location || 'N/A'}</td>
                            <td><span class="badge ${statusClass}">${productStatus}</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="icon-btn view" onclick="viewProduct('${product.id}')" data-tooltip="Ver">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="icon-btn edit" onclick="editProduct('${product.id}')" data-tooltip="Editar">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="icon-btn qr" onclick="showQR('${product.id}')" data-tooltip="QR">
                                        <i class="fas fa-qrcode"></i>
                                    </button>
                                    <button class="icon-btn delete" onclick="deleteProduct('${product.id}')" data-tooltip="Eliminar">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            }

            renderInventoryPagination();
        }

        function renderSuppliers() {
            const tbody = document.getElementById('suppliersTableBody');
            tbody.innerHTML = '';

            if (app.suppliers.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="7" class="text-center empty-state">
                            <i class="fas fa-truck"></i>
                            <p>No hay proveedores registrados</p>
                        </td>
                    </tr>
                `;
            } else {
                app.suppliers.forEach(supplier => {
                    const productCount = app.products.filter(p => p.supplier === supplier.id).length;

                    tbody.innerHTML += `
                        <tr>
                            <td><span class="badge badge-info">${supplier.id}</span></td>
                            <td>${supplier.name}</td>
                            <td>${supplier.contact || '-'}</td>
                            <td>${supplier.phone || '-'}</td>
                            <td>${supplier.email || '-'}</td>
                            <td><span class="badge badge-success">${productCount}</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="icon-btn edit" onclick="editSupplier('${supplier.id}')" data-tooltip="Editar">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="icon-btn delete" onclick="deleteSupplier('${supplier.id}')" data-tooltip="Eliminar">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            }
        }

        function renderNotifications() {
            const list = document.getElementById('notificationList');
            const count = document.getElementById('notificationCount');

            count.textContent = app.getUnreadCount();

            list.innerHTML = '';
            if (app.notifications.length === 0) {
                list.innerHTML = '<div class="notification-item">No hay notificaciones</div>';
            } else {
                app.notifications.slice(0, 5).forEach(n => {
                    list.innerHTML += `
                        <div class="notification-item ${n.read ? '' : 'unread'}" onclick="markNotificationRead(${n.id})">
                            <strong>${n.title}</strong>
                            <p>${n.message}</p>
                            <small>${n.time}</small>
                        </div>
                    `;
                });
            }
        }

        function renderInventoryPagination() {
            const totalPages = app.getTotalPages();
            const currentPage = app.currentPage;
            const pagination = document.getElementById('inventoryPagination');
            const info = document.getElementById('inventoryPaginationInfo');

            info.textContent = `Página ${currentPage} de ${totalPages || 1}`;

            pagination.innerHTML = '';

            // Botón anterior
            pagination.innerHTML += `
                <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                    <a class="page-link" onclick="changeInventoryPage(${currentPage - 1})">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                </li>
            `;

            // Números de página
            const startPage = Math.max(1, currentPage - 2);
            const endPage = Math.min(totalPages, startPage + 4);

            for (let i = startPage; i <= endPage; i++) {
                pagination.innerHTML += `
                    <li class="page-item ${currentPage === i ? 'active' : ''}">
                        <a class="page-link" onclick="changeInventoryPage(${i})">${i}</a>
                    </li>
                `;
            }

            // Botón siguiente
            pagination.innerHTML += `
                <li class="page-item ${currentPage === totalPages || totalPages === 0 ? 'disabled' : ''}">
                    <a class="page-link" onclick="changeInventoryPage(${currentPage + 1})">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                </li>
            `;
        }

        function updateCharts() {
            // Gráfico de categorías
            const categoryData = app.getCategoryData();
            const categoryCtx = document.getElementById('categoryChart')?.getContext('2d');
            
            if (categoryCtx) {
                if (app.charts.category) app.charts.category.destroy();
                
                app.charts.category = new Chart(categoryCtx, {
                    type: 'doughnut',
                    data: {
                        labels: categoryData.labels,
                        datasets: [{
                            data: categoryData.values,
                            backgroundColor: ['#3a5ec7', '#28a745', '#ffc107', '#dc3545', '#6f42c1', '#17a2b8', '#fd7e14'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { 
                                position: 'bottom',
                                labels: { color: getComputedStyle(document.body).getPropertyValue('--text-primary') }
                            }
                        }
                    }
                });
            }

            // Gráfico de movimientos
            const movementData = app.getMovementData(7);
            const movementCtx = document.getElementById('movementChart')?.getContext('2d');
            
            if (movementCtx) {
                if (app.charts.movement) app.charts.movement.destroy();
                
                app.charts.movement = new Chart(movementCtx, {
                    type: 'line',
                    data: {
                        labels: movementData.labels,
                        datasets: [
                            {
                                label: 'Entradas',
                                data: movementData.entradas,
                                borderColor: '#28a745',
                                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                                fill: true,
                                tension: 0.4
                            },
                            {
                                label: 'Salidas',
                                data: movementData.salidas,
                                borderColor: '#dc3545',
                                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                                fill: true,
                                tension: 0.4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: { color: 'rgba(128,128,128,0.1)' },
                                ticks: { color: getComputedStyle(document.body).getPropertyValue('--text-primary') }
                            },
                            x: {
                                grid: { display: false },
                                ticks: { color: getComputedStyle(document.body).getPropertyValue('--text-primary') }
                            }
                        },
                        plugins: {
                            legend: { 
                                labels: { color: getComputedStyle(document.body).getPropertyValue('--text-primary') }
                            }
                        }
                    }
                });
            }

            // Gráfico de valor por categoría
            const valueData = app.getCategoryValueData();
            const valueCtx = document.getElementById('valueCategoryChart')?.getContext('2d');
            
            if (valueCtx) {
                if (app.charts.value) app.charts.value.destroy();
                
                app.charts.value = new Chart(valueCtx, {
                    type: 'bar',
                    data: {
                        labels: valueData.labels,
                        datasets: [{
                            label: 'Valor ($)',
                            data: valueData.values,
                            backgroundColor: '#3a5ec7'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: { 
                                    callback: value => '$' + value.toLocaleString(),
                                    color: getComputedStyle(document.body).getPropertyValue('--text-primary')
                                }
                            },
                            x: {
                                ticks: { color: getComputedStyle(document.body).getPropertyValue('--text-primary') }
                            }
                        },
                        plugins: {
                            legend: { display: false }
                        }
                    }
                });
            }

            // Actualizar stats de reportes
            const stats = app.getStats();
            document.getElementById('reportTotalValue').textContent = '$' + stats.totalValue.toFixed(2);
            document.getElementById('reportAvgPrice').textContent = '$' + stats.avgPrice.toFixed(2);
            document.getElementById('reportTotalItems').textContent = stats.total;
            document.getElementById('reportLowStock').textContent = stats.lowStock;
        }

        // ============================================
        // FUNCIONES DE NAVEGACIÓN
        // ============================================
        function showView(view) {
            document.getElementById('dashboardView').style.display = 'none';
            document.getElementById('inventoryView').style.display = 'none';
            document.getElementById('suppliersView').style.display = 'none';
            document.getElementById('reportsView').style.display = 'none';
            
            document.getElementById(`${view}View`).style.display = 'block';
            
            const titles = {
                dashboard: 'Dashboard',
                inventory: 'Inventario',
                suppliers: 'Proveedores',
                reports: 'Reportes'
            };
            
            document.getElementById('pageTitle').innerHTML = `
                <i class="fas fa-${view === 'dashboard' ? 'home' : view === 'inventory' ? 'boxes' : view === 'suppliers' ? 'truck' : 'chart-line'}"></i>
                ${titles[view]}
            `;

            // Renderizar según la vista
            if (view === 'dashboard') {
                renderDashboard();
            } else if (view === 'inventory') {
                renderInventory();
            } else if (view === 'suppliers') {
                renderSuppliers();
            } else if (view === 'reports') {
                updateCharts();
            }

            // Actualizar clases activas
            document.querySelectorAll('.sidebar-menu a').forEach(link => {
                link.classList.remove('active');
                if (link.id === `${view}Link`) {
                    link.classList.add('active');
                }
            });

            // Cerrar sidebar en móvil
            if (window.innerWidth <= 992) {
                document.getElementById('sidebar').classList.remove('open');
            }
        }

        // ============================================
        // FUNCIONES DE PRODUCTOS
        // ============================================
        function openProductModal(mode = 'add', productId = null) {
            const modal = document.getElementById('productModal');
            const title = document.getElementById('productModalTitle');
            
            if (mode === 'add') {
                title.innerHTML = '<i class="fas fa-plus-circle"></i> Nuevo Producto';
                document.getElementById('productForm').reset();
                document.getElementById('productId').value = '';
                document.getElementById('productMinStock').value = '5';
            } else {
                title.innerHTML = '<i class="fas fa-edit"></i> Editar Producto';
                const product = app.getProductById(productId);
                if (product) {
                    document.getElementById('productId').value = product.id;
                    document.getElementById('productName').value = product.name;
                    document.getElementById('productSKU').value = product.sku || '';
                    document.getElementById('productCategory').value = product.category;
                    document.getElementById('productPrice').value = product.price;
                    document.getElementById('productCost').value = product.cost || '';
                    document.getElementById('productStock').value = product.stock;
                    document.getElementById('productMinStock').value = product.minStock || 5;
                    document.getElementById('productLocation').value = product.location || '';
                    document.getElementById('productDescription').value = product.description || '';
                    document.getElementById('productImage').value = product.image || '';
                    document.getElementById('productSupplier').value = product.supplier || '';
                }
            }
            
            modal.classList.add('show');
        }

        function saveProduct() {
            const productId = document.getElementById('productId').value;
            const product = {
                name: document.getElementById('productName').value,
                sku: document.getElementById('productSKU').value,
                category: document.getElementById('productCategory').value,
                price: parseFloat(document.getElementById('productPrice').value),
                cost: parseFloat(document.getElementById('productCost').value) || 0,
                stock: parseInt(document.getElementById('productStock').value),
                minStock: parseInt(document.getElementById('productMinStock').value) || 5,
                location: document.getElementById('productLocation').value,
                supplier: document.getElementById('productSupplier').value,
                description: document.getElementById('productDescription').value,
                image: document.getElementById('productImage').value
            };

            if (!product.category || !product.name || !product.price || product.stock === undefined) {
                app.showNotification('Completa los campos obligatorios', 'error');
                return;
            }

            if (productId) {
                app.updateProduct(productId, product);
                app.showNotification('Producto actualizado', 'success');
            } else {
                app.addProduct(product);
                app.showNotification('Producto agregado', 'success');
            }

            closeModal('productModal');
            
            // Actualizar vistas
            renderDashboard();
            renderInventory();
        }

        function viewProduct(id) {
            const product = app.getProductById(id);
            if (!product) return;

            const status = app.getProductStatus(product.stock, product.minStock);
            app.showNotification(`${product.name} - Stock: ${product.stock} - Estado: ${status}`, 'info');
        }

        function editProduct(id) {
            openProductModal('edit', id);
        }

        function deleteProduct(id) {
            if (confirm('¿Eliminar este producto?')) {
                app.deleteProduct(id);
                renderDashboard();
                renderInventory();
            }
        }

        // ============================================
        // FUNCIONES DE PROVEEDORES
        // ============================================
        function openSupplierModal(mode = 'add', supplierId = null) {
            const modal = document.getElementById('supplierModal');
            const title = document.getElementById('supplierModalTitle');
            
            if (mode === 'add') {
                title.innerHTML = '<i class="fas fa-truck"></i> Nuevo Proveedor';
                document.getElementById('supplierForm').reset();
                document.getElementById('supplierId').value = '';
            } else {
                title.innerHTML = '<i class="fas fa-edit"></i> Editar Proveedor';
                const supplier = app.getSupplierById(supplierId);
                if (supplier) {
                    document.getElementById('supplierId').value = supplier.id;
                    document.getElementById('supplierName').value = supplier.name;
                    document.getElementById('supplierContact').value = supplier.contact || '';
                    document.getElementById('supplierPhone').value = supplier.phone || '';
                    document.getElementById('supplierEmail').value = supplier.email || '';
                    document.getElementById('supplierAddress').value = supplier.address || '';
                }
            }
            
            modal.classList.add('show');
        }

        function saveSupplier() {
            const supplierId = document.getElementById('supplierId').value;
            const supplier = {
                name: document.getElementById('supplierName').value,
                contact: document.getElementById('supplierContact').value,
                phone: document.getElementById('supplierPhone').value,
                email: document.getElementById('supplierEmail').value,
                address: document.getElementById('supplierAddress').value
            };

            if (!supplier.name) {
                app.showNotification('El nombre del proveedor es obligatorio', 'error');
                return;
            }

            if (supplierId) {
                app.updateSupplier(supplierId, supplier);
            } else {
                app.addSupplier(supplier);
            }

            closeModal('supplierModal');
            renderSuppliers();
        }

        function editSupplier(id) {
            openSupplierModal('edit', id);
        }

        function deleteSupplier(id) {
            const productCount = app.products.filter(p => p.supplier === id).length;
            if (productCount > 0) {
                if (!confirm(`Este proveedor tiene ${productCount} producto(s). ¿Eliminar de todas formas?`)) {
                    return;
                }
            } else {
                if (!confirm('¿Eliminar este proveedor?')) {
                    return;
                }
            }
            app.deleteSupplier(id);
            renderSuppliers();
        }

        // ============================================
        // FUNCIONES DE QR Y CÓDIGO DE BARRAS
        // ============================================
        function showQR(productId) {
            const product = app.getProductById(productId);
            if (!product) return;

            const modal = document.getElementById('qrModal');
            const qrContainer = document.getElementById('qrcode');
            qrContainer.innerHTML = '';

            const productData = JSON.stringify({
                id: product.id,
                name: product.name,
                price: product.price,
                sku: product.sku || product.id
            });

            QRCode.toCanvas(productData, { width: 180 }, (error, canvas) => {
                if (!error) {
                    qrContainer.appendChild(canvas);
                } else {
                    qrContainer.innerHTML = '<p>Error al generar QR</p>';
                }
            });

            document.getElementById('qrProductName').textContent = product.name;
            document.getElementById('downloadQR').onclick = () => {
                const canvas = qrContainer.querySelector('canvas');
                if (canvas) {
                    const link = document.createElement('a');
                    link.download = `qr_${product.id}.png`;
                    link.href = canvas.toDataURL();
                    link.click();
                }
            };

            modal.classList.add('show');
        }

        function showBarcode(productId) {
            const product = app.getProductById(productId);
            if (!product) return;

            const modal = document.getElementById('barcodeModal');
            const barcodeValue = product.sku || product.id;

            JsBarcode('#barcode', barcodeValue, {
                format: 'CODE128',
                displayValue: true,
                fontSize: 14,
                height: 40
            });

            document.getElementById('barcodeProductName').textContent = product.name;
            document.getElementById('downloadBarcode').onclick = () => {
                const svg = document.getElementById('barcode');
                const serializer = new XMLSerializer();
                const source = serializer.serializeToString(svg);
                const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(source);
                
                const link = document.createElement('a');
                link.download = `barcode_${product.id}.svg`;
                link.href = url;
                link.click();
            };

            modal.classList.add('show');
        }

        // ============================================
        // FUNCIONES DE UTILIDAD
        // ============================================
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('show');
        }

        function changeInventoryPage(page) {
            if (page < 1 || page > app.getTotalPages()) return;
            app.currentPage = page;
            renderInventory();
        }

        function markNotificationRead(id) {
            app.markNotificationAsRead(id);
            renderNotifications();
        }

        // ============================================
        // INICIALIZACIÓN
        // ============================================
        document.addEventListener('DOMContentLoaded', () => {
            // Aplicar tema guardado
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            } else {
                document.querySelector('#themeToggle i').className = 'fas fa-moon';
            }

            // Cargar selects
            const categorySelects = ['productCategory', 'inventoryCategoryFilter'];
            categorySelects.forEach(id => {
                const select = document.getElementById(id);
                if (select) {
                    select.innerHTML = '<option value="all">Todas las categorías</option>';
                    app.categories.forEach(cat => {
                        select.innerHTML += `<option value="${cat}">${cat}</option>`;
                    });
                }
            });

            const locationSelect = document.getElementById('productLocation');
            if (locationSelect) {
                locationSelect.innerHTML = '<option value="">Seleccionar</option>';
                app.locations.forEach(loc => {
                    locationSelect.innerHTML += `<option value="${loc}">${loc}</option>`;
                });
            }

            const supplierSelect = document.getElementById('productSupplier');
            if (supplierSelect) {
                supplierSelect.innerHTML = '<option value="">Seleccionar</option>';
                app.suppliers.forEach(sup => {
                    supplierSelect.innerHTML += `<option value="${sup.id}">${sup.name}</option>`;
                });
            }

            // Renderizar vistas
            showView('dashboard');
            renderNotifications();

            // Event listeners
            document.getElementById('themeToggle').addEventListener('click', () => app.toggleTheme());
            document.getElementById('sidebarToggle').addEventListener('click', () => app.toggleSidebar());
            document.getElementById('menuToggle').addEventListener('click', () => {
                document.getElementById('sidebar').classList.toggle('open');
            });

            document.getElementById('notificationBtn').addEventListener('click', (e) => {
                e.stopPropagation();
                document.getElementById('notificationDropdown').classList.toggle('show');
            });

            document.getElementById('markAllRead').addEventListener('click', () => {
                app.markAllNotificationsAsRead();
                renderNotifications();
            });

            document.getElementById('viewAllNotifications').addEventListener('click', (e) => {
                e.preventDefault();
                app.showNotification('Todas las notificaciones', 'info');
                document.getElementById('notificationDropdown').classList.remove('show');
            });

            // Navegación
            document.getElementById('dashboardLink').addEventListener('click', (e) => {
                e.preventDefault();
                showView('dashboard');
            });

            document.getElementById('inventoryLink').addEventListener('click', (e) => {
                e.preventDefault();
                showView('inventory');
            });

            document.getElementById('suppliersLink').addEventListener('click', (e) => {
                e.preventDefault();
                showView('suppliers');
            });

            document.getElementById('reportsLink').addEventListener('click', (e) => {
                e.preventDefault();
                showView('reports');
            });

            // Botones de acción rápida
            document.getElementById('quickAddProduct').addEventListener('click', () => openProductModal('add'));
            document.getElementById('quickScanQR').addEventListener('click', () => {
                app.showNotification('Escáner QR - Próximamente', 'info');
            });
            document.getElementById('quickGenerateReport').addEventListener('click', () => {
                app.showNotification('Generando reporte...', 'info');
                setTimeout(() => {
                    app.showNotification('Reporte generado', 'success');
                    if (typeof confetti === 'function') {
                        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
                    }
                }, 1500);
            });
            document.getElementById('quickCheckStock').addEventListener('click', () => {
                document.getElementById('inventoryStatusFilter').value = 'Stock bajo';
                showView('inventory');
            });

            // Botones principales
            document.getElementById('newProductBtn').addEventListener('click', () => openProductModal('add'));
            document.getElementById('newSupplierBtn').addEventListener('click', () => openSupplierModal('add'));

            document.getElementById('saveProduct').addEventListener('click', saveProduct);
            document.getElementById('saveSupplier').addEventListener('click', saveSupplier);

            // Filtros
            document.getElementById('inventorySearch')?.addEventListener('input', () => {
                app.currentPage = 1;
                renderInventory();
            });
            
            document.getElementById('inventoryCategoryFilter')?.addEventListener('change', () => {
                app.currentPage = 1;
                renderInventory();
            });
            
            document.getElementById('inventoryStatusFilter')?.addEventListener('change', () => {
                app.currentPage = 1;
                renderInventory();
            });
            
            document.getElementById('clearInventoryFilters')?.addEventListener('click', () => {
                document.getElementById('inventorySearch').value = '';
                document.getElementById('inventoryCategoryFilter').value = 'all';
                document.getElementById('inventoryStatusFilter').value = 'all';
                app.currentPage = 1;
                renderInventory();
            });

            document.getElementById('refreshRecent')?.addEventListener('click', () => {
                renderDashboard();
                app.showNotification('Datos actualizados', 'success');
            });

            // Exportación
            document.getElementById('exportDropdownBtn')?.addEventListener('click', (e) => {
                e.stopPropagation();
                const options = document.getElementById('exportOptions');
                options.style.display = options.style.display === 'none' ? 'block' : 'none';
            });

            document.querySelectorAll('.export-option').forEach(opt => {
                opt.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const format = opt.dataset.format;
                    app.showNotification(`Exportando a ${format.toUpperCase()}...`, 'info');
                    document.getElementById('exportOptions').style.display = 'none';
                    
                    setTimeout(() => {
                        app.showNotification(`Reporte exportado a ${format.toUpperCase()}`, 'success');
                        if (typeof confetti === 'function') {
                            confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
                        }
                    }, 1500);
                });
            });

            // Importación
            document.getElementById('importBtn')?.addEventListener('click', () => {
                app.showNotification('Función de importación - Próximamente', 'info');
            });

            // Búsqueda global
            document.getElementById('globalSearch').addEventListener('input', (e) => {
                const search = e.target.value;
                const suggestions = document.getElementById('searchSuggestions');
                
                if (search.length >= 2) {
                    const results = app.products.filter(p => 
                        p.name.toLowerCase().includes(search.toLowerCase())
                    ).slice(0, 5);
                    
                    if (results.length > 0) {
                        suggestions.innerHTML = results.map(p => `
                            <div class="suggestion-item" onclick="showView('inventory'); document.getElementById('inventorySearch').value='${p.name}'; renderInventory(); document.getElementById('searchSuggestions').classList.remove('show');">
                                <i class="fas fa-box"></i>
                                <span>${p.name}</span>
                                <small>${p.id}</small>
                            </div>
                        `).join('');
                        suggestions.classList.add('show');
                    } else {
                        suggestions.classList.remove('show');
                    }
                } else {
                    suggestions.classList.remove('show');
                }
            });

            // Cerrar dropdowns al hacer clic fuera
            document.addEventListener('click', (e) => {
                if (!e.target.closest('.notification-container')) {
                    document.getElementById('notificationDropdown')?.classList.remove('show');
                }
                if (!e.target.closest('#exportDropdownBtn') && !e.target.closest('#exportOptions')) {
                    document.getElementById('exportOptions')?.style.display = 'none';
                }
                if (!e.target.closest('.search-box')) {
                    document.getElementById('searchSuggestions')?.classList.remove('show');
                }
            });

            // Cambiar período de gráficos
            document.getElementById('categoryPeriod')?.addEventListener('change', () => {
                updateCharts();
            });

            document.getElementById('movementPeriod')?.addEventListener('change', (e) => {
                const days = parseInt(e.target.value);
                // Aquí podrías actualizar los datos según el período
                updateCharts();
            });

            // Actualizar cada 30 segundos
            setInterval(renderNotifications, 30000);
        });

        // Exponer funciones globales
        window.viewProduct = viewProduct;
        window.editProduct = editProduct;
        window.deleteProduct = deleteProduct;
        window.editSupplier = editSupplier;
        window.deleteSupplier = deleteSupplier;
        window.showQR = showQR;
        window.showBarcode = showBarcode;
        window.closeModal = closeModal;
        window.changeInventoryPage = changeInventoryPage;
        window.markNotificationRead = markNotificationRead;
        window.openProductModal = openProductModal;
        window.openSupplierModal = openSupplierModal;
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>