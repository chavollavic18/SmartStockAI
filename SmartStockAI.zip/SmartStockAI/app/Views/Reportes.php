<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Reportes Avanzados con IA Predictiva</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <!-- TensorFlow.js -->
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.10.0/dist/tf.min.js"></script>
    <!-- Modelos pre-entrenados para mayor precisión -->
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow-models/universal-sentence-encoder@1.3.3/dist/universal-sentence-encoder.min.js"></script>
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 250px;
            --primary-rgb: 58, 94, 199;
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #000000;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #000000;
            transition: var(--transition);
            min-height: 100vh;
        }

        /* Scrollbar personalizado */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--primary);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary-dark);
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: var(--transition);
            border-left: 4px solid transparent;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .sidebar-menu i {
            width: 25px;
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: var(--transition);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: #000000;
        }

        .controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: #000000;
            position: relative;
        }

        .theme-switcher:hover, .notifications:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        /* Badge de notificaciones */
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .notification-badge.hidden {
            display: none;
        }

        /* Dropdown de notificaciones */
        .notification-container {
            position: relative;
        }

        .notification-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            width: 320px;
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            z-index: 1000;
            display: none;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .notification-dropdown.show {
            display: block;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .notification-header {
            padding: 15px;
            border-bottom: 1px solid var(--gray);
            font-weight: 600;
            background: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
        }

        .notification-list {
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-item {
            padding: 12px 15px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
        }

        .notification-item:hover {
            background: rgba(58, 94, 199, 0.05);
        }

        .notification-item.unread {
            background: rgba(58, 94, 199, 0.1);
            border-left: 3px solid var(--primary);
        }

        .notification-item strong {
            display: block;
            margin-bottom: 3px;
        }

        .notification-item small {
            color: var(--gray);
            font-size: 11px;
        }

        /* Sección de Reportes */
        .reports-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .advanced-filters {
            background: rgba(58, 94, 199, 0.05);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid rgba(58, 94, 199, 0.2);
        }

        .filter-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 10px;
        }

        .report-controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .report-type-selector {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .report-type-btn {
            padding: 10px 20px;
            border: 1px solid var(--primary);
            background: white;
            color: var(--primary);
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
        }

        .report-type-btn.active {
            background: var(--primary);
            color: white;
            box-shadow: 0 3px 10px rgba(58, 94, 199, 0.3);
        }

        .report-type-btn:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
        }

        .report-actions {
            display: flex;
            gap: 10px;
            margin-left: auto;
            flex-wrap: wrap;
        }

        .report-content {
            min-height: 400px;
            border: 1px solid rgba(0,0,0,0.1);
            border-radius: var(--border-radius);
            padding: 20px;
            background: white;
            margin-bottom: 20px;
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
        }

        .report-table th, .report-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .report-table th {
            background-color: rgba(58, 94, 199, 0.1);
            font-weight: 600;
            color: var(--primary);
        }

        .report-table tr:hover {
            background-color: rgba(0,0,0,0.02);
        }

        .chart-container {
            height: 300px;
            margin: 20px 0;
            position: relative;
        }

        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: var(--transition);
            border-bottom: 3px solid var(--primary);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin: 10px 0;
        }

        .stat-title {
            color: var(--gray);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .trend-up {
            color: var(--secondary);
        }

        .trend-down {
            color: var(--danger);
        }

        .insights-section {
            background: rgba(58, 94, 199, 0.05);
            border-radius: var(--border-radius);
            padding: 20px;
            margin: 20px 0;
        }

        .insight-item {
            margin-bottom: 15px;
            padding: 15px;
            border-left: 4px solid var(--primary);
            background: white;
            border-radius: 0 var(--border-radius) var(--border-radius) 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .saved-reports {
            margin-top: 30px;
        }

        .saved-reports-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }

        .saved-report-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary);
            transition: var(--transition);
        }

        .saved-report-card:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }

        .saved-report-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            display: none;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Toast de notificaciones */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
        }

        .toast {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            padding: 15px 20px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            animation: slideInRight 0.3s forwards;
            min-width: 300px;
            border-left: 4px solid var(--primary);
        }

        .toast.success {
            border-left-color: var(--secondary);
        }

        .toast.error {
            border-left-color: var(--danger);
        }

        .toast.warning {
            border-left-color: var(--warning);
        }

        .toast i {
            margin-right: 10px;
            font-size: 20px;
        }

        .toast.success i {
            color: var(--secondary);
        }

        .toast.error i {
            color: var(--danger);
        }

        .toast.warning i {
            color: var(--warning);
        }

        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* Badges para estados */
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
            display: inline-block;
        }

        .badge.bg-success {
            background-color: var(--secondary);
        }

        .badge.bg-warning {
            background-color: var(--warning);
        }

        .badge.bg-danger {
            background-color: var(--danger);
        }

        .badge.bg-info {
            background-color: #17a2b8;
        }

        .badge.bg-primary {
            background-color: var(--primary);
        }

        /* Estilos para reportes */
        .report-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid var(--primary);
            padding-bottom: 15px;
        }

        .report-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 5px;
        }

        .report-subtitle {
            color: var(--gray);
            font-size: 16px;
        }

        .report-footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: var(--gray);
            border-top: 1px solid #ddd;
            padding-top: 15px;
        }

        .no-print {
            display: block;
        }

        @media print {
            .no-print {
                display: none !important;
            }
            
            .report-content {
                border: none;
                box-shadow: none;
                padding: 0;
            }
            
            body {
                background: white;
            }
            
            .sidebar, .header, .report-controls, .advanced-filters {
                display: none;
            }
            
            .main-content {
                margin-left: 0;
                padding: 0;
            }
        }

        /* Tabs */
        .tab-content {
            margin-top: 20px;
        }

        .nav-tabs .nav-link {
            color: var(--text);
            border: none;
            padding: 10px 20px;
            font-weight: 500;
        }

        .nav-tabs .nav-link.active {
            background-color: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
        }

        .nav-tabs .nav-link:hover:not(.active) {
            background-color: rgba(58, 94, 199, 0.1);
            border-radius: var(--border-radius) var(--border-radius) 0 0;
        }

        /* Tablas de comparación */
        .comparison-table {
            width: 100%;
            border-collapse: collapse;
        }

        .comparison-table th, .comparison-table td {
            padding: 10px;
            text-align: center;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .comparison-table th {
            background-color: rgba(58, 94, 199, 0.1);
            font-weight: 600;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: var(--gray);
        }

        /* Estilos para TensorFlow.js mejorados */
        .tensorflow-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: var(--border-radius);
            padding: 20px;
            margin: 20px 0;
            color: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .tensorflow-section h4, .tensorflow-section h5 {
            color: white;
        }

        .tensorflow-section p {
            color: rgba(255,255,255,0.9);
        }

        .tensorflow-chart {
            height: 300px;
            margin: 20px 0;
            background: rgba(255,255,255,0.1);
            border-radius: var(--border-radius);
            padding: 15px;
        }

        .prediction-results {
            margin-top: 20px;
        }

        .prediction-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary);
            color: #000;
        }

        .training-status {
            padding: 10px 15px;
            border-radius: var(--border-radius);
            margin-bottom: 15px;
            font-weight: 500;
        }

        .training-status.training {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .training-status.completed {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .training-status.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .model-controls {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .tensorflow-insight {
            background: rgba(255,255,255,0.1);
            border-left: 4px solid var(--warning);
            padding: 15px;
            margin: 15px 0;
            border-radius: 0 var(--border-radius) var(--border-radius) 0;
            color: white;
        }

        .progress-bar {
            height: 20px;
            background-color: rgba(255,255,255,0.2);
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary), var(--primary-dark));
            transition: width 0.3s ease;
            border-radius: 10px;
        }

        /* Datos externos */
        .external-data-section {
            background: rgba(255,255,255,0.15);
            border-radius: var(--border-radius);
            padding: 15px;
            margin: 15px 0;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .sentiment-indicator {
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .sentiment-positive {
            background-color: rgba(40, 167, 69, 0.2);
            color: #28a745;
        }

        .sentiment-negative {
            background-color: rgba(220, 53, 69, 0.2);
            color: #dc3545;
        }

        .sentiment-neutral {
            background-color: rgba(255, 193, 7, 0.2);
            color: #ffc107;
        }

        .market-trends {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin: 15px 0;
        }

        .market-trend-card {
            background: rgba(255,255,255,0.15);
            border-radius: var(--border-radius);
            padding: 15px;
            text-align: center;
            backdrop-filter: blur(10px);
        }

        .market-trend-value {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 5px 0;
        }

        .external-data-source {
            font-size: 0.8rem;
            opacity: 0.8;
            margin-top: 5px;
        }

        .ai-recommendation {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: var(--border-radius);
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .recommendation-list {
            list-style: none;
            padding: 0;
        }

        .recommendation-list li {
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }

        .recommendation-list li:last-child {
            border-bottom: none;
        }

        .recommendation-list li i {
            margin-right: 10px;
        }

        .real-time-badge {
            background: linear-gradient(135deg, #ff6b6b, #ee5253);
            color: white;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            margin-left: 10px;
            animation: pulse 2s infinite;
            display: inline-block;
        }

        @keyframes pulse {
            0% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.7; transform: scale(1.05); }
            100% { opacity: 1; transform: scale(1); }
        }

        .data-freshness {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.8);
            text-align: center;
            margin-top: 10px;
        }

        .api-status {
            display: inline-flex;
            align-items: center;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
            margin-right: 5px;
        }

        .api-status.online {
            background-color: #d4edda;
            color: #155724;
        }

        .api-status.offline {
            background-color: #f8d7da;
            color: #721c24;
        }

        .api-status i {
            margin-right: 4px;
        }
        
        /* Nuevos estilos para tendencias mejoradas */
        .trends-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .trend-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary);
        }
        
        .trend-card h5 {
            margin-bottom: 15px;
            color: var(--primary);
        }
        
        .trend-indicator {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .trend-value {
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .trend-change {
            font-size: 0.9rem;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 12px;
        }
        
        .trend-change.positive {
            background-color: #d4edda;
            color: #155724;
        }
        
        .trend-change.negative {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .trend-change.neutral {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .trend-description {
            font-size: 0.9rem;
            color: var(--gray);
            margin-top: 10px;
        }
        
        .seasonal-pattern {
            background: rgba(58, 94, 199, 0.05);
            border-radius: var(--border-radius);
            padding: 15px;
            margin: 15px 0;
        }
        
        .seasonal-chart {
            height: 200px;
            margin: 15px 0;
        }
        
        .forecast-section {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border-radius: var(--border-radius);
            padding: 20px;
            margin: 20px 0;
        }
        
        .forecast-section h4 {
            color: white;
            margin-bottom: 15px;
        }
        
        .forecast-values {
            display: flex;
            justify-content: space-around;
            text-align: center;
            margin: 20px 0;
        }
        
        .forecast-value {
            flex: 1;
        }
        
        .forecast-value .value {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .forecast-value .label {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .performance-comparison {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .performance-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 15px;
            text-align: center;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .performance-card h6 {
            margin-bottom: 10px;
            color: var(--primary);
        }
        
        .performance-value {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 10px 0;
        }
        
        .performance-change {
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .category-trends {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .category-trend-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            border-top: 4px solid var(--primary);
        }
        
        .category-trend-card h6 {
            margin-bottom: 10px;
        }
        
        .category-trend-value {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 5px 0;
        }
        
        .trend-analysis-tabs {
            margin: 20px 0;
        }
        
        .analysis-tab-content {
            margin-top: 20px;
        }

        /* Estilos para el menú toggle móvil */
        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 1001;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            cursor: pointer;
            transition: var(--transition);
        }

        .menu-toggle:hover {
            transform: scale(1.1);
            background: var(--primary-dark);
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 0;
            }
            
            .sidebar.open {
                transform: translateX(0);
                width: var(--sidebar-width);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .report-controls {
                flex-direction: column;
            }

            .report-actions {
                margin-left: 0;
                justify-content: flex-end;
            }

            .filter-row {
                flex-direction: column;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .controls {
                margin-top: 15px;
                width: 100%;
                justify-content: space-between;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }

            .saved-reports-list {
                grid-template-columns: 1fr;
            }

            .report-type-selector {
                flex-direction: column;
            }
            
            .report-type-btn {
                width: 100%;
                text-align: center;
            }
            
            .filter-group {
                min-width: 100%;
            }
            
            .report-actions {
                flex-direction: column;
                width: 100%;
            }
            
            .report-actions .btn {
                width: 100%;
                margin-bottom: 10px;
            }
            
            .filter-actions {
                flex-direction: column;
            }
            
            .filter-actions .btn {
                width: 100%;
                margin-bottom: 10px;
            }

            .market-trends {
                grid-template-columns: 1fr;
            }

            .forecast-values {
                flex-direction: column;
                gap: 15px;
            }

            .performance-comparison {
                grid-template-columns: 1fr;
            }

            .category-trends {
                grid-template-columns: 1fr;
            }

            .trends-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px;
            }
            
            .reports-section {
                padding: 15px;
            }

            .toast {
                min-width: 250px;
            }

            .notification-dropdown {
                width: 280px;
                right: -50px;
            }
        }

        /* Asegurar que todos los textos sean negros */
        body, body *:not(.sidebar *):not(.modal-header *):not(.action-btn):not(.badge):not(.page-link:hover):not(.page-item.active .page-link) {
            color: #000000 !important;
        }

        /* Ajustes para mantener contraste en elementos especiales */
        .sidebar, .modal-header, .action-btn, .badge, .page-link:hover, .page-item.active .page-link {
            color: white !important;
        }

        /* Inputs y selects */
        .form-control, .form-select {
            color: #000000 !important;
            background-color: #ffffff !important;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.25);
        }

        .form-control::placeholder {
            color: #999 !important;
        }

        /* Botones */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
        }

        .btn-primary {
            background: var(--primary);
            color: white !important;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3);
        }

        .btn-outline-primary {
            border: 1px solid var(--primary);
            color: var(--primary) !important;
            background: transparent;
        }

        .btn-outline-primary:hover {
            background: var(--primary);
            color: white !important;
        }

        .btn-secondary {
            background: var(--gray);
            color: white !important;
        }

        .btn-success {
            background: var(--secondary);
            color: white !important;
        }

        .btn-danger {
            background: var(--danger);
            color: white !important;
        }

        .btn-warning {
            background: var(--warning);
            color: #000 !important;
        }

        .btn-info {
            background: var(--info);
            color: white !important;
        }

        /* Dropdown menu */
        .dropdown-menu {
            background: var(--card-bg);
            border: 1px solid rgba(0,0,0,0.1);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .dropdown-item {
            color: #000 !important;
            padding: 8px 20px;
        }

        .dropdown-item:hover {
            background: rgba(58, 94, 199, 0.1);
        }

        .dropdown-item i {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="loading-overlay" id="loadingOverlay">
        <div class="spinner"></div>
    </div>

    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot me-2"></i>SmartStock AI
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <li><a href="http://localhost/SmartStockAI/admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes"></i> Inventario</a></li>
                <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck"></i> Proveedores</a></li>
                <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users"></i> Usuarios</a></li>
                <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-exchange-alt"></i> Transacciones</a></li>
                <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-line"></i> Reportes</a></li>
                <li><a href="#" class="active"><i class="fas fa-user-friends"></i> Clientes</a></li>
                <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-user"></i> Mi Perfil</a></li>
                <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-alt"></i> Seguridad</a></li>
                <li><a href="http://localhost/SmartStockAI/login.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a></li>
                <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-cog"></i> Configuración</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1 class="page-title">
                    <i class="fas fa-chart-line me-2"></i>
                    Reportes Avanzados con IA Predictiva
                    <span class="real-time-badge" id="realTimeBadge">IA EN TIEMPO REAL</span>
                </h1>
                
                <div class="controls">
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notification-container">
                        <div class="notifications" id="notificationBtn">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge hidden" id="notificationBadge">0</span>
                        </div>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-header">
                                <i class="fas fa-bell me-2"></i>Notificaciones
                            </div>
                            <div class="notification-list" id="notificationList">
                                <!-- Las notificaciones se cargarán aquí dinámicamente -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Filtros Avanzados -->
            <div class="advanced-filters no-print">
                <h5><i class="fas fa-filter me-2"></i>Filtros Avanzados</h5>
                <div class="filter-row">
                    <div class="filter-group">
                        <label class="form-label">Categoría</label>
                        <select class="form-select" id="categoryFilter">
                            <option value="all">Todas las categorías</option>
                            <option value="Electrónicos">Electrónicos</option>
                            <option value="Ropa">Ropa</option>
                            <option value="Hogar">Hogar</option>
                            <option value="Deportes">Deportes</option>
                            <option value="Alimentos">Alimentos</option>
                            <option value="Juguetes">Juguetes</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Estado de Stock</label>
                        <select class="form-select" id="stockStatusFilter">
                            <option value="all">Todos los estados</option>
                            <option value="En stock">En stock</option>
                            <option value="Stock bajo">Stock bajo</option>
                            <option value="Stock crítico">Stock crítico</option>
                            <option value="Agotado">Agotado</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Rango de Precios</label>
                        <div class="input-group">
                            <input type="number" class="form-control" id="minPrice" placeholder="Mínimo">
                            <span class="input-group-text">-</span>
                            <input type="number" class="form-control" id="maxPrice" placeholder="Máximo">
                        </div>
                    </div>
                </div>
                <div class="filter-row">
                    <div class="filter-group">
                        <label class="form-label">Rango de Stock</label>
                        <div class="input-group">
                            <input type="number" class="form-control" id="minStock" placeholder="Mínimo">
                            <span class="input-group-text">-</span>
                            <input type="number" class="form-control" id="maxStock" placeholder="Máximo">
                        </div>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Ordenar por</label>
                        <select class="form-select" id="sortBy">
                            <option value="name">Nombre (A-Z)</option>
                            <option value="name_desc">Nombre (Z-A)</option>
                            <option value="price">Precio (Menor a Mayor)</option>
                            <option value="price_desc">Precio (Mayor a Menor)</option>
                            <option value="stock">Stock (Menor a Mayor)</option>
                            <option value="stock_desc">Stock (Mayor a Menor)</option>
                            <option value="value">Valor Total (Menor a Mayor)</option>
                            <option value="value_desc">Valor Total (Mayor a Menor)</option>
                        </select>
                    </div>
                </div>
                <div class="filter-actions">
                    <button class="btn btn-outline-secondary" id="resetFilters">
                        <i class="fas fa-redo me-2"></i>Restablecer
                    </button>
                    <button class="btn btn-primary" id="applyFilters">
                        <i class="fas fa-check me-2"></i>Aplicar Filtros
                    </button>
                </div>
            </div>
            
            <!-- Sección de Reportes -->
            <div class="reports-section">
                <div class="report-controls">
                    <div class="report-type-selector">
                        <button class="report-type-btn active" data-type="inventory">Inventario General</button>
                        <button class="report-type-btn" data-type="stock">Niveles de Stock</button>
                        <button class="report-type-btn" data-type="categories">Por Categorías</button>
                        <button class="report-type-btn" data-type="valuation">Valoración</button>
                        <button class="report-type-btn" data-type="trends">Tendencias</button>
                        <button class="report-type-btn" data-type="comparison">Comparación</button>
                        <button class="report-type-btn" data-type="ai">Análisis IA</button>
                    </div>
                    
                    <div class="report-actions no-print">
                        <div class="btn-group">
                            <button class="btn btn-outline-primary" id="saveReport">
                                <i class="fas fa-save me-2"></i>Guardar
                            </button>
                        </div>
                        
                        <button class="btn btn-outline-primary" id="printReport">
                            <i class="fas fa-print me-2"></i>Imprimir
                        </button>
                        
                        <div class="btn-group">
                            <button class="btn btn-primary" id="exportDropdownBtn">
                                <i class="fas fa-file-export me-2"></i>Exportar
                            </button>
                            <button class="btn btn-primary dropdown-toggle dropdown-toggle-split" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="visually-hidden">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#" data-format="pdf"><i class="fas fa-file-pdf me-2"></i>PDF</a></li>
                                <li><a class="dropdown-item" href="#" data-format="excel"><i class="fas fa-file-excel me-2"></i>Excel</a></li>
                                <li><a class="dropdown-item" href="#" data-format="csv"><i class="fas fa-file-csv me-2"></i>CSV</a></li>
                                <li><a class="dropdown-item" href="#" data-format="json"><i class="fas fa-file-code me-2"></i>JSON</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="report-content" id="reportContent">
                    <!-- El contenido del reporte se cargará aquí dinámicamente -->
                </div>
            </div>
            
            <!-- Reportes Guardados -->
            <div class="saved-reports no-print">
                <h4><i class="fas fa-bookmark me-2"></i>Reportes Guardados</h4>
                <div class="saved-reports-list" id="savedReportsList">
                    <!-- Los reportes guardados se cargarán aquí dinámicamente -->
                </div>
            </div>
        </div>
    </div>
    
    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function getGlobalSettings() {
            try { return JSON.parse(localStorage.getItem('globalSettings')) || {}; } catch (error) { return {}; }
        }

        function getConfiguredMinimumStock(product) {
            const configured = Number(getGlobalSettings().minStockAlert);
            return Number.isFinite(Number(product.minStock)) ? Number(product.minStock) : (configured || 5);
        }

        function getConfiguredCurrency() {
            return getGlobalSettings().currencySymbol || 'MXN';
        }

        function formatReportCurrency(value) {
            return `${getConfiguredCurrency()} ${Number(value || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        }

        function summarizeProducts(products) {
            return products.reduce((summary, product) => {
                const value = Number(product.price || 0) * Number(product.stock || 0);
                const minimumStock = getConfiguredMinimumStock(product);
                summary.totalProducts++;
                summary.totalValue += value;
                if (product.stock === 0) summary.outOfStock++;
                else if (product.stock <= minimumStock) summary.lowStock++;
                summary.byCategory[product.category] ||= { count: 0, value: 0 };
                summary.byCategory[product.category].count++;
                summary.byCategory[product.category].value += value;
                return summary;
            }, { totalProducts: 0, totalValue: 0, lowStock: 0, outOfStock: 0, byCategory: {} });
        }

        // ============================================
        // CLASE PARA GESTIONAR PRODUCTOS
        // ============================================
        class ProductManager {
            constructor() {
                try {
                    this.products = JSON.parse(localStorage.getItem('products')) || [];
                } catch (error) {
                    this.products = [];
                    localStorage.removeItem('products');
                }
                
                // Inicializar con datos de ejemplo si no hay productos
                if (this.products.length === 0) {
                    this.initializeSampleData();
                }
            }
            
            initializeSampleData() {
                this.products = [
                    {
                        id: 'PRD-001',
                        name: 'Laptop HP Pavilion',
                        category: 'Electrónicos',
                        price: 850.00,
                        stock: 5,
                        minStock: 10,
                        description: 'Laptop HP Pavilion con procesador Intel i5, 8GB RAM, 256GB SSD',
                        image: 'https://via.placeholder.com/300x200?text=Laptop+HP',
                        lastUpdated: '2023-10-15'
                    },
                    {
                        id: 'PRD-002',
                        name: 'Smartphone Samsung Galaxy',
                        category: 'Electrónicos',
                        price: 620.00,
                        stock: 42,
                        minStock: 15,
                        description: 'Smartphone Samsung Galaxy con pantalla AMOLED de 6.5", 128GB almacenamiento',
                        image: 'https://via.placeholder.com/300x200?text=Samsung+Galaxy',
                        lastUpdated: '2023-11-20'
                    },
                    {
                        id: 'PRD-003',
                        name: 'Zapatillas Deportivas',
                        category: 'Deportes',
                        price: 75.00,
                        stock: 12,
                        minStock: 20,
                        description: 'Zapatillas deportivas para running, tallas disponibles del 38 al 45',
                        image: 'https://via.placeholder.com/300x200?text=Zapatillas',
                        lastUpdated: '2023-12-05'
                    },
                    {
                        id: 'PRD-004',
                        name: 'Monitor LG 24"',
                        category: 'Electrónicos',
                        price: 220.00,
                        stock: 28,
                        minStock: 8,
                        description: 'Monitor LG 24 pulgadas, resolución Full HD, conexión HDMI y VGA',
                        image: 'https://via.placeholder.com/300x200?text=Monitor+LG',
                        lastUpdated: '2023-10-28'
                    },
                    {
                        id: 'PRD-005',
                        name: 'Camiseta Algodón',
                        category: 'Ropa',
                        price: 25.00,
                        stock: 3,
                        minStock: 20,
                        description: 'Camiseta de algodón 100%, disponible en varios colores',
                        image: 'https://via.placeholder.com/300x200?text=Camiseta',
                        lastUpdated: '2023-11-10'
                    },
                    {
                        id: 'PRD-006',
                        name: 'Silla de Oficina',
                        category: 'Hogar',
                        price: 120.00,
                        stock: 15,
                        minStock: 10,
                        description: 'Silla ergonómica para oficina, ajustable en altura',
                        image: 'https://via.placeholder.com/300x200?text=Silla+Oficina',
                        lastUpdated: '2023-12-15'
                    },
                    {
                        id: 'PRD-007',
                        name: 'Tablet Android',
                        category: 'Electrónicos',
                        price: 299.99,
                        stock: 8,
                        minStock: 12,
                        description: 'Tablet Android con pantalla de 10", 64GB almacenamiento',
                        image: 'https://via.placeholder.com/300x200?text=Tablet+Android',
                        lastUpdated: '2023-11-30'
                    },
                    {
                        id: 'PRD-008',
                        name: 'Set de Herramientas',
                        category: 'Hogar',
                        price: 89.99,
                        stock: 20,
                        minStock: 15,
                        description: 'Set completo de herramientas para el hogar con 50 piezas',
                        image: 'https://via.placeholder.com/300x200?text=Herramientas',
                        lastUpdated: '2023-10-05'
                    },
                    {
                        id: 'PRD-009',
                        name: 'Auriculares Inalámbricos',
                        category: 'Electrónicos',
                        price: 150.00,
                        stock: 25,
                        minStock: 10,
                        description: 'Auriculares Bluetooth con cancelación de ruido',
                        image: 'https://via.placeholder.com/300x200?text=Auriculares',
                        lastUpdated: '2023-12-10'
                    },
                    {
                        id: 'PRD-010',
                        name: 'Mochila Impermeable',
                        category: 'Deportes',
                        price: 45.00,
                        stock: 18,
                        minStock: 15,
                        description: 'Mochila resistente al agua para actividades al aire libre',
                        image: 'https://via.placeholder.com/300x200?text=Mochila',
                        lastUpdated: '2023-11-25'
                    }
                ];
                this.saveProducts();
            }
            
            getProductStatus(stock, minStock = null) {
                if (stock === 0) return 'Agotado';
                const threshold = minStock === null ? getGlobalSettings().minStockAlert || 5 : minStock;
                if (stock <= Math.max(1, threshold * 0.2)) return 'Stock crítico';
                if (stock <= threshold) return 'Stock bajo';
                return 'En stock';
            }
            
            getStatusClass(stock, minStock = null) {
                if (stock === 0) return 'bg-danger';
                const threshold = minStock === null ? getGlobalSettings().minStockAlert || 5 : minStock;
                if (stock <= Math.max(1, threshold * 0.2)) return 'bg-danger';
                if (stock <= threshold) return 'bg-warning';
                return 'bg-success';
            }
            
            getAllProducts() {
                return this.products;
            }
            
            getProductsByCategory() {
                const categories = {};
                this.products.forEach(product => {
                    if (!categories[product.category]) {
                        categories[product.category] = [];
                    }
                    categories[product.category].push(product);
                });
                return categories;
            }
            
            getStockSummary() {
                const summary = {
                    totalProducts: this.products.length,
                    totalValue: 0,
                    lowStock: 0,
                    outOfStock: 0,
                    byCategory: {}
                };
                
                this.products.forEach(product => {
                    summary.totalValue += product.price * product.stock;
                    
                    if (product.stock === 0) {
                        summary.outOfStock++;
                    } else if (product.stock <= product.minStock) {
                        summary.lowStock++;
                    }
                    
                    if (!summary.byCategory[product.category]) {
                        summary.byCategory[product.category] = {
                            count: 0,
                            value: 0
                        };
                    }
                    
                    summary.byCategory[product.category].count++;
                    summary.byCategory[product.category].value += product.price * product.stock;
                });
                
                return summary;
            }
            
            getHistoricalData() {
                // Datos históricos detallados y realistas para tendencias
                const currentDate = new Date();
                const months = [];
                
                // Generar últimos 24 meses
                for (let i = 23; i >= 0; i--) {
                    const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
                    const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                    months.push(monthKey);
                }
                
                const historicalData = {};
                let baseValue = 12000;
                let baseProducts = 20;
                
                // Patrón estacional simulado (más realista)
                const seasonalPattern = {
                    '01': 0.95, '02': 0.90, '03': 1.05, '04': 1.10,
                    '05': 1.15, '06': 1.20, '07': 1.10, '08': 1.05,
                    '09': 1.00, '10': 1.10, '11': 1.25, '12': 1.30
                };
                
                // Eventos especiales
                const specialEvents = {
                    '2023-06': 1.25, // Verano
                    '2023-11': 1.35, // Black Friday
                    '2023-12': 1.40, // Navidad
                    '2024-01': 1.20, // Rebajas
                    '2024-06': 1.30, // Verano
                    '2024-11': 1.40, // Black Friday
                    '2024-12': 1.45  // Navidad
                };
                
                months.forEach(month => {
                    const monthNum = month.split('-')[1];
                    let seasonalFactor = seasonalPattern[monthNum] || 1.0;
                    
                    // Aplicar factor de evento especial si existe
                    if (specialEvents[month]) {
                        seasonalFactor = specialEvents[month];
                    }
                    
                    // Tendencia general de crecimiento (más realista)
                    const trendFactor = 1 + (Math.log(months.indexOf(month) + 1) * 0.03);
                    
                    // Variación aleatoria controlada
                    const randomVariation = (Math.random() * 0.05) - 0.025;
                    
                    const value = baseValue * seasonalFactor * trendFactor * (1 + randomVariation);
                    const products = baseProducts * seasonalFactor * (1 + (Math.random() * 0.05 - 0.025));
                    
                    historicalData[month] = {
                        totalValue: Math.round(value),
                        totalProducts: Math.round(products),
                        lowStock: Math.floor(2 + (Math.random() * 4)),
                        seasonalFactor: seasonalFactor,
                        trendFactor: trendFactor,
                        event: specialEvents[month] ? 'Evento especial' : 'Normal'
                    };
                    
                    baseValue = value * 0.97; // Ligera disminución para simular consumo
                    baseProducts = products;
                });
                
                return historicalData;
            }
            
            getEnhancedHistoricalData() {
                return this.getHistoricalData();
            }
            
            getCategoryTrends() {
                const categories = ['Electrónicos', 'Ropa', 'Hogar', 'Deportes'];
                const trends = {};
                
                categories.forEach(category => {
                    // Tendencias específicas por categoría con datos más realistas
                    let baseTrend = 1.0;
                    let baseValue = 5000;
                    
                    switch(category) {
                        case 'Electrónicos':
                            baseTrend = 1.18; // Tendencia alcista fuerte
                            baseValue = 8500;
                            break;
                        case 'Ropa':
                            baseTrend = 0.92; // Tendencia bajista
                            baseValue = 3500;
                            break;
                        case 'Hogar':
                            baseTrend = 1.08; // Tendencia moderadamente alcista
                            baseValue = 4200;
                            break;
                        case 'Deportes':
                            baseTrend = 1.12; // Tendencia alcista
                            baseValue = 3800;
                            break;
                    }
                    
                    trends[category] = {
                        currentValue: Math.round(baseValue * baseTrend * (0.9 + Math.random() * 0.2)),
                        growthRate: (baseTrend - 1) * 100,
                        seasonality: Math.random() > 0.5 ? 'Alta' : 'Media',
                        volatility: Math.random() * 0.15,
                        performance: baseTrend > 1.1 ? 'Excelente' : baseTrend > 1.0 ? 'Buena' : 'Regular',
                        recommendedAction: baseTrend > 1.1 ? 'Incrementar inventario' : 
                                         baseTrend < 0.95 ? 'Reducir inventario' : 'Mantener nivel'
                    };
                });
                
                return trends;
            }
            
            saveProducts() {
                localStorage.setItem('products', JSON.stringify(this.products));
            }
            
            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'}"></i>
                    <span>${message}</span>
                `;
                
                document.getElementById('toastContainer').appendChild(toast);
                
                setTimeout(() => {
                    toast.style.animation = 'slideOutRight 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }
        }

        // ============================================
        // CLASE PARA GESTIONAR REPORTES GUARDADOS
        // ============================================
        class SavedReportsManager {
            constructor() {
                try {
                    this.savedReports = JSON.parse(localStorage.getItem('savedReports')) || [];
                } catch (error) {
                    this.savedReports = [];
                    localStorage.removeItem('savedReports');
                }
            }
            
            saveReport(name, filters, reportType, content = null) {
                const report = {
                    id: Date.now(),
                    name,
                    filters,
                    reportType,
                    content,
                    createdAt: new Date().toISOString()
                };
                
                this.savedReports.push(report);
                localStorage.setItem('savedReports', JSON.stringify(this.savedReports));
                
                return report.id;
            }
            
            getSavedReports() {
                return this.savedReports;
            }
            
            deleteReport(id) {
                this.savedReports = this.savedReports.filter(report => report.id !== id);
                localStorage.setItem('savedReports', JSON.stringify(this.savedReports));
            }
            
            getReportById(id) {
                return this.savedReports.find(report => report.id === parseInt(id));
            }
        }

        // ============================================
        // CLASE PARA ANÁLISIS CON TENSORFLOW.JS - VERSIÓN MEJORADA
        // ============================================
        class AdvancedTensorFlowAnalyzer {
            constructor() {
                this.model = null;
                this.modelsTrained = false;
                this.isTraining = false;
                this.trainingHistory = {
                    loss: [],
                    val_loss: [],
                    accuracy: [],
                    val_accuracy: [],
                    mae: [],
                    val_mae: []
                };
                this.externalData = null;
                this.lastUpdate = null;
                this.updateInterval = null;
                this.predictionAccuracy = 0;
                this.modelMetrics = {
                    mse: 0,
                    mae: 0,
                    r2: 0,
                    confidence: 0
                };
                this.ensembleModels = [];
                this.apiStatus = {
                    alphaVantage: false,
                    worldBank: false,
                    fred: false,
                    googleTrends: false,
                    weather: false,
                    sentiment: false
                };
            }
            
            // Inicializar actualizaciones en tiempo real
            initializeRealTimeUpdates() {
                // Actualizar datos cada 5 segundos (más realista que cada segundo)
                this.updateInterval = setInterval(() => {
                    this.fetchAllRealTimeData();
                }, 5000);
                
                // Cargar datos iniciales
                this.fetchAllRealTimeData();
            }
            
            // Detener actualizaciones en tiempo real
            stopRealTimeUpdates() {
                if (this.updateInterval) {
                    clearInterval(this.updateInterval);
                    this.updateInterval = null;
                }
            }
            
            // Obtener todos los datos en tiempo real
            async fetchAllRealTimeData() {
                try {
                    await Promise.all([
                        this.fetchEconomicIndicators(),
                        this.fetchMarketTrends(),
                        this.fetchNewsSentiment(),
                        this.fetchWeatherData(),
                        this.fetchGoogleTrendsData(),
                        this.fetchWorldBankData(),
                        this.fetchFREDData()
                    ]);
                    
                    this.lastUpdate = new Date();
                    console.log('Datos en tiempo real actualizados:', this.lastUpdate);
                    
                    // Actualizar UI si está disponible
                    if (window.updateRealTimeData) {
                        window.updateRealTimeData(this.externalData, this.lastUpdate);
                    }
                    
                    return this.externalData;
                } catch (error) {
                    console.error('Error actualizando datos en tiempo real:', error);
                    productManager.showNotification('Error conectando con fuentes de datos en tiempo real', 'error');
                }
            }
            
            // Obtener indicadores económicos de múltiples fuentes
            async fetchEconomicIndicators() {
                try {
                    // Simular datos económicos realistas
                    this.externalData = {
                        ...this.externalData,
                        economicIndicators: {
                            gdpGrowth: 2.4 + (Math.random() * 0.6 - 0.3),
                            inflation: 3.1 + (Math.random() * 0.4 - 0.2),
                            unemployment: 3.6 + (Math.random() * 0.3 - 0.15),
                            consumerConfidence: 72 + Math.floor(Math.random() * 8 - 4),
                            retailGrowth: 4.3 + (Math.random() * 0.8 - 0.4),
                            industrialProduction: 2.1 + (Math.random() * 0.4 - 0.2),
                            interestRate: 5.25 + (Math.random() * 0.25 - 0.125),
                            housingStarts: 1.2 + (Math.random() * 0.2 - 0.1)
                        }
                    };
                    
                    this.apiStatus.alphaVantage = true;
                    
                } catch (error) {
                    console.warn('Error obteniendo indicadores económicos:', error);
                    this.apiStatus.alphaVantage = false;
                }
            }
            
            // Obtener datos del Banco Mundial
            async fetchWorldBankData() {
                try {
                    // Datos simulados del Banco Mundial
                    this.externalData = {
                        ...this.externalData,
                        worldBank: {
                            gdpPerCapita: 65000 + Math.floor(Math.random() * 2000 - 1000),
                            tradeBalance: -450 + Math.floor(Math.random() * 100 - 50),
                            foreignInvestment: 280 + Math.floor(Math.random() * 40 - 20),
                            inflationWorld: 3.8 + (Math.random() * 0.4 - 0.2)
                        }
                    };
                    
                    this.apiStatus.worldBank = true;
                    
                } catch (error) {
                    console.warn('Error obteniendo datos del Banco Mundial:', error);
                    this.apiStatus.worldBank = false;
                }
            }
            
            // Obtener datos de la Reserva Federal (FRED)
            async fetchFREDData() {
                try {
                    // Datos simulados de la Fed
                    this.externalData = {
                        ...this.externalData,
                        fred: {
                            moneySupply: 21000 + Math.floor(Math.random() * 200 - 100),
                            consumerCredit: 4800 + Math.floor(Math.random() * 100 - 50),
                            businessInventories: 2500 + Math.floor(Math.random() * 50 - 25),
                            retailSales: 680 + Math.floor(Math.random() * 20 - 10)
                        }
                    };
                    
                    this.apiStatus.fred = true;
                    
                } catch (error) {
                    console.warn('Error obteniendo datos de FRED:', error);
                    this.apiStatus.fred = false;
                }
            }
            
            // Obtener tendencias de mercado
            async fetchMarketTrends() {
                try {
                    const trends = {
                        'Electrónicos': { 
                            trend: 1.18 + (Math.random() * 0.06 - 0.03), 
                            sentiment: 0.72 + (Math.random() * 0.1 - 0.05),
                            volume: 850 + Math.floor(Math.random() * 100 - 50),
                            momentum: 0.15 + (Math.random() * 0.06 - 0.03)
                        },
                        'Ropa': { 
                            trend: 0.92 + (Math.random() * 0.04 - 0.02), 
                            sentiment: 0.48 + (Math.random() * 0.08 - 0.04),
                            volume: 420 + Math.floor(Math.random() * 60 - 30),
                            momentum: -0.08 + (Math.random() * 0.04 - 0.02)
                        },
                        'Hogar': { 
                            trend: 1.08 + (Math.random() * 0.04 - 0.02), 
                            sentiment: 0.58 + (Math.random() * 0.06 - 0.03),
                            volume: 380 + Math.floor(Math.random() * 50 - 25),
                            momentum: 0.05 + (Math.random() * 0.04 - 0.02)
                        },
                        'Deportes': { 
                            trend: 1.12 + (Math.random() * 0.04 - 0.02), 
                            sentiment: 0.65 + (Math.random() * 0.08 - 0.04),
                            volume: 520 + Math.floor(Math.random() * 70 - 35),
                            momentum: 0.08 + (Math.random() * 0.04 - 0.02)
                        }
                    };
                    
                    this.externalData = {
                        ...this.externalData,
                        marketTrends: trends
                    };
                    
                } catch (error) {
                    console.warn('Error obteniendo tendencias de mercado:', error);
                }
            }
            
            // Obtener datos climáticos (afectan ventas de ciertas categorías)
            async fetchWeatherData() {
                try {
                    // Datos climáticos simulados
                    const seasons = ['Invierno', 'Primavera', 'Verano', 'Otoño'];
                    const currentSeason = seasons[Math.floor(Math.random() * 4)];
                    
                    this.externalData = {
                        ...this.externalData,
                        weather: {
                            season: currentSeason,
                            temperature: 15 + Math.floor(Math.random() * 20 - 10),
                            precipitation: Math.random() * 30,
                            impactFactor: currentSeason === 'Verano' ? 1.25 : 
                                        currentSeason === 'Invierno' ? 0.85 : 1.0
                        }
                    };
                    
                    this.apiStatus.weather = true;
                    
                } catch (error) {
                    console.warn('Error obteniendo datos climáticos:', error);
                    this.apiStatus.weather = false;
                }
            }
            
            // Obtener sentimiento de noticias
            async fetchNewsSentiment() {
                try {
                    // Análisis de sentimiento por categoría
                    const sentiment = {
                        'Electrónicos': 65 + Math.floor(Math.random() * 20 - 10),
                        'Ropa': 48 + Math.floor(Math.random() * 16 - 8),
                        'Hogar': 55 + Math.floor(Math.random() * 14 - 7),
                        'Deportes': 62 + Math.floor(Math.random() * 18 - 9)
                    };
                    
                    this.externalData = {
                        ...this.externalData,
                        newsSentiment: sentiment
                    };
                    
                    this.apiStatus.sentiment = true;
                    
                } catch (error) {
                    console.warn('Error obteniendo sentimiento de noticias:', error);
                    this.apiStatus.sentiment = false;
                }
            }
            
            // Obtener datos de Google Trends
            async fetchGoogleTrendsData() {
                try {
                    const trends = {
                        'Electrónicos': 72 + Math.floor(Math.random() * 12 - 6),
                        'Ropa': 45 + Math.floor(Math.random() * 10 - 5),
                        'Hogar': 38 + Math.floor(Math.random() * 8 - 4),
                        'Deportes': 55 + Math.floor(Math.random() * 14 - 7)
                    };
                    
                    this.externalData = {
                        ...this.externalData,
                        googleTrends: trends
                    };
                    
                    this.apiStatus.googleTrends = true;
                    
                } catch (error) {
                    console.warn('Error obteniendo datos de Google Trends:', error);
                    this.apiStatus.googleTrends = false;
                }
            }
            
            // Crear modelo de predicción avanzado con múltiples capas
            async createAdvancedPredictionModel() {
                if (typeof tf === 'undefined') {
                    throw new Error('TensorFlow.js no está cargado correctamente');
                }
                
                // Modelo principal
                this.model = tf.sequential();
                
                // Capa de entrada con 17 características
                this.model.add(tf.layers.dense({
                    units: 32,
                    activation: 'relu',
                    inputShape: [17],
                    kernelRegularizer: tf.regularizers.l2({ l2: 0.001 })
                }));
                
                this.model.add(tf.layers.dropout({ rate: 0.2 }));
                
                this.model.add(tf.layers.dense({
                    units: 64,
                    activation: 'relu',
                    kernelRegularizer: tf.regularizers.l2({ l2: 0.001 })
                }));
                
                this.model.add(tf.layers.batchNormalization());
                this.model.add(tf.layers.dropout({ rate: 0.3 }));
                
                this.model.add(tf.layers.dense({
                    units: 32,
                    activation: 'relu'
                }));
                
                this.model.add(tf.layers.dense({
                    units: 16,
                    activation: 'relu'
                }));
                
                // Capa de salida
                this.model.add(tf.layers.dense({
                    units: 1,
                    activation: 'linear'
                }));
                
                // Optimizador con learning rate adaptativo
                const optimizer = tf.train.adam(0.001);
                
                this.model.compile({
                    optimizer: optimizer,
                    loss: 'meanSquaredError',
                    metrics: ['mae', 'mse']
                });
                
                console.log('Modelo avanzado de predicción creado exitosamente');
                
                // Crear modelos de ensemble (votación ponderada)
                await this.createEnsembleModels();
                
                return this.model;
            }
            
            // Crear modelos de ensemble para mayor precisión
            async createEnsembleModels() {
                this.ensembleModels = [];
                
                // Modelo 1: Red más profunda
                const model1 = tf.sequential();
                model1.add(tf.layers.dense({ units: 48, activation: 'relu', inputShape: [17] }));
                model1.add(tf.layers.dense({ units: 96, activation: 'relu' }));
                model1.add(tf.layers.dense({ units: 48, activation: 'relu' }));
                model1.add(tf.layers.dense({ units: 24, activation: 'relu' }));
                model1.add(tf.layers.dense({ units: 1 }));
                model1.compile({ optimizer: 'adam', loss: 'mse', metrics: ['mae'] });
                
                // Modelo 2: Red con regularización fuerte
                const model2 = tf.sequential();
                model2.add(tf.layers.dense({ units: 24, activation: 'relu', inputShape: [17] }));
                model2.add(tf.layers.dropout({ rate: 0.4 }));
                model2.add(tf.layers.dense({ units: 48, activation: 'relu' }));
                model2.add(tf.layers.dropout({ rate: 0.4 }));
                model2.add(tf.layers.dense({ units: 24, activation: 'relu' }));
                model2.add(tf.layers.dense({ units: 1 }));
                model2.compile({ optimizer: 'adam', loss: 'mse', metrics: ['mae'] });
                
                // Modelo 3: Red simple (para votación)
                const model3 = tf.sequential();
                model3.add(tf.layers.dense({ units: 32, activation: 'relu', inputShape: [17] }));
                model3.add(tf.layers.dense({ units: 16, activation: 'relu' }));
                model3.add(tf.layers.dense({ units: 8, activation: 'relu' }));
                model3.add(tf.layers.dense({ units: 1 }));
                model3.compile({ optimizer: 'adam', loss: 'mse', metrics: ['mae'] });
                
                this.ensembleModels = [model1, model2, model3];
            }
            
            // Preparar características avanzadas
            prepareAdvancedFeatures(products) {
                // Mapeo de categorías con encoding one-hot
                const categoryMap = {
                    'Electrónicos': [1, 0, 0, 0],
                    'Ropa': [0, 1, 0, 0],
                    'Hogar': [0, 0, 1, 0],
                    'Deportes': [0, 0, 0, 1]
                };
                
                const features = [];
                const labels = [];
                
                // Valores para normalización
                const maxPrice = Math.max(...products.map(p => p.price));
                const maxStock = Math.max(...products.map(p => p.stock));
                const maxMinStock = Math.max(1, ...products.map(p => getConfiguredMinimumStock(p)));
                
                products.forEach(product => {
                    // Datos externos para la categoría
                    const marketData = this.externalData?.marketTrends[product.category] || { 
                        trend: 1.0, sentiment: 0.5, volume: 500, momentum: 0 
                    };
                    const newsData = this.externalData?.newsSentiment[product.category] || 50;
                    const trendsData = this.externalData?.googleTrends[product.category] || 50;
                    
                    // Datos económicos
                    const economic = this.externalData?.economicIndicators || {
                        gdpGrowth: 2.0, inflation: 3.0, consumerConfidence: 70, retailGrowth: 3.0
                    };
                    
                    // Datos climáticos
                    const weather = this.externalData?.weather || { impactFactor: 1.0 };
                    
                    // Codificación de categoría
                    const categoryEncoding = categoryMap[product.category] || [0, 0, 0, 0];
                    
                    // Características avanzadas (17 características)
                    const productFeatures = [
                        // Características del producto
                        product.price / maxPrice,                    // Precio normalizado
                        product.stock / maxStock,                     // Stock actual
                        getConfiguredMinimumStock(product) / maxMinStock, // Stock mínimo
                        
                        // Características de mercado
                        marketData.trend,                              // Tendencia de mercado
                        marketData.sentiment,                          // Sentimiento de mercado
                        marketData.volume / 1000,                      // Volumen normalizado
                        marketData.momentum + 0.5,                     // Momentum ajustado
                        
                        // Sentimiento y tendencias
                        newsData / 100,                                 // Sentimiento de noticias
                        trendsData / 100,                               // Tendencias de búsqueda
                        
                        // Indicadores económicos
                        economic.gdpGrowth / 5,                         // Crecimiento PIB
                        economic.consumerConfidence / 100,              // Confianza consumidor
                        economic.retailGrowth / 10,                     // Crecimiento retail
                        
                        // Factores externos
                        weather.impactFactor,                           // Factor climático
                        
                        // Codificación categoría (one-hot)
                        ...categoryEncoding
                    ];
                    
                    features.push(productFeatures);
                    
                    // Etiqueta: ventas estimadas (target)
                    const estimatedSales = this.calculateAdvancedSalesEstimate(
                        product, marketData, newsData, trendsData, economic, weather
                    );
                    labels.push(estimatedSales);
                });
                
                return {
                    features: tf.tensor2d(features),
                    labels: tf.tensor1d(labels)
                };
            }
            
            // Cálculo avanzado de ventas estimadas
            calculateAdvancedSalesEstimate(product, marketData, newsData, trendsData, economic, weather) {
                // Factores base
                const priceFactor = Math.max(0.2, 1 - (product.price / 2000));
                const stockFactor = Math.min(1.5, product.stock / 30);
                const categoryBase = product.category === 'Electrónicos' ? 1.3 : 
                                    product.category === 'Deportes' ? 1.2 : 
                                    product.category === 'Ropa' ? 0.9 : 1.0;
                
                // Factores de mercado ponderados
                const marketFactor = marketData.trend * marketData.sentiment * 
                                    (1 + marketData.momentum);
                
                // Factores externos ponderados
                const externalFactor = (newsData / 100) * (trendsData / 100) * 
                                      (economic.consumerConfidence / 70) * weather.impactFactor;
                
                // Ventas base
                const baseSales = 20;
                
                // Cálculo avanzado con pesos específicos
                const calculatedSales = baseSales * categoryBase + 
                    (priceFactor * 30) +
                    (stockFactor * 10) +
                    (marketFactor * 25) +
                    (externalFactor * 20) +
                    0;
                
                return Math.max(5, Math.min(150, Math.round(calculatedSales)));
            }
            
            // Entrenar modelo con validación cruzada
            async trainModelWithCrossValidation(products, epochs = 100) {
                if (!this.model) {
                    await this.createAdvancedPredictionModel();
                }
                
                this.isTraining = true;
                this.trainingHistory = { loss: [], val_loss: [], mae: [], val_mae: [], accuracy: [], val_accuracy: [] };
                
                try {
                    const { features, labels } = this.prepareAdvancedFeatures(products);
                    
                    // Validación cruzada (80% entrenamiento, 20% validación)
                    if (!products.length) {
                        throw new Error('No hay productos suficientes para entrenar el modelo');
                    }
                    const splitIndex = products.length > 1
                        ? Math.min(products.length - 1, Math.max(1, Math.floor(products.length * 0.8)))
                        : 1;
                    const trainFeatures = features.slice(0, splitIndex);
                    const trainLabels = labels.slice(0, splitIndex);
                    const valFeatures = products.length > 1 ? features.slice(splitIndex) : features.slice(0, 1);
                    const valLabels = products.length > 1 ? labels.slice(splitIndex) : labels.slice(0, 1);
                    
                    // Entrenamiento con early stopping
                    let bestLoss = Infinity;
                    let patience = 0;
                    
                    for (let epoch = 0; epoch < epochs; epoch++) {
                        const history = await this.model.fit(trainFeatures, trainLabels, {
                            epochs: 1,
                            batchSize: 4,
                            validationData: [valFeatures, valLabels],
                            verbose: 0
                        });
                        
                        const loss = history.history.loss[0];
                        const valLoss = history.history.val_loss[0];
                        const mae = history.history.mae[0];
                        const valMae = history.history.val_mae[0];
                        
                        this.trainingHistory.loss.push(loss);
                        this.trainingHistory.val_loss.push(valLoss);
                        this.trainingHistory.mae.push(mae);
                        this.trainingHistory.val_mae.push(valMae);
                        
                        // Calcular precisión aproximada
                        const accuracy = Math.max(0, 100 - (mae * 5));
                        const valAccuracy = Math.max(0, 100 - (valMae * 5));
                        this.trainingHistory.accuracy.push(accuracy);
                        this.trainingHistory.val_accuracy.push(valAccuracy);
                        
                        // Early stopping
                        if (valLoss < bestLoss) {
                            bestLoss = valLoss;
                            patience = 0;
                        } else {
                            patience++;
                            if (patience >= 10) {
                                console.log(`Early stopping en época ${epoch + 1}`);
                                break;
                            }
                        }
                        
                        if (window.updateTrainingProgress) {
                            window.updateTrainingProgress(epoch + 1, epochs, loss, valLoss, accuracy);
                        }
                    }

                    await Promise.all(this.ensembleModels.map(model => model.fit(trainFeatures, trainLabels, {
                        epochs: Math.max(10, Math.min(epochs, 30)),
                        batchSize: Math.min(4, products.length),
                        validationData: [valFeatures, valLabels],
                        verbose: 0
                    })));
                    
                    // Calcular métricas finales
                    const predictions = this.model.predict(valFeatures);
                    const predValues = await predictions.data();
                    const trueValues = await valLabels.data();
                    
                    // Calcular MSE, MAE, R²
                    let mse = 0, mae = 0;
                    const mean = trueValues.reduce((a, b) => a + b, 0) / trueValues.length;
                    let ssRes = 0, ssTot = 0;
                    
                    for (let i = 0; i < predValues.length; i++) {
                        mse += Math.pow(predValues[i] - trueValues[i], 2);
                        mae += Math.abs(predValues[i] - trueValues[i]);
                        ssRes += Math.pow(predValues[i] - trueValues[i], 2);
                        ssTot += Math.pow(trueValues[i] - mean, 2);
                    }
                    
                    mse /= predValues.length;
                    mae /= predValues.length;
                    const rawR2 = ssTot === 0 ? 0 : 1 - (ssRes / ssTot);
                    const r2 = Number.isFinite(rawR2) ? Math.max(0, Math.min(1, rawR2)) : 0;
                    const confidence = ssTot === 0 ? 0 : Math.round(r2 * 100);
                    
                    this.modelMetrics = {
                        mse: mse,
                        mae: mae,
                        r2: r2,
                        confidence: confidence
                    };
                    this.modelsTrained = true;
                    
                    this.isTraining = false;
                    
                    // Liberar memoria
                    features.dispose();
                    labels.dispose();
                    trainFeatures.dispose();
                    trainLabels.dispose();
                    valFeatures.dispose();
                    valLabels.dispose();
                    predictions.dispose();
                    
                    return this.trainingHistory;
                } catch (error) {
                    this.isTraining = false;
                    console.error('Error entrenando el modelo:', error);
                    throw error;
                }
            }
            
            // Predecir con ensemble (votación ponderada)
            async predictWithEnsemble(products) {
                if (!this.modelsTrained || !this.model || this.ensembleModels.length === 0) {
                    throw new Error('Los modelos no han sido entrenados');
                }
                
                const { features } = this.prepareAdvancedFeatures(products);
                
                // Predicciones de cada modelo
                const predictions = [];
                
                // Modelo principal
                const mainPred = this.model.predict(features);
                predictions.push(await mainPred.data());
                
                // Modelos ensemble
                for (const model of this.ensembleModels) {
                    const pred = model.predict(features);
                    predictions.push(await pred.data());
                    pred.dispose();
                }
                
                // Votación ponderada (pesos basados en precisión)
                const weights = [0.5, 0.2, 0.15, 0.15]; // Modelo principal tiene más peso
                const ensemblePredictions = [];
                
                for (let i = 0; i < predictions[0].length; i++) {
                    let weightedSum = 0;
                    for (let j = 0; j < predictions.length; j++) {
                        weightedSum += predictions[j][i] * weights[j];
                    }
                    ensemblePredictions.push(Math.max(0, Math.round(weightedSum)));
                }
                
                // Liberar memoria
                features.dispose();
                mainPred.dispose();
                
                // Calcular intervalo de confianza
                const predictionsMatrix = predictions.map(p => Array.from(p));
                const confidenceIntervals = [];
                
                for (let i = 0; i < predictions[0].length; i++) {
                    const values = predictionsMatrix.map(p => p[i]);
                    const mean = values.reduce((a, b) => a + b, 0) / values.length;
                    const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length;
                    const stdDev = Math.sqrt(variance);
                    confidenceIntervals.push({
                        lower: Math.max(0, mean - 1.96 * stdDev),
                        upper: mean + 1.96 * stdDev
                    });
                }
                
                // Combinar con información del producto
                const results = products.map((product, index) => {
                    const marketData = this.externalData?.marketTrends[product.category] || { 
                        trend: 1.0, sentiment: 0.5, volume: 500, momentum: 0 
                    };
                    const newsData = this.externalData?.newsSentiment[product.category] || 50;
                    const economic = this.externalData?.economicIndicators || { consumerConfidence: 70 };
                    
                    const confidence = confidenceIntervals[index];
                    const prediction = ensemblePredictions[index];
                    
                    return {
                        ...product,
                        predictedSales: prediction,
                        confidenceInterval: confidence,
                        confidence: this.modelMetrics.confidence,
                        reorderRecommendation: this.getIntelligentRecommendation(
                            product, prediction, marketData, economic, confidence
                        ),
                        marketTrend: marketData.trend,
                        marketSentiment: marketData.sentiment,
                        newsSentiment: newsData,
                        economicOutlook: this.getEconomicOutlook(economic),
                        opportunityScore: this.calculateOpportunityScore(
                            product, prediction, marketData, newsData, economic, confidence
                        ),
                        riskLevel: this.calculateRiskLevel(product, prediction, marketData, confidence),
                        lastUpdated: this.lastUpdate
                    };
                });
                
                return results;
            }
            
            // Recomendación inteligente
            getIntelligentRecommendation(product, predictedSales, marketData, economic, confidence) {
                const weeksOfSupply = product.stock / (predictedSales / 4.33);
                const marketStrength = marketData.trend * marketData.sentiment;
                const economicStrength = economic.consumerConfidence / 70;
                
                // Nivel de riesgo
                const riskScore = (product.stock === 0) ? 100 :
                                 (product.stock <= product.minStock) ? 80 :
                                 (weeksOfSupply < 1) ? 90 :
                                 (weeksOfSupply < 2) ? 70 :
                                 (weeksOfSupply < 3) ? 50 :
                                 (weeksOfSupply > 10) ? 30 : 20;
                
                if (product.stock === 0) {
                    return {
                        action: 'URGENTE - Sin stock',
                        priority: 'critical',
                        message: 'Producto agotado. Reordenar inmediatamente.',
                        riskScore: 100
                    };
                }
                
                if (weeksOfSupply < 1) {
                    return {
                        action: 'Reordenar URGENTE',
                        priority: 'critical',
                        message: `Stock para menos de 1 semana. Pedir ${Math.ceil(predictedSales * 2)} unidades.`,
                        riskScore: 90
                    };
                }
                
                if (weeksOfSupply < 2) {
                    const urgency = marketStrength > 1.1 ? 'ALTA' : 'Media';
                    return {
                        action: `Reordenar - Urgencia ${urgency}`,
                        priority: 'high',
                        message: `Stock para ${weeksOfSupply.toFixed(1)} semanas. Considerar pedido.`,
                        riskScore: 70
                    };
                }
                
                if (weeksOfSupply < 3) {
                    return {
                        action: 'Monitorear stock',
                        priority: 'medium',
                        message: `Stock para ${weeksOfSupply.toFixed(1)} semanas. Programar revisión.`,
                        riskScore: 50
                    };
                }
                
                if (weeksOfSupply > 10) {
                    return {
                        action: 'Exceso de inventario',
                        priority: 'low',
                        message: `Stock para ${weeksOfSupply.toFixed(1)} semanas. Considerar promociones.`,
                        riskScore: 30
                    };
                }
                
                return {
                    action: 'Nivel adecuado',
                    priority: 'normal',
                    message: `Stock óptimo para ${weeksOfSupply.toFixed(1)} semanas.`,
                    riskScore: 20
                };
            }
            
            // Calcular puntuación de oportunidad
            calculateOpportunityScore(product, predictedSales, marketData, newsData, economic, confidence) {
                let score = 0;
                
                // Factor de stock (30 puntos máx)
                if (product.stock === 0) score += 30;
                else if (product.stock <= product.minStock) score += 25;
                else if (product.stock <= product.minStock * 2) score += 15;
                
                // Factor de ventas previstas (20 puntos)
                const salesFactor = Math.min(20, (predictedSales / 30) * 20);
                score += salesFactor;
                
                // Factor de tendencia de mercado (15 puntos)
                score += (marketData.trend - 0.8) * 30;
                
                // Factor de sentimiento (10 puntos)
                score += (marketData.sentiment - 0.4) * 20;
                
                // Factor de noticias (10 puntos)
                score += ((newsData - 40) / 60) * 10;
                
                // Factor económico (10 puntos)
                score += ((economic.consumerConfidence - 50) / 50) * 10;
                
                // Factor de confianza en predicción (5 puntos)
                score += (confidence.upper - confidence.lower) < 20 ? 5 : 0;
                
                return Math.min(100, Math.max(0, Math.round(score)));
            }
            
            // Calcular nivel de riesgo
            calculateRiskLevel(product, predictedSales, marketData, confidence) {
                const weeksOfSupply = product.stock / (predictedSales / 4.33);
                
                let risk = 0;
                risk += (product.stock === 0) ? 40 : 0;
                risk += (weeksOfSupply < 1) ? 30 : (weeksOfSupply < 2) ? 20 : (weeksOfSupply > 10) ? 15 : 5;
                risk += marketData.trend < 0.9 ? 15 : 0;
                risk += (confidence.upper - confidence.lower) > 30 ? 10 : 0;
                
                if (risk >= 70) return 'Alto';
                if (risk >= 40) return 'Medio';
                return 'Bajo';
            }
            
            // Obtener perspectiva económica
            getEconomicOutlook(economic) {
                if (!economic) return 'Neutral';
                
                const score = (economic.gdpGrowth > 2.5 ? 1 : 0) +
                            (economic.inflation < 3.5 ? 1 : 0) +
                            (economic.consumerConfidence > 70 ? 1 : 0) +
                            (economic.retailGrowth > 4 ? 1 : 0);
                
                if (score >= 3) return 'Muy positivo';
                if (score >= 2) return 'Positivo';
                if (score >= 1) return 'Neutral';
                return 'Negativo';
            }
            
            // Obtener datos para gráfico de entrenamiento
            getTrainingChartData() {
                if (!this.trainingHistory.loss.length) return null;
                
                return {
                    labels: Array.from({length: this.trainingHistory.loss.length}, (_, i) => i + 1),
                    datasets: [
                        {
                            label: 'Pérdida Entrenamiento',
                            data: this.trainingHistory.loss,
                            borderColor: '#3a5ec7',
                            backgroundColor: 'rgba(58, 94, 199, 0.1)',
                            fill: true,
                            tension: 0.4,
                            yAxisID: 'y-loss'
                        },
                        {
                            label: 'Pérdida Validación',
                            data: this.trainingHistory.val_loss,
                            borderColor: '#28a745',
                            backgroundColor: 'rgba(40, 167, 69, 0.1)',
                            fill: true,
                            tension: 0.4,
                            yAxisID: 'y-loss'
                        },
                        {
                            label: 'Precisión Entrenamiento',
                            data: this.trainingHistory.accuracy,
                            borderColor: '#ffc107',
                            backgroundColor: 'rgba(255, 193, 7, 0.1)',
                            fill: true,
                            tension: 0.4,
                            yAxisID: 'y-accuracy'
                        },
                        {
                            label: 'Precisión Validación',
                            data: this.trainingHistory.val_accuracy,
                            borderColor: '#17a2b8',
                            backgroundColor: 'rgba(23, 162, 184, 0.1)',
                            fill: true,
                            tension: 0.4,
                            yAxisID: 'y-accuracy'
                        }
                    ]
                };
            }
            
            // Obtener métricas del modelo
            getModelMetrics() {
                return this.modelMetrics;
            }
            
            // Obtener estado de las APIs
            getAPIStatus() {
                const overall = Object.values(this.apiStatus).some(status => status);
                return {
                    ...this.apiStatus,
                    lastUpdate: this.lastUpdate,
                    overall: overall,
                    connectedCount: Object.values(this.apiStatus).filter(Boolean).length,
                    totalCount: Object.keys(this.apiStatus).length
                };
            }
        }

        // ============================================
        // CLASE PARA GENERAR REPORTES
        // ============================================
        class AdvancedReportGenerator {
            constructor() {
                this.currentReportType = 'inventory';
                this.currentFilters = {};
                this.charts = {};
            }
            
            generateReport(type, filters = {}) {
                this.currentReportType = type;
                this.currentFilters = filters;
                
                switch(type) {
                    case 'inventory':
                        return this.generateInventoryReport(filters);
                    case 'stock':
                        return this.generateStockReport(filters);
                    case 'categories':
                        return this.generateCategoriesReport(filters);
                    case 'valuation':
                        return this.generateValuationReport(filters);
                    case 'trends':
                        return this.generateTrendsReport(filters);
                    case 'comparison':
                        return this.generateComparisonReport(filters);
                    case 'ai':
                        return this.generateAIReport(filters);
                    default:
                        return this.generateInventoryReport(filters);
                }
            }
            
            applyFilters(products, filters) {
                let filtered = [...products];
                
                // Filtrar por categoría
                if (filters.category && filters.category !== 'all') {
                    filtered = filtered.filter(p => p.category === filters.category);
                }
                
                // Filtrar por estado de stock
                if (filters.stockStatus && filters.stockStatus !== 'all') {
                    filtered = filtered.filter(p => {
                        const status = productManager.getProductStatus(p.stock);
                        return status === filters.stockStatus;
                    });
                }
                
                // Filtrar por rango de precios
                const minPrice = Number(filters.minPrice);
                const maxPrice = Number(filters.maxPrice);
                const minStock = Number(filters.minStock);
                const maxStock = Number(filters.maxStock);
                if (filters.minPrice !== '' && Number.isFinite(minPrice)) {
                    filtered = filtered.filter(p => Number(p.price) >= minPrice);
                }
                if (filters.maxPrice !== '' && Number.isFinite(maxPrice)) {
                    filtered = filtered.filter(p => Number(p.price) <= maxPrice);
                }
                
                // Filtrar por rango de stock
                if (filters.minStock !== '' && Number.isInteger(minStock)) {
                    filtered = filtered.filter(p => Number(p.stock) >= minStock);
                }
                if (filters.maxStock !== '' && Number.isInteger(maxStock)) {
                    filtered = filtered.filter(p => Number(p.stock) <= maxStock);
                }
                
                // Ordenar
                if (filters.sortBy) {
                    switch(filters.sortBy) {
                        case 'name':
                            filtered.sort((a, b) => a.name.localeCompare(b.name));
                            break;
                        case 'name_desc':
                            filtered.sort((a, b) => b.name.localeCompare(a.name));
                            break;
                        case 'price':
                            filtered.sort((a, b) => a.price - b.price);
                            break;
                        case 'price_desc':
                            filtered.sort((a, b) => b.price - a.price);
                            break;
                        case 'stock':
                            filtered.sort((a, b) => a.stock - b.stock);
                            break;
                        case 'stock_desc':
                            filtered.sort((a, b) => b.stock - a.stock);
                            break;
                        case 'value':
                            filtered.sort((a, b) => (a.price * a.stock) - (b.price * b.stock));
                            break;
                        case 'value_desc':
                            filtered.sort((a, b) => (b.price * b.stock) - (a.price * a.stock));
                            break;
                    }
                }
                
                return filtered;
            }
            
            generateInventoryReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                const summary = summarizeProducts(products);
                
                if (products.length === 0) {
                    return this.generateEmptyState('No hay productos que coincidan con los filtros aplicados');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title"><i class="fas fa-boxes me-2"></i>Reporte de Inventario General</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()} a las ${new Date().toLocaleTimeString()}</div>
                    </div>
                    
                    <div class="stats-cards">
                        <div class="stat-card">
                            <i class="fas fa-box fa-2x mb-2" style="color: var(--primary);"></i>
                            <div class="stat-title">Total de Productos</div>
                            <div class="stat-value">${products.length}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-dollar-sign fa-2x mb-2" style="color: var(--secondary);"></i>
                            <div class="stat-title">Valor Total del Inventario</div>
                            <div class="stat-value">$${summary.totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-exclamation-triangle fa-2x mb-2" style="color: var(--warning);"></i>
                            <div class="stat-title">Productos con Stock Bajo</div>
                            <div class="stat-value">${summary.lowStock}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-times-circle fa-2x mb-2" style="color: var(--danger);"></i>
                            <div class="stat-title">Productos Agotados</div>
                            <div class="stat-value">${summary.outOfStock}</div>
                        </div>
                    </div>
                    
                    <h3><i class="fas fa-list me-2"></i>Lista de Productos</h3>
                    <div class="table-responsive">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Precio</th>
                                    <th>Stock</th>
                                    <th>Stock Mínimo</th>
                                    <th>Valor Total</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                products.forEach(product => {
                    const status = productManager.getProductStatus(product.stock, getConfiguredMinimumStock(product));
                    const statusClass = productManager.getStatusClass(product.stock, getConfiguredMinimumStock(product));
                    const totalValue = product.price * product.stock;
                    
                    html += `
                        <tr>
                            <td><span class="badge bg-primary">${product.id}</span></td>
                            <td><strong>${product.name}</strong></td>
                            <td>${product.category}</td>
                            <td>$${product.price.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>${product.stock}</td>
                            <td>${getConfiguredMinimumStock(product)}</td>
                            <td>$${totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td><span class="badge ${statusClass}">${status}</span></td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Insights Rápidos</h5>
                        <div class="insight-item">
                            <strong>Valor promedio por producto:</strong> $${(summary.totalValue / products.length).toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                        </div>
                        <div class="insight-item">
                            <strong>Producto más valioso:</strong> ${products.reduce((max, p) => (p.price * p.stock) > (max.price * max.stock) ? p : max).name}
                        </div>
                        <div class="insight-item">
                            <strong>Necesitan reorden:</strong> ${summary.lowStock} productos requieren atención
                        </div>
                    </div>
                    
                    <div class="report-footer">
                        <i class="fas fa-robot me-2"></i>Reporte generado por SmartStock AI - Página 1 de 1
                    </div>
                `;
                
                return html;
            }
            
            generateStockReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                const lowStockProducts = products.filter(p => p.stock <= getConfiguredMinimumStock(p));
                
                if (lowStockProducts.length === 0) {
                    return this.generateEmptyState('No hay productos con stock bajo o crítico');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title"><i class="fas fa-exclamation-triangle me-2"></i>Reporte de Niveles de Stock</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div class="stats-cards">
                        <div class="stat-card">
                            <i class="fas fa-exclamation-triangle fa-2x mb-2" style="color: var(--warning);"></i>
                            <div class="stat-title">Stock Bajo</div>
                            <div class="stat-value">${lowStockProducts.filter(p => p.stock > getConfiguredMinimumStock(p) * 0.2).length}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-exclamation-circle fa-2x mb-2" style="color: var(--danger);"></i>
                            <div class="stat-title">Stock Crítico</div>
                            <div class="stat-value">${lowStockProducts.filter(p => p.stock <= getConfiguredMinimumStock(p) * 0.2 && p.stock > 0).length}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-times-circle fa-2x mb-2" style="color: var(--danger);"></i>
                            <div class="stat-title">Agotados</div>
                            <div class="stat-value">${products.filter(p => p.stock === 0).length}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-boxes fa-2x mb-2" style="color: var(--primary);"></i>
                            <div class="stat-title">Total Afectados</div>
                            <div class="stat-value">${lowStockProducts.length}</div>
                        </div>
                    </div>
                    
                    <h3><i class="fas fa-list me-2"></i>Productos que Requieren Atención</h3>
                    <div class="table-responsive">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Stock Actual</th>
                                    <th>Stock Mínimo</th>
                                    <th>Déficit</th>
                                    <th>Prioridad</th>
                                    <th>Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                lowStockProducts.sort((a, b) => (a.stock / (a.minStock || 10)) - (b.stock / (b.minStock || 10))).forEach(product => {
                    const deficit = getConfiguredMinimumStock(product) - product.stock;
                    const priority = deficit > 10 ? 'Alta' : deficit > 5 ? 'Media' : 'Baja';
                    const priorityClass = deficit > 10 ? 'bg-danger' : deficit > 5 ? 'bg-warning' : 'bg-info';
                    
                    html += `
                        <tr>
                            <td><span class="badge bg-primary">${product.id}</span></td>
                            <td><strong>${product.name}</strong></td>
                            <td>${product.category}</td>
                            <td class="${product.stock === 0 ? 'text-danger fw-bold' : ''}">${product.stock}</td>
                            <td>${getConfiguredMinimumStock(product)}</td>
                            <td class="fw-bold">${deficit > 0 ? deficit : 0}</td>
                            <td><span class="badge ${priorityClass}">${priority}</span></td>
                            <td><button class="btn btn-sm btn-primary" onclick="quickOrder('${product.id}')"><i class="fas fa-shopping-cart me-1"></i>Ordenar</button></td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Recomendaciones</h5>
                        <div class="insight-item">
                            <strong>Acción inmediata:</strong> ${lowStockProducts.filter(p => p.stock <= 5).length} productos necesitan reabastecimiento urgente.
                        </div>
                        <div class="insight-item">
                            <strong>Valor de reorden estimado:</strong> ${formatReportCurrency(lowStockProducts.reduce((sum, p) => sum + (p.price * Math.max(0, getConfiguredMinimumStock(p) - p.stock)), 0))}
                        </div>
                        <div class="insight-item">
                            <strong>Proveedores a contactar:</strong> ${[...new Set(lowStockProducts.map(p => p.category))].join(', ')}
                        </div>
                    </div>
                    
                    <div class="report-footer">
                        <i class="fas fa-robot me-2"></i>Reporte generado por SmartStock AI - Página 1 de 1
                    </div>
                `;
                
                return html;
            }
            
            generateCategoriesReport(filters = {}) {
                const filteredProducts = this.applyFilters(productManager.getAllProducts(), filters);
                const productsByCategory = filteredProducts.reduce((groups, product) => {
                    (groups[product.category] ||= []).push(product);
                    return groups;
                }, {});
                const summary = summarizeProducts(filteredProducts);
                
                if (Object.keys(productsByCategory).length === 0) {
                    return this.generateEmptyState('No hay categorías con productos');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title"><i class="fas fa-tags me-2"></i>Reporte por Categorías</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div class="stats-cards">
                `;
                
                // Tarjetas de resumen por categoría
                Object.keys(summary.byCategory).forEach(category => {
                    const categoryData = summary.byCategory[category];
                    html += `
                        <div class="stat-card">
                            <i class="fas fa-folder fa-2x mb-2" style="color: var(--primary);"></i>
                            <div class="stat-title">${category}</div>
                            <div class="stat-value">${categoryData.count}</div>
                            <div class="small">Valor: $${categoryData.value.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                        </div>
                    `;
                });
                
                html += `
                    </div>
                `;
                
                // Tablas detalladas por categoría
                Object.keys(productsByCategory).forEach(category => {
                    const products = productsByCategory[category];
                    const categoryValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0);
                    
                    html += `
                        <h3><i class="fas fa-folder-open me-2"></i>Categoría: ${category} <small class="text-muted">(Total: $${categoryValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})})</small></h3>
                        <div class="table-responsive">
                            <table class="report-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Producto</th>
                                        <th>Precio</th>
                                        <th>Stock</th>
                                        <th>Stock Mínimo</th>
                                        <th>Valor Total</th>
                                        <th>Estado</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;
                    
                    products.forEach(product => {
                        const status = productManager.getProductStatus(product.stock, getConfiguredMinimumStock(product));
                        const statusClass = productManager.getStatusClass(product.stock, getConfiguredMinimumStock(product));
                        const totalValue = product.price * product.stock;
                        
                        html += `
                            <tr>
                                <td><span class="badge bg-primary">${product.id}</span></td>
                                <td><strong>${product.name}</strong></td>
                                <td>$${product.price.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                <td>${product.stock}</td>
                                <td>${getConfiguredMinimumStock(product)}</td>
                                <td>$${totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                <td><span class="badge ${statusClass}">${status}</span></td>
                            </tr>
                        `;
                    });
                    
                    html += `
                                </tbody>
                            </table>
                        </div>
                    `;
                });
                
                html += `
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Análisis por Categoría</h5>
                        <div class="insight-item">
                            <strong>Categoría con mayor valor:</strong> ${Object.keys(summary.byCategory).reduce((a, b) => summary.byCategory[a].value > summary.byCategory[b].value ? a : b)} ($${Math.max(...Object.values(summary.byCategory).map(c => c.value)).toLocaleString()})
                        </div>
                        <div class="insight-item">
                            <strong>Categoría con más productos:</strong> ${Object.keys(summary.byCategory).reduce((a, b) => summary.byCategory[a].count > summary.byCategory[b].count ? a : b)} (${Math.max(...Object.values(summary.byCategory).map(c => c.count))} productos)
                        </div>
                        <div class="insight-item">
                            <strong>Distribución:</strong> ${Object.keys(summary.byCategory).length} categorías activas
                        </div>
                    </div>
                    
                    <div class="chart-container">
                        <canvas id="categoryChart"></canvas>
                    </div>
                    
                    <div class="report-footer">
                        <i class="fas fa-robot me-2"></i>Reporte generado por SmartStock AI - Página 1 de 1
                    </div>
                `;
                
                // Generar gráfico después de que se renderice el HTML
                setTimeout(() => {
                    this.generateCategoryChart(productsByCategory);
                }, 100);
                
                return html;
            }
            
            generateValuationReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                const summary = summarizeProducts(products);
                
                if (products.length === 0) {
                    return this.generateEmptyState('No hay productos que coincidan con los filtros aplicados');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title"><i class="fas fa-dollar-sign me-2"></i>Reporte de Valoración de Inventario</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div class="stats-cards">
                        <div class="stat-card">
                            <i class="fas fa-dollar-sign fa-2x mb-2" style="color: var(--primary);"></i>
                            <div class="stat-title">Valor Total</div>
                            <div class="stat-value">$${summary.totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-chart-line fa-2x mb-2" style="color: var(--secondary);"></i>
                            <div class="stat-title">Valor Promedio</div>
                            <div class="stat-value">$${(summary.totalValue / products.length).toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-arrow-up fa-2x mb-2" style="color: var(--success);"></i>
                            <div class="stat-title">Productos Alto Valor</div>
                            <div class="stat-value">${products.filter(p => (p.price * p.stock) > 1000).length}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-arrow-down fa-2x mb-2" style="color: var(--warning);"></i>
                            <div class="stat-title">Productos Bajo Valor</div>
                            <div class="stat-value">${products.filter(p => (p.price * p.stock) < 100).length}</div>
                        </div>
                    </div>
                    
                    <h3><i class="fas fa-list me-2"></i>Productos por Valor Total</h3>
                    <div class="table-responsive">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Precio Unitario</th>
                                    <th>Stock</th>
                                    <th>Valor Total</th>
                                    <th>% del Inventario</th>
                                    <th>Clasificación</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                // Ordenar productos por valor total (descendente)
                const sortedProducts = [...products].sort((a, b) => (b.price * b.stock) - (a.price * a.stock));
                
                sortedProducts.forEach(product => {
                    const totalValue = product.price * product.stock;
                    const percentage = (totalValue / summary.totalValue) * 100;
                    const classification = totalValue > 5000 ? 'A' : totalValue > 1000 ? 'B' : totalValue > 500 ? 'C' : 'D';
                    const classColor = classification === 'A' ? 'bg-danger' : classification === 'B' ? 'bg-warning' : classification === 'C' ? 'bg-info' : 'bg-secondary';
                    
                    html += `
                        <tr>
                            <td><strong>${product.name}</strong></td>
                            <td>${product.category}</td>
                            <td>$${product.price.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>${product.stock}</td>
                            <td class="fw-bold">$${totalValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>${percentage.toFixed(2)}%</td>
                            <td><span class="badge ${classColor}">Clase ${classification}</span></td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="chart-container">
                        <canvas id="valuationChart"></canvas>
                    </div>
                    
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Análisis de Valor</h5>
                        <div class="insight-item">
                            <strong>Concentración de valor (Regla 80/20):</strong> Los ${Math.ceil(products.length * 0.2)} productos más valiosos representan el ${this.calculateTopPercentage(sortedProducts, Math.ceil(products.length * 0.2), summary.totalValue)}% del inventario.
                        </div>
                        <div class="insight-item">
                            <strong>Producto estrella:</strong> ${sortedProducts[0].name} ($${sortedProducts[0].price * sortedProducts[0].stock})
                        </div>
                        <div class="insight-item">
                            <strong>Rotación recomendada:</strong> Priorizar gestión de productos Clase A y B
                        </div>
                    </div>
                    
                    <div class="report-footer">
                        <i class="fas fa-robot me-2"></i>Reporte generado por SmartStock AI - Página 1 de 1
                    </div>
                `;
                
                // Generar gráfico después de que se renderice el HTML
                setTimeout(() => {
                    this.generateValuationChart(sortedProducts);
                }, 100);
                
                return html;
            }
            
            generateTrendsReport(filters = {}) {
                const historicalData = productManager.getEnhancedHistoricalData();
                const forecast = this.generateForecast(historicalData);
                const categoryTrends = productManager.getCategoryTrends();
                const months = Object.keys(historicalData);
                const values = months.map(month => historicalData[month].totalValue);
                const productCounts = months.map(month => historicalData[month].totalProducts);
                
                // Calcular tendencias
                const growthRate = ((values[values.length - 1] - values[0]) / values[0] * 100).toFixed(1);
                const recentGrowth = ((values[values.length - 1] - values[values.length - 4]) / values[values.length - 4] * 100).toFixed(1);
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title"><i class="fas fa-chart-line me-2"></i>Reporte de Tendencias Avanzado</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()} | Análisis de 24 meses</div>
                    </div>
                    
                    <div class="stats-cards">
                        <div class="stat-card">
                            <i class="fas fa-chart-line fa-2x mb-2" style="color: var(--primary);"></i>
                            <div class="stat-title">Tendencia General</div>
                            <div class="stat-value ${growthRate > 0 ? 'trend-up' : 'trend-down'}">${growthRate}%</div>
                            <div class="small">Últimos 24 meses</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-chart-bar fa-2x mb-2" style="color: var(--secondary);"></i>
                            <div class="stat-title">Tendencia Reciente</div>
                            <div class="stat-value ${recentGrowth > 0 ? 'trend-up' : 'trend-down'}">${recentGrowth}%</div>
                            <div class="small">Últimos 3 meses</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-calendar-alt fa-2x mb-2" style="color: var(--info);"></i>
                            <div class="stat-title">Valor Promedio</div>
                            <div class="stat-value">$${(values.reduce((a, b) => a + b, 0) / values.length).toLocaleString()}</div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-boxes fa-2x mb-2" style="color: var(--warning);"></i>
                            <div class="stat-title">Pico Estacional</div>
                            <div class="stat-value">${this.identifyPeakMonth(historicalData)}</div>
                        </div>
                    </div>
                    
                    <!-- Análisis de Tendencias por Categoría -->
                    <h3><i class="fas fa-chart-pie me-2"></i>Tendencias por Categoría</h3>
                    <div class="category-trends">
                `;
                
                Object.keys(categoryTrends).forEach(category => {
                    const trend = categoryTrends[category];
                    const trendClass = trend.growthRate > 5 ? 'trend-up' : trend.growthRate < 0 ? 'trend-down' : '';
                    const iconClass = category === 'Electrónicos' ? 'fa-laptop' : 
                                    category === 'Ropa' ? 'fa-tshirt' :
                                    category === 'Hogar' ? 'fa-home' : 'fa-futbol';
                    
                    html += `
                        <div class="category-trend-card">
                            <i class="fas ${iconClass} fa-2x mb-2" style="color: var(--primary);"></i>
                            <h6>${category}</h6>
                            <div class="category-trend-value ${trendClass}">${trend.growthRate > 0 ? '+' : ''}${trend.growthRate.toFixed(1)}%</div>
                            <div class="trend-description">
                                <div><strong>Valor:</strong> $${trend.currentValue.toLocaleString()}</div>
                                <div><strong>Estacionalidad:</strong> ${trend.seasonality}</div>
                                <div><strong>Rendimiento:</strong> ${trend.performance}</div>
                                <div><strong>Acción:</strong> ${trend.recommendedAction}</div>
                            </div>
                        </div>
                    `;
                });
                
                html += `
                    </div>
                    
                    <!-- Tabs para diferentes análisis -->
                    <div class="trend-analysis-tabs">
                        <ul class="nav nav-tabs" id="trendTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="value-tab" data-bs-toggle="tab" data-bs-target="#value-tab-pane" type="button" role="tab">Valor del Inventario</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="products-tab" data-bs-toggle="tab" data-bs-target="#products-tab-pane" type="button" role="tab">Cantidad de Productos</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="seasonal-tab" data-bs-toggle="tab" data-bs-target="#seasonal-tab-pane" type="button" role="tab">Patrones Estacionales</button>
                            </li>
                        </ul>
                        <div class="tab-content analysis-tab-content" id="trendTabContent">
                            <div class="tab-pane fade show active" id="value-tab-pane" role="tabpanel">
                                <h4><i class="fas fa-chart-line me-2"></i>Evolución del Valor del Inventario</h4>
                                <div class="chart-container">
                                    <canvas id="trendsValueChart"></canvas>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="products-tab-pane" role="tabpanel">
                                <h4><i class="fas fa-boxes me-2"></i>Evolución de la Cantidad de Productos</h4>
                                <div class="chart-container">
                                    <canvas id="trendsProductsChart"></canvas>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="seasonal-tab-pane" role="tabpanel">
                                <h4><i class="fas fa-calendar-alt me-2"></i>Análisis de Patrones Estacionales</h4>
                                <div class="seasonal-pattern">
                                    <div class="chart-container">
                                        <canvas id="seasonalChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Indicadores de Rendimiento -->
                    <h3><i class="fas fa-chart-bar me-2"></i>Indicadores de Rendimiento</h3>
                    <div class="performance-comparison">
                        <div class="performance-card">
                            <h6>Crecimiento Anual</h6>
                            <div class="performance-value ${growthRate > 0 ? 'trend-up' : 'trend-down'}">
                                ${growthRate}%
                            </div>
                            <div class="performance-change">vs. año anterior</div>
                        </div>
                        <div class="performance-card">
                            <h6>Crecimiento Trimestral</h6>
                            <div class="performance-value ${recentGrowth > 0 ? 'trend-up' : 'trend-down'}">
                                ${recentGrowth}%
                            </div>
                            <div class="performance-change">vs. trimestre anterior</div>
                        </div>
                        <div class="performance-card">
                            <h6>Volatilidad</h6>
                            <div class="performance-value">${this.calculateVolatility(values).toFixed(1)}%</div>
                            <div class="performance-change">Desviación estándar</div>
                        </div>
                        <div class="performance-card">
                            <h6>Máximo Histórico</h6>
                            <div class="performance-value">$${Math.max(...values).toLocaleString()}</div>
                            <div class="performance-change">${this.getMonthOfMax(historicalData)}</div>
                        </div>
                    </div>
                    
                    <!-- Pronóstico y Proyecciones -->
                    <div class="forecast-section">
                        <h4><i class="fas fa-chart-line me-2"></i>Pronóstico y Proyecciones</h4>
                        <div class="forecast-values">
                            <div class="forecast-value">
                                <div class="value">$${forecast.nextMonth.toLocaleString()}</div>
                                <div class="label">Próximo Mes</div>
                            </div>
                            <div class="forecast-value">
                                <div class="value">$${forecast.nextQuarter.toLocaleString()}</div>
                                <div class="label">Próximo Trimestre</div>
                            </div>
                            <div class="forecast-value">
                                <div class="value">${forecast.confidence}%</div>
                                <div class="label">Confianza</div>
                            </div>
                            <div class="forecast-value">
                                <div class="value">${forecast.trend}</div>
                                <div class="label">Tendencia</div>
                            </div>
                        </div>
                        <div class="insight-item" style="background: rgba(255,255,255,0.2); border: none; color: white;">
                            <i class="fas fa-robot me-2"></i>
                            <strong>Recomendación:</strong> ${this.generateForecastRecommendation(historicalData)}
                        </div>
                    </div>
                    
                    <!-- Datos Históricos Detallados -->
                    <h3><i class="fas fa-history me-2"></i>Datos Históricos Detallados</h3>
                    <div class="table-responsive">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>Mes</th>
                                    <th>Valor Total</th>
                                    <th>Productos</th>
                                    <th>Stock Bajo</th>
                                    <th>Factor Estacional</th>
                                    <th>Evento</th>
                                    <th>Tendencia</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                months.slice(-12).forEach((month, index) => {
                    const data = historicalData[month];
                    const prevValue = index > 0 ? historicalData[months[months.length - 12 + index - 1]].totalValue : data.totalValue;
                    const trend = data.totalValue > prevValue ? '↑' : data.totalValue < prevValue ? '↓' : '→';
                    const trendClass = data.totalValue > prevValue ? 'trend-up' : data.totalValue < prevValue ? 'trend-down' : '';
                    
                    html += `
                        <tr>
                            <td><strong>${month}</strong></td>
                            <td>$${data.totalValue.toLocaleString()}</td>
                            <td>${data.totalProducts}</td>
                            <td>${data.lowStock}</td>
                            <td>${data.seasonalFactor.toFixed(2)}</td>
                            <td><span class="badge ${data.event === 'Evento especial' ? 'bg-warning' : 'bg-secondary'}">${data.event}</span></td>
                            <td class="${trendClass} fw-bold">${trend}</td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Análisis de Tendencias</h5>
                        <div class="insight-item">
                            <strong>Patrón estacional:</strong> ${this.identifySeasonalPattern(historicalData)}
                        </div>
                        <div class="insight-item">
                            <strong>Proyección:</strong> ${this.generateProjection(historicalData)}
                        </div>
                        <div class="insight-item">
                            <strong>Recomendaciones estratégicas:</strong> ${this.generateStrategicRecommendations(historicalData, categoryTrends)}
                        </div>
                    </div>
                    
                    <div class="report-footer">
                        <i class="fas fa-robot me-2"></i>Reporte generado por SmartStock AI - Página 1 de 1
                    </div>
                `;
                
                // Generar gráficos después de que se renderice el HTML
                setTimeout(() => {
                    this.generateTrendsValueChart(months, values);
                    this.generateTrendsProductsChart(months, productCounts);
                    this.generateSeasonalChart(historicalData);
                }, 100);
                
                return html;
            }
            
            generateComparisonReport(filters = {}) {
                const filteredProducts = this.applyFilters(productManager.getAllProducts(), filters);
                const productsByCategory = filteredProducts.reduce((groups, product) => {
                    (groups[product.category] ||= []).push(product);
                    return groups;
                }, {});
                const categories = Object.keys(productsByCategory);
                
                if (categories.length === 0) {
                    return this.generateEmptyState('No hay categorías para comparar');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title"><i class="fas fa-chart-bar me-2"></i>Reporte de Comparación por Categorías</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <h3><i class="fas fa-table me-2"></i>Resumen por Categoría</h3>
                    <div class="table-responsive">
                        <table class="comparison-table">
                            <thead>
                                <tr>
                                    <th>Categoría</th>
                                    <th>Productos</th>
                                    <th>Valor Total</th>
                                    <th>Valor Promedio</th>
                                    <th>Stock Promedio</th>
                                    <th>Stock Bajo</th>
                                    <th>% del Inventario</th>
                                    <th>Rendimiento</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                const totalValue = summarizeProducts(filteredProducts).totalValue;
                
                categories.forEach(category => {
                    const products = productsByCategory[category];
                    const categoryValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0);
                    const avgValue = categoryValue / products.length;
                    const avgStock = products.reduce((sum, p) => sum + p.stock, 0) / products.length;
                    const lowStockCount = products.filter(p => p.stock <= getConfiguredMinimumStock(p)).length;
                    const percentage = (categoryValue / totalValue) * 100;
                    
                    // Determinar rendimiento
                    const performance = percentage > 30 ? 'Excelente' : percentage > 20 ? 'Bueno' : percentage > 10 ? 'Regular' : 'Bajo';
                    const perfClass = percentage > 30 ? 'bg-success' : percentage > 20 ? 'bg-info' : percentage > 10 ? 'bg-warning' : 'bg-danger';
                    
                    html += `
                        <tr>
                            <td><strong>${category}</strong></td>
                            <td>${products.length}</td>
                            <td>$${categoryValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>$${avgValue.toLocaleString('es-ES', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            <td>${avgStock.toFixed(1)}</td>
                            <td>${lowStockCount}</td>
                            <td>${percentage.toFixed(2)}%</td>
                            <td><span class="badge ${perfClass}">${performance}</span></td>
                        </tr>
                    `;
                });
                
                html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="chart-container">
                        <canvas id="comparisonChart"></canvas>
                    </div>
                    
                    <div class="insights-section">
                        <h5><i class="fas fa-lightbulb me-2"></i>Análisis Comparativo</h5>
                        <div class="insight-item">
                            <strong>Categoría líder:</strong> ${this.identifyLeadingCategory(productsByCategory)}
                        </div>
                        <div class="insight-item">
                            <strong>Oportunidades de mejora:</strong> ${this.identifyOpportunities(productsByCategory)}
                        </div>
                        <div class="insight-item">
                            <strong>Recomendación:</strong> Enfocar recursos en categorías con mejor rendimiento y potencial de crecimiento.
                        </div>
                    </div>
                    
                    <div class="report-footer">
                        <i class="fas fa-robot me-2"></i>Reporte generado por SmartStock AI - Página 1 de 1
                    </div>
                `;
                
                // Generar gráfico después de que se renderice el HTML
                setTimeout(() => {
                    this.generateComparisonChart(productsByCategory);
                }, 100);
                
                return html;
            }
            
            generateAIReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                
                if (products.length === 0) {
                    return this.generateEmptyState('No hay productos que coincidan con los filtros aplicados');
                }
                
                let html = `
                    <div class="report-header">
                        <h1 class="report-title"><i class="fas fa-brain me-2"></i>Análisis Predictivo con IA Avanzada</h1>
                        <div class="report-subtitle">Generado el ${new Date().toLocaleDateString()} a las ${new Date().toLocaleTimeString()}</div>
                    </div>
                    
                    <div class="tensorflow-section">
                        <h4><i class="fas fa-microchip me-2"></i>Modelo de Predicción Multi-Capa con TensorFlow.js</h4>
                        <p>Este análisis utiliza redes neuronales profundas con 4 capas ocultas y modelos ensemble para máxima precisión. Los datos se actualizan en tiempo real desde múltiples fuentes externas.</p>
                        
                        <div class="external-data-section">
                            <h5><i class="fas fa-satellite-dish me-2"></i>Datos en Tiempo Real</h5>
                            <div class="market-trends">
                                <div class="market-trend-card">
                                    <i class="fas fa-globe fa-2x mb-2"></i>
                                    <div class="stat-title">APIs Conectadas</div>
                                    <div class="market-trend-value" id="apiConnectedCount">0/6</div>
                                    <div class="external-data-source" id="apiStatusList"></div>
                                </div>
                                <div class="market-trend-card">
                                    <i class="fas fa-clock fa-2x mb-2"></i>
                                    <div class="stat-title">Última Actualización</div>
                                    <div class="market-trend-value" id="lastUpdateTime">Conectando...</div>
                                    <div class="external-data-source">Tiempo real activo</div>
                                </div>
                                <div class="market-trend-card">
                                    <i class="fas fa-chart-line fa-2x mb-2"></i>
                                    <div class="stat-title">Precisión Modelo</div>
                                    <div class="market-trend-value" id="modelAccuracy">-</div>
                                    <div class="external-data-source">R²: -</div>
                                </div>
                                <div class="market-trend-card">
                                    <i class="fas fa-database fa-2x mb-2"></i>
                                    <div class="stat-title">Fuentes Activas</div>
                                    <div class="market-trend-value" id="dataSources">6</div>
                                    <div class="external-data-source">Alpha Vantage, World Bank, FRED, Google Trends, Weather, Sentiment</div>
                                </div>
                            </div>
                            <div class="data-freshness" id="dataFreshness">
                                <i class="fas fa-sync-alt fa-spin me-2"></i>Actualización automática cada 5 segundos
                            </div>
                        </div>
                        
                        <div class="model-controls">
                            <button class="btn btn-primary" id="trainModelBtn">
                                <i class="fas fa-brain me-2"></i>Entrenar Modelo Avanzado (100 épocas)
                            </button>
                            <button class="btn btn-success" id="predictSalesBtn" disabled>
                                <i class="fas fa-chart-line me-2"></i>Predecir con Ensemble
                            </button>
                            <button class="btn btn-info" id="refreshDataBtn">
                                <i class="fas fa-sync-alt me-2"></i>Actualizar Datos
                            </button>
                            <button class="btn btn-warning" id="showMetricsBtn" disabled>
                                <i class="fas fa-chart-bar me-2"></i>Ver Métricas
                            </button>
                        </div>
                        
                        <div id="trainingStatus"></div>
                        <div id="trainingProgress" style="display: none;">
                            <div class="progress-bar">
                                <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                            </div>
                            <div id="progressText" class="text-center mt-2">Progreso: 0%</div>
                        </div>
                        
                        <div id="trainingChartContainer" style="display: none;">
                            <h5><i class="fas fa-chart-line me-2"></i>Progreso del Entrenamiento</h5>
                            <div class="chart-container">
                                <canvas id="trainingChart"></canvas>
                            </div>
                        </div>
                        
                        <div id="realTimeInsights" style="display: none;"></div>
                        <div id="predictionResults" class="prediction-results" style="display: none;"></div>
                    </div>
                    
                    <div class="tensorflow-insight">
                        <h5><i class="fas fa-info-circle me-2"></i>¿Cómo funciona el análisis avanzado?</h5>
                        <p>El sistema utiliza redes neuronales profundas con las siguientes características:</p>
                        <ul>
                            <li><strong>Arquitectura:</strong> 4 capas ocultas con 32, 64, 32 y 16 neuronas</li>
                            <li><strong>Regularización:</strong> Dropout (20-30%) y L2 regularization</li>
                            <li><strong>Ensemble:</strong> 3 modelos adicionales con votación ponderada</li>
                            <li><strong>Validación cruzada:</strong> 80/20 con early stopping</li>
                            <li><strong>Datos externos:</strong> 6 APIs en tiempo real con actualización cada 5 segundos</li>
                        </ul>
                        <p>Precisión objetivo: R² > 0.85 (actual: <span id="currentR2">-</span>)</p>
                    </div>
                    
                    <div class="report-footer">
                        <i class="fas fa-robot me-2"></i>Reporte generado por SmartStock AI con TensorFlow.js - Versión 2.0
                    </div>
                `;
                
                // Agregar event listeners después de que se renderice el HTML
                setTimeout(() => {
                    const trainButton = document.getElementById('trainModelBtn');
                    const predictButton = document.getElementById('predictSalesBtn');
                    const refreshButton = document.getElementById('refreshDataBtn');
                    const metricsButton = document.getElementById('showMetricsBtn');
                    if (!trainButton || !predictButton || !refreshButton || !metricsButton) return;
                    trainButton.addEventListener('click', () => this.trainModelWithData(products));
                    predictButton.addEventListener('click', () => this.predictSalesWithModel(products));
                    refreshButton.addEventListener('click', () => this.refreshRealTimeData());
                    metricsButton.addEventListener('click', () => this.showModelMetrics());
                    
                    // Actualizar información de datos en tiempo real
                    this.updateRealTimeInfo();
                }, 100);
                
                return html;
            }
            
            async trainModelWithData(products) {
                const trainBtn = document.getElementById('trainModelBtn');
                const predictBtn = document.getElementById('predictSalesBtn');
                const metricsBtn = document.getElementById('showMetricsBtn');
                const statusDiv = document.getElementById('trainingStatus');
                const progressDiv = document.getElementById('trainingProgress');
                const chartContainer = document.getElementById('trainingChartContainer');
                const insightsDiv = document.getElementById('realTimeInsights');
                
                trainBtn.disabled = true;
                trainBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Obteniendo datos en tiempo real...';
                statusDiv.innerHTML = '<div class="training-status training">Conectando con fuentes de datos externas...</div>';
                
                try {
                    // Obtener datos en tiempo real
                    await advancedTensorFlowAnalyzer.fetchAllRealTimeData();
                    
                    trainBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Entrenando modelo (100 épocas)...';
                    statusDiv.innerHTML = '<div class="training-status training">Datos cargados. Iniciando entrenamiento avanzado...</div>';
                    progressDiv.style.display = 'block';
                    
                    // Función global para actualizar progreso
                    window.updateTrainingProgress = (epoch, totalEpochs, loss, valLoss, accuracy) => {
                        const progress = (epoch / totalEpochs) * 100;
                        document.getElementById('progressFill').style.width = `${progress}%`;
                        document.getElementById('progressText').innerHTML = `
                            Progreso: ${Math.round(progress)}% | Época ${epoch}/${totalEpochs}<br>
                            Pérdida: ${loss.toFixed(4)} | Val: ${valLoss ? valLoss.toFixed(4) : 'N/A'} | Prec: ${accuracy ? accuracy.toFixed(1) : 'N/A'}%
                        `;
                    };
                    
                    await advancedTensorFlowAnalyzer.trainModelWithCrossValidation(products, 100);
                    
                    const metrics = advancedTensorFlowAnalyzer.getModelMetrics();
                    
                    statusDiv.innerHTML = `
                        <div class="training-status completed">
                            <i class="fas fa-check-circle me-2"></i>
                            Modelo entrenado exitosamente<br>
                            <small>MSE: ${metrics.mse.toFixed(2)} | MAE: ${metrics.mae.toFixed(2)} | R²: ${metrics.r2.toFixed(3)} | Confianza: ${metrics.confidence}%</small>
                        </div>
                    `;
                    
                    document.getElementById('modelAccuracy').innerHTML = `${metrics.confidence}%`;
                    document.getElementById('currentR2').innerHTML = Math.max(0, metrics.r2).toFixed(3);
                    
                    predictBtn.disabled = false;
                    metricsBtn.disabled = false;
                    trainBtn.disabled = false;
                    trainBtn.innerHTML = '<i class="fas fa-brain me-2"></i>Reentrenar Modelo';
                    progressDiv.style.display = 'none';
                    
                    // Mostrar gráfico de entrenamiento
                    chartContainer.style.display = 'block';
                    this.showTrainingChart();
                    
                    // Mostrar insights en tiempo real
                    this.showRealTimeInsights(insightsDiv);
                    
                    productManager.showNotification('Modelo entrenado exitosamente con alta precisión', 'success');
                } catch (error) {
                    statusDiv.innerHTML = `<div class="training-status error">Error: ${error.message}</div>`;
                    trainBtn.disabled = false;
                    trainBtn.innerHTML = '<i class="fas fa-brain me-2"></i>Entrenar Modelo Avanzado';
                    progressDiv.style.display = 'none';
                    productManager.showNotification('Error entrenando el modelo: ' + error.message, 'error');
                }
            }
            
            async predictSalesWithModel(products) {
                const predictBtn = document.getElementById('predictSalesBtn');
                const resultsDiv = document.getElementById('predictionResults');
                
                predictBtn.disabled = true;
                predictBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Analizando con ensemble...';
                
                try {
                    const predictions = await advancedTensorFlowAnalyzer.predictWithEnsemble(products);
                    const metrics = advancedTensorFlowAnalyzer.getModelMetrics();
                    
                    let html = `
                        <h5><i class="fas fa-chart-line me-2"></i>Predicciones con Ensemble (Confianza: ${metrics.confidence}%)</h5>
                        <div class="table-responsive">
                            <table class="report-table">
                                <thead>
                                    <tr>
                                        <th>Producto</th>
                                        <th>Categoría</th>
                                        <th>Precio</th>
                                        <th>Stock</th>
                                        <th>Ventas Previstas</th>
                                        <th>Intervalo Confianza</th>
                                        <th>Tendencia</th>
                                        <th>Sentimiento</th>
                                        <th>Oportunidad</th>
                                        <th>Riesgo</th>
                                        <th>Recomendación</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;
                    
                    predictions.forEach(product => {
                        const recommendation = product.reorderRecommendation;
                        const priorityClass = recommendation.priority === 'critical' ? 'bg-danger' :
                                             recommendation.priority === 'high' ? 'bg-warning' :
                                             recommendation.priority === 'medium' ? 'bg-info' : 'bg-success';
                        
                        const sentimentClass = product.marketSentiment > 0.6 ? 'sentiment-positive' : 
                                             product.marketSentiment < 0.4 ? 'sentiment-negative' : 'sentiment-neutral';
                        
                        const opportunityClass = product.opportunityScore > 70 ? 'bg-success' :
                                               product.opportunityScore > 40 ? 'bg-info' : 'bg-warning';
                        
                        const riskClass = product.riskLevel === 'Alto' ? 'bg-danger' :
                                         product.riskLevel === 'Medio' ? 'bg-warning' : 'bg-success';
                        
                        html += `
                            <tr>
                                <td><strong>${product.name}</strong></td>
                                <td>${product.category}</td>
                                <td>$${product.price.toLocaleString()}</td>
                                <td>${product.stock}</td>
                                <td class="fw-bold">${product.predictedSales}</td>
                                <td>
                                    ${Math.round(product.confidenceInterval.lower)} - ${Math.round(product.confidenceInterval.upper)}
                                    <br><small class="text-muted">95% confianza</small>
                                </td>
                                <td><span class="badge ${product.marketTrend > 1.05 ? 'bg-success' : product.marketTrend < 0.95 ? 'bg-danger' : 'bg-secondary'}">${(product.marketTrend * 100 - 100).toFixed(1)}%</span></td>
                                <td><span class="sentiment-indicator ${sentimentClass}">${(product.marketSentiment * 100).toFixed(0)}%</span></td>
                                <td><span class="badge ${opportunityClass}">${product.opportunityScore}%</span></td>
                                <td><span class="badge ${riskClass}">${product.riskLevel}</span></td>
                                <td>
                                    <span class="badge ${priorityClass}" data-tooltip="${recommendation.message}">${recommendation.action}</span>
                                </td>
                            </tr>
                        `;
                    });
                    
                    html += `
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="ai-recommendation mt-3">
                            <h5><i class="fas fa-robot me-2"></i>Recomendaciones de IA (Basadas en Ensemble)</h5>
                            <ul class="recommendation-list">
                                <li><i class="fas fa-bullseye text-warning"></i> <strong>Oportunidades altas (>70%):</strong> ${predictions.filter(p => p.opportunityScore > 70).length} productos requieren acción inmediata</li>
                                <li><i class="fas fa-chart-line text-success"></i> <strong>Tendencias positivas:</strong> ${predictions.filter(p => p.marketTrend > 1.05).length} categorías en crecimiento</li>
                                <li><i class="fas fa-exclamation-triangle text-danger"></i> <strong>Riesgo alto:</strong> ${predictions.filter(p => p.riskLevel === 'Alto').length} productos con riesgo significativo</li>
                                <li><i class="fas fa-sync-alt text-info"></i> <strong>Precisión modelo:</strong> R² = ${metrics.r2.toFixed(3)} | MAE = ${metrics.mae.toFixed(2)} unidades</li>
                                <li><i class="fas fa-clock text-primary"></i> <strong>Última actualización:</strong> ${predictions[0]?.lastUpdated ? new Date(predictions[0].lastUpdated).toLocaleString() : 'N/A'}</li>
                            </ul>
                        </div>
                        
                        <div class="data-freshness mt-3">
                            <i class="fas fa-check-circle text-success me-2"></i>Análisis completado con modelo ensemble de ${advancedTensorFlowAnalyzer.ensembleModels.length + 1} modelos
                        </div>
                    `;
                    
                    resultsDiv.innerHTML = html;
                    resultsDiv.style.display = 'block';
                    
                    predictBtn.disabled = false;
                    predictBtn.innerHTML = '<i class="fas fa-chart-line me-2"></i>Predecir con Ensemble';
                    
                    productManager.showNotification('Predicciones generadas con alta precisión', 'success');
                } catch (error) {
                    resultsDiv.innerHTML = `<div class="training-status error">Error: ${error.message}</div>`;
                    resultsDiv.style.display = 'block';
                    predictBtn.disabled = false;
                    predictBtn.innerHTML = '<i class="fas fa-chart-line me-2"></i>Predecir con Ensemble';
                    productManager.showNotification('Error generando predicciones: ' + error.message, 'error');
                }
            }
            
            async refreshRealTimeData() {
                const refreshBtn = document.getElementById('refreshDataBtn');
                refreshBtn.disabled = true;
                refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Actualizando...';
                
                try {
                    await advancedTensorFlowAnalyzer.fetchAllRealTimeData();
                    this.updateRealTimeInfo();
                    productManager.showNotification('Datos en tiempo real actualizados correctamente', 'success');
                } catch (error) {
                    productManager.showNotification('Error actualizando datos: ' + error.message, 'error');
                } finally {
                    refreshBtn.disabled = false;
                    refreshBtn.innerHTML = '<i class="fas fa-sync-alt me-2"></i>Actualizar Datos';
                }
            }
            
            showModelMetrics() {
                const metrics = advancedTensorFlowAnalyzer.getModelMetrics();
                const apiStatus = advancedTensorFlowAnalyzer.getAPIStatus();
                
                productManager.showNotification(
                    `MSE: ${metrics.mse.toFixed(2)} | MAE: ${metrics.mae.toFixed(2)} | R²: ${metrics.r2.toFixed(3)} | Confianza: ${metrics.confidence}% | APIs: ${apiStatus.connectedCount}/${apiStatus.totalCount}`,
                    'info'
                );
            }
            
            updateRealTimeInfo() {
                const apiStatus = advancedTensorFlowAnalyzer.getAPIStatus();
                const metrics = advancedTensorFlowAnalyzer.getModelMetrics();
                const lastUpdateTime = document.getElementById('lastUpdateTime');
                const apiConnectedCount = document.getElementById('apiConnectedCount');
                const apiStatusList = document.getElementById('apiStatusList');
                const dataFreshness = document.getElementById('dataFreshness');
                const modelAccuracy = document.getElementById('modelAccuracy');
                const currentR2 = document.getElementById('currentR2');
                
                if (lastUpdateTime) {
                    lastUpdateTime.textContent = apiStatus.lastUpdate ? 
                        new Date(apiStatus.lastUpdate).toLocaleTimeString() : 'Esperando datos...';
                }
                
                if (apiConnectedCount) {
                    apiConnectedCount.textContent = `${apiStatus.connectedCount}/${apiStatus.totalCount}`;
                }
                
                if (apiStatusList) {
                    apiStatusList.innerHTML = `
                        <span class="api-status ${apiStatus.alphaVantage ? 'online' : 'offline'}"><i class="fas fa-${apiStatus.alphaVantage ? 'check' : 'times'}"></i> Alpha</span>
                        <span class="api-status ${apiStatus.worldBank ? 'online' : 'offline'}"><i class="fas fa-${apiStatus.worldBank ? 'check' : 'times'}"></i> World</span>
                        <span class="api-status ${apiStatus.fred ? 'online' : 'offline'}"><i class="fas fa-${apiStatus.fred ? 'check' : 'times'}"></i> FRED</span>
                        <span class="api-status ${apiStatus.googleTrends ? 'online' : 'offline'}"><i class="fas fa-${apiStatus.googleTrends ? 'check' : 'times'}"></i> Trends</span>
                        <span class="api-status ${apiStatus.weather ? 'online' : 'offline'}"><i class="fas fa-${apiStatus.weather ? 'check' : 'times'}"></i> Weather</span>
                        <span class="api-status ${apiStatus.sentiment ? 'online' : 'offline'}"><i class="fas fa-${apiStatus.sentiment ? 'check' : 'times'}"></i> Sent</span>
                    `;
                }
                
                if (modelAccuracy) {
                    modelAccuracy.textContent = metrics.confidence ? `${metrics.confidence}%` : '-';
                }
                
                if (currentR2) {
                    currentR2.textContent = Number.isFinite(metrics.r2) ? Math.max(0, metrics.r2).toFixed(3) : '0.000';
                }
                
                if (dataFreshness) {
                    dataFreshness.innerHTML = `
                        <i class="fas fa-sync-alt fa-spin me-2"></i>
                        Última actualización: ${apiStatus.lastUpdate ? new Date(apiStatus.lastUpdate).toLocaleString() : 'Nunca'} | 
                        APIs conectadas: ${apiStatus.connectedCount}/${apiStatus.totalCount}
                    `;
                }
            }
            
            showRealTimeInsights(container) {
                const apiStatus = advancedTensorFlowAnalyzer.getAPIStatus();
                const externalData = advancedTensorFlowAnalyzer.externalData;
                const metrics = advancedTensorFlowAnalyzer.getModelMetrics();
                
                if (!externalData) {
                    container.innerHTML = '<div class="training-status warning">Esperando datos en tiempo real...</div>';
                    container.style.display = 'block';
                    return;
                }
                
                let html = `
                    <h5><i class="fas fa-chart-line me-2"></i>Insights en Tiempo Real</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="prediction-card">
                                <h6><i class="fas fa-globe me-2"></i>Indicadores Económicos</h6>
                                <div class="row">
                                    <div class="col-6">
                                        <small>PIB: ${externalData.economicIndicators.gdpGrowth.toFixed(1)}%</small>
                                    </div>
                                    <div class="col-6">
                                        <small>Inflación: ${externalData.economicIndicators.inflation.toFixed(1)}%</small>
                                    </div>
                                    <div class="col-6">
                                        <small>Confianza: ${externalData.economicIndicators.consumerConfidence}</small>
                                    </div>
                                    <div class="col-6">
                                        <small>Retail: ${externalData.economicIndicators.retailGrowth.toFixed(1)}%</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="prediction-card">
                                <h6><i class="fas fa-cloud-sun me-2"></i>Factores Climáticos</h6>
                                <div><strong>Temporada:</strong> ${externalData.weather.season}</div>
                                <div><strong>Temperatura:</strong> ${externalData.weather.temperature}°C</div>
                                <div><strong>Impacto:</strong> ${(externalData.weather.impactFactor * 100).toFixed(0)}%</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="prediction-card mt-3">
                        <h6><i class="fas fa-chart-bar me-2"></i>Tendencias de Mercado por Categoría</h6>
                        <div class="row">
                `;
                
                Object.entries(externalData.marketTrends).forEach(([category, data]) => {
                    const trendClass = data.trend > 1.05 ? 'text-success' : data.trend < 0.95 ? 'text-danger' : 'text-warning';
                    const sentimentClass = data.sentiment > 0.6 ? 'sentiment-positive' : data.sentiment < 0.4 ? 'sentiment-negative' : 'sentiment-neutral';
                    
                    html += `
                        <div class="col-md-3 text-center mb-3">
                            <strong>${category}</strong>
                            <div class="${trendClass} fw-bold">${(data.trend * 100 - 100).toFixed(1)}%</div>
                            <span class="sentiment-indicator ${sentimentClass}">${(data.sentiment * 100).toFixed(0)}%</span>
                            <small class="d-block">Vol: ${data.volume}</small>
                        </div>
                    `;
                });
                
                html += `
                        </div>
                    </div>
                    
                    <div class="data-freshness mt-3">
                        <i class="fas fa-robot me-2"></i>Métricas del modelo: 
                        R² = ${metrics.r2 ? metrics.r2.toFixed(3) : 'N/A'} | 
                        MAE = ${metrics.mae ? metrics.mae.toFixed(2) : 'N/A'} | 
                        Confianza = ${metrics.confidence ? metrics.confidence + '%' : 'N/A'}
                    </div>
                `;
                
                container.innerHTML = html;
                container.style.display = 'block';
            }
            
            showTrainingChart() {
                const trainingData = advancedTensorFlowAnalyzer.getTrainingChartData();
                if (!trainingData) return;
                
                const canvas = document.getElementById('trainingChart');
                if (!canvas) return;
                const ctx = canvas.getContext('2d');
                
                // Destruir gráfico anterior si existe
                if (this.charts.trainingChart) {
                    this.charts.trainingChart.destroy();
                }
                
                this.charts.trainingChart = new Chart(ctx, {
                    type: 'line',
                    data: trainingData,
                    options: {
                        responsive: true,
                        scales: {
                            'y-loss': {
                                type: 'linear',
                                position: 'left',
                                title: {
                                    display: true,
                                    text: 'Pérdida'
                                }
                            },
                            'y-accuracy': {
                                type: 'linear',
                                position: 'right',
                                title: {
                                    display: true,
                                    text: 'Precisión (%)'
                                },
                                min: 0,
                                max: 100,
                                grid: {
                                    drawOnChartArea: false
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                mode: 'index',
                                intersect: false
                            }
                        }
                    }
                });
            }
            
            generateCategoryChart(productsByCategory) {
                const canvas = document.getElementById('categoryChart');
                if (!canvas) return;
                const ctx = canvas.getContext('2d');
                const categories = Object.keys(productsByCategory);
                const data = categories.map(category => {
                    return productsByCategory[category].length;
                });
                
                if (this.charts.categoryChart) {
                    this.charts.categoryChart.destroy();
                }
                
                this.charts.categoryChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: categories,
                        datasets: [{
                            data: data,
                            backgroundColor: [
                                '#3a5ec7', '#28a745', '#ffc107', '#dc3545', '#17a2b8', '#6f42c1'
                            ],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            }
                        }
                    }
                });
            }
            
            generateValuationChart(products) {
                const canvas = document.getElementById('valuationChart');
                if (!canvas) return;
                const ctx = canvas.getContext('2d');
                
                if (this.charts.valuationChart) {
                    this.charts.valuationChart.destroy();
                }
                
                // Tomar los 10 productos más valiosos
                const topProducts = products.slice(0, 10);
                const labels = topProducts.map(p => p.name.length > 15 ? p.name.substring(0, 15) + '...' : p.name);
                const data = topProducts.map(p => p.price * p.stock);
                
                this.charts.valuationChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Valor Total ($)',
                            data: data,
                            backgroundColor: '#3a5ec7',
                            borderColor: '#2a4bb0',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        indexAxis: 'y',
                        scales: {
                            x: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Valor ($)'
                                }
                            }
                        }
                    }
                });
            }
            
            generateTrendsValueChart(months, values) {
                const canvas = document.getElementById('trendsValueChart');
                if (!canvas) return;
                const ctx = canvas.getContext('2d');
                
                if (this.charts.trendsValueChart) {
                    this.charts.trendsValueChart.destroy();
                }
                
                // Mostrar últimos 12 meses
                const last12Months = months.slice(-12);
                const last12Values = values.slice(-12);
                
                this.charts.trendsValueChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: last12Months,
                        datasets: [{
                            label: 'Valor del Inventario ($)',
                            data: last12Values,
                            borderColor: '#3a5ec7',
                            backgroundColor: 'rgba(58, 94, 199, 0.1)',
                            fill: true,
                            tension: 0.4,
                            pointBackgroundColor: '#3a5ec7',
                            pointBorderColor: '#ffffff',
                            pointBorderWidth: 2,
                            pointRadius: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return `$${context.raw.toLocaleString()}`;
                                    }
                                }
                            }
                        }
                    }
                });
            }
            
            generateTrendsProductsChart(months, productCounts) {
                const canvas = document.getElementById('trendsProductsChart');
                if (!canvas) return;
                const ctx = canvas.getContext('2d');
                
                if (this.charts.trendsProductsChart) {
                    this.charts.trendsProductsChart.destroy();
                }
                
                // Mostrar últimos 12 meses
                const last12Months = months.slice(-12);
                const last12Counts = productCounts.slice(-12);
                
                this.charts.trendsProductsChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: last12Months,
                        datasets: [{
                            label: 'Cantidad de Productos',
                            data: last12Counts,
                            borderColor: '#28a745',
                            backgroundColor: 'rgba(40, 167, 69, 0.1)',
                            fill: true,
                            tension: 0.4,
                            pointBackgroundColor: '#28a745',
                            pointBorderColor: '#ffffff',
                            pointBorderWidth: 2,
                            pointRadius: 4
                        }]
                    },
                    options: {
                        responsive: true
                    }
                });
            }
            
            generateSeasonalChart(historicalData) {
                const canvas = document.getElementById('seasonalChart');
                if (!canvas) return;
                const ctx = canvas.getContext('2d');
                
                if (this.charts.seasonalChart) {
                    this.charts.seasonalChart.destroy();
                }
                
                // Agrupar por mes para ver patrones estacionales
                const monthlyData = {};
                Object.keys(historicalData).forEach(month => {
                    const monthKey = month.split('-')[1];
                    if (!monthlyData[monthKey]) {
                        monthlyData[monthKey] = {
                            values: [],
                            count: 0
                        };
                    }
                    monthlyData[monthKey].values.push(historicalData[month].totalValue);
                    monthlyData[monthKey].count++;
                });
                
                // Calcular promedio por mes
                const monthNames = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
                const monthlyAverages = monthNames.map((name, index) => {
                    const monthKey = String(index + 1).padStart(2, '0');
                    if (monthlyData[monthKey]) {
                        return monthlyData[monthKey].values.reduce((a, b) => a + b, 0) / monthlyData[monthKey].count;
                    }
                    return 0;
                });
                
                this.charts.seasonalChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: monthNames,
                        datasets: [{
                            label: 'Valor Promedio por Mes',
                            data: monthlyAverages,
                            backgroundColor: '#ffc107',
                            borderColor: '#e0a800',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return `$${context.raw.toLocaleString()}`;
                                    }
                                }
                            }
                        }
                    }
                });
            }
            
            generateComparisonChart(productsByCategory) {
                const canvas = document.getElementById('comparisonChart');
                if (!canvas) return;
                const ctx = canvas.getContext('2d');
                const categories = Object.keys(productsByCategory);
                
                if (this.charts.comparisonChart) {
                    this.charts.comparisonChart.destroy();
                }
                
                const data = categories.map(category => {
                    const products = productsByCategory[category];
                    return products.reduce((sum, p) => sum + (p.price * p.stock), 0);
                });
                
                this.charts.comparisonChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: categories,
                        datasets: [{
                            data: data,
                            backgroundColor: [
                                '#3a5ec7', '#28a745', '#ffc107', '#dc3545', '#17a2b8', '#6f42c1'
                            ],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.raw || 0;
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = ((value / total) * 100).toFixed(1);
                                        return `${label}: $${value.toLocaleString()} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            }
            
            calculateTopPercentage(products, count, totalValue) {
                const topValue = products.slice(0, count).reduce((sum, p) => sum + (p.price * p.stock), 0);
                return ((topValue / totalValue) * 100).toFixed(1);
            }
            
            identifyPeakMonth(historicalData) {
                const monthlyAverages = {};
                Object.keys(historicalData).forEach(month => {
                    const monthKey = month.split('-')[1];
                    if (!monthlyAverages[monthKey]) {
                        monthlyAverages[monthKey] = {
                            sum: 0,
                            count: 0
                        };
                    }
                    monthlyAverages[monthKey].sum += historicalData[month].totalValue;
                    monthlyAverages[monthKey].count++;
                });
                
                let maxMonth = '';
                let maxValue = 0;
                const monthNames = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
                
                Object.keys(monthlyAverages).forEach(month => {
                    const avg = monthlyAverages[month].sum / monthlyAverages[month].count;
                    if (avg > maxValue) {
                        maxValue = avg;
                        maxMonth = monthNames[parseInt(month) - 1];
                    }
                });
                
                return maxMonth;
            }
            
            getMonthOfMax(historicalData) {
                let maxMonth = '';
                let maxValue = 0;
                
                Object.keys(historicalData).forEach(month => {
                    if (historicalData[month].totalValue > maxValue) {
                        maxValue = historicalData[month].totalValue;
                        maxMonth = month;
                    }
                });
                
                return maxMonth;
            }
            
            calculateVolatility(values) {
                const returns = [];
                for (let i = 1; i < values.length; i++) {
                    const returnValue = (values[i] - values[i-1]) / values[i-1];
                    returns.push(returnValue);
                }
                
                const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
                const variance = returns.reduce((a, b) => a + Math.pow(b - avgReturn, 2), 0) / returns.length;
                const volatility = Math.sqrt(variance) * 100;
                
                return volatility;
            }
            
            generateForecast(historicalData) {
                const values = Object.values(historicalData).map(d => d.totalValue);
                const lastValue = values[values.length - 1];
                
                // Método de promedio móvil ponderado
                const shortTermAvg = values.slice(-3).reduce((a, b) => a + b, 0) / 3;
                const mediumTermAvg = values.slice(-6).reduce((a, b) => a + b, 0) / 6;
                const longTermAvg = values.slice(-12).reduce((a, b) => a + b, 0) / 12;
                
                // Calcular tendencia reciente
                const recentGrowth = (values[values.length - 1] - values[values.length - 4]) / values[values.length - 4];
                
                // Factores de estacionalidad
                const lastMonth = new Date().getMonth() + 1;
                const monthKey = String(lastMonth).padStart(2, '0');
                const nextYear = new Date().getFullYear() + (lastMonth === 12 ? 1 : 0);
                const nextMonthKey = `${nextYear}-${String(lastMonth === 12 ? 1 : lastMonth + 1).padStart(2, '0')}`;
                const historicalKeys = Object.keys(historicalData);
                const seasonalFactor = historicalData[nextMonthKey]?.seasonalFactor ||
                    historicalData[historicalKeys[historicalKeys.length - 1]]?.seasonalFactor || 1.0;
                
                // Pronóstico ponderado
                const nextMonth = (shortTermAvg * 0.5 + mediumTermAvg * 0.3 + longTermAvg * 0.2) * (1 + recentGrowth * 0.7) * seasonalFactor;
                const nextQuarter = nextMonth * (1 + recentGrowth * 0.5) * 3;
                
                // Calcular confianza
                const recentVolatility = this.calculateVolatility(values.slice(-6));
                const confidence = Math.min(95, Math.max(60, 100 - recentVolatility * 2));
                
                // Determinar tendencia
                let trend = 'Estable';
                if (recentGrowth > 0.03) trend = 'Alcista fuerte';
                else if (recentGrowth > 0.01) trend = 'Alcista';
                else if (recentGrowth < -0.03) trend = 'Bajista fuerte';
                else if (recentGrowth < -0.01) trend = 'Bajista';
                
                return {
                    nextMonth: Math.round(nextMonth),
                    nextQuarter: Math.round(nextQuarter),
                    confidence: Math.round(confidence),
                    trend: trend
                };
            }
            
            generateForecastRecommendation(historicalData) {
                const forecast = this.generateForecast(historicalData);
                const values = Object.values(historicalData).map(d => d.totalValue);
                const lastValue = values[values.length - 1];
                
                if (forecast.nextMonth > lastValue * 1.1) {
                    return "Se espera crecimiento significativo. Incremente inventario para aprovechar la demanda, especialmente en categorías de alta rotación.";
                } else if (forecast.nextMonth > lastValue * 1.05) {
                    return "Se espera crecimiento moderado. Mantenga niveles actuales con monitoreo de categorías en tendencia positiva.";
                } else if (forecast.nextMonth < lastValue * 0.9) {
                    return "Se espera contracción. Reduzca inventario y enfoque en promociones para liquidar stock antes de la caída.";
                } else if (forecast.nextMonth < lastValue * 0.95) {
                    return "Se espera ligera disminución. Optimice niveles de inventario y evalúe estrategias de precios.";
                } else {
                    return "Se espera estabilidad. Mantenga operaciones normales con monitoreo continuo de indicadores clave.";
                }
            }
            
            generateProjection(historicalData) {
                const values = Object.values(historicalData).map(d => d.totalValue);
                const lastValue = values[values.length - 1];
                const firstValue = values[0];
                const avgGrowth = (values[values.length - 1] - values[0]) / (values.length - 1);
                const forecast = this.generateForecast(historicalData);
                
                if (avgGrowth > 0) {
                    return `Tendencia alcista con crecimiento anual del ${((lastValue - firstValue) / firstValue * 100).toFixed(1)}%. Proyección: $${forecast.nextMonth.toLocaleString()} para el próximo mes (${forecast.confidence}% confianza).`;
                } else if (avgGrowth < 0) {
                    return `Tendencia bajista con decrecimiento anual del ${((firstValue - lastValue) / firstValue * 100).toFixed(1)}%. Proyección: $${forecast.nextMonth.toLocaleString()} para el próximo mes (${forecast.confidence}% confianza).`;
                } else {
                    return `Tendencia estable. Proyección: $${forecast.nextMonth.toLocaleString()} para el próximo mes (${forecast.confidence}% confianza).`;
                }
            }
            
            identifySeasonalPattern(historicalData) {
                const values = Object.values(historicalData).map(d => d.totalValue);
                const avg = values.reduce((a, b) => a + b, 0) / values.length;
                
                // Análisis de patrones estacionales
                const monthlyData = {};
                Object.keys(historicalData).forEach(month => {
                    const monthKey = month.split('-')[1];
                    if (!monthlyData[monthKey]) {
                        monthlyData[monthKey] = [];
                    }
                    monthlyData[monthKey].push(historicalData[month].totalValue);
                });
                
                // Calcular coeficiente de variación por mes
                const monthlyCV = {};
                Object.keys(monthlyData).forEach(month => {
                    const monthlyValues = monthlyData[month];
                    const monthlyAvg = monthlyValues.reduce((a, b) => a + b, 0) / monthlyValues.length;
                    const monthlyStd = Math.sqrt(monthlyValues.reduce((a, b) => a + Math.pow(b - monthlyAvg, 2), 0) / monthlyValues.length);
                    monthlyCV[month] = (monthlyStd / monthlyAvg) * 100;
                });
                
                // Identificar meses con mayor variabilidad
                const highVariabilityMonths = Object.keys(monthlyCV).filter(month => monthlyCV[month] > 15);
                const lowVariabilityMonths = Object.keys(monthlyCV).filter(month => monthlyCV[month] < 8);
                
                const monthNames = {
                    '01': 'Enero', '02': 'Febrero', '03': 'Marzo', '04': 'Abril',
                    '05': 'Mayo', '06': 'Junio', '07': 'Julio', '08': 'Agosto',
                    '09': 'Septiembre', '10': 'Octubre', '11': 'Noviembre', '12': 'Diciembre'
                };
                
                if (highVariabilityMonths.length > 0) {
                    const highVarMonthNames = highVariabilityMonths.map(month => monthNames[month]).join(', ');
                    return `Alta estacionalidad detectada en ${highVarMonthNames}. Ajuste inventario según picos de demanda.`;
                } else if (lowVariabilityMonths.length > 8) {
                    return `Baja estacionalidad. La demanda es estable durante todo el año.`;
                } else {
                    return `Estacionalidad moderada. Observe patrones específicos por categoría.`;
                }
            }
            
            generateStrategicRecommendations(historicalData, categoryTrends) {
                const recommendations = [];
                const values = Object.values(historicalData).map(d => d.totalValue);
                const recentGrowth = (values[values.length - 1] - values[values.length - 4]) / values[values.length - 4] * 100;
                
                // Analizar tendencias por categoría
                Object.keys(categoryTrends).forEach(category => {
                    const trend = categoryTrends[category];
                    if (trend.growthRate > 8) {
                        recommendations.push(`Incrementar inventario en ${category} (crecimiento ${trend.growthRate.toFixed(1)}%)`);
                    } else if (trend.growthRate < -5) {
                        recommendations.push(`Reducir exposición en ${category} (decrecimiento ${trend.growthRate.toFixed(1)}%)`);
                    }
                });
                
                // Recomendaciones generales
                if (recentGrowth > 5) {
                    recommendations.push("Aprovechar momento alcista para negociar mejores precios con proveedores");
                } else if (recentGrowth < -5) {
                    recommendations.push("Implementar estrategias de liquidación y promociones para reducir inventario");
                }
                
                // Recomendación basada en estacionalidad
                const seasonalPattern = this.identifySeasonalPattern(historicalData);
                if (seasonalPattern.includes("Alta estacionalidad")) {
                    recommendations.push("Implementar sistema de compras anticipadas para meses pico");
                }
                
                return recommendations.length > 0 ? recommendations.join('; ') : 'Mantener estrategia actual con monitoreo continuo de indicadores.';
            }
            
            identifyLeadingCategory(productsByCategory) {
                let leadingCategory = '';
                let maxValue = 0;
                
                Object.keys(productsByCategory).forEach(category => {
                    const value = productsByCategory[category].reduce((sum, p) => sum + (p.price * p.stock), 0);
                    if (value > maxValue) {
                        maxValue = value;
                        leadingCategory = category;
                    }
                });
                
                return `${leadingCategory} ($${maxValue.toLocaleString()})`;
            }
            
            identifyOpportunities(productsByCategory) {
                const opportunities = [];
                
                Object.keys(productsByCategory).forEach(category => {
                    const products = productsByCategory[category];
                    const lowStockCount = products.filter(p => p.stock <= getConfiguredMinimumStock(p)).length;
                    const highValueLowStock = products.filter(p => (p.price * p.stock) > 1000 && p.stock <= getConfiguredMinimumStock(p)).length;
                    
                    if (lowStockCount > products.length * 0.3) {
                        opportunities.push(`${category}: ${lowStockCount} productos con stock bajo`);
                    }
                    
                    if (highValueLowStock > 0) {
                        opportunities.push(`${category}: ${highValueLowStock} productos de alto valor con stock bajo (prioridad)`);
                    }
                });
                
                return opportunities.length > 0 ? opportunities.join('; ') : 'Todas las categorías muestran niveles de stock adecuados';
            }
            
            generateEmptyState(message) {
                return `
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h4>No hay datos para mostrar</h4>
                        <p>${message}</p>
                        <button class="btn btn-primary mt-3" onclick="resetFilters()">
                            <i class="fas fa-redo me-2"></i>Restablecer Filtros
                        </button>
                    </div>
                `;
            }
            
            printReport() {
                window.print();
            }
            
            async exportToPDF() {
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF('l', 'mm', 'a4');
                
                // Obtener el contenido del reporte
                const reportContent = document.getElementById('reportContent');
                
                // Usar html2canvas para capturar el contenido como imagen
                try {
                    const canvas = await html2canvas(reportContent, {
                        scale: 2,
                        backgroundColor: '#ffffff'
                    });
                    
                    const imgData = canvas.toDataURL('image/png');
                    const imgWidth = 280; // A4 landscape width in mm
                    const imgHeight = (canvas.height * imgWidth) / canvas.width;
                    
                    doc.addImage(imgData, 'PNG', 10, 10, imgWidth, imgHeight);
                    doc.save(`reporte_smartstock_${new Date().toISOString().split('T')[0]}.pdf`);
                    productManager.showNotification('Reporte exportado a PDF correctamente', 'success');
                } catch (error) {
                    productManager.showNotification('Error exportando a PDF: ' + error.message, 'error');
                }
            }

            getExportProducts() {
                return this.applyFilters(productManager.getAllProducts(), getCurrentFilters());
            }
            
            exportToExcel() {
                const products = this.getExportProducts();
                const worksheet = XLSX.utils.json_to_sheet(products.map(p => ({
                    ID: p.id,
                    Producto: p.name,
                    Categoría: p.category,
                    Precio: p.price,
                    Stock: p.stock,
                    'Stock Mínimo': getConfiguredMinimumStock(p),
                    'Valor Total': p.price * p.stock,
                    Estado: productManager.getProductStatus(p.stock, getConfiguredMinimumStock(p))
                })));
                
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, 'Inventario');
                
                // Agregar hoja de resumen
                const summary = summarizeProducts(products);
                const summaryData = [
                    ['Métrica', 'Valor'],
                    ['Total Productos', summary.totalProducts],
                    ['Valor Total', summary.totalValue],
                    ['Stock Bajo', summary.lowStock],
                    ['Agotados', summary.outOfStock],
                    ['Fecha', new Date().toLocaleDateString()]
                ];
                const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
                XLSX.utils.book_append_sheet(workbook, summarySheet, 'Resumen');
                
                XLSX.writeFile(workbook, `reporte_smartstock_${new Date().toISOString().split('T')[0]}.xlsx`);
                productManager.showNotification('Reporte exportado a Excel correctamente', 'success');
            }
            
            exportToCSV() {
                const products = this.getExportProducts();
                const escapeCsv = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
                const csvContent = [
                    ['ID', 'Producto', 'Categoría', 'Precio', 'Stock', 'Stock Mínimo', 'Valor Total', 'Estado'],
                    ...products.map(p => [
                        p.id,
                        p.name,
                        p.category,
                        p.price,
                        p.stock,
                        getConfiguredMinimumStock(p),
                        p.price * p.stock,
                        productManager.getProductStatus(p.stock, getConfiguredMinimumStock(p))
                    ])
                ].map(row => row.map(escapeCsv).join(',')).join('\n');
                
                const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
                const link = document.createElement('a');
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', `reporte_smartstock_${new Date().toISOString().split('T')[0]}.csv`);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                productManager.showNotification('Reporte exportado a CSV correctamente', 'success');
            }
            
            exportToJSON() {
                const products = this.getExportProducts();
                const summary = summarizeProducts(products);
                const data = {
                    metadata: {
                        fecha: new Date().toISOString(),
                        tipo: 'reporte_inventario',
                        version: '2.0'
                    },
                    resumen: {
                        totalProductos: products.length,
                        valorTotal: summary.totalValue,
                        stockBajo: summary.lowStock,
                        agotados: summary.outOfStock
                    },
                    productos: products.map(p => ({
                        ...p,
                        valorTotal: p.price * p.stock,
                        estado: productManager.getProductStatus(p.stock, getConfiguredMinimumStock(p))
                    }))
                };
                
                const jsonContent = JSON.stringify(data, null, 2);
                const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
                const link = document.createElement('a');
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', `reporte_smartstock_${new Date().toISOString().split('T')[0]}.json`);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                productManager.showNotification('Reporte exportado a JSON correctamente', 'success');
            }
        }

        // ============================================
        // INSTANCIAS GLOBALES
        // ============================================
        const productManager = new ProductManager();
        const savedReportsManager = new SavedReportsManager();
        const advancedTensorFlowAnalyzer = new AdvancedTensorFlowAnalyzer();
        const reportGenerator = new AdvancedReportGenerator();

        // ============================================
        // FUNCIONES GLOBALES
        // ============================================
        
        // Función global para actualizar datos en tiempo real
        window.updateRealTimeData = function(externalData, lastUpdate) {
            const insights = document.getElementById('realTimeInsights');
            if (insights && insights.style.display !== 'none') {
                reportGenerator.updateRealTimeInfo();
                reportGenerator.showRealTimeInsights(insights);
            }
        };

        // Función para cargar reportes guardados
        function loadSavedReports() {
            const savedReports = savedReportsManager.getSavedReports();
            const savedReportsList = document.getElementById('savedReportsList');
            
            savedReportsList.innerHTML = '';
            
            if (savedReports.length === 0) {
                savedReportsList.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-bookmark"></i>
                        <h4>No hay reportes guardados</h4>
                        <p>Guarda un reporte para verlo aquí</p>
                    </div>
                `;
                return;
            }
            
            savedReports.forEach(report => {
                const reportCard = document.createElement('div');
                reportCard.className = 'saved-report-card';
                reportCard.innerHTML = `
                    <h6><i class="fas fa-file-alt me-2"></i>${report.name}</h6>
                    <p><small><i class="fas fa-tag me-1"></i>${report.reportType} | <i class="fas fa-calendar me-1"></i>${new Date(report.createdAt).toLocaleDateString()}</small></p>
                    <div class="saved-report-actions">
                        <button class="btn btn-sm btn-outline-primary load-report" data-id="${report.id}">
                            <i class="fas fa-eye me-1"></i>Cargar
                        </button>
                        <button class="btn btn-sm btn-outline-danger delete-report" data-id="${report.id}">
                            <i class="fas fa-trash me-1"></i>Eliminar
                        </button>
                    </div>
                `;
                
                savedReportsList.appendChild(reportCard);
            });
            
            // Agregar event listeners a los botones
            document.querySelectorAll('.load-report').forEach(btn => {
                btn.addEventListener('click', function() {
                    const reportId = this.getAttribute('data-id');
                    const report = savedReportsManager.getReportById(reportId);
                    
                    if (report) {
                        // Si el reporte tiene contenido guardado, cargarlo directamente
                        if (report.content) {
                            document.getElementById('reportContent').innerHTML = report.content;
                        } else {
                            // Si no, aplicar filtros y generar el reporte
                            applyFiltersFromSavedReport(report.filters);
                            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(report.reportType, report.filters);
                        }
                        
                        // Activar el botón del tipo de reporte correspondiente
                        document.querySelectorAll('.report-type-btn').forEach(b => b.classList.remove('active'));
                        const activeBtn = document.querySelector(`.report-type-btn[data-type="${report.reportType}"]`);
                        if (activeBtn) activeBtn.classList.add('active');
                        
                        productManager.showNotification(`Reporte "${report.name}" cargado`, 'success');
                    }
                });
            });
            
            document.querySelectorAll('.delete-report').forEach(btn => {
                btn.addEventListener('click', function() {
                    const reportId = this.getAttribute('data-id');
                    if (confirm('¿Estás seguro de que deseas eliminar este reporte guardado?')) {
                        savedReportsManager.deleteReport(parseInt(reportId));
                        loadSavedReports();
                        productManager.showNotification('Reporte eliminado', 'success');
                    }
                });
            });
        }
        
        // Función para aplicar filtros desde un reporte guardado
        function applyFiltersFromSavedReport(filters) {
            if (filters.category) document.getElementById('categoryFilter').value = filters.category;
            if (filters.stockStatus) document.getElementById('stockStatusFilter').value = filters.stockStatus;
            if (filters.minPrice) document.getElementById('minPrice').value = filters.minPrice;
            if (filters.maxPrice) document.getElementById('maxPrice').value = filters.maxPrice;
            if (filters.minStock) document.getElementById('minStock').value = filters.minStock;
            if (filters.maxStock) document.getElementById('maxStock').value = filters.maxStock;
            if (filters.sortBy) document.getElementById('sortBy').value = filters.sortBy;
        }
        
        // Función para obtener los filtros actuales
        function getCurrentFilters() {
            return {
                category: document.getElementById('categoryFilter').value,
                stockStatus: document.getElementById('stockStatusFilter').value,
                minPrice: document.getElementById('minPrice').value,
                maxPrice: document.getElementById('maxPrice').value,
                minStock: document.getElementById('minStock').value,
                maxStock: document.getElementById('maxStock').value,
                sortBy: document.getElementById('sortBy').value
            };
        }
        
        // Función para aplicar filtros
        function applyFilters() {
            const filters = getCurrentFilters();
            const activeReportType = document.querySelector('.report-type-btn.active').getAttribute('data-type');
            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(activeReportType, filters);
            productManager.showNotification('Filtros aplicados correctamente', 'success');
        }
        
        // Función para restablecer filtros
        function resetFilters() {
            document.getElementById('categoryFilter').value = 'all';
            document.getElementById('stockStatusFilter').value = 'all';
            document.getElementById('minPrice').value = '';
            document.getElementById('maxPrice').value = '';
            document.getElementById('minStock').value = '';
            document.getElementById('maxStock').value = '';
            document.getElementById('sortBy').value = 'name';
            
            const activeReportType = document.querySelector('.report-type-btn.active').getAttribute('data-type');
            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(activeReportType);
            productManager.showNotification('Filtros restablecidos', 'info');
        }
        
        // Función para guardar reporte
        function saveReport() {
            const reportName = prompt('Ingresa un nombre para el reporte:');
            if (reportName) {
                const filters = getCurrentFilters();
                const reportType = document.querySelector('.report-type-btn.active').getAttribute('data-type');
                const content = document.getElementById('reportContent').innerHTML;
                
                savedReportsManager.saveReport(reportName, filters, reportType, content);
                loadSavedReports();
                productManager.showNotification('Reporte guardado correctamente', 'success');
            }
        }
        
        // Función para orden rápido
        window.quickOrder = function(productId) {
            const product = productManager.getAllProducts().find(p => p.id === productId);
            if (product) {
                productManager.showNotification(`Solicitud de orden para ${product.name} enviada al proveedor`, 'success');
            }
        };
        
        // Función para cambiar tema
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            const themeIcon = document.querySelector('#themeToggle i');
            themeIcon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }
        
        // Función para toggle del menú en móviles
        function toggleMenu() {
            document.getElementById('sidebar').classList.toggle('open');
        }
        
        // Función para toggle de notificaciones
        function toggleNotifications() {
            document.getElementById('notificationDropdown').classList.toggle('show');
        }
        
        // Función para actualizar notificaciones de stock
        function updateStockNotifications() {
            const lowStockProducts = productManager.getAllProducts().filter(p => p.stock <= getConfiguredMinimumStock(p));
            const notificationBadge = document.getElementById('notificationBadge');
            const notificationList = document.getElementById('notificationList');
            
            if (lowStockProducts.length > 0) {
                notificationBadge.textContent = lowStockProducts.length;
                notificationBadge.classList.remove('hidden');
                
                notificationList.innerHTML = '';
                lowStockProducts.forEach(product => {
                    const notificationItem = document.createElement('div');
                    notificationItem.className = 'notification-item unread';
                    notificationItem.innerHTML = `
                        <strong><i class="fas fa-exclamation-triangle me-2" style="color: var(--warning);"></i>Stock bajo: ${product.name}</strong>
                        <p class="small mb-1">Quedan ${product.stock} unidades (mínimo ${getConfiguredMinimumStock(product)})</p>
                        <small>${new Date().toLocaleTimeString()}</small>
                    `;
                    notificationList.appendChild(notificationItem);
                });
            } else {
                notificationBadge.classList.add('hidden');
                notificationList.innerHTML = `
                    <div class="notification-item">
                        <p class="text-center mb-0"><i class="fas fa-check-circle me-2" style="color: var(--secondary);"></i>No hay notificaciones</p>
                    </div>
                `;
            }
        }
        
        // Cerrar dropdown de notificaciones al hacer clic fuera
        document.addEventListener('click', function(event) {
            const notificationBtn = document.getElementById('notificationBtn');
            const notificationDropdown = document.getElementById('notificationDropdown');
            
            if (notificationBtn && notificationDropdown && 
                !notificationBtn.contains(event.target) && 
                !notificationDropdown.contains(event.target)) {
                notificationDropdown.classList.remove('show');
            }
        });
        
        // Inicialización cuando el DOM está listo
        document.addEventListener('DOMContentLoaded', function() {
            // Cargar tema guardado
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            }
            
            // Generar reporte inicial
            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport('inventory');
            
            // Cargar reportes guardados
            loadSavedReports();
            
            // Iniciar actualizaciones en tiempo real
            advancedTensorFlowAnalyzer.initializeRealTimeUpdates();
            
            // Actualizar notificaciones iniciales
            updateStockNotifications();
            
            // Event listeners
            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            document.getElementById('menuToggle').addEventListener('click', toggleMenu);
            document.getElementById('notificationBtn').addEventListener('click', toggleNotifications);
            document.getElementById('exportDropdownBtn').addEventListener('click', () => reportGenerator.exportToExcel());
            document.getElementById('printReport').addEventListener('click', () => reportGenerator.printReport());
            document.getElementById('applyFilters').addEventListener('click', applyFilters);
            document.getElementById('resetFilters').addEventListener('click', resetFilters);
            document.getElementById('saveReport').addEventListener('click', saveReport);
            
            // Exportación por tipo de formato
            document.querySelectorAll('.dropdown-item[data-format]').forEach(item => {
                item.addEventListener('click', function(e) {
                    e.preventDefault();
                    const format = this.getAttribute('data-format');
                    
                    switch(format) {
                        case 'pdf':
                            reportGenerator.exportToPDF();
                            break;
                        case 'excel':
                            reportGenerator.exportToExcel();
                            break;
                        case 'csv':
                            reportGenerator.exportToCSV();
                            break;
                        case 'json':
                            reportGenerator.exportToJSON();
                            break;
                    }
                });
            });
            
            // Cambiar tipo de reporte
            document.querySelectorAll('.report-type-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.report-type-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    
                    const reportType = this.getAttribute('data-type');
                    const filters = getCurrentFilters();
                    document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(reportType, filters);
                });
            });
            
            // Actualizar notificaciones cada 30 segundos
            setInterval(updateStockNotifications, 30000);
            
            // Actualizar datos en tiempo real cada 5 segundos
            setInterval(() => {
                if (document.getElementById('realTimeInsights') && 
                    document.getElementById('realTimeInsights').style.display !== 'none') {
                    reportGenerator.updateRealTimeInfo();
                }
            }, 5000);
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>