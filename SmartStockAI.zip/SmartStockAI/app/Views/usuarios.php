<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Gestión de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Chart.js para gráficos -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- EmailJS para envío de correos -->
    <script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
    <!-- jsPDF para exportar PDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <!-- SheetJS para Excel -->
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 250px;
            --primary-rgb: 58, 94, 199;
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #000000;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #000000;
            transition: var(--transition);
            min-height: 100vh;
        }

        /* Scrollbar personalizado */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--primary);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary-dark);
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar mejorado */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 0;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 3px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
            margin-bottom: 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo i {
            font-size: 28px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: var(--transition);
            border-left: 4px solid transparent;
            font-weight: 500;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }

        .sidebar-menu i {
            width: 25px;
            font-size: 18px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: var(--transition);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: #000000;
        }

        .page-title i {
            color: var(--primary);
            margin-right: 10px;
        }

        .controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: #000000;
            position: relative;
        }

        .theme-switcher:hover, .notifications:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        /* Badge de notificaciones */
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        .notification-badge.hidden {
            display: none;
        }

        /* Dropdown de notificaciones */
        .notification-container {
            position: relative;
        }

        .notification-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            width: 350px;
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            z-index: 1000;
            display: none;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .notification-dropdown.show {
            display: block;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .notification-header {
            padding: 15px;
            border-bottom: 1px solid var(--gray);
            font-weight: 600;
            background: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .notification-header button {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            cursor: pointer;
        }

        .notification-list {
            max-height: 350px;
            overflow-y: auto;
        }

        .notification-item {
            padding: 15px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: var(--transition);
            cursor: pointer;
        }

        .notification-item:hover {
            background: rgba(58, 94, 199, 0.05);
        }

        .notification-item.unread {
            background: rgba(58, 94, 199, 0.1);
            border-left: 3px solid var(--primary);
        }

        .notification-item strong {
            display: block;
            margin-bottom: 5px;
            color: var(--primary);
        }

        .notification-item p {
            margin-bottom: 5px;
            font-size: 13px;
        }

        .notification-item small {
            color: var(--gray);
            font-size: 11px;
        }

        .notification-footer {
            padding: 10px 15px;
            text-align: center;
            border-top: 1px solid var(--gray);
        }

        .notification-footer a {
            color: var(--primary);
            text-decoration: none;
            font-size: 13px;
        }

        /* Estadísticas rápidas */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            transition: var(--transition);
            border-left: 4px solid transparent;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        .stat-users {
            border-left-color: var(--primary);
        }

        .stat-active {
            border-left-color: var(--secondary);
        }

        .stat-pending {
            border-left-color: var(--warning);
        }

        .stat-inactive {
            border-left-color: var(--danger);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 20px;
        }

        .stat-users .stat-icon {
            background: rgba(58, 94, 199, 0.2);
            color: var(--primary);
        }

        .stat-active .stat-icon {
            background: rgba(40, 167, 69, 0.2);
            color: var(--secondary);
        }

        .stat-pending .stat-icon {
            background: rgba(255, 193, 7, 0.2);
            color: var(--warning);
        }

        .stat-inactive .stat-icon {
            background: rgba(220, 53, 69, 0.2);
            color: var(--danger);
        }

        .stat-content {
            flex: 1;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: #000000;
            line-height: 1.2;
        }

        .stat-label {
            color: var(--gray);
            font-size: 14px;
            margin-bottom: 5px;
        }

        .stat-trend {
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .trend-up {
            color: var(--secondary);
        }

        .trend-down {
            color: var(--danger);
        }

        /* Gráficos */
        .charts-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .chart-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .chart-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .chart-title i {
            margin-right: 8px;
        }

        .chart-container {
            position: relative;
            height: 250px;
        }

        /* Filtros y Búsqueda mejorados */
        .filters-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .filters-section h5 {
            margin-bottom: 15px;
            color: var(--primary);
        }

        .search-box {
            position: relative;
        }

        .search-box input {
            padding-left: 40px;
            color: #000000;
            border-radius: var(--border-radius);
            border: 1px solid rgba(0,0,0,0.1);
            height: 45px;
        }

        .search-box input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.25);
        }

        .search-box input::placeholder {
            color: #999;
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 15px;
            color: var(--gray);
        }

        /* Búsqueda inteligente */
        .search-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border-radius: 0 0 var(--border-radius) var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            z-index: 100;
            max-height: 200px;
            overflow-y: auto;
            display: none;
            border: 1px solid rgba(0,0,0,0.1);
            border-top: none;
        }

        .search-suggestions.show {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        .suggestion-item {
            padding: 12px 15px;
            cursor: pointer;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .suggestion-item:last-child {
            border-bottom: none;
        }

        .suggestion-item:hover {
            background: rgba(58, 94, 199, 0.05);
        }

        .suggestion-item i {
            color: var(--primary);
            width: 20px;
        }

        .suggestion-highlight {
            font-weight: 600;
            color: var(--primary);
        }

        /* Filtros avanzados */
        .advanced-filters-toggle {
            background: transparent;
            border: 1px solid rgba(58, 94, 199, 0.3);
            color: var(--primary);
            font-size: 14px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 15px;
            border-radius: 20px;
            margin-top: 15px;
            transition: var(--transition);
        }

        .advanced-filters-toggle:hover {
            background: rgba(58, 94, 199, 0.1);
            border-color: var(--primary);
        }

        .advanced-filters-content {
            display: none;
            margin-top: 20px;
            padding: 20px;
            background: rgba(58, 94, 199, 0.05);
            border-radius: var(--border-radius);
            border: 1px solid rgba(58, 94, 199, 0.1);
        }

        .advanced-filters-content.show {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        .filter-group {
            margin-bottom: 20px;
        }

        .filter-title {
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--primary);
            font-size: 14px;
        }

        .filter-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .filter-tag {
            background: white;
            border: 1px solid rgba(0,0,0,0.1);
            border-radius: 20px;
            padding: 6px 15px;
            font-size: 13px;
            cursor: pointer;
            transition: var(--transition);
        }

        .filter-tag.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .filter-tag:hover {
            background: rgba(58, 94, 199, 0.1);
            border-color: var(--primary);
        }

        .filter-tag.active:hover {
            background: var(--primary-dark);
        }

        /* Acciones masivas */
        .bulk-actions {
            background: var(--primary);
            border-radius: var(--border-radius);
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3);
            display: none;
            color: white;
            animation: slideDown 0.3s ease;
        }

        .bulk-actions.show {
            display: block;
        }

        .bulk-actions .btn-outline-primary {
            background: white;
            border: none;
            color: var(--primary) !important;
        }

        .bulk-actions .btn-outline-primary:hover {
            background: var(--light);
            transform: translateY(-2px);
        }

        .bulk-actions .btn-outline-warning {
            background: white;
            border: none;
            color: var(--warning) !important;
        }

        .bulk-actions .btn-outline-danger {
            background: white;
            border: none;
            color: var(--danger) !important;
        }

        .bulk-actions .btn-outline-secondary {
            background: white;
            border: none;
            color: var(--gray) !important;
        }

        /* Tabla de Usuarios mejorada */
        .users-table {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            background: rgba(58, 94, 199, 0.02);
        }

        .table-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--primary);
        }

        .table-title i {
            margin-right: 8px;
        }

        .table-info {
            color: var(--gray);
            font-size: 14px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            color: #000000;
        }

        th {
            font-weight: 600;
            background: rgba(58, 94, 199, 0.05);
            color: var(--primary);
            font-size: 14px;
        }

        tr:hover {
            background: rgba(58, 94, 199, 0.02);
        }

        .user-info-cell {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar-thumb {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--primary);
        }

        .user-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
            margin-top: 5px;
        }

        .user-tag {
            background: #e9ecef;
            border-radius: 12px;
            padding: 2px 8px;
            font-size: 10px;
            color: #495057;
        }

        .tag-admin {
            background: #ebf8ff;
            color: #3182ce;
        }

        .tag-supervisor {
            background: #f0fff4;
            color: #38a169;
        }

        .tag-new {
            background: #fff5f5;
            color: #e53e3e;
        }

        .tag-vip {
            background: #fff5f0;
            color: #dd6b20;
        }

        /* Badges para estados */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }

        .badge.bg-success {
            background-color: var(--secondary);
        }

        .badge.bg-warning {
            background-color: var(--warning);
            color: #000;
        }

        .badge.bg-danger {
            background-color: var(--danger);
        }

        .badge.bg-info {
            background-color: var(--info);
        }

        .badge.bg-primary {
            background-color: var(--primary);
        }

        .badge.bg-secondary {
            background-color: var(--gray);
        }

        /* Botones de acción */
        .action-btn {
            padding: 6px 10px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            transition: var(--transition);
            color: white;
            font-size: 12px;
            width: 30px;
            height: 30px;
        }

        .btn-view {
            background: var(--info);
        }

        .btn-edit {
            background: var(--primary);
        }

        .btn-delete {
            background: var(--danger);
        }

        .btn-permissions {
            background: #6f42c1;
        }

        .btn-email {
            background: var(--warning);
            color: #000;
        }

        .btn-reset {
            background: var(--secondary);
        }

        .action-btn:hover {
            opacity: 0.8;
            transform: translateY(-2px);
        }

        /* Paginación mejorada */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-top: 1px solid rgba(0,0,0,0.05);
        }

        .pagination-info {
            color: var(--gray);
            font-size: 14px;
        }

        .pagination {
            display: flex;
            gap: 5px;
        }

        .page-item {
            list-style: none;
        }

        .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: 8px;
            border: 1px solid rgba(0,0,0,0.1);
            color: #000000;
            text-decoration: none;
            transition: var(--transition);
            font-size: 14px;
        }

        .page-link:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.active .page-link {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.disabled .page-link {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Modal mejorado */
        .modal-content {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            color: #000000 !important;
            background-color: #ffffff !important;
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border-top-left-radius: var(--border-radius);
            border-top-right-radius: var(--border-radius);
            padding: 20px;
        }

        .modal-header h5 {
            color: white;
        }

        .modal-header .btn-close {
            filter: invert(1);
        }

        .modal-body {
            padding: 25px;
            color: #000000 !important;
        }

        .modal-body p, 
        .modal-body span, 
        .modal-body strong,
        .modal-body div:not(.badge) {
            color: #000000 !important;
        }

        .modal-footer {
            padding: 20px;
            border-top: 1px solid rgba(0,0,0,0.05);
        }

        /* Avatar en modales */
        .user-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
            border: 3px solid var(--primary);
            box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3);
        }

        .avatar-upload {
            position: relative;
            display: inline-block;
        }

        .avatar-upload-label {
            position: absolute;
            bottom: 0;
            right: 0;
            background: var(--primary);
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: 2px solid white;
        }

        /* Permisos en grid */
        .permissions-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
            max-height: 300px;
            overflow-y: auto;
            padding: 10px;
            background: rgba(58, 94, 199, 0.05);
            border-radius: var(--border-radius);
        }

        .permission-item {
            display: flex;
            align-items: center;
            padding: 8px;
            background: white;
            border-radius: 8px;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .permission-item input[type="checkbox"] {
            margin-right: 10px;
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .permission-item label {
            cursor: pointer;
            font-size: 14px;
        }

        /* Historial de actividad */
        .activity-log {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .activity-log h5 {
            margin-bottom: 15px;
            color: var(--primary);
        }

        .activity-item {
            display: flex;
            padding: 12px 0;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            transition: var(--transition);
        }

        .activity-item:hover {
            background: rgba(58, 94, 199, 0.02);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 16px;
        }

        .activity-login .activity-icon {
            background: rgba(40, 167, 69, 0.2);
            color: var(--secondary);
        }

        .activity-edit .activity-icon {
            background: rgba(58, 94, 199, 0.2);
            color: var(--primary);
        }

        .activity-create .activity-icon {
            background: rgba(23, 162, 184, 0.2);
            color: var(--info);
        }

        .activity-delete .activity-icon {
            background: rgba(220, 53, 69, 0.2);
            color: var(--danger);
        }

        .activity-permissions .activity-icon {
            background: rgba(111, 66, 193, 0.2);
            color: #6f42c1;
        }

        .activity-info {
            flex: 1;
        }

        .activity-title {
            font-weight: 600;
            margin-bottom: 3px;
        }

        .activity-desc {
            font-size: 14px;
            color: var(--gray);
            margin-bottom: 3px;
        }

        .activity-time {
            font-size: 12px;
            color: var(--gray);
        }

        .activity-user {
            font-size: 12px;
            font-weight: 600;
            color: var(--primary);
        }

        /* Indicador de fortaleza de contraseña */
        .password-strength {
            height: 5px;
            border-radius: 5px;
            margin-top: 8px;
            transition: var(--transition);
            background: #e9ecef;
            overflow: hidden;
        }

        .strength-bar {
            height: 100%;
            width: 0;
            transition: width 0.3s ease;
        }

        .strength-weak .strength-bar {
            background-color: var(--danger);
            width: 25%;
        }

        .strength-medium .strength-bar {
            background-color: var(--warning);
            width: 50%;
        }

        .strength-strong .strength-bar {
            background-color: var(--secondary);
            width: 75%;
        }

        .strength-very-strong .strength-bar {
            background-color: var(--primary);
            width: 100%;
        }

        .password-requirements {
            font-size: 12px;
            color: var(--gray);
            margin-top: 5px;
        }

        .password-match {
            font-size: 12px;
            margin-top: 5px;
        }

        .match-success {
            color: var(--secondary);
        }

        .match-error {
            color: var(--danger);
        }

        /* Exportación mejorada */
        .export-options {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            z-index: 100;
            width: 200px;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .export-options.show {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        .export-option {
            padding: 10px 12px;
            cursor: pointer;
            border-radius: 5px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .export-option:hover {
            background: rgba(58, 94, 199, 0.05);
        }

        .export-option i {
            width: 20px;
            color: var(--primary);
        }

        /* Tooltips */
        [data-tooltip] {
            position: relative;
            cursor: help;
        }

        [data-tooltip]:before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 5px 10px;
            background: var(--dark);
            color: white;
            border-radius: 4px;
            font-size: 11px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 1000;
            pointer-events: none;
        }

        [data-tooltip]:hover:before {
            opacity: 1;
            visibility: visible;
            bottom: 120%;
        }

        /* Toast de notificaciones */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
        }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            padding: 15px 20px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            animation: slideInRight 0.3s forwards;
            min-width: 300px;
            border-left: 4px solid var(--primary);
        }

        .toast.success {
            border-left-color: var(--secondary);
        }

        .toast.error {
            border-left-color: var(--danger);
        }

        .toast.warning {
            border-left-color: var(--warning);
        }

        .toast.info {
            border-left-color: var(--primary);
        }

        .toast i {
            margin-right: 15px;
            font-size: 20px;
        }

        .toast.success i {
            color: var(--secondary);
        }

        .toast.error i {
            color: var(--danger);
        }

        .toast.warning i {
            color: var(--warning);
        }

        .toast.info i {
            color: var(--primary);
        }

        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        /* Botones */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
        }

        .btn-primary {
            background: var(--primary);
            color: white !important;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3);
        }

        .btn-success {
            background: var(--secondary);
            color: white !important;
        }

        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
        }

        .btn-outline-secondary {
            border: 1px solid var(--gray);
            color: #000 !important;
        }

        .btn-outline-secondary:hover {
            background: var(--gray);
            color: white !important;
        }

        /* Estado vacío */
        .empty-state {
            text-align: center;
            padding: 40px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: var(--gray);
        }

        .empty-state h4 {
            margin-bottom: 10px;
        }

        /* Animaciones */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 0;
            }
            
            .sidebar.open {
                transform: translateX(0);
                width: var(--sidebar-width);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .menu-toggle {
                display: block;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .controls {
                margin-top: 15px;
                width: 100%;
                justify-content: space-between;
            }
        }

        @media (max-width: 768px) {
            .stats-container {
                grid-template-columns: 1fr;
            }

            .filters-section .row {
                gap: 10px;
            }

            .filter-actions {
                flex-direction: column;
            }

            .filter-actions .btn {
                width: 100%;
            }

            .table-header {
                flex-direction: column;
                gap: 10px;
            }

            .pagination-container {
                flex-direction: column;
                gap: 10px;
            }

            .notification-dropdown {
                width: 300px;
                right: -50px;
            }

            .charts-container {
                grid-template-columns: 1fr;
            }

            .modal-dialog {
                margin: 10px;
            }

            .bulk-actions .d-flex {
                flex-direction: column;
                gap: 10px;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 15px;
            }

            .stats-container {
                gap: 10px;
            }

            .stat-card {
                padding: 15px;
            }

            .stat-icon {
                width: 45px;
                height: 45px;
                font-size: 18px;
            }

            .stat-value {
                font-size: 20px;
            }

            .notification-dropdown {
                width: 280px;
                right: -70px;
            }

            .toast {
                min-width: 250px;
            }

            .action-btn {
                margin-bottom: 5px;
            }
        }

        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 1001;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            cursor: pointer;
            transition: var(--transition);
        }

        .menu-toggle:hover {
            transform: scale(1.1);
            background: var(--primary-dark);
        }

        /* Asegurar que todos los textos sean negros */
        body, body *:not(.sidebar *):not(.modal-header *):not(.action-btn):not(.badge):not(.page-link:hover):not(.page-item.active .page-link) {
            color: #000000 !important;
        }

        /* Ajustes para mantener contraste en elementos especiales */
        .sidebar, .modal-header, .action-btn, .badge, .page-link:hover, .page-item.active .page-link {
            color: white !important;
        }

        /* Inputs y selects */
        .form-control, .form-select {
            color: #000000 !important;
            background-color: #ffffff !important;
            border: 1px solid rgba(0,0,0,0.1);
            border-radius: 8px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.25);
        }

        .form-control::placeholder {
            color: #999 !important;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot"></i>
                    <span>SmartStock AI</span>
                </div>
            </div>
            
            <ul class="sidebar-menu">
               <li><a href="http://localhost/SmartStockAI/admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes"></i> Inventario</a></li>
                <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck"></i> Proveedores</a></li>
                <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users"></i> Usuarios</a></li>
                <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-exchange-alt"></i> Transacciones</a></li>
                <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-line"></i> Reportes</a></li>
                <li><a href="#" class="active"><i class="fas fa-user-friends"></i> Clientes</a></li>
                <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-user"></i> Mi Perfil</a></li>
                <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-alt"></i> Seguridad</a></li>
                <li><a href="http://localhost/SmartStockAI/login.php"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a></li>
                <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-cog"></i> Configuración</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1 class="page-title">
                    <i class="fas fa-users-cog"></i>
                    Gestión de Usuarios
                </h1>
                
                <div class="controls">
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notification-container">
                        <div class="notifications" id="notificationBtn">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge" id="notificationBadge">3</span>
                        </div>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-header">
                                <span><i class="fas fa-bell me-2"></i>Notificaciones</span>
                                <button id="markAllRead">Marcar todas</button>
                            </div>
                            <div class="notification-list" id="notificationList">
                                <!-- Las notificaciones se cargarán dinámicamente -->
                            </div>
                            <div class="notification-footer">
                                <a href="#" id="viewAllNotifications">Ver todas las notificaciones</a>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary" id="btnNewUser">
                        <i class="fas fa-user-plus me-2"></i>Nuevo Usuario
                    </button>
                </div>
            </div>
            
            <!-- Estadísticas rápidas mejoradas -->
            <div class="stats-container">
                <div class="stat-card stat-users">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Total de Usuarios</div>
                        <div class="stat-value" id="totalUsers">0</div>
                        <div class="stat-trend" id="totalTrend">
                            <i class="fas fa-arrow-up trend-up"></i>
                            <span class="trend-up">+12% este mes</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-active">
                    <div class="stat-icon">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Usuarios Activos</div>
                        <div class="stat-value" id="activeUsers">0</div>
                        <div class="stat-trend">
                            <i class="fas fa-circle text-success"></i>
                            <span id="activePercentage">0% del total</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-pending">
                    <div class="stat-icon">
                        <i class="fas fa-user-clock"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Usuarios Pendientes</div>
                        <div class="stat-value" id="pendingUsers">0</div>
                        <div class="stat-trend" id="pendingTrend">
                            <i class="fas fa-exclamation-triangle text-warning"></i>
                            <span class="text-warning">Requieren activación</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-inactive">
                    <div class="stat-icon">
                        <i class="fas fa-user-slash"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Usuarios Inactivos</div>
                        <div class="stat-value" id="inactiveUsers">0</div>
                        <div class="stat-trend">
                            <i class="fas fa-clock"></i>
                            <span id="inactiveInfo">Última semana</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Gráficos de estadísticas -->
            <div class="charts-container">
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-chart-pie"></i>
                        Distribución por Rol
                    </div>
                    <div class="chart-container">
                        <canvas id="usersByRoleChart"></canvas>
                    </div>
                </div>
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-chart-line"></i>
                        Actividad de Usuarios (últimos 7 días)
                    </div>
                    <div class="chart-container">
                        <canvas id="userActivityChart"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Historial de actividad reciente -->
            <div class="activity-log">
                <h5>
                    <i class="fas fa-history me-2"></i>
                    Actividad Reciente
                </h5>
                <div id="activityList">
                    <!-- La actividad se cargará dinámicamente -->
                </div>
            </div>
            
            <!-- Acciones masivas -->
            <div class="bulk-actions" id="bulkActions">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-check-circle me-2"></i>
                        <span id="selectedCount">0 usuarios seleccionados</span>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-sm btn-outline-primary" id="btnBulkActivate" data-tooltip="Activar usuarios seleccionados">
                            <i class="fas fa-check me-1"></i> Activar
                        </button>
                        <button class="btn btn-sm btn-outline-warning" id="btnBulkDeactivate" data-tooltip="Desactivar usuarios seleccionados">
                            <i class="fas fa-ban me-1"></i> Desactivar
                        </button>
                        <button class="btn btn-sm btn-outline-danger" id="btnBulkDelete" data-tooltip="Eliminar usuarios seleccionados">
                            <i class="fas fa-trash me-1"></i> Eliminar
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" id="btnBulkEmail" data-tooltip="Enviar correo masivo">
                            <i class="fas fa-envelope me-1"></i> Email
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" id="btnClearSelection">
                            <i class="fas fa-times me-1"></i> Limpiar
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Filtros y Búsqueda mejorados -->
            <div class="filters-section">
                <h5><i class="fas fa-filter me-2"></i>Filtros y Búsqueda</h5>
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" class="form-control" id="searchInput" placeholder="Buscar por nombre, email o ID...">
                            <div class="search-suggestions" id="searchSuggestions"></div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <select class="form-select" id="roleFilter">
                            <option value="all">Rol: Todos</option>
                            <option value="Administrador">Administrador</option>
                            <option value="Supervisor">Supervisor</option>
                            <option value="Usuario">Usuario</option>
                            <option value="Invitado">Invitado</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select class="form-select" id="statusFilter">
                            <option value="all">Estado: Todos</option>
                            <option value="Activo">Activo</option>
                            <option value="Inactivo">Inactivo</option>
                            <option value="Pendiente">Pendiente</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-outline-secondary w-100" id="btnExport">
                            <i class="fas fa-download me-1"></i> Exportar
                        </button>
                        <div class="export-options" id="exportOptions">
                            <div class="export-option" data-format="csv">
                                <i class="fas fa-file-csv"></i> CSV
                            </div>
                            <div class="export-option" data-format="excel">
                                <i class="fas fa-file-excel"></i> Excel
                            </div>
                            <div class="export-option" data-format="pdf">
                                <i class="fas fa-file-pdf"></i> PDF
                            </div>
                            <div class="export-option" data-format="json">
                                <i class="fas fa-file-code"></i> JSON
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-outline-secondary w-100" id="btnRefresh">
                            <i class="fas fa-sync-alt me-1"></i> Actualizar
                        </button>
                    </div>
                </div>
                
                <!-- Filtros avanzados -->
                <button class="advanced-filters-toggle" id="advancedFiltersToggle">
                    <i class="fas fa-sliders-h"></i> Filtros avanzados
                </button>
                <div class="advanced-filters-content" id="advancedFiltersContent">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="filter-group">
                                <div class="filter-title">Fecha de Registro</div>
                                <div class="row">
                                    <div class="col-6">
                                        <input type="date" class="form-control" id="dateFrom" placeholder="Desde">
                                    </div>
                                    <div class="col-6">
                                        <input type="date" class="form-control" id="dateTo" placeholder="Hasta">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="filter-group">
                                <div class="filter-title">Último Acceso</div>
                                <div class="filter-tags" id="lastAccessTags">
                                    <div class="filter-tag" data-value="today">Hoy</div>
                                    <div class="filter-tag" data-value="week">Esta semana</div>
                                    <div class="filter-tag" data-value="month">Este mes</div>
                                    <div class="filter-tag" data-value="never">Nunca</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="filter-group">
                                <div class="filter-title">Etiquetas</div>
                                <div class="filter-tags" id="tagFilters">
                                    <div class="filter-tag" data-value="admin">Administradores</div>
                                    <div class="filter-tag" data-value="supervisor">Supervisores</div>
                                    <div class="filter-tag" data-value="new">Nuevos</div>
                                    <div class="filter-tag" data-value="vip">VIP</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <button class="btn btn-sm btn-primary" id="applyAdvancedFilters">
                                <i class="fas fa-check me-1"></i> Aplicar filtros
                            </button>
                            <button class="btn btn-sm btn-outline-secondary" id="clearAdvancedFilters">
                                <i class="fas fa-times me-1"></i> Limpiar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Tabla de Usuarios mejorada -->
            <div class="users-table">
                <div class="table-header">
                    <h3 class="table-title">
                        <i class="fas fa-list"></i>
                        Lista de Usuarios
                    </h3>
                    <span class="table-info" id="userCount">Mostrando 0 de 0 usuarios</span>
                </div>
                
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th width="50">
                                    <input type="checkbox" id="selectAllUsers">
                                </th>
                                <th>ID</th>
                                <th>Usuario</th>
                                <th>Email</th>
                                <th>Rol</th>
                                <th>Estado</th>
                                <th>Último acceso</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="usersTableBody">
                            <!-- Los usuarios se cargarán dinámicamente -->
                        </tbody>
                    </table>
                </div>
                
                <!-- Paginación mejorada -->
                <div class="pagination-container">
                    <div class="pagination-info" id="paginationInfo">
                        Mostrando 1-8 de 0 usuarios
                    </div>
                    <ul class="pagination" id="pagination">
                        <!-- La paginación se generará dinámicamente -->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para agregar/editar usuario (mejorado) -->
    <div class="modal fade" id="userModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">
                        <i class="fas fa-user-plus me-2"></i>
                        Agregar Nuevo Usuario
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="userForm">
                        <input type="hidden" id="userId">
                        
                        <!-- Avatar upload mejorado -->
                        <div class="text-center mb-4">
                            <div class="avatar-upload">
                                <img src="https://via.placeholder.com/100x100?text=NU" id="userAvatarPreview" class="user-avatar">
                                <label for="userAvatar" class="avatar-upload-label" data-tooltip="Cambiar avatar">
                                    <i class="fas fa-camera"></i>
                                </label>
                                <input type="file" id="userAvatar" accept="image/*" style="display: none;">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="userName" class="form-label">Nombre completo</label>
                                    <input type="text" class="form-control" id="userName" required placeholder="Ej: Juan Pérez">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="userEmail" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="userEmail" required placeholder="ejemplo@correo.com">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="userPhone" class="form-label">Teléfono</label>
                                    <input type="tel" class="form-control" id="userPhone" placeholder="+1234567890">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="userDepartment" class="form-label">Departamento</label>
                                    <select class="form-select" id="userDepartment">
                                        <option value="">Seleccionar</option>
                                        <option value="Ventas">Ventas</option>
                                        <option value="Compras">Compras</option>
                                        <option value="Inventario">Inventario</option>
                                        <option value="Administración">Administración</option>
                                        <option value="IT">IT</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="userRole" class="form-label">Rol</label>
                                    <select class="form-select" id="userRole" required>
                                        <option value="">Seleccionar rol</option>
                                        <option value="Administrador">Administrador</option>
                                        <option value="Supervisor">Supervisor</option>
                                        <option value="Usuario">Usuario</option>
                                        <option value="Invitado">Invitado</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="userStatus" class="form-label">Estado</label>
                                    <select class="form-select" id="userStatus" required>
                                        <option value="Activo">Activo</option>
                                        <option value="Inactivo">Inactivo</option>
                                        <option value="Pendiente">Pendiente</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row" id="passwordFields">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="userPassword" class="form-label">Contraseña</label>
                                    <input type="password" class="form-control" id="userPassword">
                                    <div class="password-strength" id="passwordStrength">
                                        <div class="strength-bar"></div>
                                    </div>
                                    <div class="password-requirements">
                                        Mínimo 8 caracteres, mayúsculas, minúsculas y números
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="userPasswordConfirm" class="form-label">Confirmar contraseña</label>
                                    <input type="password" class="form-control" id="userPasswordConfirm">
                                    <div class="password-match" id="passwordMatch"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="userDescription" class="form-label">Descripción/Notas</label>
                            <textarea class="form-control" id="userDescription" rows="2" placeholder="Información adicional sobre el usuario..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </button>
                    <button type="button" class="btn btn-primary" id="saveUser">
                        <i class="fas fa-save me-1"></i> Guardar Usuario
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para ver usuario (mejorado) -->
    <div class="modal fade" id="viewUserModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-user-circle me-2"></i>
                        Detalles del Usuario
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <img id="viewUserAvatar" src="https://via.placeholder.com/100x100?text=AV" alt="Avatar del usuario" class="user-avatar">
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>ID:</strong> <span id="viewUserId"></span></p>
                            <p><strong>Nombre:</strong> <span id="viewUserName"></span></p>
                            <p><strong>Email:</strong> <span id="viewUserEmail"></span></p>
                            <p><strong>Teléfono:</strong> <span id="viewUserPhone">-</span></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Rol:</strong> <span id="viewUserRole" class="badge"></span></p>
                            <p><strong>Estado:</strong> <span id="viewUserStatus" class="badge"></span></p>
                            <p><strong>Departamento:</strong> <span id="viewUserDepartment">-</span></p>
                            <p><strong>Último acceso:</strong> <span id="viewUserLastAccess"></span></p>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <p><strong>Fecha de registro:</strong> <span id="viewUserRegistration"></span></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>IP de registro:</strong> <span id="viewUserIP">192.168.1.1</span></p>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <strong>Descripción/Notas:</strong>
                        <p id="viewUserDescription" class="mt-2 p-3 bg-light rounded">Sin descripción</p>
                    </div>
                    
                    <div class="mt-4">
                        <strong><i class="fas fa-key me-2"></i>Permisos:</strong>
                        <div id="viewUserPermissions" class="permissions-container mt-2">
                            <!-- Los permisos se cargarán dinámicamente -->
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <strong><i class="fas fa-history me-2"></i>Actividad reciente:</strong>
                        <div id="viewUserActivity" class="mt-2">
                            <!-- La actividad se cargará dinámicamente -->
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Cerrar
                    </button>
                    <button type="button" class="btn btn-primary" id="btnEditFromView">
                        <i class="fas fa-edit me-1"></i> Editar
                    </button>
                    <button type="button" class="btn btn-success" id="btnEmailFromView">
                        <i class="fas fa-envelope me-1"></i> Enviar Email
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para gestionar permisos (mejorado) -->
    <div class="modal fade" id="permissionsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-key me-2"></i>
                        Gestión de Permisos
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p><strong>Usuario:</strong> <span id="permissionsUserName"></span></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Rol:</strong> <span id="permissionsUserRole"></span></p>
                        </div>
                    </div>
                    
                    <h6 class="mb-3">Permisos del usuario:</h6>
                    <div class="permissions-container">
                        <div class="permission-item">
                            <input type="checkbox" id="permInventory">
                            <label for="permInventory">Gestión de Inventario</label>
                        </div>
                        <div class="permission-item">
                            <input type="checkbox" id="permUsers">
                            <label for="permUsers">Gestión de Usuarios</label>
                        </div>
                        <div class="permission-item">
                            <input type="checkbox" id="permReports">
                            <label for="permReports">Ver Reportes</label>
                        </div>
                        <div class="permission-item">
                            <input type="checkbox" id="permSales">
                            <label for="permSales">Gestión de Ventas</label>
                        </div>
                        <div class="permission-item">
                            <input type="checkbox" id="permSettings">
                            <label for="permSettings">Configuración</label>
                        </div>
                        <div class="permission-item">
                            <input type="checkbox" id="permExport">
                            <label for="permExport">Exportar Datos</label>
                        </div>
                        <div class="permission-item">
                            <input type="checkbox" id="permClients">
                            <label for="permClients">Gestión de Clientes</label>
                        </div>
                        <div class="permission-item">
                            <input type="checkbox" id="permSuppliers">
                            <label for="permSuppliers">Gestión de Proveedores</label>
                        </div>
                        <div class="permission-item">
                            <input type="checkbox" id="permTransactions">
                            <label for="permTransactions">Ver Transacciones</label>
                        </div>
                        <div class="permission-item">
                            <input type="checkbox" id="permAudit">
                            <label for="permAudit">Auditoría</label>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <label class="form-check">
                            <input type="checkbox" class="form-check-input" id="permSelectAll">
                            <span class="form-check-label">Seleccionar todos</span>
                        </label>
                    </div>
                    
                    <div class="alert alert-info mt-3">
                        <i class="fas fa-info-circle me-2"></i>
                        Los permisos heredados del rol no se pueden modificar individualmente.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </button>
                    <button type="button" class="btn btn-primary" id="savePermissions">
                        <i class="fas fa-save me-1"></i> Guardar Permisos
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para enviar correo -->
    <div class="modal fade" id="emailModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-envelope me-2"></i>
                        Enviar Correo
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="emailUserId">
                    <input type="hidden" id="emailUserEmail">
                    
                    <div class="mb-3">
                        <label for="emailTo" class="form-label">Para</label>
                        <input type="email" class="form-control" id="emailTo" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label for="emailSubject" class="form-label">Asunto</label>
                        <input type="text" class="form-control" id="emailSubject" value="Notificación de SmartStock AI">
                    </div>
                    
                    <div class="mb-3">
                        <label for="emailMessage" class="form-label">Mensaje</label>
                        <textarea class="form-control" id="emailMessage" rows="5" placeholder="Escribe tu mensaje aquí..."></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-check">
                            <input type="checkbox" class="form-check-input" id="emailCopyMe">
                            <span class="form-check-label">Enviarme una copia</span>
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </button>
                    <button type="button" class="btn btn-primary" id="sendEmail">
                        <i class="fas fa-paper-plane me-1"></i> Enviar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para restablecer contraseña -->
    <div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-key me-2"></i>
                        Restablecer Contraseña
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="resetUserId">
                    <input type="hidden" id="resetUserEmail">
                    
                    <p>Se enviará un enlace de restablecimiento de contraseña al correo del usuario.</p>
                    
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        El usuario recibirá un correo con instrucciones para crear una nueva contraseña.
                    </div>
                    
                    <div class="mb-3">
                        <label for="resetEmail" class="form-label">Correo del usuario</label>
                        <input type="email" class="form-control" id="resetEmail" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </button>
                    <button type="button" class="btn btn-primary" id="sendResetLink">
                        <i class="fas fa-paper-plane me-1"></i> Enviar enlace
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============================================
        // CLASE PARA GESTIONAR USUARIOS (VERSIÓN MEJORADA)
        // ============================================
        class EnhancedUserManager {
            constructor() {
                this.users = JSON.parse(localStorage.getItem('users')) || [];
                this.activityLog = JSON.parse(localStorage.getItem('userActivity')) || [];
                this.notifications = JSON.parse(localStorage.getItem('notifications')) || [];
                this.currentUserId = null;
                this.currentPage = 1;
                this.itemsPerPage = 8;
                this.filteredUsers = [];
                this.selectedUsers = new Set();
                this.activeFilters = {
                    search: '',
                    role: 'all',
                    status: 'all',
                    dateFrom: '',
                    dateTo: '',
                    lastAccess: [],
                    tags: []
                };
                this.charts = {};
                
                // Inicializar EmailJS
                this.initEmailJS();
                
                // Inicializar con datos de ejemplo si no hay usuarios
                if (this.users.length === 0) {
                    this.initializeSampleData();
                }
                
                // Inicializar actividad si no existe
                if (this.activityLog.length === 0) {
                    this.initializeSampleActivity();
                }
                
                // Inicializar notificaciones
                if (this.notifications.length === 0) {
                    this.initializeNotifications();
                }
            }
            
            initEmailJS() {
                // Configuración de EmailJS
                // IMPORTANTE: Reemplaza con tus credenciales de EmailJS
                this.emailJSConfig = {
                    serviceId: 'service_smartstock',
                    templateId: 'template_user_notification',
                    publicKey: 'YOUR_PUBLIC_KEY'
                };
                
                // Inicializar EmailJS
                if (typeof emailjs !== 'undefined') {
                    emailjs.init(this.emailJSConfig.publicKey);
                    console.log('EmailJS inicializado correctamente');
                } else {
                    console.error('EmailJS no está cargado');
                }
            }
            
            initializeSampleData() {
                const now = new Date();
                const today = now.toISOString().split('T')[0];
                const yesterday = new Date(now.setDate(now.getDate() - 1)).toISOString().split('T')[0];
                const lastWeek = new Date(now.setDate(now.getDate() - 7)).toISOString().split('T')[0];
                
                this.users = [
                    {
                        id: 'USR-001',
                        name: 'Admin User',
                        email: 'admin@smartstock.com',
                        phone: '+34 612 345 678',
                        department: 'Administración',
                        role: 'Administrador',
                        status: 'Activo',
                        lastAccess: 'Hoy, 09:45',
                        avatar: 'https://ui-avatars.com/api/?name=Admin+User&background=3a5ec7&color=fff&size=100',
                        description: 'Usuario administrador principal con todos los permisos',
                        permissions: {
                            inventory: true,
                            users: true,
                            reports: true,
                            sales: true,
                            settings: true,
                            export: true,
                            clients: true,
                            suppliers: true,
                            transactions: true,
                            audit: true
                        },
                        registrationDate: '2023-01-15',
                        registrationIP: '192.168.1.100',
                        tags: ['admin', 'vip']
                    },
                    {
                        id: 'USR-002',
                        name: 'María García',
                        email: 'maria.garcia@empresa.com',
                        phone: '+34 623 456 789',
                        department: 'Ventas',
                        role: 'Supervisor',
                        status: 'Activo',
                        lastAccess: 'Ayer, 16:30',
                        avatar: 'https://ui-avatars.com/api/?name=Maria+Garcia&background=28a745&color=fff&size=100',
                        description: 'Supervisora del departamento de ventas',
                        permissions: {
                            inventory: true,
                            users: false,
                            reports: true,
                            sales: true,
                            settings: false,
                            export: true,
                            clients: true,
                            suppliers: false,
                            transactions: true,
                            audit: false
                        },
                        registrationDate: '2023-03-20',
                        registrationIP: '192.168.1.105',
                        tags: ['supervisor']
                    },
                    {
                        id: 'USR-003',
                        name: 'Juan Pérez',
                        email: 'juan.perez@empresa.com',
                        phone: '+34 634 567 890',
                        department: 'Compras',
                        role: 'Usuario',
                        status: 'Pendiente',
                        lastAccess: 'Nunca',
                        avatar: 'https://ui-avatars.com/api/?name=Juan+Perez&background=ffc107&color=000&size=100',
                        description: 'Nuevo usuario pendiente de activación',
                        permissions: {
                            inventory: true,
                            users: false,
                            reports: false,
                            sales: false,
                            settings: false,
                            export: false,
                            clients: false,
                            suppliers: true,
                            transactions: false,
                            audit: false
                        },
                        registrationDate: '2023-06-10',
                        registrationIP: '192.168.1.110',
                        tags: ['new']
                    },
                    {
                        id: 'USR-004',
                        name: 'Laura Rodríguez',
                        email: 'laura.rodriguez@empresa.com',
                        phone: '+34 645 678 901',
                        department: 'Inventario',
                        role: 'Supervisor',
                        status: 'Activo',
                        lastAccess: 'Hoy, 08:15',
                        avatar: 'https://ui-avatars.com/api/?name=Laura+Rodriguez&background=28a745&color=fff&size=100',
                        description: 'Supervisora de inventario',
                        permissions: {
                            inventory: true,
                            users: false,
                            reports: true,
                            sales: false,
                            settings: false,
                            export: true,
                            clients: false,
                            suppliers: true,
                            transactions: true,
                            audit: false
                        },
                        registrationDate: '2023-02-28',
                        registrationIP: '192.168.1.115',
                        tags: ['supervisor']
                    },
                    {
                        id: 'USR-005',
                        name: 'Carlos López',
                        email: 'carlos.lopez@empresa.com',
                        phone: '+34 656 789 012',
                        department: 'Ventas',
                        role: 'Usuario',
                        status: 'Inactivo',
                        lastAccess: '15/05/2023',
                        avatar: 'https://ui-avatars.com/api/?name=Carlos+Lopez&background=6c757d&color=fff&size=100',
                        description: 'Usuario desactivado por inactividad',
                        permissions: {
                            inventory: true,
                            users: false,
                            reports: false,
                            sales: true,
                            settings: false,
                            export: false,
                            clients: true,
                            suppliers: false,
                            transactions: true,
                            audit: false
                        },
                        registrationDate: '2023-04-05',
                        registrationIP: '192.168.1.120',
                        tags: []
                    },
                    {
                        id: 'USR-006',
                        name: 'Ana Martínez',
                        email: 'ana.martinez@empresa.com',
                        phone: '+34 667 890 123',
                        department: 'Compras',
                        role: 'Usuario',
                        status: 'Activo',
                        lastAccess: 'Ayer, 17:45',
                        avatar: 'https://ui-avatars.com/api/?name=Ana+Martinez&background=17a2b8&color=fff&size=100',
                        description: 'Usuario del departamento de compras',
                        permissions: {
                            inventory: true,
                            users: false,
                            reports: false,
                            sales: false,
                            settings: false,
                            export: false,
                            clients: false,
                            suppliers: true,
                            transactions: true,
                            audit: false
                        },
                        registrationDate: '2023-05-12',
                        registrationIP: '192.168.1.125',
                        tags: []
                    },
                    {
                        id: 'USR-007',
                        name: 'Roberto Sánchez',
                        email: 'roberto.sanchez@empresa.com',
                        phone: '+34 678 901 234',
                        department: 'IT',
                        role: 'Supervisor',
                        status: 'Activo',
                        lastAccess: 'Hoy, 10:20',
                        avatar: 'https://ui-avatars.com/api/?name=Roberto+Sanchez&background=28a745&color=fff&size=100',
                        description: 'Supervisor de IT',
                        permissions: {
                            inventory: true,
                            users: true,
                            reports: true,
                            sales: false,
                            settings: true,
                            export: true,
                            clients: false,
                            suppliers: false,
                            transactions: true,
                            audit: true
                        },
                        registrationDate: '2023-03-15',
                        registrationIP: '192.168.1.130',
                        tags: ['supervisor', 'vip']
                    },
                    {
                        id: 'USR-008',
                        name: 'Invitado',
                        email: 'invitado@empresa.com',
                        phone: '',
                        department: '',
                        role: 'Invitado',
                        status: 'Inactivo',
                        lastAccess: '12/05/2023',
                        avatar: 'https://ui-avatars.com/api/?name=Invitado&background=6c757d&color=fff&size=100',
                        description: 'Cuenta de invitado con acceso limitado',
                        permissions: {
                            inventory: false,
                            users: false,
                            reports: false,
                            sales: false,
                            settings: false,
                            export: false,
                            clients: false,
                            suppliers: false,
                            transactions: false,
                            audit: false
                        },
                        registrationDate: '2023-01-10',
                        registrationIP: '192.168.1.135',
                        tags: []
                    }
                ];
                this.saveUsers();
            }
            
            initializeSampleActivity() {
                const now = new Date();
                
                this.activityLog = [
                    {
                        id: 'ACT-001',
                        userId: 'USR-001',
                        type: 'login',
                        title: 'Inicio de sesión',
                        description: 'Admin User inició sesión en el sistema',
                        timestamp: now.toISOString(),
                        ip: '192.168.1.100'
                    },
                    {
                        id: 'ACT-002',
                        userId: 'USR-002',
                        type: 'edit',
                        title: 'Usuario actualizado',
                        description: 'María García actualizó su perfil',
                        timestamp: new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString(),
                        ip: '192.168.1.105'
                    },
                    {
                        id: 'ACT-003',
                        userId: 'USR-001',
                        type: 'create',
                        title: 'Nuevo usuario',
                        description: 'Juan Pérez fue registrado en el sistema',
                        timestamp: new Date(now.getTime() - 5 * 60 * 60 * 1000).toISOString(),
                        ip: '192.168.1.100'
                    },
                    {
                        id: 'ACT-004',
                        userId: 'USR-001',
                        type: 'permissions',
                        title: 'Permisos actualizados',
                        description: 'Admin User actualizó los permisos de Carlos López',
                        timestamp: new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString(),
                        ip: '192.168.1.100'
                    },
                    {
                        id: 'ACT-005',
                        userId: 'USR-004',
                        type: 'login',
                        title: 'Inicio de sesión',
                        description: 'Laura Rodríguez inició sesión',
                        timestamp: new Date(now.getTime() - 30 * 60 * 1000).toISOString(),
                        ip: '192.168.1.115'
                    }
                ];
                this.saveActivity();
            }
            
            initializeNotifications() {
                this.notifications = [
                    {
                        id: 1,
                        title: 'Nuevo usuario registrado',
                        message: 'Juan Pérez se ha registrado en el sistema',
                        time: 'Hace 5 minutos',
                        read: false,
                        type: 'user',
                        userId: 'USR-003'
                    },
                    {
                        id: 2,
                        title: 'Intento de acceso fallido',
                        message: 'Se detectaron 3 intentos fallidos en la cuenta de admin',
                        time: 'Hace 12 minutos',
                        read: false,
                        type: 'security'
                    },
                    {
                        id: 3,
                        title: 'Actualización de permisos',
                        message: 'Los permisos de María García fueron actualizados',
                        time: 'Ayer a las 14:30',
                        read: true,
                        type: 'user',
                        userId: 'USR-002'
                    }
                ];
                
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
            }
            
            generateId() {
                const lastId = this.users.length > 0 
                    ? Math.max(...this.users.map(u => parseInt(u.id.split('-')[1]))) 
                    : 0;
                return `USR-${String(lastId + 1).padStart(3, '0')}`;
            }
            
            generateActivityId() {
                const lastId = this.activityLog.length > 0 
                    ? Math.max(...this.activityLog.map(a => parseInt(a.id.split('-')[1]))) 
                    : 0;
                return `ACT-${String(lastId + 1).padStart(3, '0')}`;
            }
            
            getRoleClass(role) {
                switch(role) {
                    case 'Administrador': return 'bg-primary';
                    case 'Supervisor': return 'bg-info';
                    case 'Usuario': return 'bg-secondary';
                    case 'Invitado': return 'bg-dark';
                    default: return 'bg-secondary';
                }
            }
            
            getStatusClass(status) {
                switch(status) {
                    case 'Activo': return 'bg-success';
                    case 'Inactivo': return 'bg-danger';
                    case 'Pendiente': return 'bg-warning';
                    default: return 'bg-secondary';
                }
            }
            
            getTagClass(tag) {
                switch(tag) {
                    case 'admin': return 'tag-admin';
                    case 'supervisor': return 'tag-supervisor';
                    case 'new': return 'tag-new';
                    case 'vip': return 'tag-vip';
                    default: return '';
                }
            }
            
            // Métodos para notificaciones
            getUnreadNotifications() {
                return this.notifications.filter(n => !n.read);
            }
            
            markAllNotificationsAsRead() {
                this.notifications.forEach(n => n.read = true);
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
                return this.notifications;
            }
            
            markNotificationAsRead(id) {
                const notification = this.notifications.find(n => n.id === id);
                if (notification) {
                    notification.read = true;
                    localStorage.setItem('notifications', JSON.stringify(this.notifications));
                }
            }
            
            addNotification(title, message, type = 'info', userId = null) {
                const newNotification = {
                    id: this.notifications.length + 1,
                    title,
                    message,
                    time: 'Ahora',
                    read: false,
                    type,
                    userId
                };
                
                this.notifications.unshift(newNotification);
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
                
                // Mostrar toast
                this.showNotification(message, 'info');
                
                return newNotification;
            }
            
            // Métodos de usuario
            addUser(user) {
                user.id = this.generateId();
                user.lastAccess = 'Nunca';
                user.avatar = user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=3a5ec7&color=fff&size=100`;
                user.registrationDate = new Date().toISOString().split('T')[0];
                user.registrationIP = '192.168.1.' + Math.floor(Math.random() * 255);
                user.tags = user.tags || [];
                
                // Permisos por defecto según el rol
                user.permissions = this.getDefaultPermissions(user.role);
                
                this.users.push(user);
                this.saveUsers();
                
                // Registrar actividad
                this.logActivity(user.id, 'create', 'Nuevo usuario', `${user.name} fue registrado en el sistema`);
                
                // Agregar notificación
                this.addNotification('Nuevo usuario registrado', `${user.name} se ha registrado en el sistema`, 'user', user.id);
                
                this.showNotification('Usuario agregado correctamente', 'success');
                return user.id;
            }
            
            getDefaultPermissions(role) {
                switch(role) {
                    case 'Administrador':
                        return {
                            inventory: true,
                            users: true,
                            reports: true,
                            sales: true,
                            settings: true,
                            export: true,
                            clients: true,
                            suppliers: true,
                            transactions: true,
                            audit: true
                        };
                    case 'Supervisor':
                        return {
                            inventory: true,
                            users: false,
                            reports: true,
                            sales: true,
                            settings: false,
                            export: true,
                            clients: true,
                            suppliers: true,
                            transactions: true,
                            audit: false
                        };
                    case 'Usuario':
                        return {
                            inventory: true,
                            users: false,
                            reports: false,
                            sales: false,
                            settings: false,
                            export: false,
                            clients: false,
                            suppliers: true,
                            transactions: true,
                            audit: false
                        };
                    case 'Invitado':
                        return {
                            inventory: false,
                            users: false,
                            reports: false,
                            sales: false,
                            settings: false,
                            export: false,
                            clients: false,
                            suppliers: false,
                            transactions: false,
                            audit: false
                        };
                    default:
                        return {
                            inventory: false,
                            users: false,
                            reports: false,
                            sales: false,
                            settings: false,
                            export: false,
                            clients: false,
                            suppliers: false,
                            transactions: false,
                            audit: false
                        };
                }
            }
            
            updateUser(id, updatedUser) {
                const index = this.users.findIndex(u => u.id === id);
                if (index !== -1) {
                    // Mantener datos que no deben cambiar
                    if (!updatedUser.avatar) {
                        updatedUser.avatar = this.users[index].avatar;
                    }
                    
                    if (!updatedUser.permissions) {
                        updatedUser.permissions = this.users[index].permissions;
                    }
                    
                    updatedUser.registrationDate = this.users[index].registrationDate;
                    updatedUser.registrationIP = this.users[index].registrationIP;
                    updatedUser.tags = this.users[index].tags || [];
                    
                    this.users[index] = {...updatedUser, id};
                    this.saveUsers();
                    
                    // Registrar actividad
                    this.logActivity(id, 'edit', 'Usuario actualizado', `${updatedUser.name} fue actualizado`);
                    
                    // Agregar notificación
                    this.addNotification('Usuario actualizado', `${updatedUser.name} fue actualizado en el sistema`, 'user', id);
                    
                    this.showNotification('Usuario actualizado correctamente', 'success');
                    return true;
                }
                return false;
            }
            
            updateUserPermissions(id, permissions) {
                const index = this.users.findIndex(u => u.id === id);
                if (index !== -1) {
                    this.users[index].permissions = permissions;
                    this.saveUsers();
                    
                    // Registrar actividad
                    this.logActivity(id, 'permissions', 'Permisos actualizados', `Permisos de ${this.users[index].name} fueron actualizados`);
                    
                    // Agregar notificación
                    this.addNotification('Permisos actualizados', `Los permisos de ${this.users[index].name} fueron actualizados`, 'user', id);
                    
                    this.showNotification('Permisos actualizados correctamente', 'success');
                    return true;
                }
                return false;
            }
            
            deleteUser(id) {
                const index = this.users.findIndex(u => u.id === id);
                if (index !== -1) {
                    const userName = this.users[index].name;
                    this.users.splice(index, 1);
                    this.saveUsers();
                    
                    // Registrar actividad
                    this.logActivity(id, 'delete', 'Usuario eliminado', `${userName} fue eliminado del sistema`);
                    
                    // Agregar notificación
                    this.addNotification('Usuario eliminado', `${userName} fue eliminado del sistema`, 'user', id);
                    
                    this.showNotification('Usuario eliminado correctamente', 'success');
                    return true;
                }
                return false;
            }
            
            // Métodos para correo electrónico
            async sendEmail(to, subject, message, copyMe = false) {
                if (typeof emailjs === 'undefined') {
                    this.showNotification('Error: EmailJS no está configurado', 'error');
                    
                    // Mostrar vista previa
                    this.showEmailPreview(to, subject, message);
                    return false;
                }
                
                try {
                    this.showNotification('Enviando correo...', 'info');
                    
                    const templateParams = {
                        to_email: to,
                        subject: subject,
                        message: message,
                        from_name: 'SmartStock AI',
                        reply_to: copyMe ? 'admin@smartstock.com' : ''
                    };
                    
                    const response = await emailjs.send(
                        this.emailJSConfig.serviceId,
                        this.emailJSConfig.templateId,
                        templateParams
                    );
                    
                    if (response.status === 200) {
                        this.showNotification(`Correo enviado exitosamente a ${to}`, 'success');
                        
                        // Registrar en actividad
                        this.logActivity(null, 'email', 'Correo enviado', `Correo enviado a ${to}`);
                        
                        return true;
                    } else {
                        throw new Error('Error al enviar el correo');
                    }
                } catch (error) {
                    console.error('Error enviando correo:', error);
                    this.showNotification('Error al enviar el correo', 'error');
                    
                    // Mostrar vista previa
                    this.showEmailPreview(to, subject, message);
                    return false;
                }
            }
            
            showEmailPreview(to, subject, message) {
                const previewWindow = window.open('', '_blank', 'width=600,height=400');
                previewWindow.document.write(`
                    <html>
                        <head>
                            <title>Vista Previa del Correo</title>
                            <style>
                                body { font-family: Arial; padding: 20px; }
                                .email-container { max-width: 600px; margin: 0 auto; }
                                .header { background: #3a5ec7; color: white; padding: 20px; }
                                .content { padding: 20px; border: 1px solid #ddd; }
                                .footer { padding: 20px; color: #666; }
                            </style>
                        </head>
                        <body>
                            <div class="email-container">
                                <div class="header">
                                    <h2>SmartStock AI</h2>
                                </div>
                                <div class="content">
                                    <p><strong>Para:</strong> ${to}</p>
                                    <p><strong>Asunto:</strong> ${subject}</p>
                                    <hr>
                                    <p>${message.replace(/\n/g, '<br>')}</p>
                                </div>
                                <div class="footer">
                                    <p>Este es un correo de respaldo. El envío automático falló.</p>
                                </div>
                            </div>
                        </body>
                    </html>
                `);
            }
            
            // Métodos para acciones masivas
            bulkActivateUsers(userIds) {
                let count = 0;
                userIds.forEach(id => {
                    const user = this.getUserById(id);
                    if (user && user.status !== 'Activo') {
                        user.status = 'Activo';
                        count++;
                        
                        // Registrar actividad
                        this.logActivity(id, 'edit', 'Usuario activado', `${user.name} fue activado`);
                    }
                });
                
                if (count > 0) {
                    this.saveUsers();
                    this.showNotification(`${count} usuarios activados correctamente`, 'success');
                }
                return count;
            }
            
            bulkDeactivateUsers(userIds) {
                let count = 0;
                userIds.forEach(id => {
                    const user = this.getUserById(id);
                    if (user && user.status === 'Activo') {
                        user.status = 'Inactivo';
                        count++;
                        
                        // Registrar actividad
                        this.logActivity(id, 'edit', 'Usuario desactivado', `${user.name} fue desactivado`);
                    }
                });
                
                if (count > 0) {
                    this.saveUsers();
                    this.showNotification(`${count} usuarios desactivados correctamente`, 'success');
                }
                return count;
            }
            
            bulkDeleteUsers(userIds) {
                let count = 0;
                userIds.forEach(id => {
                    const user = this.getUserById(id);
                    if (user) {
                        this.deleteUser(id);
                        count++;
                    }
                });
                
                if (count > 0) {
                    this.showNotification(`${count} usuarios eliminados correctamente`, 'success');
                }
                return count;
            }
            
            bulkSendEmail(userIds, subject, message) {
                const emails = [];
                userIds.forEach(id => {
                    const user = this.getUserById(id);
                    if (user && user.email) {
                        emails.push(user.email);
                    }
                });
                
                if (emails.length > 0) {
                    const emailList = emails.join(', ');
                    this.showNotification(`Correo enviado a ${emails.length} usuarios`, 'success');
                    
                    // Registrar actividad
                    this.logActivity(null, 'email', 'Correo masivo', `Correo enviado a ${emails.length} usuarios`);
                    
                    // Mostrar vista previa
                    this.showEmailPreview(emailList, subject, message);
                }
                
                return emails.length;
            }
            
            // Métodos para filtros avanzados
            updateFilters(newFilters) {
                this.activeFilters = { ...this.activeFilters, ...newFilters };
                this.applyFilters();
            }
            
            applyFilters() {
                this.filteredUsers = this.users.filter(user => {
                    const matchesSearch = this.activeFilters.search === '' || 
                                         user.name.toLowerCase().includes(this.activeFilters.search.toLowerCase()) || 
                                         user.email.toLowerCase().includes(this.activeFilters.search.toLowerCase()) ||
                                         user.id.toLowerCase().includes(this.activeFilters.search.toLowerCase()) ||
                                         (user.phone && user.phone.includes(this.activeFilters.search));
                    
                    const matchesRole = this.activeFilters.role === 'all' || user.role === this.activeFilters.role;
                    const matchesStatus = this.activeFilters.status === 'all' || user.status === this.activeFilters.status;
                    const matchesDateFrom = this.activeFilters.dateFrom === '' || user.registrationDate >= this.activeFilters.dateFrom;
                    const matchesDateTo = this.activeFilters.dateTo === '' || user.registrationDate <= this.activeFilters.dateTo;
                    
                    // Filtro por último acceso
                    let matchesLastAccess = true;
                    if (this.activeFilters.lastAccess && this.activeFilters.lastAccess.length > 0) {
                        const lastAccessLower = user.lastAccess.toLowerCase();
                        matchesLastAccess = this.activeFilters.lastAccess.some(access => {
                            if (access === 'never') return lastAccessLower === 'nunca';
                            if (access === 'today') return lastAccessLower.includes('hoy');
                            if (access === 'week') return lastAccessLower.includes('ayer') || lastAccessLower.includes('semana');
                            if (access === 'month') return true; // Simplificado
                            return false;
                        });
                    }
                    
                    // Filtro por tags
                    const matchesTags = this.activeFilters.tags.length === 0 || 
                                       this.activeFilters.tags.some(tag => user.tags.includes(tag));
                    
                    return matchesSearch && matchesRole && matchesStatus && 
                           matchesDateFrom && matchesDateTo && matchesLastAccess && matchesTags;
                });
                
                return this.filteredUsers;
            }
            
            // Métodos para gráficos
            generateCharts() {
                this.generateUsersByRoleChart();
                this.generateUserActivityChart();
            }
            
            generateUsersByRoleChart() {
                const ctx = document.getElementById('usersByRoleChart');
                if (!ctx) return;
                
                const roles = ['Administrador', 'Supervisor', 'Usuario', 'Invitado'];
                const roleCounts = roles.map(role => 
                    this.users.filter(user => user.role === role).length
                );
                
                // Destruir gráfico anterior si existe
                if (this.charts.usersByRole) {
                    this.charts.usersByRole.destroy();
                }
                
                this.charts.usersByRole = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: roles,
                        datasets: [{
                            data: roleCounts,
                            backgroundColor: [
                                'rgba(58, 94, 199, 0.7)',
                                'rgba(23, 162, 184, 0.7)',
                                'rgba(108, 117, 125, 0.7)',
                                'rgba(52, 58, 64, 0.7)'
                            ],
                            borderColor: [
                                'rgba(58, 94, 199, 1)',
                                'rgba(23, 162, 184, 1)',
                                'rgba(108, 117, 125, 1)',
                                'rgba(52, 58, 64, 1)'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                            }
                        },
                        cutout: '60%'
                    }
                });
            }
            
            generateUserActivityChart() {
                const ctx = document.getElementById('userActivityChart');
                if (!ctx) return;
                
                // Datos de los últimos 7 días
                const labels = [];
                const data = [];
                
                for (let i = 6; i >= 0; i--) {
                    const date = new Date();
                    date.setDate(date.getDate() - i);
                    const dateStr = date.toISOString().split('T')[0];
                    const dayName = date.toLocaleDateString('es', { weekday: 'short' });
                    labels.push(dayName);
                    
                    // Contar actividades en ese día
                    const count = this.activityLog.filter(activity => 
                        activity.timestamp.split('T')[0] === dateStr
                    ).length;
                    
                    data.push(count);
                }
                
                // Destruir gráfico anterior si existe
                if (this.charts.userActivity) {
                    this.charts.userActivity.destroy();
                }
                
                this.charts.userActivity = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Actividad de Usuarios',
                            data: data,
                            backgroundColor: 'rgba(58, 94, 199, 0.1)',
                            borderColor: 'rgba(58, 94, 199, 1)',
                            borderWidth: 2,
                            tension: 0.3,
                            fill: true,
                            pointBackgroundColor: 'rgba(58, 94, 199, 1)',
                            pointBorderColor: '#fff',
                            pointBorderWidth: 2,
                            pointRadius: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    stepSize: 1
                                },
                                grid: {
                                    color: 'rgba(0,0,0,0.05)'
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                }
                            }
                        }
                    }
                });
            }
            
            // Métodos para actividad
            logActivity(userId, type, title, description) {
                const activity = {
                    id: this.generateActivityId(),
                    userId: userId,
                    type: type,
                    title: title,
                    description: description,
                    timestamp: new Date().toISOString(),
                    ip: '192.168.1.' + Math.floor(Math.random() * 255)
                };
                
                this.activityLog.unshift(activity);
                
                // Mantener solo las últimas 50 actividades
                if (this.activityLog.length > 50) {
                    this.activityLog = this.activityLog.slice(0, 50);
                }
                
                this.saveActivity();
            }
            
            getRecentActivity(limit = 5) {
                return this.activityLog.slice(0, limit);
            }
            
            getUserActivity(userId, limit = 5) {
                return this.activityLog.filter(a => a.userId === userId).slice(0, limit);
            }
            
            // Métodos para búsqueda inteligente
            getSearchSuggestions(query) {
                if (query.length < 2) return [];
                
                const suggestions = [];
                const seen = new Set();
                
                // Buscar en usuarios
                this.users.forEach(user => {
                    if (user.name.toLowerCase().includes(query.toLowerCase()) && !seen.has(user.name)) {
                        suggestions.push({
                            text: user.name,
                            icon: 'fa-user',
                            type: 'Nombre'
                        });
                        seen.add(user.name);
                    }
                    
                    if (user.email.toLowerCase().includes(query.toLowerCase()) && !seen.has(user.email)) {
                        suggestions.push({
                            text: user.email,
                            icon: 'fa-envelope',
                            type: 'Email'
                        });
                        seen.add(user.email);
                    }
                    
                    if (user.id.toLowerCase().includes(query.toLowerCase()) && !seen.has(user.id)) {
                        suggestions.push({
                            text: user.id,
                            icon: 'fa-id-card',
                            type: 'ID'
                        });
                        seen.add(user.id);
                    }
                    
                    if (user.phone && user.phone.includes(query) && !seen.has(user.phone)) {
                        suggestions.push({
                            text: user.phone,
                            icon: 'fa-phone',
                            type: 'Teléfono'
                        });
                        seen.add(user.phone);
                    }
                });
                
                return suggestions.slice(0, 5);
            }
            
            // Métodos para exportación
            exportData(format) {
                let data = '';
                let filename = '';
                let dataToExport = this.filteredUsers.length > 0 ? this.filteredUsers : this.users;
                
                switch(format) {
                    case 'csv':
                        this.exportToCSV(dataToExport);
                        break;
                    case 'excel':
                        this.exportToExcel(dataToExport);
                        break;
                    case 'pdf':
                        this.exportToPDF(dataToExport);
                        break;
                    case 'json':
                        this.exportToJSON(dataToExport);
                        break;
                }
            }
            
            exportToCSV(data) {
                const headers = ['ID', 'Nombre', 'Email', 'Teléfono', 'Rol', 'Estado', 'Último Acceso', 'Fecha Registro'];
                const csvRows = [];
                
                csvRows.push(headers.join(','));
                
                for (const row of data) {
                    const values = [
                        row.id,
                        `"${row.name}"`,
                        `"${row.email}"`,
                        `"${row.phone || ''}"`,
                        row.role,
                        row.status,
                        `"${row.lastAccess}"`,
                        row.registrationDate
                    ];
                    csvRows.push(values.join(','));
                }
                
                const blob = new Blob(['\uFEFF' + csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `usuarios_${new Date().toISOString().split('T')[0]}.csv`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                this.showNotification('Datos exportados a CSV', 'success');
            }
            
            exportToExcel(data) {
                const worksheet = XLSX.utils.json_to_sheet(data.map(user => ({
                    ID: user.id,
                    Nombre: user.name,
                    Email: user.email,
                    Teléfono: user.phone || '',
                    Rol: user.role,
                    Estado: user.status,
                    'Último Acceso': user.lastAccess,
                    'Fecha Registro': user.registrationDate,
                    Departamento: user.department || ''
                })));
                
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, 'Usuarios');
                
                XLSX.writeFile(workbook, `usuarios_${new Date().toISOString().split('T')[0]}.xlsx`);
                
                this.showNotification('Datos exportados a Excel', 'success');
            }
            
            exportToPDF(data) {
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();
                
                doc.setFontSize(20);
                doc.setTextColor(58, 94, 199);
                doc.text('Reporte de Usuarios', 105, 15, { align: 'center' });
                
                doc.setFontSize(10);
                doc.setTextColor(100, 100, 100);
                doc.text(`Generado el: ${new Date().toLocaleDateString()}`, 105, 22, { align: 'center' });
                
                // Estadísticas
                const stats = this.getStats();
                doc.setFontSize(12);
                doc.setTextColor(0, 0, 0);
                doc.text(`Total: ${stats.total} | Activos: ${stats.active} | Pendientes: ${stats.pending}`, 20, 35);
                
                // Tabla
                const tableData = data.map(user => [
                    user.id,
                    user.name,
                    user.email,
                    user.role,
                    user.status
                ]);
                
                doc.autoTable({
                    startY: 45,
                    head: [['ID', 'Nombre', 'Email', 'Rol', 'Estado']],
                    body: tableData,
                    styles: { fontSize: 8 },
                    headStyles: { fillColor: [58, 94, 199] }
                });
                
                doc.save(`usuarios_${new Date().toISOString().split('T')[0]}.pdf`);
                
                this.showNotification('Datos exportados a PDF', 'success');
            }
            
            exportToJSON(data) {
                const jsonContent = JSON.stringify(data, null, 2);
                const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `usuarios_${new Date().toISOString().split('T')[0]}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                this.showNotification('Datos exportados a JSON', 'success');
            }
            
            // Métodos para estadísticas
            getStats() {
                const total = this.users.length;
                const active = this.users.filter(u => u.status === 'Activo').length;
                const pending = this.users.filter(u => u.status === 'Pendiente').length;
                const inactive = this.users.filter(u => u.status === 'Inactivo').length;
                
                return { total, active, pending, inactive };
            }
            
            // Métodos de acceso
            getUserById(id) {
                return this.users.find(u => u.id === id);
            }
            
            getAllUsers() {
                return this.users;
            }
            
            filterUsers(searchTerm = '', role = 'all', status = 'all') {
                return this.updateFilters({ search: searchTerm, role, status });
            }
            
            getPaginatedUsers(page = 1) {
                const startIndex = (page - 1) * this.itemsPerPage;
                const endIndex = startIndex + this.itemsPerPage;
                return this.filteredUsers.slice(startIndex, endIndex);
            }
            
            getTotalPages() {
                return Math.ceil(this.filteredUsers.length / this.itemsPerPage);
            }
            
            saveUsers() {
                localStorage.setItem('users', JSON.stringify(this.users));
            }
            
            saveActivity() {
                localStorage.setItem('userActivity', JSON.stringify(this.activityLog));
            }
            
            showNotification(message, type = 'info') {
                const toastContainer = document.getElementById('toastContainer');
                if (!toastContainer) return;
                
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'}"></i>
                    <span>${message}</span>
                `;
                
                toastContainer.appendChild(toast);
                
                setTimeout(() => {
                    toast.style.animation = 'slideOutRight 0.3s forwards';
                    setTimeout(() => {
                        if (toast.parentNode) {
                            toast.parentNode.removeChild(toast);
                        }
                    }, 300);
                }, 3000);
            }
        }

        // ============================================
        // INSTANCIA GLOBAL
        // ============================================
        const userManager = new EnhancedUserManager();

        // ============================================
        // FUNCIONES DE RENDERIZADO
        // ============================================
        
        // Renderizar tabla de usuarios
        function renderUsersTable() {
            const tableBody = document.getElementById('usersTableBody');
            if (!tableBody) return;
            
            tableBody.innerHTML = '';
            
            const searchTerm = document.getElementById('searchInput').value;
            const role = document.getElementById('roleFilter').value;
            const status = document.getElementById('statusFilter').value;
            
            // Actualizar filtros
            userManager.updateFilters({
                search: searchTerm,
                role: role,
                status: status
            });
            
            // Obtener usuarios paginados
            const users = userManager.getPaginatedUsers(userManager.currentPage);
            const totalPages = userManager.getTotalPages();
            
            // Actualizar contador
            document.getElementById('userCount').textContent = 
                `Mostrando ${users.length} de ${userManager.filteredUsers.length} usuarios`;
            
            document.getElementById('paginationInfo').textContent = 
                `Mostrando ${users.length} de ${userManager.filteredUsers.length} usuarios`;
            
            // Actualizar estadísticas
            updateStats();
            
            // Renderizar usuarios
            if (users.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="8" class="text-center py-5">
                            <div class="empty-state">
                                <i class="fas fa-users-slash"></i>
                                <h4>No se encontraron usuarios</h4>
                                <p>Intenta con otros filtros o crea un nuevo usuario</p>
                                <button class="btn btn-primary mt-3" onclick="document.getElementById('btnNewUser').click()">
                                    <i class="fas fa-user-plus me-2"></i>Nuevo Usuario
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            } else {
                users.forEach(user => {
                    const roleClass = userManager.getRoleClass(user.role);
                    const statusClass = userManager.getStatusClass(user.status);
                    const isSelected = userManager.selectedUsers.has(user.id);
                    
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>
                            <input type="checkbox" class="bulk-checkbox user-checkbox" data-id="${user.id}" ${isSelected ? 'checked' : ''}>
                        </td>
                        <td>
                            <span class="badge bg-primary">${user.id}</span>
                            ${user.tags && user.tags.length > 0 ? 
                                `<div class="user-tags mt-1">
                                    ${user.tags.map(tag => `<span class="user-tag ${userManager.getTagClass(tag)}">${tag}</span>`).join('')}
                                </div>` : ''}
                        </td>
                        <td>
                            <div class="user-info-cell">
                                <img src="${user.avatar}" class="user-avatar-thumb" alt="${user.name}">
                                <div>
                                    <strong>${user.name}</strong>
                                    ${user.department ? `<div class="text-muted small">${user.department}</div>` : ''}
                                </div>
                            </div>
                        </td>
                        <td>${user.email}</td>
                        <td><span class="badge ${roleClass}">${user.role}</span></td>
                        <td><span class="badge ${statusClass}">${user.status}</span></td>
                        <td>${user.lastAccess}</td>
                        <td>
                            <button class="action-btn btn-view" data-id="${user.id}" data-tooltip="Ver detalles">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="action-btn btn-edit" data-id="${user.id}" data-tooltip="Editar usuario">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn btn-permissions" data-id="${user.id}" data-tooltip="Gestionar permisos">
                                <i class="fas fa-key"></i>
                            </button>
                            <button class="action-btn btn-email" data-id="${user.id}" data-tooltip="Enviar correo">
                                <i class="fas fa-envelope"></i>
                            </button>
                            <button class="action-btn btn-reset" data-id="${user.id}" data-tooltip="Restablecer contraseña">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                            <button class="action-btn btn-delete" data-id="${user.id}" data-tooltip="Eliminar usuario">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });
            }
            
            // Actualizar acciones masivas
            updateBulkActions();
            
            // Renderizar paginación
            renderPagination(totalPages);
            
            // Agregar event listeners a los botones
            addTableEventListeners();
        }
        
        // Renderizar paginación
        function renderPagination(totalPages) {
            const pagination = document.getElementById('pagination');
            if (!pagination) return;
            
            pagination.innerHTML = '';
            
            if (totalPages <= 1) {
                return;
            }
            
            const currentPage = userManager.currentPage;
            
            // Botón anterior
            const prevLi = document.createElement('li');
            prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
            prevLi.innerHTML = `<a class="page-link" href="#"><i class="fas fa-chevron-left"></i></a>`;
            prevLi.addEventListener('click', (e) => {
                e.preventDefault();
                if (currentPage > 1) {
                    userManager.currentPage--;
                    renderUsersTable();
                }
            });
            pagination.appendChild(prevLi);
            
            // Números de página
            const maxVisible = 5;
            let start = Math.max(1, currentPage - Math.floor(maxVisible / 2));
            let end = Math.min(totalPages, start + maxVisible - 1);
            
            if (end - start + 1 < maxVisible) {
                start = Math.max(1, end - maxVisible + 1);
            }
            
            for (let i = start; i <= end; i++) {
                const pageLi = document.createElement('li');
                pageLi.className = `page-item ${currentPage === i ? 'active' : ''}`;
                pageLi.innerHTML = `<a class="page-link" href="#">${i}</a>`;
                pageLi.addEventListener('click', (e) => {
                    e.preventDefault();
                    userManager.currentPage = i;
                    renderUsersTable();
                });
                pagination.appendChild(pageLi);
            }
            
            // Botón siguiente
            const nextLi = document.createElement('li');
            nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
            nextLi.innerHTML = `<a class="page-link" href="#"><i class="fas fa-chevron-right"></i></a>`;
            nextLi.addEventListener('click', (e) => {
                e.preventDefault();
                if (currentPage < totalPages) {
                    userManager.currentPage++;
                    renderUsersTable();
                }
            });
            pagination.appendChild(nextLi);
        }
        
        // Actualizar estadísticas
        function updateStats() {
            const stats = userManager.getStats();
            const total = stats.total;
            const active = stats.active;
            const pending = stats.pending;
            const inactive = stats.inactive;
            
            document.getElementById('totalUsers').textContent = total;
            document.getElementById('activeUsers').textContent = active;
            document.getElementById('pendingUsers').textContent = pending;
            document.getElementById('inactiveUsers').textContent = inactive;
            
            // Porcentajes
            const activePercentage = total > 0 ? Math.round((active / total) * 100) : 0;
            document.getElementById('activePercentage').textContent = `${activePercentage}% del total`;
            
            // Tendencias (simuladas)
            document.getElementById('totalTrend').innerHTML = `
                <i class="fas fa-arrow-up trend-up"></i>
                <span class="trend-up">+12% este mes</span>
            `;
            
            document.getElementById('pendingTrend').innerHTML = `
                <i class="fas fa-exclamation-triangle text-warning"></i>
                <span class="text-warning">Requieren activación</span>
            `;
            
            document.getElementById('inactiveInfo').textContent = `Última semana`;
        }
        
        // Actualizar acciones masivas
        function updateBulkActions() {
            const selectedCount = userManager.selectedUsers.size;
            document.getElementById('selectedCount').textContent = `${selectedCount} usuarios seleccionados`;
            
            if (selectedCount > 0) {
                document.getElementById('bulkActions').classList.add('show');
            } else {
                document.getElementById('bulkActions').classList.remove('show');
            }
        }
        
        // Renderizar actividad reciente
        function renderRecentActivity() {
            const activityList = document.getElementById('activityList');
            if (!activityList) return;
            
            activityList.innerHTML = '';
            
            const activities = userManager.getRecentActivity(5);
            
            if (activities.length === 0) {
                activityList.innerHTML = '<p class="text-center py-3">No hay actividad reciente</p>';
            } else {
                activities.forEach(activity => {
                    const user = activity.userId ? userManager.getUserById(activity.userId) : null;
                    const userName = user ? user.name : 'Sistema';
                    const timeAgo = getTimeAgo(activity.timestamp);
                    
                    const activityItem = document.createElement('div');
                    activityItem.className = 'activity-item';
                    activityItem.innerHTML = `
                        <div class="activity-icon activity-${activity.type}">
                            <i class="fas ${getActivityIcon(activity.type)}"></i>
                        </div>
                        <div class="activity-info">
                            <div class="activity-title">${activity.title}</div>
                            <div class="activity-desc">${activity.description}</div>
                            <div class="d-flex justify-content-between">
                                <span class="activity-user">${userName}</span>
                                <span class="activity-time">${timeAgo}</span>
                            </div>
                        </div>
                    `;
                    activityList.appendChild(activityItem);
                });
            }
        }
        
        // Renderizar notificaciones
        function renderNotifications() {
            const list = document.getElementById('notificationList');
            const badge = document.getElementById('notificationBadge');
            
            if (!list || !badge) return;
            
            const unreadCount = userManager.getUnreadNotifications().length;
            badge.textContent = unreadCount;
            badge.classList.toggle('hidden', unreadCount === 0);
            
            list.innerHTML = '';
            
            userManager.notifications.slice(0, 5).forEach(notification => {
                const item = document.createElement('div');
                item.className = `notification-item ${notification.read ? '' : 'unread'}`;
                item.dataset.id = notification.id;
                item.innerHTML = `
                    <strong>${notification.title}</strong>
                    <p>${notification.message}</p>
                    <small>${notification.time}</small>
                `;
                item.addEventListener('click', () => {
                    userManager.markNotificationAsRead(notification.id);
                    renderNotifications();
                    
                    if (notification.userId) {
                        viewUser(notification.userId);
                    }
                });
                list.appendChild(item);
            });
        }
        
        // Función auxiliar para obtener icono de actividad
        function getActivityIcon(type) {
            switch(type) {
                case 'login': return 'fa-sign-in-alt';
                case 'create': return 'fa-user-plus';
                case 'edit': return 'fa-edit';
                case 'delete': return 'fa-trash';
                case 'permissions': return 'fa-key';
                case 'email': return 'fa-envelope';
                default: return 'fa-info-circle';
            }
        }
        
        // Función auxiliar para obtener tiempo transcurrido
        function getTimeAgo(timestamp) {
            const now = new Date();
            const time = new Date(timestamp);
            const diffMs = now - time;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMs / 3600000);
            const diffDays = Math.floor(diffMs / 86400000);
            
            if (diffMins < 1) return 'Hace un momento';
            if (diffMins < 60) return `Hace ${diffMins} minuto${diffMins > 1 ? 's' : ''}`;
            if (diffHours < 24) return `Hace ${diffHours} hora${diffHours > 1 ? 's' : ''}`;
            if (diffDays < 7) return `Hace ${diffDays} día${diffDays > 1 ? 's' : ''}`;
            
            return time.toLocaleDateString();
        }
        
        // ============================================
        // FUNCIONES DE EVENTOS
        // ============================================
        
        function addTableEventListeners() {
            // Botones de ver
            document.querySelectorAll('.btn-view').forEach(btn => {
                btn.addEventListener('click', function() {
                    const userId = this.getAttribute('data-id');
                    viewUser(userId);
                });
            });
            
            // Botones de editar
            document.querySelectorAll('.btn-edit').forEach(btn => {
                btn.addEventListener('click', function() {
                    const userId = this.getAttribute('data-id');
                    openEditModal(userId);
                });
            });
            
            // Botones de eliminar
            document.querySelectorAll('.btn-delete').forEach(btn => {
                btn.addEventListener('click', function() {
                    const userId = this.getAttribute('data-id');
                    deleteUser(userId);
                });
            });
            
            // Botones de permisos
            document.querySelectorAll('.btn-permissions').forEach(btn => {
                btn.addEventListener('click', function() {
                    const userId = this.getAttribute('data-id');
                    openPermissionsModal(userId);
                });
            });
            
            // Botones de email
            document.querySelectorAll('.btn-email').forEach(btn => {
                btn.addEventListener('click', function() {
                    const userId = this.getAttribute('data-id');
                    openEmailModal(userId);
                });
            });
            
            // Botones de restablecer contraseña
            document.querySelectorAll('.btn-reset').forEach(btn => {
                btn.addEventListener('click', function() {
                    const userId = this.getAttribute('data-id');
                    openResetPasswordModal(userId);
                });
            });
            
            // Checkboxes de selección masiva
            document.querySelectorAll('.user-checkbox').forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const userId = this.getAttribute('data-id');
                    if (this.checked) {
                        userManager.selectedUsers.add(userId);
                    } else {
                        userManager.selectedUsers.delete(userId);
                        document.getElementById('selectAllUsers').checked = false;
                    }
                    updateBulkActions();
                });
            });
        }
        
        // Ver usuario
        function viewUser(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            
            const roleClass = userManager.getRoleClass(user.role);
            const statusClass = userManager.getStatusClass(user.status);
            
            document.getElementById('viewUserId').textContent = user.id;
            document.getElementById('viewUserName').textContent = user.name;
            document.getElementById('viewUserEmail').textContent = user.email;
            document.getElementById('viewUserPhone').textContent = user.phone || '-';
            document.getElementById('viewUserRole').textContent = user.role;
            document.getElementById('viewUserRole').className = `badge ${roleClass}`;
            document.getElementById('viewUserStatus').textContent = user.status;
            document.getElementById('viewUserStatus').className = `badge ${statusClass}`;
            document.getElementById('viewUserDepartment').textContent = user.department || '-';
            document.getElementById('viewUserLastAccess').textContent = user.lastAccess;
            document.getElementById('viewUserRegistration').textContent = user.registrationDate || '-';
            document.getElementById('viewUserDescription').textContent = user.description || 'Sin descripción';
            document.getElementById('viewUserAvatar').src = user.avatar;
            
            // Mostrar permisos
            const permissionsContainer = document.getElementById('viewUserPermissions');
            permissionsContainer.innerHTML = '';
            
            const permissions = user.permissions;
            const permissionLabels = {
                inventory: 'Gestión de Inventario',
                users: 'Gestión de Usuarios',
                reports: 'Ver Reportes',
                sales: 'Gestión de Ventas',
                settings: 'Configuración',
                export: 'Exportar Datos',
                clients: 'Gestión de Clientes',
                suppliers: 'Gestión de Proveedores',
                transactions: 'Ver Transacciones',
                audit: 'Auditoría'
            };
            
            for (const [key, value] of Object.entries(permissions)) {
                const label = permissionLabels[key] || key;
                const permissionItem = document.createElement('div');
                permissionItem.className = 'permission-item';
                permissionItem.innerHTML = `
                    <input type="checkbox" ${value ? 'checked' : ''} disabled>
                    <label>${label}</label>
                `;
                permissionsContainer.appendChild(permissionItem);
            }
            
            // Mostrar actividad reciente del usuario
            const activityContainer = document.getElementById('viewUserActivity');
            const userActivity = userManager.getUserActivity(userId, 3);
            
            if (userActivity.length === 0) {
                activityContainer.innerHTML = '<p class="text-muted">No hay actividad reciente</p>';
            } else {
                let activityHtml = '';
                userActivity.forEach(activity => {
                    const timeAgo = getTimeAgo(activity.timestamp);
                    activityHtml += `
                        <div class="d-flex justify-content-between mb-2">
                            <span>${activity.title}</span>
                            <small class="text-muted">${timeAgo}</small>
                        </div>
                    `;
                });
                activityContainer.innerHTML = activityHtml;
            }
            
            // Configurar botones
            document.getElementById('btnEditFromView').onclick = () => {
                const modal = bootstrap.Modal.getInstance(document.getElementById('viewUserModal'));
                modal.hide();
                openEditModal(userId);
            };
            
            document.getElementById('btnEmailFromView').onclick = () => {
                const modal = bootstrap.Modal.getInstance(document.getElementById('viewUserModal'));
                modal.hide();
                openEmailModal(userId);
            };
            
            const modal = new bootstrap.Modal(document.getElementById('viewUserModal'));
            modal.show();
        }
        
        // Abrir modal de edición
        function openEditModal(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            
            document.getElementById('modalTitle').textContent = 'Editar Usuario';
            document.getElementById('userId').value = user.id;
            document.getElementById('userName').value = user.name;
            document.getElementById('userEmail').value = user.email;
            document.getElementById('userPhone').value = user.phone || '';
            document.getElementById('userDepartment').value = user.department || '';
            document.getElementById('userRole').value = user.role;
            document.getElementById('userStatus').value = user.status;
            document.getElementById('userDescription').value = user.description || '';
            document.getElementById('userAvatarPreview').src = user.avatar;
            
            // Ocultar campos de contraseña para edición
            document.getElementById('passwordFields').style.display = 'none';
            
            const modal = new bootstrap.Modal(document.getElementById('userModal'));
            modal.show();
        }
        
        // Abrir modal de permisos
        function openPermissionsModal(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            
            document.getElementById('permissionsUserName').textContent = user.name;
            document.getElementById('permissionsUserRole').textContent = user.role;
            
            // Establecer los valores de los checkboxes según los permisos del usuario
            document.getElementById('permInventory').checked = user.permissions.inventory;
            document.getElementById('permUsers').checked = user.permissions.users;
            document.getElementById('permReports').checked = user.permissions.reports;
            document.getElementById('permSales').checked = user.permissions.sales;
            document.getElementById('permSettings').checked = user.permissions.settings;
            document.getElementById('permExport').checked = user.permissions.export;
            document.getElementById('permClients').checked = user.permissions.clients;
            document.getElementById('permSuppliers').checked = user.permissions.suppliers;
            document.getElementById('permTransactions').checked = user.permissions.transactions;
            document.getElementById('permAudit').checked = user.permissions.audit;
            
            // Guardar el ID del usuario en el botón de guardar
            document.getElementById('savePermissions').setAttribute('data-user-id', user.id);
            
            const modal = new bootstrap.Modal(document.getElementById('permissionsModal'));
            modal.show();
        }
        
        // Abrir modal de email
        function openEmailModal(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            
            document.getElementById('emailUserId').value = user.id;
            document.getElementById('emailUserEmail').value = user.email;
            document.getElementById('emailTo').value = user.email;
            document.getElementById('emailSubject').value = 'Notificación de SmartStock AI';
            document.getElementById('emailMessage').value = '';
            
            const modal = new bootstrap.Modal(document.getElementById('emailModal'));
            modal.show();
        }
        
        // Abrir modal de restablecer contraseña
        function openResetPasswordModal(userId) {
            const user = userManager.getUserById(userId);
            if (!user) return;
            
            document.getElementById('resetUserId').value = user.id;
            document.getElementById('resetUserEmail').value = user.email;
            document.getElementById('resetEmail').value = user.email;
            
            const modal = new bootstrap.Modal(document.getElementById('resetPasswordModal'));
            modal.show();
        }
        
        // Eliminar usuario
        function deleteUser(userId) {
            if (confirm('¿Estás seguro de que deseas eliminar este usuario?')) {
                userManager.deleteUser(userId);
                
                // Limpiar selección si estaba seleccionado
                if (userManager.selectedUsers.has(userId)) {
                    userManager.selectedUsers.delete(userId);
                }
                
                renderUsersTable();
                renderRecentActivity();
                renderNotifications();
            }
        }
        
        // Guardar usuario
        function saveUser() {
            const form = document.getElementById('userForm');
            if (!form.checkValidity()) {
                form.reportValidity();
                return;
            }
            
            const userId = document.getElementById('userId').value;
            const user = {
                name: document.getElementById('userName').value,
                email: document.getElementById('userEmail').value,
                phone: document.getElementById('userPhone').value,
                department: document.getElementById('userDepartment').value,
                role: document.getElementById('userRole').value,
                status: document.getElementById('userStatus').value,
                description: document.getElementById('userDescription').value,
                avatar: document.getElementById('userAvatarPreview').src
            };
            
            // Solo agregar contraseña si es un nuevo usuario
            if (!userId) {
                const password = document.getElementById('userPassword').value;
                const passwordConfirm = document.getElementById('userPasswordConfirm').value;
                
                if (password !== passwordConfirm) {
                    userManager.showNotification('Las contraseñas no coinciden', 'error');
                    return;
                }
                
                if (password.length < 8) {
                    userManager.showNotification('La contraseña debe tener al menos 8 caracteres', 'error');
                    return;
                }
                
                // En una aplicación real, aquí deberías encriptar la contraseña
                user.password = password;
            }
            
            if (userId) {
                // Editar usuario existente
                userManager.updateUser(userId, user);
            } else {
                // Agregar nuevo usuario
                userManager.addUser(user);
            }
            
            // Cerrar modal y actualizar tabla
            const modal = bootstrap.Modal.getInstance(document.getElementById('userModal'));
            modal.hide();
            
            renderUsersTable();
            renderRecentActivity();
            renderNotifications();
            userManager.generateCharts();
        }
        
        // Guardar permisos
        function savePermissions() {
            const userId = document.getElementById('savePermissions').getAttribute('data-user-id');
            const permissions = {
                inventory: document.getElementById('permInventory').checked,
                users: document.getElementById('permUsers').checked,
                reports: document.getElementById('permReports').checked,
                sales: document.getElementById('permSales').checked,
                settings: document.getElementById('permSettings').checked,
                export: document.getElementById('permExport').checked,
                clients: document.getElementById('permClients').checked,
                suppliers: document.getElementById('permSuppliers').checked,
                transactions: document.getElementById('permTransactions').checked,
                audit: document.getElementById('permAudit').checked
            };
            
            userManager.updateUserPermissions(userId, permissions);
            
            // Cerrar modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('permissionsModal'));
            modal.hide();
            
            renderRecentActivity();
            renderNotifications();
        }
        
        // Enviar correo
        async function sendEmail() {
            const userId = document.getElementById('emailUserId').value;
            const to = document.getElementById('emailTo').value;
            const subject = document.getElementById('emailSubject').value;
            const message = document.getElementById('emailMessage').value;
            const copyMe = document.getElementById('emailCopyMe').checked;
            
            if (!message) {
                userManager.showNotification('Por favor escribe un mensaje', 'error');
                return;
            }
            
            await userManager.sendEmail(to, subject, message, copyMe);
            
            // Cerrar modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('emailModal'));
            modal.hide();
            
            renderRecentActivity();
        }
        
        // Enviar enlace de restablecimiento
        async function sendResetLink() {
            const userId = document.getElementById('resetUserId').value;
            const email = document.getElementById('resetEmail').value;
            
            const subject = 'Restablecimiento de contraseña - SmartStock AI';
            const message = `Hola,\n\nHas solicitado restablecer tu contraseña. Haz clic en el siguiente enlace para crear una nueva contraseña:\n\nhttps://smartstock.ai/reset-password?token=ejemplo123\n\nSi no solicitaste este cambio, ignora este mensaje.\n\nSaludos,\nEquipo SmartStock AI`;
            
            await userManager.sendEmail(email, subject, message, false);
            
            // Cerrar modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('resetPasswordModal'));
            modal.hide();
            
            userManager.showNotification('Enlace de restablecimiento enviado', 'success');
            renderRecentActivity();
        }
        
        // Limpiar filtros
        function clearFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('roleFilter').value = 'all';
            document.getElementById('statusFilter').value = 'all';
            document.getElementById('dateFrom').value = '';
            document.getElementById('dateTo').value = '';
            
            // Limpiar tags activos
            document.querySelectorAll('.filter-tag.active').forEach(tag => {
                tag.classList.remove('active');
            });
            
            userManager.activeFilters = {
                search: '',
                role: 'all',
                status: 'all',
                dateFrom: '',
                dateTo: '',
                lastAccess: [],
                tags: []
            };
            
            userManager.currentPage = 1;
            renderUsersTable();
        }
        
        // Aplicar filtros avanzados
        function applyAdvancedFilters() {
            // Tags de último acceso
            const lastAccess = [];
            document.querySelectorAll('#lastAccessTags .filter-tag.active').forEach(tag => {
                lastAccess.push(tag.getAttribute('data-value'));
            });
            
            // Tags de etiquetas
            const tags = [];
            document.querySelectorAll('#tagFilters .filter-tag.active').forEach(tag => {
                tags.push(tag.getAttribute('data-value'));
            });
            
            userManager.updateFilters({
                dateFrom: document.getElementById('dateFrom').value,
                dateTo: document.getElementById('dateTo').value,
                lastAccess: lastAccess,
                tags: tags
            });
            
            userManager.currentPage = 1;
            renderUsersTable();
            
            // Cerrar panel de filtros avanzados
            document.getElementById('advancedFiltersContent').classList.remove('show');
        }
        
        // ============================================
        // INICIALIZACIÓN
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            // Cargar tema guardado
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            }
            
            // Inicializar
            renderUsersTable();
            renderRecentActivity();
            renderNotifications();
            userManager.generateCharts();
            
            // Event listeners básicos
            document.getElementById('themeToggle').addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
                const icon = this.querySelector('i');
                icon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
                localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
            });
            
            document.getElementById('menuToggle').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('open');
            });
            
            document.getElementById('notificationBtn').addEventListener('click', function() {
                document.getElementById('notificationDropdown').classList.toggle('show');
            });
            
            document.getElementById('markAllRead').addEventListener('click', function() {
                userManager.markAllNotificationsAsRead();
                renderNotifications();
            });
            
            document.getElementById('saveUser').addEventListener('click', saveUser);
            document.getElementById('savePermissions').addEventListener('click', savePermissions);
            document.getElementById('sendEmail').addEventListener('click', sendEmail);
            document.getElementById('sendResetLink').addEventListener('click', sendResetLink);
            
            // Botón nuevo usuario
            document.getElementById('btnNewUser').addEventListener('click', function() {
                document.getElementById('modalTitle').textContent = 'Agregar Nuevo Usuario';
                document.getElementById('userForm').reset();
                document.getElementById('userId').value = '';
                document.getElementById('userAvatarPreview').src = 'https://ui-avatars.com/api/?name=NU&background=3a5ec7&color=fff&size=100';
                
                // Mostrar campos de contraseña para nuevo usuario
                document.getElementById('passwordFields').style.display = 'flex';
                
                // Resetear indicadores de contraseña
                document.getElementById('passwordStrength').className = 'password-strength';
                document.querySelector('.strength-bar').style.width = '0';
                document.getElementById('passwordMatch').textContent = '';
                
                const modal = new bootstrap.Modal(document.getElementById('userModal'));
                modal.show();
            });
            
            // Avatar preview
            document.getElementById('userAvatar').addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById('userAvatarPreview').src = e.target.result;
                    };
                    reader.readAsDataURL(file);
                }
            });
            
            // Filtros y búsqueda
            document.getElementById('searchInput').addEventListener('input', function() {
                userManager.currentPage = 1;
                renderUsersTable();
            });
            
            document.getElementById('roleFilter').addEventListener('change', function() {
                userManager.currentPage = 1;
                renderUsersTable();
            });
            
            document.getElementById('statusFilter').addEventListener('change', function() {
                userManager.currentPage = 1;
                renderUsersTable();
            });
            
            document.getElementById('btnRefresh').addEventListener('click', function() {
                renderUsersTable();
                renderRecentActivity();
                renderNotifications();
                userManager.generateCharts();
                userManager.showNotification('Datos actualizados', 'success');
            });
            
            // Selección masiva
            document.getElementById('selectAllUsers').addEventListener('change', function() {
                const checkboxes = document.querySelectorAll('.user-checkbox');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                    const userId = checkbox.getAttribute('data-id');
                    if (this.checked) {
                        userManager.selectedUsers.add(userId);
                    } else {
                        userManager.selectedUsers.delete(userId);
                    }
                });
                updateBulkActions();
            });
            
            // Acciones masivas
            document.getElementById('btnBulkActivate').addEventListener('click', function() {
                const userIds = Array.from(userManager.selectedUsers);
                userManager.bulkActivateUsers(userIds);
                userManager.selectedUsers.clear();
                document.getElementById('selectAllUsers').checked = false;
                renderUsersTable();
                renderRecentActivity();
                renderNotifications();
            });
            
            document.getElementById('btnBulkDeactivate').addEventListener('click', function() {
                const userIds = Array.from(userManager.selectedUsers);
                userManager.bulkDeactivateUsers(userIds);
                userManager.selectedUsers.clear();
                document.getElementById('selectAllUsers').checked = false;
                renderUsersTable();
                renderRecentActivity();
                renderNotifications();
            });
            
            document.getElementById('btnBulkDelete').addEventListener('click', function() {
                if (confirm(`¿Estás seguro de que deseas eliminar ${userManager.selectedUsers.size} usuarios?`)) {
                    const userIds = Array.from(userManager.selectedUsers);
                    userManager.bulkDeleteUsers(userIds);
                    userManager.selectedUsers.clear();
                    document.getElementById('selectAllUsers').checked = false;
                    renderUsersTable();
                    renderRecentActivity();
                    renderNotifications();
                }
            });
            
            document.getElementById('btnBulkEmail').addEventListener('click', function() {
                const userIds = Array.from(userManager.selectedUsers);
                const subject = prompt('Asunto del correo:', 'Notificación de SmartStock AI');
                if (subject) {
                    const message = prompt('Mensaje:');
                    if (message) {
                        userManager.bulkSendEmail(userIds, subject, message);
                    }
                }
            });
            
            document.getElementById('btnClearSelection').addEventListener('click', function() {
                userManager.selectedUsers.clear();
                document.getElementById('selectAllUsers').checked = false;
                renderUsersTable();
            });
            
            // Filtros avanzados
            document.getElementById('advancedFiltersToggle').addEventListener('click', function() {
                const content = document.getElementById('advancedFiltersContent');
                if (content) {
                    content.classList.toggle('show');
                }
            });
            
            document.querySelectorAll('.filter-tag').forEach(tag => {
                tag.addEventListener('click', function() {
                    this.classList.toggle('active');
                });
            });
            
            document.getElementById('applyAdvancedFilters').addEventListener('click', applyAdvancedFilters);
            document.getElementById('clearAdvancedFilters').addEventListener('click', clearFilters);
            
            // Búsqueda inteligente
            document.getElementById('searchInput').addEventListener('input', function() {
                const searchTerm = this.value;
                
                // Mostrar sugerencias de búsqueda
                const suggestions = userManager.getSearchSuggestions(searchTerm);
                const suggestionsContainer = document.getElementById('searchSuggestions');
                
                if (suggestionsContainer && suggestions.length > 0 && searchTerm.length >= 2) {
                    suggestionsContainer.innerHTML = '';
                    suggestions.forEach(suggestion => {
                        const suggestionElement = document.createElement('div');
                        suggestionElement.className = 'suggestion-item';
                        suggestionElement.innerHTML = `
                            <i class="fas ${suggestion.icon}"></i>
                            <span>${suggestion.text}</span>
                            <small class="text-muted ms-auto">${suggestion.type}</small>
                        `;
                        suggestionElement.addEventListener('click', function() {
                            document.getElementById('searchInput').value = suggestion.text;
                            userManager.updateFilters({ search: suggestion.text });
                            suggestionsContainer.classList.remove('show');
                            userManager.currentPage = 1;
                            renderUsersTable();
                        });
                        suggestionsContainer.appendChild(suggestionElement);
                    });
                    suggestionsContainer.classList.add('show');
                } else if (suggestionsContainer) {
                    suggestionsContainer.classList.remove('show');
                }
            });
            
            // Exportación
            document.getElementById('btnExport').addEventListener('click', function() {
                const options = document.getElementById('exportOptions');
                if (options) {
                    options.classList.toggle('show');
                }
            });
            
            document.querySelectorAll('.export-option').forEach(option => {
                option.addEventListener('click', function() {
                    const format = this.getAttribute('data-format');
                    userManager.exportData(format);
                    const exportOptions = document.getElementById('exportOptions');
                    if (exportOptions) {
                        exportOptions.classList.remove('show');
                    }
                });
            });
            
            // Indicador de fortaleza de contraseña
            document.getElementById('userPassword').addEventListener('input', function() {
                const password = this.value;
                const strengthIndicator = document.getElementById('passwordStrength');
                
                let strength = 0;
                if (password.length >= 8) strength++;
                if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
                if (password.match(/\d/)) strength++;
                if (password.match(/[^a-zA-Z\d]/)) strength++;
                
                strengthIndicator.className = 'password-strength';
                if (password.length === 0) {
                    document.querySelector('.strength-bar').style.width = '0';
                } else if (strength <= 1) {
                    strengthIndicator.classList.add('strength-weak');
                } else if (strength === 2) {
                    strengthIndicator.classList.add('strength-medium');
                } else if (strength === 3) {
                    strengthIndicator.classList.add('strength-strong');
                } else {
                    strengthIndicator.classList.add('strength-very-strong');
                }
                
                // Verificar coincidencia de contraseñas
                const confirmPassword = document.getElementById('userPasswordConfirm').value;
                const matchIndicator = document.getElementById('passwordMatch');
                
                if (confirmPassword && password !== confirmPassword) {
                    matchIndicator.textContent = 'Las contraseñas no coinciden';
                    matchIndicator.className = 'password-match match-error';
                } else if (confirmPassword) {
                    matchIndicator.textContent = 'Las contraseñas coinciden';
                    matchIndicator.className = 'password-match match-success';
                } else {
                    matchIndicator.textContent = '';
                }
            });
            
            document.getElementById('userPasswordConfirm').addEventListener('input', function() {
                const password = document.getElementById('userPassword').value;
                const confirmPassword = this.value;
                const matchIndicator = document.getElementById('passwordMatch');
                
                if (password && confirmPassword && password !== confirmPassword) {
                    matchIndicator.textContent = 'Las contraseñas no coinciden';
                    matchIndicator.className = 'password-match match-error';
                } else if (password && confirmPassword) {
                    matchIndicator.textContent = 'Las contraseñas coinciden';
                    matchIndicator.className = 'password-match match-success';
                } else {
                    matchIndicator.textContent = '';
                }
            });
            
            // Seleccionar todos los permisos
            document.getElementById('permSelectAll').addEventListener('change', function() {
                const checkboxes = document.querySelectorAll('#permissionsModal .permission-item input[type="checkbox"]');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
            });
            
            // Ver todas las notificaciones
            document.getElementById('viewAllNotifications').addEventListener('click', function(e) {
                e.preventDefault();
                userManager.showNotification('Mostrando todas las notificaciones', 'info');
                document.getElementById('notificationDropdown').classList.remove('show');
            });
            
            // Cerrar menús desplegables al hacer clic fuera
            document.addEventListener('click', function(event) {
                // Cerrar sugerencias de búsqueda
                const searchInput = document.getElementById('searchInput');
                const searchSuggestions = document.getElementById('searchSuggestions');
                if (searchInput && searchSuggestions && !searchInput.contains(event.target) && !searchSuggestions.contains(event.target)) {
                    searchSuggestions.classList.remove('show');
                }
                
                // Cerrar opciones de exportación
                const btnExport = document.getElementById('btnExport');
                const exportOptions = document.getElementById('exportOptions');
                if (btnExport && exportOptions && !btnExport.contains(event.target) && !exportOptions.contains(event.target)) {
                    exportOptions.classList.remove('show');
                }
                
                // Cerrar notificaciones
                const notificationBtn = document.getElementById('notificationBtn');
                const notificationDropdown = document.getElementById('notificationDropdown');
                if (notificationBtn && notificationDropdown && !notificationBtn.contains(event.target) && !notificationDropdown.contains(event.target)) {
                    notificationDropdown.classList.remove('show');
                }
            });
            
            // Actualizar cada 30 segundos
            setInterval(() => {
                renderNotifications();
            }, 30000);
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>