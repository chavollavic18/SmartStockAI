<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Panel de Control Profesional</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #4361ee;
            --primary-dark: #3a56d4;
            --primary-light: #eef2ff;
            --secondary: #06d6a0;
            --secondary-dark: #05c095;
            --danger: #ef476f;
            --danger-dark: #d43f63;
            --warning: #ffd166;
            --warning-dark: #e6bc5c;
            --info: #4cc9f0;
            --info-dark: #3fb5d8;
            --dark: #2b2d42;
            --gray: #8d99ae;
            --gray-light: #edf2f4;
            --light: #f8f9fa;
            --success: #06d6a0;
            --success-dark: #05c095;
            --bg: #f8fafd;
            --card-bg: #ffffff;
            --text: #2b2d42;
            --text-light: #6c757d;
            --border-radius: 16px;
            --border-radius-sm: 12px;
            --border-radius-lg: 24px;
            --transition: all 0.25s ease;
            --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --shadow-lg: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            --shadow-hover: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        .dark-mode {
            --bg: #1e1e2e;
            --card-bg: #2d2d44;
            --text: #f8f9fa;
            --text-light: #a0a0b0;
            --gray-light: #3d3d54;
            --primary-light: #2d2d44;
        }

        body {
            background-color: var(--bg);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: var(--text);
            transition: var(--transition);
            min-height: 100vh;
            font-size: 14px;
            line-height: 1.6;
        }

        /* Scrollbar */
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: var(--gray-light); border-radius: 4px; }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary-dark); }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 24px 0;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 24px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
            margin-bottom: 20px;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo i {
            font-size: 28px;
            background: rgba(255, 255, 255, 0.2);
            padding: 8px;
            border-radius: 12px;
        }

        .logo span {
            background: rgba(255, 255, 255, 0.15);
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 11px;
            font-weight: 500;
            margin-left: 8px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            flex: 1;
        }

        .sidebar-menu li {
            margin-bottom: 2px;
        }

        .sidebar-menu a {
            color: white;
            text-decoration: none;
            padding: 14px 24px;
            display: flex;
            align-items: center;
            transition: var(--transition);
            border-left: 4px solid transparent;
            font-weight: 500;
            gap: 14px;
        }

        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255, 255, 255, 0.15);
            border-left-color: white;
        }

        .sidebar-menu a i {
            width: 24px;
            font-size: 18px;
            text-align: center;
        }

        .sidebar-menu .badge {
            background: var(--danger);
            color: white;
            font-size: 11px;
            padding: 4px 8px;
            border-radius: 30px;
            margin-left: auto;
            font-weight: 600;
        }

        .admin-only {
            border-top: 1px solid rgba(255, 255, 255, 0.15);
            margin-top: 20px;
            padding-top: 20px;
        }

        .admin-label {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 0 24px;
            margin-bottom: 10px;
            opacity: 0.7;
            font-weight: 600;
        }

        .logout-section {
            margin-top: auto;
            padding: 20px 24px;
            border-top: 1px solid rgba(255, 255, 255, 0.15);
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border: none;
            width: 100%;
            padding: 14px 20px;
            border-radius: var(--border-radius-sm);
            display: flex;
            align-items: center;
            gap: 12px;
            transition: var(--transition);
            cursor: pointer;
            font-size: 15px;
            font-weight: 500;
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 25px 30px;
            transition: var(--transition);
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--gray-light);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 600;
            box-shadow: var(--shadow-md);
        }

        .user-details h4 {
            margin-bottom: 5px;
            font-size: 18px;
            font-weight: 600;
        }

        .user-details p {
            margin: 0;
            color: var(--text-light);
            font-size: 14px;
        }

        .user-role {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 6px;
        }

        .role-admin {
            background: var(--warning);
            color: #000;
        }

        .role-employee {
            background: var(--secondary);
            color: white;
        }

        .role-manager {
            background: var(--info);
            color: white;
        }

        .controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .search-container {
            position: relative;
            width: 320px;
        }

        .search-input {
            width: 100%;
            padding: 12px 20px 12px 48px;
            border: 2px solid var(--gray-light);
            border-radius: 40px;
            background: var(--card-bg);
            color: var(--text);
            font-size: 14px;
            transition: var(--transition);
        }

        .search-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(67, 97, 238, 0.15);
        }

        .search-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
        }

        .theme-switcher,
        .notifications,
        .fullscreen-btn {
            background: var(--card-bg);
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: var(--shadow-sm);
            border: 2px solid var(--gray-light);
        }

        .theme-switcher:hover,
        .notifications:hover,
        .fullscreen-btn:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-md);
            border-color: var(--primary);
        }

        .notifications {
            position: relative;
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 22px;
            height: 22px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }

        .action-btn {
            background: var(--card-bg);
            border: 2px solid var(--gray-light);
            border-radius: var(--border-radius);
            padding: 22px 16px;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: var(--shadow-sm);
            position: relative;
            overflow: hidden;
        }

        .action-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary);
            transform: scaleX(0);
            transition: var(--transition);
        }

        .action-btn:hover::before {
            transform: scaleX(1);
        }

        .action-btn:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-hover);
            border-color: var(--primary);
        }

        .action-btn:active {
            transform: translateY(-2px);
        }

        .action-icon {
            font-size: 32px;
            margin-bottom: 12px;
            color: var(--primary);
        }

        .action-text {
            font-size: 15px;
            font-weight: 600;
        }

        .action-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: var(--danger);
            color: white;
            border-radius: 30px;
            padding: 3px 10px;
            font-size: 11px;
            font-weight: 600;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 24px;
            box-shadow: var(--shadow-md);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .stat-card::after {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 120px;
            height: 120px;
            background: var(--primary-light);
            border-radius: 50%;
            transform: translate(40px, -40px);
            opacity: 0.3;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .stat-value {
            font-size: 34px;
            font-weight: 700;
            margin-bottom: 8px;
            position: relative;
            z-index: 1;
        }

        .stat-label {
            font-size: 14px;
            color: var(--text-light);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
            position: relative;
            z-index: 1;
        }

        .stat-icon {
            position: absolute;
            bottom: 15px;
            right: 15px;
            font-size: 48px;
            color: var(--primary);
            opacity: 0.15;
        }

        .stat-change {
            font-size: 13px;
            margin-top: 10px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .stat-change.positive {
            color: var(--secondary);
        }

        .stat-change.negative {
            color: var(--danger);
        }

        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 24px;
            margin-bottom: 30px;
        }

        .card {
            background: var(--card-bg);
            border-radius: var(--border-radius-lg);
            padding: 24px;
            box-shadow: var(--shadow-md);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            border: 2px solid var(--gray-light);
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
            border-color: var(--primary);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-light);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .card-icon {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .bg-primary-light {
            background: var(--primary-light);
            color: var(--primary);
        }

        .bg-warning-light {
            background: rgba(255, 209, 102, 0.15);
            color: var(--warning);
        }

        .bg-success-light {
            background: rgba(6, 214, 160, 0.15);
            color: var(--secondary);
        }

        .bg-danger-light {
            background: rgba(239, 71, 111, 0.15);
            color: var(--danger);
        }

        .bg-info-light {
            background: rgba(76, 201, 240, 0.15);
            color: var(--info);
        }

        .card-value {
            font-size: 38px;
            font-weight: 700;
            margin: 15px 0 8px;
        }

        .card-description {
            font-size: 14px;
            color: var(--text-light);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .progress {
            height: 8px;
            background-color: var(--gray-light);
            border-radius: 4px;
            margin: 15px 0;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            border-radius: 4px;
            transition: width 0.6s ease;
            position: relative;
            overflow: hidden;
        }

        .progress-bar::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            animation: shimmer 1.5s infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        /* Charts Section */
        .charts-section {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            margin-bottom: 30px;
        }

        .chart-container {
            background: var(--card-bg);
            border-radius: var(--border-radius-lg);
            padding: 24px;
            box-shadow: var(--shadow-md);
            border: 2px solid var(--gray-light);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .chart-title {
            font-size: 18px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .chart-actions {
            display: flex;
            gap: 8px;
            background: var(--gray-light);
            padding: 4px;
            border-radius: 40px;
        }

        .chart-btn {
            background: transparent;
            border: none;
            border-radius: 30px;
            padding: 8px 18px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            color: var(--text-light);
        }

        .chart-btn.active {
            background: var(--primary);
            color: white;
        }

        .chart-btn:hover:not(.active) {
            background: var(--card-bg);
        }

        /* Activity List */
        .activity-list {
            list-style: none;
            padding: 0;
        }

        .activity-item {
            display: flex;
            align-items: center;
            padding: 16px 0;
            border-bottom: 1px solid var(--gray-light);
            transition: var(--transition);
        }

        .activity-item:hover {
            background: var(--gray-light);
            padding-left: 12px;
            border-radius: var(--border-radius-sm);
            transform: translateX(5px);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 16px;
            font-size: 20px;
        }

        .activity-content {
            flex: 1;
        }

        .activity-title {
            font-weight: 600;
            margin-bottom: 5px;
            font-size: 15px;
        }

        .activity-time {
            font-size: 12px;
            color: var(--text-light);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Notifications Panel */
        .notifications-panel {
            position: fixed;
            top: 90px;
            right: 30px;
            width: 400px;
            background: var(--card-bg);
            border-radius: var(--border-radius-lg);
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            display: none;
            max-height: 550px;
            overflow-y: auto;
            border: 2px solid var(--gray-light);
        }

        .notifications-panel.show {
            display: block;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .notification-header {
            padding: 20px 24px;
            border-bottom: 2px solid var(--gray-light);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--primary-light);
            border-radius: var(--border-radius-lg) var(--border-radius-lg) 0 0;
            position: sticky;
            top: 0;
            z-index: 2;
        }

        .notification-header h5 {
            font-size: 16px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0;
        }

        .notification-item {
            padding: 18px 24px;
            border-bottom: 1px solid var(--gray-light);
            cursor: pointer;
            transition: var(--transition);
        }

        .notification-item:hover {
            background: var(--gray-light);
            transform: translateX(5px);
        }

        .notification-item.unread {
            background: var(--primary-light);
            position: relative;
        }

        .notification-item.unread::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: var(--primary);
        }

        .notification-title {
            font-weight: 600;
            margin-bottom: 6px;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .notification-message {
            font-size: 13px;
            color: var(--text-light);
            margin-bottom: 6px;
        }

        .notification-time {
            font-size: 11px;
            color: var(--text-light);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        /* Admin Sections */
        .admin-section {
            background: var(--card-bg);
            border-radius: var(--border-radius-lg);
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: var(--shadow-md);
            border: 2px solid var(--gray-light);
        }

        .section-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--gray-light);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .admin-feature {
            padding: 20px 24px;
            border-radius: var(--border-radius);
            background: var(--bg);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: var(--transition);
            border: 2px solid transparent;
        }

        .admin-feature:hover {
            transform: translateX(10px);
            border-color: var(--primary);
            box-shadow: var(--shadow-md);
        }

        .admin-feature i {
            width: 56px;
            height: 56px;
            border-radius: 14px;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            font-size: 22px;
        }

        .admin-feature h5 {
            margin-bottom: 6px;
            font-size: 16px;
            font-weight: 600;
        }

        .admin-feature p {
            margin: 0;
            color: var(--text-light);
            font-size: 14px;
        }

        .admin-feature small {
            color: var(--text-light);
            font-size: 12px;
        }

        /* Restricted Section */
        .restricted-section {
            background: var(--card-bg);
            border-radius: var(--border-radius-lg);
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: var(--shadow-md);
            border-left: 6px solid var(--danger);
        }

        .restricted-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
        }

        .restricted-header i {
            color: var(--danger);
            font-size: 36px;
        }

        .restricted-header h3 {
            font-size: 22px;
            font-weight: 600;
            margin: 0;
        }

        .restricted-content {
            padding: 20px;
            background: rgba(239, 71, 111, 0.1);
            border-radius: var(--border-radius);
            font-size: 14px;
            line-height: 1.7;
        }

        .restricted-content ul {
            list-style: none;
            padding: 0;
            margin-top: 15px;
        }

        .restricted-content li {
            margin-bottom: 10px;
        }

        .restricted-content i {
            width: 20px;
            margin-right: 8px;
        }

        /* Modales */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(5px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            animation: fadeIn 0.2s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-overlay.show {
            display: flex;
        }

        .modal {
            background: var(--card-bg);
            border-radius: 28px;
            width: 95%;
            max-width: 750px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.3);
            animation: scaleIn 0.3s ease;
            border: 2px solid var(--gray-light);
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .modal-header {
            padding: 24px 28px;
            border-bottom: 2px solid var(--gray-light);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--primary-light);
            border-radius: 28px 28px 0 0;
            position: sticky;
            top: 0;
            z-index: 2;
        }

        .modal-header h4 {
            font-size: 20px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0;
        }

        .modal-body {
            padding: 28px;
        }

        .modal-footer {
            padding: 24px 28px;
            border-top: 2px solid var(--gray-light);
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            background: var(--bg);
            border-radius: 0 0 28px 28px;
            position: sticky;
            bottom: 0;
            z-index: 2;
        }

        /* Formularios */
        .form-group {
            margin-bottom: 22px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 14px;
        }

        .form-control,
        .form-select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--gray-light);
            border-radius: 12px;
            background: var(--card-bg);
            color: var(--text);
            font-size: 14px;
            transition: var(--transition);
        }

        .form-control:focus,
        .form-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(67, 97, 238, 0.15);
        }

        .form-control.error {
            border-color: var(--danger);
        }

        .error-message {
            color: var(--danger);
            font-size: 12px;
            margin-top: 5px;
        }

        /* Botones */
        .btn {
            padding: 12px 28px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 600;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            justify-content: center;
        }

        .btn:active {
            transform: scale(0.98);
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(67, 97, 238, 0.3);
        }

        .btn-secondary {
            background: var(--gray);
            color: white;
        }

        .btn-secondary:hover {
            background: #7a879f;
            transform: translateY(-2px);
        }

        .btn-success {
            background: var(--secondary);
            color: white;
        }

        .btn-success:hover {
            background: var(--secondary-dark);
            transform: translateY(-2px);
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: var(--danger-dark);
            transform: translateY(-2px);
        }

        .btn-outline {
            background: transparent;
            border: 2px solid var(--primary);
            color: var(--primary);
        }

        .btn-outline:hover {
            background: var(--primary);
            color: white;
        }

        .btn-sm {
            padding: 8px 16px;
            font-size: 13px;
        }

        .btn-lg {
            padding: 14px 32px;
            font-size: 16px;
        }

        .btn-block {
            width: 100%;
        }

        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Product Items */
        .product-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px;
            border: 2px solid var(--gray-light);
            border-radius: var(--border-radius);
            margin-bottom: 10px;
            transition: var(--transition);
            background: var(--card-bg);
        }

        .product-item:hover {
            border-color: var(--primary);
            transform: translateX(5px);
            box-shadow: var(--shadow-sm);
        }

        .product-info h5 {
            margin-bottom: 6px;
            font-size: 16px;
            font-weight: 600;
        }

        .product-info h6 {
            margin-bottom: 6px;
            font-size: 15px;
            font-weight: 600;
        }

        .product-info p {
            margin: 0;
            color: var(--text-light);
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .product-price {
            font-weight: 700;
            color: var(--secondary);
            font-size: 20px;
        }

        .stock-indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }

        .stock-critical {
            background: var(--danger);
        }

        .stock-low {
            background: var(--warning);
        }

        .stock-good {
            background: var(--secondary);
        }

        .product-stock {
            font-size: 12px;
            padding: 3px 10px;
            border-radius: 30px;
            background: var(--gray-light);
        }

        .stock-critical-badge {
            background: var(--danger);
            color: white;
        }

        .stock-low-badge {
            background: var(--warning);
            color: #000;
        }

        .stock-good-badge {
            background: var(--secondary);
            color: white;
        }

        /* Cart Items */
        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            border: 2px solid var(--gray-light);
            border-radius: var(--border-radius-sm);
            margin-bottom: 10px;
            transition: var(--transition);
        }

        .cart-item:hover {
            border-color: var(--primary);
        }

        /* QR Container */
        .qr-container {
            text-align: center;
            padding: 30px;
            background: white;
            border-radius: var(--border-radius);
            margin: 20px 0;
        }

        #qrcode {
            margin: 20px auto;
            display: inline-block;
            padding: 20px;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-md);
        }

        #qrcode img {
            max-width: 200px;
            height: auto;
        }

        /* Inventory Items */
        .inventory-item {
            transition: var(--transition);
        }

        .inventory-item:hover td {
            background: var(--gray-light) !important;
        }

        .inventory-item.low-stock {
            background: rgba(255, 209, 102, 0.1);
        }

        .inventory-item.critical-stock {
            background: rgba(239, 71, 111, 0.1);
        }

        .inventory-item.out-stock {
            background: rgba(239, 71, 111, 0.2);
        }

        /* AI Analysis */
        .ai-analysis-result {
            background: var(--bg);
            padding: 22px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            border: 2px solid var(--gray-light);
        }

        .ai-analysis-result h5 {
            margin-bottom: 18px;
            font-size: 16px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
        }

        .prediction-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid var(--gray-light);
            font-size: 14px;
        }

        .prediction-item:last-child {
            border-bottom: none;
        }

        .text-success {
            color: var(--secondary);
        }

        .text-danger {
            color: var(--danger);
        }

        .text-warning {
            color: var(--warning);
        }

        .text-primary {
            color: var(--primary);
        }

        /* Tabs */
        .tab-buttons {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            background: var(--gray-light);
            padding: 5px;
            border-radius: 40px;
        }

        .tab-btn {
            padding: 10px 20px;
            background: transparent;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 600;
            font-size: 13px;
            color: var(--text-light);
        }

        .tab-btn.active {
            background: var(--primary);
            color: white;
        }

        .tab-btn:hover:not(.active) {
            background: var(--card-bg);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        /* Loading Spinner */
        .spinner-border {
            width: 40px;
            height: 40px;
            border: 4px solid var(--gray-light);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* Toast */
        .toast-container {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 2100;
        }

        .toast {
            min-width: 300px;
            background: var(--card-bg);
            border: 2px solid var(--gray-light);
            border-radius: var(--border-radius);
            overflow: hidden;
            animation: slideInRight 0.3s ease;
        }

        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .toast-header {
            padding: 12px 18px;
            border-bottom: 2px solid var(--gray-light);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .toast-header.bg-success {
            background: var(--secondary);
            color: white;
        }

        .toast-header.bg-danger {
            background: var(--danger);
            color: white;
        }

        .toast-header.bg-warning {
            background: var(--warning);
            color: #000;
        }

        .toast-body {
            padding: 15px 18px;
            font-size: 14px;
        }

        /* Menu Toggle */
        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 56px;
            height: 56px;
            border-radius: 16px;
            position: fixed;
            bottom: 25px;
            left: 25px;
            z-index: 1001;
            box-shadow: var(--shadow-lg);
            cursor: pointer;
            font-size: 22px;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .menu-toggle:hover {
            background: var(--primary-dark);
            transform: scale(1.05);
        }

        /* Table */
        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th {
            background: var(--primary-light);
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            color: var(--text);
        }

        .table td {
            padding: 15px;
            border-bottom: 1px solid var(--gray-light);
        }

        .table-hover tbody tr:hover {
            background: var(--gray-light);
        }

        /* Badges */
        .badge {
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge.bg-success {
            background: var(--secondary);
            color: white;
        }

        .badge.bg-warning {
            background: var(--warning);
            color: #000;
        }

        .badge.bg-danger {
            background: var(--danger);
            color: white;
        }

        .badge.bg-info {
            background: var(--info);
            color: white;
        }

        .badge.bg-primary {
            background: var(--primary);
            color: white;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 0;
            }

            .sidebar.open {
                transform: translateX(0);
                width: 280px;
            }

            .main-content {
                margin-left: 0;
            }

            .menu-toggle {
                display: flex;
            }

            .charts-section {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 20px 15px;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 20px;
            }

            .controls {
                width: 100%;
                justify-content: space-between;
            }

            .search-container {
                width: 100%;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .quick-actions {
                grid-template-columns: repeat(2, 1fr);
            }

            .notifications-panel {
                width: 90%;
                right: 5%;
                left: 5%;
            }

            .modal {
                width: 95%;
                margin: 10px;
            }

            .modal-body {
                padding: 20px;
            }
        }
    </style>
</head>

<body>
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-robot"></i>
                    SmartStock
                    <span>v3.0</span>
                </div>
            </div>

            <ul class="sidebar-menu">
                <li><a href="#" data-page="dashboard" class="active"><i class="fas fa-home"></i> Dashboard <span class="badge">Nuevo</span></a></li>
                <li><a href="#" data-page="inventario"><i class="fas fa-boxes"></i> Inventario</a></li>
                <li><a href="#" data-page="reportes"><i class="fas fa-chart-line"></i> Reportes</a></li>
                <li><a href="#" data-page="clientes"><i class="fas fa-users"></i> Clientes</a></li>
                <li><a href="#" data-page="proveedores"><i class="fas fa-truck"></i> Proveedores</a></li>
                <li><a href="#" data-page="transacciones"><i class="fas fa-exchange-alt"></i> Transacciones</a></li>
                <li><a href="#" data-page="ventas"><i class="fas fa-shopping-cart"></i> Ventas</a></li>
                <li class="admin-only" id="adminMenuSection">
                    <div class="admin-label">Administración</div>
                </li>
                <li><a href="#" data-page="usuarios"><i class="fas fa-user-cog"></i> Usuarios</a></li>
                <li><a href="#" data-page="perfil"><i class="fas fa-user-circle"></i> Mi Perfil</a></li>
                <li><a href="#" data-page="seguridad"><i class="fas fa-shield-alt"></i> Seguridad</a></li>
                <li><a href="#" data-page="configuracion"><i class="fas fa-cog"></i> Configuración</a></li>
                <li><a href="#" data-page="ayuda"><i class="fas fa-question-circle"></i> Ayuda</a></li>
            </ul>

            <div class="logout-section">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </button>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="user-info">
                    <div class="user-avatar" id="userAvatar">AG</div>
                    <div class="user-details">
                        <h4 id="userName">Ana García</h4>
                        <p id="userEmail">admin@smartstock.ai</p>
                        <span class="user-role role-admin" id="userRole">Administrador</span>
                    </div>
                </div>

                <div class="controls">
                    <div class="search-container">
                        <input type="text" class="search-input" id="searchInput" placeholder="Buscar productos, clientes...">
                        <i class="fas fa-search search-icon"></i>
                    </div>
                    <div class="fullscreen-btn" id="fullscreenToggle">
                        <i class="fas fa-expand"></i>
                    </div>
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notifications" id="notificationsBtn">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge" id="notificationBadge">5</span>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="quick-actions">
                <button class="action-btn" id="quickSaleBtn">
                    <div class="action-icon">
                        <i class="fas fa-cash-register"></i>
                    </div>
                    <div class="action-text">Venta Rápida</div>
                    <span class="action-badge">Nuevo</span>
                </button>
                <button class="action-btn" id="addProductBtn">
                    <div class="action-icon">
                        <i class="fas fa-plus-circle"></i>
                    </div>
                    <div class="action-text">Agregar Producto</div>
                </button>
                <button class="action-btn" id="generateReportBtn">
                    <div class="action-icon">
                        <i class="fas fa-file-pdf"></i>
                    </div>
                    <div class="action-text">Generar Reporte</div>
                </button>
                <button class="action-btn" id="inventoryCheckBtn">
                    <div class="action-icon">
                        <i class="fas fa-clipboard-check"></i>
                    </div>
                    <div class="action-text">Revisar Inventario</div>
                    <span class="action-badge">3</span>
                </button>
                <button class="action-btn" id="aiAnalysisBtn">
                    <div class="action-icon">
                        <i class="fas fa-brain"></i>
                    </div>
                    <div class="action-text">Análisis IA</div>
                </button>
                <button class="action-btn" id="qrGeneratorBtn">
                    <div class="action-icon">
                        <i class="fas fa-qrcode"></i>
                    </div>
                    <div class="action-text">Generar QR</div>
                </button>
                <button class="action-btn" id="importDataBtn">
                    <div class="action-icon">
                        <i class="fas fa-file-import"></i>
                    </div>
                    <div class="action-text">Importar Datos</div>
                </button>
                <button class="action-btn" id="exportDataBtn">
                    <div class="action-icon">
                        <i class="fas fa-file-export"></i>
                    </div>
                    <div class="action-text">Exportar Datos</div>
                </button>
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value" id="dailySales">$4,850</div>
                    <div class="stat-label">Ventas Hoy</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> +15.3% vs ayer
                    </div>
                    <i class="fas fa-shopping-cart stat-icon"></i>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="lowStock">6</div>
                    <div class="stat-label">Stock Bajo</div>
                    <div class="stat-change negative">
                        <i class="fas fa-arrow-down"></i> -2 vs ayer
                    </div>
                    <i class="fas fa-exclamation-triangle stat-icon"></i>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="pendingOrders">15</div>
                    <div class="stat-label">Pedidos Pendientes</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> +5 nuevos
                    </div>
                    <i class="fas fa-truck stat-icon"></i>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="customerCount">234</div>
                    <div class="stat-label">Clientes Activos</div>
                    <div class="stat-change positive">
                        <i class="fas fa-arrow-up"></i> +18 este mes
                    </div>
                    <i class="fas fa-users stat-icon"></i>
                </div>
            </div>

            <!-- Dashboard Cards -->
            <div class="dashboard-cards">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Productos en Stock</div>
                        <div class="card-icon bg-primary-light">
                            <i class="fas fa-box"></i>
                        </div>
                    </div>
                    <div class="card-value" id="totalProducts">1,456</div>
                    <div class="progress">
                        <div class="progress-bar" style="width: 82%; background-color: var(--primary);"></div>
                    </div>
                    <div class="card-description">
                        <span><i class="fas fa-arrow-up text-success"></i> +108 este mes</span>
                        <span>82% capacidad</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Ventas del Mes</div>
                        <div class="card-icon bg-success-light">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                    </div>
                    <div class="card-value" id="monthlySales">$32,450</div>
                    <div class="progress">
                        <div class="progress-bar" style="width: 78%; background-color: var(--secondary);"></div>
                    </div>
                    <div class="card-description">
                        <span><i class="fas fa-arrow-up text-success"></i> +18% vs mes ant</span>
                        <span>78% meta</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Pedidos Pendientes</div>
                        <div class="card-icon bg-warning-light">
                            <i class="fas fa-clipboard-list"></i>
                        </div>
                    </div>
                    <div class="card-value">42</div>
                    <div class="progress">
                        <div class="progress-bar" style="width: 52%; background-color: var(--warning);"></div>
                    </div>
                    <div class="card-description">
                        <span><i class="fas fa-exclamation-circle text-warning"></i> 12 urgentes</span>
                        <span>52% procesados</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Alertas del Sistema</div>
                        <div class="card-icon bg-danger-light">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                    </div>
                    <div class="card-value" id="systemAlerts">4</div>
                    <div class="progress">
                        <div class="progress-bar" style="width: 100%; background-color: var(--danger);"></div>
                    </div>
                    <div class="card-description">
                        <span><i class="fas fa-clock"></i> 2 críticas</span>
                        <span>Revisar ahora</span>
                    </div>
                </div>
            </div>

            <!-- Charts Section -->
            <div class="charts-section">
                <div class="chart-container">
                    <div class="chart-header">
                        <div class="chart-title">
                            <i class="fas fa-chart-line text-primary"></i>
                            Ventas 2024
                        </div>
                        <div class="chart-actions">
                            <button class="chart-btn active" data-period="week">Semana</button>
                            <button class="chart-btn" data-period="month">Mes</button>
                            <button class="chart-btn" data-period="quarter">Trimestre</button>
                            <button class="chart-btn" data-period="year">Año</button>
                        </div>
                    </div>
                    <canvas id="salesChart" style="height: 300px; width: 100%;"></canvas>
                </div>

                <div class="chart-container">
                    <div class="chart-header">
                        <div class="chart-title">
                            <i class="fas fa-history text-info"></i>
                            Actividad Reciente
                        </div>
                        <button class="btn btn-sm btn-outline" id="refreshActivityBtn">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                    <ul class="activity-list" id="activityList">
                        <li class="activity-item">
                            <div class="activity-icon bg-primary-light">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-title">Venta #2345 - $850</div>
                                <div class="activity-time">
                                    <i class="far fa-clock"></i> Hace 5 min
                                    <span class="badge bg-success">Completado</span>
                                </div>
                            </div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon bg-success-light">
                                <i class="fas fa-box"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-title">Stock actualizado: Laptop HP</div>
                                <div class="activity-time">
                                    <i class="far fa-clock"></i> Hace 1 hora
                                    <span class="badge bg-info">+15</span>
                                </div>
                            </div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon bg-warning-light">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-title">Alerta: Monitor 24" bajo</div>
                                <div class="activity-time">
                                    <i class="far fa-clock"></i> Hace 2 horas
                                    <span class="badge bg-warning">Stock: 3</span>
                                </div>
                            </div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon bg-info-light">
                                <i class="fas fa-user-plus"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-title">Nuevo cliente: María López</div>
                                <div class="activity-time">
                                    <i class="far fa-clock"></i> Hace 3 horas
                                </div>
                            </div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon bg-danger-light">
                                <i class="fas fa-truck"></i>
                            </div>
                            <div class="activity-content">
                                <div class="activity-title">Pedido #1234 entregado</div>
                                <div class="activity-time">
                                    <i class="far fa-clock"></i> Hace 4 horas
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Admin Features -->
            <div class="admin-section" id="adminSection">
                <h3 class="section-title">
                    <i class="fas fa-crown text-warning"></i>
                    Panel de Administración
                </h3>

                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="admin-feature" data-feature="users">
                            <i class="fas fa-user-cog"></i>
                            <div>
                                <h5>Gestión de Usuarios</h5>
                                <p>Crear, editar y eliminar usuarios. Asignar roles y permisos.</p>
                                <small>12 usuarios activos · 3 pendientes</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-feature" data-feature="database">
                            <i class="fas fa-database"></i>
                            <div>
                                <h5>Base de Datos</h5>
                                <p>Copias de seguridad, restauración y optimización.</p>
                                <small>Último backup: Hoy 10:30 · 2.3 GB</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-feature" data-feature="security">
                            <i class="fas fa-shield-alt"></i>
                            <div>
                                <h5>Seguridad</h5>
                                <p>Políticas de seguridad, 2FA y logs de acceso.</p>
                                <small>Nivel: Alto · 2FA activado</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-feature" data-feature="system">
                            <i class="fas fa-cogs"></i>
                            <div>
                                <h5>Ajustes del Sistema</h5>
                                <p>Configuración general y personalización.</p>
                                <small>v3.0 · Actualización disponible</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-feature" data-feature="audit">
                            <i class="fas fa-history"></i>
                            <div>
                                <h5>Auditoría</h5>
                                <p>Registro completo de acciones del sistema.</p>
                                <small>Últimas 24h: 234 acciones</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-feature" data-feature="backup">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <div>
                                <h5>Backups</h5>
                                <p>Gestión de copias de seguridad automáticas.</p>
                                <small>15 backups · 12.5 GB</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Restricted Section -->
            <div class="restricted-section" id="restrictedSection">
                <div class="restricted-header">
                    <i class="fas fa-lock"></i>
                    <h3>Acceso Restringido</h3>
                </div>
                <div class="restricted-content">
                    <p><strong>No tienes permisos para acceder al panel de administración.</strong></p>
                    <p>Tus funciones disponibles son:</p>
                    <ul>
                        <li><i class="fas fa-check text-success"></i> Gestión de Inventario</li>
                        <li><i class="fas fa-check text-success"></i> Ventas y Transacciones</li>
                        <li><i class="fas fa-check text-success"></i> Reportes Básicos</li>
                        <li><i class="fas fa-check text-success"></i> Clientes y Proveedores</li>
                        <li><i class="fas fa-times text-danger"></i> Administración de Usuarios</li>
                        <li><i class="fas fa-times text-danger"></i> Configuración del Sistema</li>
                    </ul>
                    <button class="btn btn-primary mt-3" id="requestAccessBtn">
                        <i class="fas fa-paper-plane"></i> Solicitar Acceso
                    </button>
                </div>
            </div>

            <!-- Common Features -->
            <div class="admin-section">
                <h3 class="section-title">
                    <i class="fas fa-star text-warning"></i>
                    Accesos Rápidos
                </h3>

                <div class="row g-4">
                    <div class="col-md-3">
                        <div class="admin-feature">
                            <i class="fas fa-box"></i>
                            <div>
                                <h5>Inventario</h5>
                                <p>1,456 productos</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="admin-feature">
                            <i class="fas fa-shopping-cart"></i>
                            <div>
                                <h5>Ventas Hoy</h5>
                                <p>$4,850</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="admin-feature">
                            <i class="fas fa-users"></i>
                            <div>
                                <h5>Clientes</h5>
                                <p>234 activos</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="admin-feature">
                            <i class="fas fa-truck"></i>
                            <div>
                                <h5>Proveedores</h5>
                                <p>28 registrados</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Notifications Panel -->
    <div class="notifications-panel" id="notificationsPanel">
        <div class="notification-header">
            <h5><i class="fas fa-bell"></i> Notificaciones (5)</h5>
            <button class="btn btn-sm btn-secondary" id="markAllReadBtn">
                <i class="fas fa-check-double"></i> Leer todas
            </button>
        </div>
        <div class="notification-item unread">
            <div class="notification-title">
                <i class="fas fa-exclamation-triangle text-warning"></i> Stock crítico
            </div>
            <div class="notification-message">3 productos requieren atención inmediata</div>
            <div class="notification-time">
                <i class="far fa-clock"></i> Hace 10 min
            </div>
        </div>
        <div class="notification-item unread">
            <div class="notification-title">
                <i class="fas fa-shopping-cart text-success"></i> Nuevo pedido #1245
            </div>
            <div class="notification-message">Cliente Corp - $2,450</div>
            <div class="notification-time">
                <i class="far fa-clock"></i> Hace 25 min
            </div>
        </div>
        <div class="notification-item unread">
            <div class="notification-title">
                <i class="fas fa-database text-info"></i> Backup completado
            </div>
            <div class="notification-message">Copia automática exitosa</div>
            <div class="notification-time">
                <i class="far fa-clock"></i> Hace 2 horas
            </div>
        </div>
        <div class="notification-item">
            <div class="notification-title">
                <i class="fas fa-download text-primary"></i> Actualización v3.0
            </div>
            <div class="notification-message">Nueva versión disponible</div>
            <div class="notification-time">
                <i class="far fa-clock"></i> Ayer
            </div>
        </div>
        <div class="notification-item">
            <div class="notification-title">
                <i class="fas fa-user-plus text-success"></i> Nuevo cliente
            </div>
            <div class="notification-message">Carlos Ruiz se registró</div>
            <div class="notification-time">
                <i class="far fa-clock"></i> Ayer
            </div>
        </div>
    </div>

    <!-- Quick Sale Modal -->
    <div class="modal-overlay" id="quickSaleModal">
        <div class="modal">
            <div class="modal-header">
                <h4><i class="fas fa-cash-register"></i> Venta Rápida</h4>
                <button class="btn btn-secondary btn-sm" id="closeQuickSaleBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-4">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Buscar Producto</label>
                            <input type="text" class="form-control" id="productSearchInput" placeholder="Nombre o código...">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Cliente</label>
                            <select class="form-select" id="customerSelect">
                                <option value="general">Cliente General</option>
                                <option value="1">Juan Pérez</option>
                                <option value="2">María López</option>
                                <option value="3">Carlos Ruiz</option>
                                <option value="new">+ Nuevo Cliente</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-12">
                        <h6 class="mb-3">Productos Disponibles</h6>
                        <div class="row g-2" id="productGrid">
                            <div class="col-md-6">
                                <div class="product-item">
                                    <div class="product-info">
                                        <h6>Laptop HP Pavilion</h6>
                                        <p>Código: LPT001 | Stock: 15</p>
                                    </div>
                                    <div class="text-end">
                                        <div class="product-price">$850</div>
                                        <button class="btn btn-primary btn-sm add-to-cart-btn w-100" data-product="Laptop HP Pavilion" data-price="850" data-code="LPT001" data-stock="15">
                                            <i class="fas fa-plus"></i> Agregar
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="product-item">
                                    <div class="product-info">
                                        <h6>Mouse Inalámbrico</h6>
                                        <p>Código: MOU002 | Stock: 42</p>
                                    </div>
                                    <div class="text-end">
                                        <div class="product-price">$25</div>
                                        <button class="btn btn-primary btn-sm add-to-cart-btn w-100" data-product="Mouse Inalámbrico" data-price="25" data-code="MOU002" data-stock="42">
                                            <i class="fas fa-plus"></i> Agregar
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="product-item">
                                    <div class="product-info">
                                        <h6>Teclado Mecánico</h6>
                                        <p>Código: TEC003 | Stock: 8</p>
                                    </div>
                                    <div class="text-end">
                                        <div class="product-price">$89</div>
                                        <button class="btn btn-primary btn-sm add-to-cart-btn w-100" data-product="Teclado Mecánico" data-price="89" data-code="TEC003" data-stock="8">
                                            <i class="fas fa-plus"></i> Agregar
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="product-item">
                                    <div class="product-info">
                                        <h6>Monitor 24"</h6>
                                        <p>Código: MON004 | Stock: 3</p>
                                    </div>
                                    <div class="text-end">
                                        <div class="product-price">$299</div>
                                        <button class="btn btn-primary btn-sm add-to-cart-btn w-100" data-product="Monitor 24\"" data-price="299" data-code="MON004" data-stock="3">
                                            <i class="fas fa-plus"></i> Agregar
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="product-item">
                                    <div class="product-info">
                                        <h6>SSD 1TB</h6>
                                        <p>Código: SSD005 | Stock: 2</p>
                                    </div>
                                    <div class="text-end">
                                        <div class="product-price">$129</div>
                                        <button class="btn btn-primary btn-sm add-to-cart-btn w-100" data-product="SSD 1TB" data-price="129" data-code="SSD005" data-stock="2">
                                            <i class="fas fa-plus"></i> Agregar
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="product-item">
                                    <div class="product-info">
                                        <h6>Impresora</h6>
                                        <p>Código: IMP006 | Stock: 12</p>
                                    </div>
                                    <div class="text-end">
                                        <div class="product-price">$450</div>
                                        <button class="btn btn-primary btn-sm add-to-cart-btn w-100" data-product="Impresora" data-price="450" data-code="IMP006" data-stock="12">
                                            <i class="fas fa-plus"></i> Agregar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-12">
                        <h6 class="mb-3">Carrito <span class="badge bg-primary" id="cartCount">0</span></h6>
                        <div id="cartItems" class="border rounded p-3 mb-3" style="min-height: 100px; max-height: 200px; overflow-y: auto;">
                            <p class="text-center text-muted my-3">El carrito está vacío</p>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Método de Pago</label>
                                    <select class="form-select" id="paymentMethodSelect">
                                        <option value="cash">Efectivo</option>
                                        <option value="card">Tarjeta</option>
                                        <option value="transfer">Transferencia</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Descuento (%)</label>
                                    <input type="number" class="form-control" id="discountInput" min="0" max="100" value="0">
                                </div>
                            </div>
                        </div>
                        <div class="text-end mt-3">
                            <h5>Subtotal: $<span id="cartSubtotal">0.00</span></h5>
                            <h5>Descuento: $<span id="discountAmount">0.00</span></h5>
                            <h4 class="text-primary">Total: $<span id="cartTotal">0.00</span></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelQuickSaleBtn">
                    <i class="fas fa-times"></i> Cancelar
                </button>
                <button class="btn btn-success" id="processSaleBtn" disabled>
                    <i class="fas fa-check"></i> Procesar Venta
                </button>
            </div>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal-overlay" id="addProductModal">
        <div class="modal">
            <div class="modal-header">
                <h4><i class="fas fa-plus-circle"></i> Agregar Producto</h4>
                <button class="btn btn-secondary btn-sm" id="closeAddProductBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="addProductForm">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nombre *</label>
                                <input type="text" class="form-control" id="productNameInput" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Código *</label>
                                <input type="text" class="form-control" id="productCodeInput" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Categoría *</label>
                                <select class="form-select" id="productCategorySelect" required>
                                    <option value="">Seleccionar</option>
                                    <option value="Electrónica">Electrónica</option>
                                    <option value="Computación">Computación</option>
                                    <option value="Accesorios">Accesorios</option>
                                    <option value="Oficina">Oficina</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Proveedor</label>
                                <select class="form-select" id="productSupplierSelect">
                                    <option value="">Seleccionar</option>
                                    <option value="1">TecnoSupply</option>
                                    <option value="2">OfficeDepot</option>
                                    <option value="3">CompuMundo</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Precio Compra ($)</label>
                                <input type="number" class="form-control" id="purchasePriceInput" min="0" step="0.01">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Precio Venta ($) *</label>
                                <input type="number" class="form-control" id="priceInput" min="0" step="0.01" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Margen (%)</label>
                                <input type="text" class="form-control" id="marginInput" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Stock Inicial *</label>
                                <input type="number" class="form-control" id="stockInput" min="0" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Stock Mínimo *</label>
                                <input type="number" class="form-control" id="minStockInput" min="0" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Stock Máximo</label>
                                <input type="number" class="form-control" id="maxStockInput" min="0">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Ubicación</label>
                        <input type="text" class="form-control" id="locationInput" placeholder="Ej: A-12">
                    </div>
                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea class="form-control" id="descriptionInput" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelAddProductBtn">
                    <i class="fas fa-times"></i> Cancelar
                </button>
                <button class="btn btn-primary" id="saveProductBtn">
                    <i class="fas fa-save"></i> Guardar
                </button>
            </div>
        </div>
    </div>

    <!-- Generate Report Modal -->
    <div class="modal-overlay" id="generateReportModal">
        <div class="modal">
            <div class="modal-header">
                <h4><i class="fas fa-file-pdf"></i> Generar Reporte</h4>
                <button class="btn btn-secondary btn-sm" id="closeReportModalBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Tipo de Reporte</label>
                    <select class="form-select" id="reportTypeSelect">
                        <option value="inventory">Inventario General</option>
                        <option value="sales">Ventas</option>
                        <option value="lowstock">Stock Bajo</option>
                        <option value="products">Productos</option>
                        <option value="customers">Clientes</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Formato</label>
                    <select class="form-select" id="reportFormatSelect">
                        <option value="pdf">PDF</option>
                        <option value="excel">Excel</option>
                        <option value="csv">CSV</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Período</label>
                    <select class="form-select" id="dateRangeSelect">
                        <option value="today">Hoy</option>
                        <option value="week">Esta Semana</option>
                        <option value="month">Este Mes</option>
                        <option value="custom">Personalizado</option>
                    </select>
                </div>
                <div id="customDateRangeDiv" style="display: none;">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Fecha Inicio</label>
                                <input type="date" class="form-control" id="startDateInput">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Fecha Fin</label>
                                <input type="date" class="form-control" id="endDateInput">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelReportBtn">
                    <i class="fas fa-times"></i> Cancelar
                </button>
                <button class="btn btn-primary" id="generateReportActionBtn">
                    <i class="fas fa-file-export"></i> Generar
                </button>
            </div>
        </div>
    </div>

    <!-- Inventory Check Modal -->
    <div class="modal-overlay" id="inventoryCheckModal">
        <div class="modal" style="max-width: 900px;">
            <div class="modal-header">
                <h4><i class="fas fa-clipboard-check"></i> Revisión de Inventario</h4>
                <button class="btn btn-secondary btn-sm" id="closeInventoryCheckBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-4">
                    <div class="col-md-8">
                        <div class="tab-buttons">
                            <button class="tab-btn active" data-tab="all">Todos (1,456)</button>
                            <button class="tab-btn" data-tab="low">Stock Bajo (6)</button>
                            <button class="tab-btn" data-tab="critical">Crítico (3)</button>
                            <button class="tab-btn" data-tab="out">Agotados (2)</button>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <input type="text" class="form-control" id="filterInventoryInput" placeholder="Filtrar...">
                    </div>
                </div>
                <div id="inventoryList" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Producto</th>
                                <th>Categoría</th>
                                <th>Stock</th>
                                <th>Mínimo</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="inventory-item">
                                <td>LPT001</td>
                                <td>Laptop HP Pavilion</td>
                                <td>Computación</td>
                                <td>15</td>
                                <td>5</td>
                                <td><span class="badge bg-success">Bueno</span></td>
                                <td>
                                    <button class="btn btn-sm btn-primary adjust-stock-btn" data-code="LPT001">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-info view-product-btn" data-code="LPT001">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr class="inventory-item low-stock">
                                <td>MON004</td>
                                <td>Monitor 24"</td>
                                <td>Electrónica</td>
                                <td>3</td>
                                <td>5</td>
                                <td><span class="badge bg-warning">Bajo</span></td>
                                <td>
                                    <button class="btn btn-sm btn-primary adjust-stock-btn" data-code="MON004">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-info view-product-btn" data-code="MON004">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr class="inventory-item">
                                <td>MOU002</td>
                                <td>Mouse Inalámbrico</td>
                                <td>Accesorios</td>
                                <td>42</td>
                                <td>10</td>
                                <td><span class="badge bg-success">Bueno</span></td>
                                <td>
                                    <button class="btn btn-sm btn-primary adjust-stock-btn" data-code="MOU002">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-info view-product-btn" data-code="MOU002">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr class="inventory-item low-stock">
                                <td>TEC003</td>
                                <td>Teclado Mecánico</td>
                                <td>Accesorios</td>
                                <td>8</td>
                                <td>10</td>
                                <td><span class="badge bg-warning">Bajo</span></td>
                                <td>
                                    <button class="btn btn-sm btn-primary adjust-stock-btn" data-code="TEC003">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-info view-product-btn" data-code="TEC003">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr class="inventory-item critical-stock">
                                <td>SSD005</td>
                                <td>SSD 1TB</td>
                                <td>Computación</td>
                                <td>2</td>
                                <td>10</td>
                                <td><span class="badge bg-danger">Crítico</span></td>
                                <td>
                                    <button class="btn btn-sm btn-primary adjust-stock-btn" data-code="SSD005">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-info view-product-btn" data-code="SSD005">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr class="inventory-item out-stock">
                                <td>IMP007</td>
                                <td>Impresora Láser</td>
                                <td>Oficina</td>
                                <td>0</td>
                                <td>3</td>
                                <td><span class="badge bg-danger">Agotado</span></td>
                                <td>
                                    <button class="btn btn-sm btn-primary adjust-stock-btn" data-code="IMP007">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-info view-product-btn" data-code="IMP007">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="closeInventoryFooterBtn">
                    <i class="fas fa-times"></i> Cerrar
                </button>
                <button class="btn btn-primary" id="exportInventoryBtn">
                    <i class="fas fa-download"></i> Exportar
                </button>
                <button class="btn btn-success" id="reorderStockBtn">
                    <i class="fas fa-shopping-cart"></i> Reordenar
                </button>
            </div>
        </div>
    </div>

    <!-- AI Analysis Modal -->
    <div class="modal-overlay" id="aiAnalysisModal">
        <div class="modal" style="max-width: 800px;">
            <div class="modal-header">
                <h4><i class="fas fa-brain"></i> Análisis IA</h4>
                <button class="btn btn-secondary btn-sm" id="closeAIAnalysisBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-4">
                    <div class="spinner-border text-primary" id="aiLoadingSpinner" style="display: none;"></div>
                </div>
                <div id="aiResults">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="ai-analysis-result">
                                <h5><i class="fas fa-chart-line text-primary"></i> Predicción de Ventas</h5>
                                <div class="prediction-item">
                                    <span>Laptop HP Pavilion</span>
                                    <span>Próx. mes: <strong>32</strong> <span class="text-success">(+17)</span></span>
                                </div>
                                <div class="prediction-item">
                                    <span>Mouse Inalámbrico</span>
                                    <span>Próx. mes: <strong>58</strong> <span class="text-success">(+16)</span></span>
                                </div>
                                <div class="prediction-item">
                                    <span>Monitor 24"</span>
                                    <span>Próx. mes: <strong>15</strong> <span class="text-success">(+12)</span></span>
                                </div>
                                <div class="prediction-item">
                                    <span>Teclado Mecánico</span>
                                    <span>Próx. mes: <strong>22</strong> <span class="text-success">(+14)</span></span>
                                </div>
                                <div class="prediction-item">
                                    <span>SSD 1TB</span>
                                    <span>Próx. mes: <strong>18</strong> <span class="text-success">(+16)</span></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="ai-analysis-result">
                                <h5><i class="fas fa-shopping-cart text-success"></i> Recomendaciones</h5>
                                <ul class="list-unstyled">
                                    <li class="mb-3"><i class="fas fa-circle text-danger me-2" style="font-size: 8px;"></i> Comprar 25 unidades de Monitor 24"</li>
                                    <li class="mb-3"><i class="fas fa-circle text-warning me-2" style="font-size: 8px;"></i> Comprar 20 unidades de Teclado Mecánico</li>
                                    <li class="mb-3"><i class="fas fa-circle text-danger me-2" style="font-size: 8px;"></i> Comprar 30 unidades de SSD 1TB</li>
                                    <li class="mb-3"><i class="fas fa-circle text-info me-2" style="font-size: 8px;"></i> Comprar 15 unidades de Impresora</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="ai-analysis-result">
                                <h5><i class="fas fa-chart-pie text-info"></i> Tendencias</h5>
                                <p>Las ventas han aumentado un 23% en el último mes. Se recomienda incrementar stock en un 30% para la próxima temporada.</p>
                                <div class="row mt-3">
                                    <div class="col-md-4 text-center">
                                        <div class="bg-primary-light p-3 rounded">
                                            <strong class="d-block fs-4">+23%</strong>
                                            <small>Ventas</small>
                                        </div>
                                    </div>
                                    <div class="col-md-4 text-center">
                                        <div class="bg-success-light p-3 rounded">
                                            <strong class="d-block fs-4">32%</strong>
                                            <small>Rotación</small>
                                        </div>
                                    </div>
                                    <div class="col-md-4 text-center">
                                        <div class="bg-warning-light p-3 rounded">
                                            <strong class="d-block fs-4">8</strong>
                                            <small>Días stock</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="closeAIAnalysisFooterBtn">
                    <i class="fas fa-times"></i> Cerrar
                </button>
                <button class="btn btn-primary" id="refreshAIAnalysisBtn">
                    <i class="fas fa-sync-alt"></i> Actualizar
                </button>
                <button class="btn btn-success" id="exportAIAnalysisBtn">
                    <i class="fas fa-download"></i> Exportar
                </button>
            </div>
        </div>
    </div>

    <!-- QR Generator Modal -->
    <div class="modal-overlay" id="qrModal">
        <div class="modal" style="max-width: 500px;">
            <div class="modal-header">
                <h4><i class="fas fa-qrcode"></i> Generar QR</h4>
                <button class="btn btn-secondary btn-sm" id="closeQRModalBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Tipo</label>
                    <select class="form-select" id="qrTypeSelect">
                        <option value="product">Producto</option>
                        <option value="invoice">Factura</option>
                        <option value="customer">Cliente</option>
                        <option value="custom">Personalizado</option>
                    </select>
                </div>
                <div class="form-group" id="qrProductGroup">
                    <label>Producto</label>
                    <select class="form-select" id="qrProductSelect">
                        <option value="LPT001">Laptop HP Pavilion</option>
                        <option value="MOU002">Mouse Inalámbrico</option>
                        <option value="TEC003">Teclado Mecánico</option>
                        <option value="MON004">Monitor 24"</option>
                        <option value="SSD005">SSD 1TB</option>
                    </select>
                </div>
                <div class="form-group" id="qrCustomGroup" style="display: none;">
                    <label>Texto</label>
                    <input type="text" class="form-control" id="qrCustomText" placeholder="Texto para QR">
                </div>
                <div class="form-group">
                    <label>Tamaño</label>
                    <select class="form-select" id="qrSizeSelect">
                        <option value="150">Pequeño</option>
                        <option value="200" selected>Mediano</option>
                        <option value="250">Grande</option>
                    </select>
                </div>
                <div class="qr-container" id="qrContainer" style="display: none;">
                    <div id="qrcode"></div>
                    <p id="qrText" class="text-muted small mt-2"></p>
                    <div class="btn-group w-100">
                        <button class="btn btn-primary" id="downloadQRBtn">
                            <i class="fas fa-download"></i> Descargar
                        </button>
                        <button class="btn btn-success" id="printQRBtn">
                            <i class="fas fa-print"></i> Imprimir
                        </button>
                    </div>
                </div>
                <button class="btn btn-primary btn-block mt-3" id="generateQRActionBtn">
                    <i class="fas fa-qrcode"></i> Generar QR
                </button>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="closeQRFooterBtn">
                    <i class="fas fa-times"></i> Cerrar
                </button>
            </div>
        </div>
    </div>

    <!-- Import Modal -->
    <div class="modal-overlay" id="importModal">
        <div class="modal">
            <div class="modal-header">
                <h4><i class="fas fa-file-import"></i> Importar Datos</h4>
                <button class="btn btn-secondary btn-sm" id="closeImportModalBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Tipo</label>
                    <select class="form-select" id="importTypeSelect">
                        <option value="products">Productos</option>
                        <option value="customers">Clientes</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Archivo</label>
                    <input type="file" class="form-control" id="importFileInput" accept=".xlsx,.xls,.csv">
                </div>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Descarga la <a href="#" id="downloadTemplateLink">plantilla</a>
                </div>
                <div id="importPreview" style="display: none;">
                    <h6>Vista Previa</h6>
                    <div style="max-height: 200px; overflow-y: auto;">
                        <table class="table table-sm">
                            <thead id="previewHeader"></thead>
                            <tbody id="previewBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelImportBtn">
                    <i class="fas fa-times"></i> Cancelar
                </button>
                <button class="btn btn-primary" id="processImportBtn" disabled>
                    <i class="fas fa-upload"></i> Importar
                </button>
            </div>
        </div>
    </div>

    <!-- Export Modal -->
    <div class="modal-overlay" id="exportModal">
        <div class="modal">
            <div class="modal-header">
                <h4><i class="fas fa-file-export"></i> Exportar Datos</h4>
                <button class="btn btn-secondary btn-sm" id="closeExportModalBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Tipo</label>
                    <select class="form-select" id="exportTypeSelect">
                        <option value="products">Productos</option>
                        <option value="customers">Clientes</option>
                        <option value="inventory">Inventario</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Formato</label>
                    <select class="form-select" id="exportFormatSelect">
                        <option value="excel">Excel</option>
                        <option value="csv">CSV</option>
                        <option value="pdf">PDF</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelExportBtn">
                    <i class="fas fa-times"></i> Cancelar
                </button>
                <button class="btn btn-primary" id="processExportBtn">
                    <i class="fas fa-download"></i> Exportar
                </button>
            </div>
        </div>
    </div>

    <!-- Request Access Modal -->
    <div class="modal-overlay" id="requestAccessModal">
        <div class="modal">
            <div class="modal-header">
                <h4><i class="fas fa-paper-plane"></i> Solicitar Acceso</h4>
                <button class="btn btn-secondary btn-sm" id="closeRequestModalBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" class="form-control" id="requestNameInput" value="Carlos López" readonly>
                </div>
                <div class="form-group">
                    <label>Rol</label>
                    <input type="text" class="form-control" id="requestRoleInput" value="Empleado" readonly>
                </div>
                <div class="form-group">
                    <label>Funciones</label>
                    <select class="form-select" id="requestFeaturesSelect" multiple size="3">
                        <option value="users" selected>Usuarios</option>
                        <option value="database" selected>Base de Datos</option>
                        <option value="security">Seguridad</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Justificación</label>
                    <textarea class="form-control" id="requestJustificationInput" rows="3" placeholder="Motivo de la solicitud..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelRequestBtn">
                    <i class="fas fa-times"></i> Cancelar
                </button>
                <button class="btn btn-primary" id="submitRequestBtn">
                    <i class="fas fa-paper-plane"></i> Enviar
                </button>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div class="toast-container">
        <div id="toast" class="toast" style="display: none;">
            <div class="toast-header" id="toastHeader">
                <i class="fas fa-check-circle me-2"></i>
                <strong class="me-auto" id="toastTitle">Éxito</strong>
                <small>ahora</small>
            </div>
            <div class="toast-body" id="toastMessage">
                Operación completada
            </div>
        </div>
    </div>

    <!-- Menu Toggle -->
    <button class="menu-toggle" id="menuToggleBtn">
        <i class="fas fa-bars"></i>
    </button>

    <script>
        // ============================================
        // CONFIGURACIÓN INICIAL
        // ============================================
        const users = {
            "admin@smartstock.ai": {
                name: "Ana García",
                role: "admin",
                avatar: "AG"
            },
            "empleado@smartstock.ai": {
                name: "Carlos López",
                role: "empleado",
                avatar: "CL"
            },
            "gerente@smartstock.ai": {
                name: "María Rodríguez",
                role: "manager",
                avatar: "MR"
            }
        };

        const products = [
            { code: "LPT001", name: "Laptop HP Pavilion", category: "Computación", price: 850, stock: 15, minStock: 5 },
            { code: "MOU002", name: "Mouse Inalámbrico", category: "Accesorios", price: 25, stock: 42, minStock: 10 },
            { code: "TEC003", name: "Teclado Mecánico", category: "Accesorios", price: 89, stock: 8, minStock: 10 },
            { code: "MON004", name: "Monitor 24\"", category: "Electrónica", price: 299, stock: 3, minStock: 5 },
            { code: "SSD005", name: "SSD 1TB", category: "Computación", price: 129, stock: 2, minStock: 10 },
            { code: "IMP006", name: "Impresora", category: "Oficina", price: 450, stock: 12, minStock: 3 },
            { code: "IMP007", name: "Impresora Láser", category: "Oficina", price: 380, stock: 0, minStock: 3 }
        ];

        const customers = [
            { id: 1, name: "Juan Pérez", email: "juan@email.com", phone: "611111111" },
            { id: 2, name: "María López", email: "maria@email.com", phone: "622222222" },
            { id: 3, name: "Carlos Ruiz", email: "carlos@email.com", phone: "633333333" }
        ];

        let currentUser = null;
        let cart = [];
        let salesChart = null;

        // ============================================
        // FUNCIONES DE UTILIDAD
        // ============================================
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const header = document.getElementById('toastHeader');
            const title = document.getElementById('toastTitle');
            const msg = document.getElementById('toastMessage');

            header.className = 'toast-header';
            if (type === 'success') {
                header.classList.add('bg-success', 'text-white');
                header.querySelector('i').className = 'fas fa-check-circle me-2';
                title.textContent = 'Éxito';
            } else if (type === 'error') {
                header.classList.add('bg-danger', 'text-white');
                header.querySelector('i').className = 'fas fa-exclamation-circle me-2';
                title.textContent = 'Error';
            } else {
                header.classList.add('bg-warning');
                header.querySelector('i').className = 'fas fa-exclamation-triangle me-2';
                title.textContent = 'Aviso';
            }

            msg.textContent = message;
            toast.style.display = 'block';

            setTimeout(() => {
                toast.style.display = 'none';
            }, 3000);
        }

        function loadUser() {
            const email = new URLSearchParams(window.location.search).get('email') || "admin@smartstock.ai";
            currentUser = users[email] || users["admin@smartstock.ai"];

            document.getElementById('userName').textContent = currentUser.name;
            document.getElementById('userEmail').textContent = email;
            document.getElementById('userAvatar').textContent = currentUser.avatar;

            const roleEl = document.getElementById('userRole');
            if (currentUser.role === 'admin') {
                roleEl.textContent = 'Administrador';
                roleEl.className = 'user-role role-admin';
                document.getElementById('adminSection').style.display = 'block';
                document.getElementById('adminMenuSection').style.display = 'block';
                document.getElementById('restrictedSection').style.display = 'none';
            } else {
                roleEl.textContent = currentUser.role === 'manager' ? 'Gerente' : 'Empleado';
                roleEl.className = currentUser.role === 'manager' ? 'user-role role-manager' : 'user-role role-employee';
                document.getElementById('adminSection').style.display = 'none';
                document.getElementById('adminMenuSection').style.display = 'none';
                document.getElementById('restrictedSection').style.display = 'block';
            }
        }

        function initChart() {
            const ctx = document.getElementById('salesChart').getContext('2d');
            salesChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
                    datasets: [{
                        label: 'Ventas 2024',
                        data: [18500, 22000, 25800, 31200, 35800, 41200, 45800, 51200, 56800, 62400, 67800, 72400],
                        borderColor: '#4361ee',
                        backgroundColor: 'rgba(67, 97, 238, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } }
                }
            });
        }

        function updateChart(period) {
            if (!salesChart) return;
            let labels, data;
            if (period === 'week') {
                labels = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
                data = [12500, 14800, 13200, 15800, 17200, 19800, 14500];
            } else if (period === 'month') {
                labels = ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4'];
                data = [45800, 51200, 56800, 62400];
            } else if (period === 'quarter') {
                labels = ['Q1', 'Q2', 'Q3', 'Q4'];
                data = [79500, 112200, 148600, 72400];
            } else {
                labels = ['2021', '2022', '2023', '2024'];
                data = [245000, 312000, 458000, 678000];
            }
            salesChart.data.labels = labels;
            salesChart.data.datasets[0].data = data;
            salesChart.update();
        }

        // ============================================
        // VENTA RÁPIDA
        // ============================================
        function setupQuickSale() {
            const modal = document.getElementById('quickSaleModal');
            const openBtn = document.getElementById('quickSaleBtn');
            const closeBtn = document.getElementById('closeQuickSaleBtn');
            const cancelBtn = document.getElementById('cancelQuickSaleBtn');
            const processBtn = document.getElementById('processSaleBtn');
            const cartItems = document.getElementById('cartItems');
            const cartCount = document.getElementById('cartCount');
            const cartSubtotal = document.getElementById('cartSubtotal');
            const discountAmount = document.getElementById('discountAmount');
            const cartTotal = document.getElementById('cartTotal');
            const discountInput = document.getElementById('discountInput');
            const searchInput = document.getElementById('productSearchInput');

            openBtn.addEventListener('click', () => {
                modal.classList.add('show');
                cart = [];
                updateCartDisplay();
            });

            closeBtn.addEventListener('click', () => modal.classList.remove('show'));
            cancelBtn.addEventListener('click', () => modal.classList.remove('show'));

            document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const product = btn.dataset.product;
                    const price = parseFloat(btn.dataset.price);
                    const code = btn.dataset.code;
                    const stock = parseInt(btn.dataset.stock);

                    const existing = cart.find(item => item.code === code);
                    if (existing) {
                        if (existing.quantity < stock) {
                            existing.quantity++;
                        } else {
                            showToast('Stock insuficiente', 'error');
                            return;
                        }
                    } else {
                        cart.push({ product, price, code, quantity: 1, stock });
                    }
                    updateCartDisplay();
                    showToast(`${product} agregado`, 'success');
                });
            });

            searchInput.addEventListener('keyup', () => {
                const term = searchInput.value.toLowerCase();
                document.querySelectorAll('#productGrid .col-md-6').forEach(el => {
                    const text = el.textContent.toLowerCase();
                    el.style.display = text.includes(term) ? 'block' : 'none';
                });
            });

            discountInput.addEventListener('input', updateCartDisplay);

            function updateCartDisplay() {
                if (cart.length === 0) {
                    cartItems.innerHTML = '<p class="text-center text-muted my-3">Carrito vacío</p>';
                    cartCount.textContent = '0';
                    cartSubtotal.textContent = '0.00';
                    discountAmount.textContent = '0.00';
                    cartTotal.textContent = '0.00';
                    processBtn.disabled = true;
                    return;
                }

                let html = '';
                let subtotal = 0;

                cart.forEach((item, idx) => {
                    const itemTotal = item.price * item.quantity;
                    subtotal += itemTotal;
                    html += `
                        <div class="cart-item">
                            <div>
                                <strong>${item.product}</strong><br>
                                <small>$${item.price} x ${item.quantity}</small>
                            </div>
                            <div>
                                <strong>$${itemTotal.toFixed(2)}</strong>
                                <button class="btn btn-danger btn-sm ms-2 remove-cart-item" data-index="${idx}">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    `;
                });

                cartItems.innerHTML = html;
                cartCount.textContent = cart.reduce((sum, i) => sum + i.quantity, 0);

                const discount = parseFloat(discountInput.value) || 0;
                const discountVal = subtotal * (discount / 100);
                const total = subtotal - discountVal;

                cartSubtotal.textContent = subtotal.toFixed(2);
                discountAmount.textContent = discountVal.toFixed(2);
                cartTotal.textContent = total.toFixed(2);
                processBtn.disabled = false;

                document.querySelectorAll('.remove-cart-item').forEach(btn => {
                    btn.addEventListener('click', () => {
                        const idx = parseInt(btn.dataset.index);
                        cart.splice(idx, 1);
                        updateCartDisplay();
                    });
                });
            }

            processBtn.addEventListener('click', () => {
                const total = parseFloat(cartTotal.textContent);
                showToast(`Venta procesada: $${total.toFixed(2)}`, 'success');
                cart = [];
                updateCartDisplay();
                modal.classList.remove('show');

                const daily = document.getElementById('dailySales');
                const current = parseFloat(daily.textContent.replace('$', '').replace(',', ''));
                daily.textContent = '$' + (current + total).toFixed(2);
            });
        }

        // ============================================
        // AGREGAR PRODUCTO
        // ============================================
        function setupAddProduct() {
            const modal = document.getElementById('addProductModal');
            const openBtn = document.getElementById('addProductBtn');
            const closeBtn = document.getElementById('closeAddProductBtn');
            const cancelBtn = document.getElementById('cancelAddProductBtn');
            const saveBtn = document.getElementById('saveProductBtn');
            const purchaseInput = document.getElementById('purchasePriceInput');
            const priceInput = document.getElementById('priceInput');
            const marginInput = document.getElementById('marginInput');

            openBtn.addEventListener('click', () => modal.classList.add('show'));
            closeBtn.addEventListener('click', () => modal.classList.remove('show'));
            cancelBtn.addEventListener('click', () => modal.classList.remove('show'));

            function calcMargin() {
                const p = parseFloat(purchaseInput.value) || 0;
                const s = parseFloat(priceInput.value) || 0;
                if (p > 0 && s > 0) {
                    marginInput.value = ((s - p) / p * 100).toFixed(2) + '%';
                } else {
                    marginInput.value = '';
                }
            }
            purchaseInput.addEventListener('input', calcMargin);
            priceInput.addEventListener('input', calcMargin);

            saveBtn.addEventListener('click', () => {
                const name = document.getElementById('productNameInput').value;
                const code = document.getElementById('productCodeInput').value;
                if (!name || !code) {
                    showToast('Complete los campos obligatorios', 'error');
                    return;
                }
                showToast(`Producto ${name} agregado`, 'success');
                modal.classList.remove('show');
                document.getElementById('addProductForm').reset();
            });
        }

        // ============================================
        // GENERAR REPORTE
        // ============================================
        function setupGenerateReport() {
            const modal = document.getElementById('generateReportModal');
            const openBtn = document.getElementById('generateReportBtn');
            const closeBtn = document.getElementById('closeReportModalBtn');
            const cancelBtn = document.getElementById('cancelReportBtn');
            const generateBtn = document.getElementById('generateReportActionBtn');
            const rangeSelect = document.getElementById('dateRangeSelect');
            const customDiv = document.getElementById('customDateRangeDiv');

            openBtn.addEventListener('click', () => modal.classList.add('show'));
            closeBtn.addEventListener('click', () => modal.classList.remove('show'));
            cancelBtn.addEventListener('click', () => modal.classList.remove('show'));

            rangeSelect.addEventListener('change', () => {
                customDiv.style.display = rangeSelect.value === 'custom' ? 'block' : 'none';
            });

            generateBtn.addEventListener('click', () => {
                const type = document.getElementById('reportTypeSelect').value;
                const format = document.getElementById('reportFormatSelect').value;
                showToast(`Reporte ${type} generado en ${format}`, 'success');
                modal.classList.remove('show');
            });
        }

        // ============================================
        // REVISAR INVENTARIO
        // ============================================
        function setupInventoryCheck() {
            const modal = document.getElementById('inventoryCheckModal');
            const openBtn = document.getElementById('inventoryCheckBtn');
            const closeBtn = document.getElementById('closeInventoryCheckBtn');
            const closeFooter = document.getElementById('closeInventoryFooterBtn');
            const exportBtn = document.getElementById('exportInventoryBtn');
            const reorderBtn = document.getElementById('reorderStockBtn');
            const filterInput = document.getElementById('filterInventoryInput');

            openBtn.addEventListener('click', () => modal.classList.add('show'));
            closeBtn.addEventListener('click', () => modal.classList.remove('show'));
            closeFooter.addEventListener('click', () => modal.classList.remove('show'));

            exportBtn.addEventListener('click', () => {
                showToast('Inventario exportado', 'success');
            });

            reorderBtn.addEventListener('click', () => {
                showToast('Órdenes de reabastecimiento generadas', 'success');
            });

            filterInput.addEventListener('keyup', () => {
                const term = filterInput.value.toLowerCase();
                document.querySelectorAll('#inventoryList tbody tr').forEach(row => {
                    row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none';
                });
            });

            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                });
            });

            document.querySelectorAll('.adjust-stock-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const code = btn.dataset.code;
                    const product = products.find(p => p.code === code);
                    if (product) {
                        const newStock = prompt(`Nuevo stock para ${product.name}:`, product.stock);
                        if (newStock && !isNaN(newStock) && newStock >= 0) {
                            product.stock = parseInt(newStock);
                            showToast(`Stock actualizado a ${newStock}`, 'success');
                        }
                    }
                });
            });

            document.querySelectorAll('.view-product-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const code = btn.dataset.code;
                    const product = products.find(p => p.code === code);
                    if (product) {
                        alert(`
                            Producto: ${product.name}
                            Código: ${product.code}
                            Categoría: ${product.category}
                            Precio: $${product.price}
                            Stock: ${product.stock}
                            Mínimo: ${product.minStock}
                        `);
                    }
                });
            });
        }

        // ============================================
        // ANÁLISIS IA
        // ============================================
        function setupAIAnalysis() {
            const modal = document.getElementById('aiAnalysisModal');
            const openBtn = document.getElementById('aiAnalysisBtn');
            const closeBtn = document.getElementById('closeAIAnalysisBtn');
            const closeFooter = document.getElementById('closeAIAnalysisFooterBtn');
            const refreshBtn = document.getElementById('refreshAIAnalysisBtn');
            const exportBtn = document.getElementById('exportAIAnalysisBtn');
            const spinner = document.getElementById('aiLoadingSpinner');

            openBtn.addEventListener('click', () => modal.classList.add('show'));
            closeBtn.addEventListener('click', () => modal.classList.remove('show'));
            closeFooter.addEventListener('click', () => modal.classList.remove('show'));

            refreshBtn.addEventListener('click', () => {
                spinner.style.display = 'inline-block';
                setTimeout(() => {
                    spinner.style.display = 'none';
                    showToast('Análisis actualizado', 'success');
                }, 1500);
            });

            exportBtn.addEventListener('click', () => {
                showToast('Reporte IA exportado', 'success');
            });
        }

        // ============================================
        // GENERADOR QR
        // ============================================
        function setupQRGenerator() {
            const modal = document.getElementById('qrModal');
            const openBtn = document.getElementById('qrGeneratorBtn');
            const closeBtn = document.getElementById('closeQRModalBtn');
            const closeFooter = document.getElementById('closeQRFooterBtn');
            const typeSelect = document.getElementById('qrTypeSelect');
            const productGroup = document.getElementById('qrProductGroup');
            const customGroup = document.getElementById('qrCustomGroup');
            const generateBtn = document.getElementById('generateQRActionBtn');
            const qrContainer = document.getElementById('qrContainer');
            const qrDiv = document.getElementById('qrcode');
            const qrText = document.getElementById('qrText');
            const downloadBtn = document.getElementById('downloadQRBtn');
            const printBtn = document.getElementById('printQRBtn');

            openBtn.addEventListener('click', () => modal.classList.add('show'));
            closeBtn.addEventListener('click', () => modal.classList.remove('show'));
            closeFooter.addEventListener('click', () => modal.classList.remove('show'));

            typeSelect.addEventListener('change', () => {
                if (typeSelect.value === 'custom') {
                    productGroup.style.display = 'none';
                    customGroup.style.display = 'block';
                } else {
                    productGroup.style.display = 'block';
                    customGroup.style.display = 'none';
                }
                qrContainer.style.display = 'none';
            });

            generateBtn.addEventListener('click', () => {
                qrDiv.innerHTML = '';
                let data = '';
                if (typeSelect.value === 'product') {
                    const code = document.getElementById('qrProductSelect').value;
                    data = `PRODUCTO:${code}`;
                } else if (typeSelect.value === 'custom') {
                    data = document.getElementById('qrCustomText').value || 'SmartStock';
                } else {
                    data = `${typeSelect.value.toUpperCase()}:${Date.now()}`;
                }

                const qr = qrcode(0, 'M');
                qr.addData(data);
                qr.make();
                qrDiv.innerHTML = qr.createImgTag(5);
                qrText.textContent = data;
                qrContainer.style.display = 'block';
                showToast('QR generado', 'success');
            });

            downloadBtn.addEventListener('click', () => {
                const img = qrDiv.querySelector('img');
                if (img) {
                    const canvas = document.createElement('canvas');
                    canvas.width = img.width;
                    canvas.height = img.height;
                    canvas.getContext('2d').drawImage(img, 0, 0);
                    const link = document.createElement('a');
                    link.download = `qr_${Date.now()}.png`;
                    link.href = canvas.toDataURL();
                    link.click();
                }
            });

            printBtn.addEventListener('click', () => {
                const win = window.open('', '_blank');
                win.document.write(`<html><body>${qrDiv.innerHTML}<p>${qrText.textContent}</p></body></html>`);
                win.print();
            });
        }

        // ============================================
        // IMPORTAR/EXPORTAR
        // ============================================
        function setupImportExport() {
            const importModal = document.getElementById('importModal');
            const exportModal = document.getElementById('exportModal');
            const importBtn = document.getElementById('importDataBtn');
            const exportBtn = document.getElementById('exportDataBtn');
            const closeImport = document.getElementById('closeImportModalBtn');
            const cancelImport = document.getElementById('cancelImportBtn');
            const closeExport = document.getElementById('closeExportModalBtn');
            const cancelExport = document.getElementById('cancelExportBtn');
            const processImport = document.getElementById('processImportBtn');
            const processExport = document.getElementById('processExportBtn');
            const fileInput = document.getElementById('importFileInput');

            importBtn.addEventListener('click', () => importModal.classList.add('show'));
            exportBtn.addEventListener('click', () => exportModal.classList.add('show'));
            closeImport.addEventListener('click', () => importModal.classList.remove('show'));
            cancelImport.addEventListener('click', () => importModal.classList.remove('show'));
            closeExport.addEventListener('click', () => exportModal.classList.remove('show'));
            cancelExport.addEventListener('click', () => exportModal.classList.remove('show'));

            fileInput.addEventListener('change', () => {
                processImport.disabled = false;
                document.getElementById('importPreview').style.display = 'block';
            });

            processImport.addEventListener('click', () => {
                showToast('Datos importados', 'success');
                importModal.classList.remove('show');
            });

            processExport.addEventListener('click', () => {
                showToast('Datos exportados', 'success');
                exportModal.classList.remove('show');
            });

            document.getElementById('downloadTemplateLink').addEventListener('click', (e) => {
                e.preventDefault();
                showToast('Plantilla descargada', 'success');
            });
        }

        // ============================================
        // SOLICITUD DE ACCESO
        // ============================================
        function setupRequestAccess() {
            const modal = document.getElementById('requestAccessModal');
            const openBtn = document.getElementById('requestAccessBtn');
            const closeBtn = document.getElementById('closeRequestModalBtn');
            const cancelBtn = document.getElementById('cancelRequestBtn');
            const submitBtn = document.getElementById('submitRequestBtn');

            openBtn.addEventListener('click', () => modal.classList.add('show'));
            closeBtn.addEventListener('click', () => modal.classList.remove('show'));
            cancelBtn.addEventListener('click', () => modal.classList.remove('show'));

            submitBtn.addEventListener('click', () => {
                showToast('Solicitud enviada', 'success');
                modal.classList.remove('show');
            });
        }

        // ============================================
        // OTRAS FUNCIONES
        // ============================================
        function setupGeneral() {
            document.getElementById('themeToggle').addEventListener('click', () => {
                document.body.classList.toggle('dark-mode');
                const icon = document.querySelector('#themeToggle i');
                icon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
            });

            document.getElementById('fullscreenToggle').addEventListener('click', () => {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen();
                } else {
                    document.exitFullscreen();
                }
            });

            document.getElementById('menuToggleBtn').addEventListener('click', () => {
                document.getElementById('sidebar').classList.toggle('open');
            });

            document.getElementById('logoutBtn').addEventListener('click', () => {
                if (confirm('¿Cerrar sesión?')) {
                    window.location.href = 'login.php';
                }
            });

            document.getElementById('notificationsBtn').addEventListener('click', () => {
                document.getElementById('notificationsPanel').classList.toggle('show');
            });

            document.getElementById('markAllReadBtn').addEventListener('click', () => {
                document.querySelectorAll('.notification-item.unread').forEach(n => n.classList.remove('unread'));
                document.getElementById('notificationBadge').textContent = '0';
            });

            document.getElementById('refreshActivityBtn').addEventListener('click', () => {
                showToast('Actividad actualizada', 'success');
            });

            document.getElementById('searchInput').addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    showToast(`Buscando: ${e.target.value}`, 'info');
                }
            });

            document.querySelectorAll('.chart-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.chart-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    updateChart(this.dataset.period);
                });
            });

            document.querySelectorAll('.sidebar-menu a').forEach(link => {
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    document.querySelectorAll('.sidebar-menu a').forEach(l => l.classList.remove('active'));
                    link.classList.add('active');
                });
            });

            document.querySelectorAll('.admin-feature').forEach(feature => {
                feature.addEventListener('click', () => {
                    showToast('Funcionalidad en desarrollo', 'info');
                });
            });

            setInterval(() => {
                const daily = document.getElementById('dailySales');
                const val = parseFloat(daily.textContent.replace('$', '').replace(',', ''));
                daily.textContent = '$' + (val + Math.random() * 10).toFixed(2);
            }, 30000);
        }

        // ============================================
        // INICIALIZACIÓN
        // ============================================
        document.addEventListener('DOMContentLoaded', () => {
            loadUser();
            initChart();

            setupQuickSale();
            setupAddProduct();
            setupGenerateReport();
            setupInventoryCheck();
            setupAIAnalysis();
            setupQRGenerator();
            setupImportExport();
            setupRequestAccess();
            setupGeneral();
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>