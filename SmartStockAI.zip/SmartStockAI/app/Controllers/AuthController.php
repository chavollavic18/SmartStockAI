<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class AuthController extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function loginProcess()
    {
        header('Content-Type: application/json');

        $json = $this->request->getJSON();
        
        $username = $json->username ?? null; 
        $password = $json->password ?? null;
        $remember = $json->rememberMe ?? false;

        if (!$username || !$password) {
            return $this->response->setJSON(['success' => false, 'message' => 'Datos incompletos']);
        }

        try {
            $db = \Config\Database::connect();
            $builder = $db->table('usuarios');
            $user = $builder->where('nombre_usuario', $username)->get()->getRow();

            if ($user) {
                if (password_verify($password, $user->password) || $password === $user->password) {
                    $session = session();
                    $session->set([
                        'id'             => $user->id,
                        'nombre_usuario' => $user->nombre_usuario,
                        'rol'            => $user->rol,
                        'logged_in'      => true
                    ]);

                    if ($remember) {
                        setcookie('remembered_user', $user->nombre_usuario, time() + (86400 * 30), "/");
                    }

                    return $this->response->setJSON([
                        'success' => true,
                        'message' => 'Inicio de sesión exitoso',
                        'redirect' => base_url('dashboard')
                    ]);
                } else {
                    return $this->response->setJSON(['success' => false, 'message' => 'Contraseña incorrecta']);
                }
            } else {
                return $this->response->setJSON(['success' => false, 'message' => 'Usuario no encontrado']);
            }
        } catch (\Exception $e) {
            return $this->response->setJSON(['success' => false, 'message' => 'Error BD: ' . $e->getMessage()]);
        }
    }
}