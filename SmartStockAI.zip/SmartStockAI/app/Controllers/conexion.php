<?php
// conexion.php

$host = "localhost";
$port = "3309"; // El puerto que aparece en tu captura
$dbname = "smartstockmodular"; // El nombre de tu base de datos en la captura
$username = "root"; // Tu usuario en la captura
$password = "vic.al17"; // Aquí va la contraseña de tu MySQL. Si no tiene, déjalo vacío.

try {
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, $username, $password, $options);
    // echo "Conexión exitosa"; // Descomenta para probar
} catch (PDOException $e) {
    // Si falla, devolvemos un JSON de error para que el JS lo entienda
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Error de conexión: ' . $e->getMessage()]);
    exit;
}
?>