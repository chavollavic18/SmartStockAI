<?php
// login_process.php
header('Content-Type: application/json');

require 'conexion.php';

// Recibir los datos JSON enviados por el fetch de login.php
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['username']) || !isset($input['password'])) {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
    exit;
}

$user_input = $input['username'];
$pass_input = $input['password'];
$remember = $input['rememberMe'] ?? false;

try {
    // IMPORTANTE: Ajusta 'username' y 'password' a los nombres reales de tus columnas en la tabla 'usuarios'
    // Si tu columna se llama 'usuario' y 'clave', cámbialo aquí abajo.
    $stmt = $pdo->prepare("SELECT id, username, password FROM usuarios WHERE username = ?");
    $stmt->execute([$user_input]);
    $user = $stmt->fetch();

    if ($user) {
        // Verificar contraseña
        // Caso A: La contraseña está encriptada con password_hash() (RECOMENDADO)
        if (password_verify($pass_input, $user['password'])) {
            iniciarSesion($user, $remember);
        }
        // Caso B: La contraseña está en texto plano (NO RECOMENDADO, pero común en pruebas)
        elseif ($pass_input === $user['password']) {
            iniciarSesion($user, $remember);
        } 
        else {
            echo json_encode(['success' => false, 'message' => 'Contraseña incorrecta']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Usuario no encontrado']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error en la base de datos: ' . $e->getMessage()]);
}

function iniciarSesion($user, $remember) {
    session_start();
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];

    // Manejar "Recordar usuario" (Cookie)
    if ($remember) {
        setcookie('remembered_user', $user['username'], time() + (86400 * 30), "/"); // 30 días
    } else {
        setcookie('remembered_user', '', time() - 3600, "/"); // Borrar cookie
    }

    echo json_encode([
        'success' => true,
        'message' => 'Inicio de sesión exitoso',
        'redirect' => 'dashboard.php' // Cambia esto por la página a la que quieres ir después del login
    ]);
}
?>