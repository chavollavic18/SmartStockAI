<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// --------------------------------------------------------------------
// RUTAS DE VISTAS (GET)
// --------------------------------------------------------------------

// Ruta principal (carga el formulario de login)
$routes->get('/', 'AuthController::index');

// Ruta para el login (también carga el formulario)
$routes->get('login', 'AuthController::index');

// Ruta para recuperar contraseña (si tienes ese controlador, si no, déjala comentada)
$routes->get('recuperar', 'Recuperar::index');


// --------------------------------------------------------------------
// RUTAS DE PROCESAMIENTO (POST)
// --------------------------------------------------------------------

// Esta es la ruta que conecta tu formulario con la Base de Datos
$routes->post('login_process', 'AuthController::loginProcess');