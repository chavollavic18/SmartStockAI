<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>SmartStock AI - Seguridad Avanzada</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>

    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --primary-light: rgba(58, 94, 199, 0.12);
            --secondary: #10b981;
            --secondary-light: rgba(16, 185, 129, 0.12);
            --dark: #0f172a;
            --light: #f8fafc;
            --gray: #64748b;
            --gray-light: #f1f5f9;
            --danger: #ef4444;
            --danger-light: rgba(239, 68, 68, 0.12);
            --warning: #f59e0b;
            --warning-light: rgba(245, 158, 11, 0.12);
            --info: #06b6d4;
            --info-light: rgba(6, 182, 212, 0.12);

            --bg: #f3f4f6;
            --card-bg: #ffffff;
            --card-border: #e2e8f0;
            --text-main: #1e293b;
            --text-muted: #64748b;

            --border-radius-sm: 8px;
            --border-radius: 16px;
            --border-radius-lg: 24px;
            --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            --sidebar-width: 270px;
            --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.02);
            --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
            --shadow-lg: 0 20px 35px -10px rgba(0, 0, 0, 0.12);
            --font-main: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;

            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }

        .dark-mode {
            --bg: #0b0f19;
            --card-bg: #151c2c;
            --card-border: #232d42;
            --text-main: #f1f5f9;
            --text-muted: #94a3b8;
            --gray-light: #1e293b;
            --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: var(--font-main); }

        html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }

        body {
            background-color: var(--bg);
            color: var(--text-main);
            transition: var(--transition);
            min-height: 100vh;
            min-height: 100dvh;
            overflow-x: hidden;
            -webkit-tap-highlight-color: transparent;
            -webkit-font-smoothing: antialiased;
        }

        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--gray); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary); }

        .app-container { display: flex; min-height: 100vh; min-height: 100dvh; }

        /* ============================================================
           OVERLAY MÓVIL
           ============================================================ */
        .sidebar-overlay {
            display: none; position: fixed; inset: 0;
            background: rgba(15, 23, 42, 0.55);
            backdrop-filter: blur(3px); -webkit-backdrop-filter: blur(3px);
            z-index: 1040; opacity: 0; transition: opacity 0.3s ease;
        }
        .sidebar-overlay.active { display: block; opacity: 1; }

        /* ============================================================
           SIDEBAR
           ============================================================ */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--sidebar-bg, linear-gradient(180deg, #1e293b 0%, #0f172a 100%));
            color: #ffffff;
            height: 100vh;
            height: 100dvh;
            position: fixed;
            left: 0; top: 0;
            padding: 24px 16px;
            padding-top: calc(24px + var(--safe-top));
            padding-bottom: calc(24px + var(--safe-bottom));
            transition: var(--transition);
            z-index: 1050;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 25px rgba(0,0,0,0.15);
            will-change: transform;
        }

        .sidebar-header {
            padding: 0 12px 24px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .logo {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -0.5px;
            background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }
        .logo span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: var(--transition);
            -webkit-text-fill-color: white;
            flex-shrink: 0;
        }

        .sidebar-close-btn {
            display: none;
            background: rgba(255,255,255,0.08);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            transition: var(--transition);
            flex-shrink: 0;
        }
        .sidebar-close-btn:hover { background: var(--danger); }

        .sidebar-nav-container { flex: 1; overflow-y: auto; padding-right: 4px; -webkit-overflow-scrolling: touch; }
        .menu-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #64748b;
            font-weight: 700;
            margin: 16px 12px 8px 12px;
        }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li { margin-bottom: 4px; }
        .sidebar-menu a {
            color: #94a3b8; text-decoration: none; padding: 12px 16px;
            display: flex; align-items: center; border-radius: var(--border-radius-sm);
            transition: var(--transition); font-weight: 500; font-size: 14px; cursor: pointer; gap: 12px;
            min-height: 44px;
            touch-action: manipulation;
        }
        .sidebar-menu a:hover { color: #ffffff; background: rgba(255, 255, 255, 0.06); transform: translateX(3px); }
        .sidebar-menu a.active { color: #ffffff; background: var(--primary); font-weight: 600; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); }
        .sidebar-menu i { font-size: 18px; width: 22px; text-align: center; flex-shrink: 0; }

        .sidebar-footer { padding-top: 16px; border-top: 1px solid rgba(255, 255, 255, 0.08); }
        .logout-btn {
            background: rgba(239, 68, 68, 0.1); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.2);
            width: 100%; padding: 12px 16px; border-radius: var(--border-radius-sm);
            display: flex; align-items: center; justify-content: center; gap: 10px;
            transition: var(--transition); cursor: pointer; font-weight: 600; font-size: 14px;
            min-height: 44px;
            touch-action: manipulation;
        }
        .logout-btn:hover { background: var(--danger); color: white; border-color: var(--danger); box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3); }

        /* ============================================================
           MAIN CONTENT
           ============================================================ */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 30px;
            padding-top: calc(30px + var(--safe-top));
            padding-bottom: calc(30px + var(--safe-bottom));
            transition: var(--transition);
            min-width: 0;
            overflow-x: hidden;
        }

        /* ============================================================
           TOP HEADER
           ============================================================ */
        .top-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px; background: var(--card-bg); padding: 16px 28px;
            border-radius: var(--border-radius); box-shadow: var(--shadow); border: 1px solid var(--card-border);
            gap: 16px;
            flex-wrap: wrap;
        }

        .user-profile-summary { display: flex; align-items: center; gap: 16px; min-width: 0; }
        .avatar-wrapper { position: relative; flex-shrink: 0; }
        .user-avatar {
            width: 50px; height: 50px; border-radius: 50%; background: var(--primary);
            color: white; display: flex; align-items: center; justify-content: center;
            font-size: 18px; font-weight: 700; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15); transition: var(--transition);
        }
        .status-indicator {
            width: 14px; height: 14px; background-color: var(--secondary);
            border: 2.5px solid var(--card-bg); border-radius: 50%; position: absolute; bottom: 0; right: 0;
        }
        .user-details { min-width: 0; }
        .user-details h5 { margin: 0; font-weight: 700; font-size: 16px; color: var(--text-main); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .user-details p { margin: 0; color: var(--text-muted); font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .user-badge {
            display: inline-block; padding: 2px 10px; border-radius: 20px;
            font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 4px;
        }
        .badge-admin { background: var(--warning-light); color: #d97706; }
        .badge-employee { background: var(--secondary-light); color: var(--secondary); }

        .header-controls { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
        .global-search { position: relative; width: 240px; }
        .global-search input {
            width: 100%; padding: 11px 40px 11px 16px; border: 1px solid var(--card-border);
            border-radius: 30px; background: var(--bg); color: var(--text-main); font-size: 16px; transition: var(--transition);
            min-height: 44px;
        }
        .global-search input:focus { outline: none; border-color: var(--primary); background: var(--card-bg); box-shadow: 0 0 0 4px var(--primary-light); }
        .global-search i { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-size: 14px; }

        .control-btn {
            width: 44px; height: 44px; border-radius: 50%; background: var(--bg);
            border: 1px solid var(--card-border); color: var(--text-main); display: flex;
            align-items: center; justify-content: center; cursor: pointer; transition: var(--transition); position: relative;
            flex-shrink: 0;
            touch-action: manipulation;
        }
        .control-btn:hover { background: var(--primary); color: white; border-color: var(--primary); transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .control-btn:active { transform: scale(0.95); }
        .btn-badge {
            position: absolute; top: -2px; right: -2px; background: var(--danger);
            color: white; font-size: 10px; font-weight: 700; width: 18px; height: 18px;
            border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid var(--card-bg);
        }

        /* ============================================================
           ESTILOS ESPECÍFICOS DE SEGURIDAD
           ============================================================ */
        .page-title-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px; flex-wrap: wrap; gap: 12px;
        }
        .page-title-bar h1 {
            font-size: 26px; font-weight: 800; display: flex; align-items: center; gap: 12px;
            flex-wrap: wrap;
        }
        .page-title-bar h1 i { color: var(--primary); }
        .security-level-badge {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.5px;
        }
        .level-high { background: var(--secondary-light); color: var(--secondary); }
        .level-medium { background: var(--warning-light); color: var(--warning); }
        .level-low { background: var(--danger-light); color: var(--danger); }

        .security-indicators {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }

        .security-indicator {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 22px;
            box-shadow: var(--shadow);
            border: 1px solid var(--card-border);
            border-left: 4px solid var(--primary);
            transition: var(--transition);
        }
        .security-indicator:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); }
        .security-indicator.indicator-good { border-left-color: var(--secondary); }
        .security-indicator.indicator-warning { border-left-color: var(--warning); }
        .security-indicator.indicator-danger { border-left-color: var(--danger); }

        .indicator-icon {
            width: 40px; height: 40px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 18px; margin-bottom: 12px;
        }
        .indicator-value { font-size: 28px; font-weight: 800; margin: 6px 0; color: var(--text-main); }
        .indicator-title { color: var(--text-muted); font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }

        .security-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 28px;
            margin-bottom: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--card-border);
        }

        .security-tabs {
            display: flex;
            border-bottom: 1px solid var(--card-border);
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 4px;
        }

        .security-tab {
            padding: 12px 20px;
            background: none;
            border: none;
            border-bottom: 3px solid transparent;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 600;
            color: var(--text-muted);
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
            border-radius: var(--border-radius-sm) var(--border-radius-sm) 0 0;
            min-height: 44px;
            touch-action: manipulation;
        }

        .security-tab:hover { color: var(--primary); background: var(--primary-light); }
        .security-tab.active { color: var(--primary); border-bottom-color: var(--primary); background: var(--primary-light); }

        .security-content { display: none; }
        .security-content.active { display: block; animation: fadeIn 0.3s ease; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }

        .security-group {
            margin-bottom: 28px;
            padding-bottom: 24px;
            border-bottom: 1px solid var(--card-border);
        }
        .security-group:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }

        .security-group-title {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 18px;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .security-group-title i {
            width: 32px; height: 32px; border-radius: 8px;
            background: var(--primary-light); color: var(--primary);
            display: flex; align-items: center; justify-content: center;
            font-size: 14px;
        }

        .security-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 16px;
        }

        .security-item {
            display: flex;
            flex-direction: column;
        }

        .security-label {
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
            font-size: 13px;
            color: var(--text-main);
        }

        .security-description {
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 6px;
            line-height: 1.5;
        }

        .security-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 28px;
            padding-top: 20px;
            border-top: 1px solid var(--card-border);
            flex-wrap: wrap;
        }

        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 52px;
            height: 28px;
            flex-shrink: 0;
        }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: #cbd5e1;
            transition: .3s;
            border-radius: 28px;
        }
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 20px;
            width: 20px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        input:checked + .toggle-slider { background-color: var(--primary); }
        input:checked + .toggle-slider:before { transform: translateX(24px); }

        .toggle-with-status { display: flex; align-items: center; gap: 12px; }
        .encryption-status {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .encryption-active { background: var(--secondary-light); color: var(--secondary); }
        .encryption-inactive { background: var(--gray-light); color: var(--text-muted); }

        .form-control, .form-select {
            background-color: var(--bg) !important;
            border: 1px solid var(--card-border);
            color: var(--text-main) !important;
            padding: 10px 14px;
            border-radius: var(--border-radius-sm);
            font-size: 16px;
            transition: var(--transition);
            min-height: 44px;
        }
        .form-control:focus, .form-select:focus {
            background-color: var(--card-bg) !important;
            border-color: var(--primary);
            color: var(--text-main) !important;
            box-shadow: 0 0 0 4px var(--primary-light);
        }
        .form-control::placeholder { color: var(--text-muted) !important; }
        .input-group-text {
            background: var(--gray-light);
            border: 1px solid var(--card-border);
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 600;
        }

        .form-check-input:checked { background-color: var(--primary); border-color: var(--primary); }
        .form-check-label { font-size: 13px; color: var(--text-main); }

        .security-logs {
            max-height: 360px;
            overflow-y: auto;
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius-sm);
            padding: 8px;
            background: var(--bg);
            -webkit-overflow-scrolling: touch;
        }
        .log-entry {
            padding: 12px 14px;
            border-bottom: 1px solid var(--card-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            flex-wrap: wrap;
        }
        .log-entry:hover { background: var(--card-bg); }
        .log-entry:last-child { border-bottom: none; }
        .log-info { flex: 1; min-width: 0; }
        .log-action { font-weight: 600; font-size: 13px; color: var(--text-main); }
        .log-time { font-size: 11px; color: var(--text-muted); margin-top: 2px; }
        .log-user { color: var(--primary); font-weight: 600; }
        .log-severity {
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            flex-shrink: 0;
        }
        .severity-high { background: var(--danger-light); color: var(--danger); }
        .severity-medium { background: var(--warning-light); color: var(--warning); }
        .severity-low { background: var(--info-light); color: var(--info); }

        .password-strength { margin-top: 10px; height: 6px; background: var(--gray-light); border-radius: 3px; overflow: hidden; }
        .password-strength-fill { height: 100%; transition: all 0.3s; border-radius: 3px; }
        .strength-weak { background: var(--danger); width: 25%; }
        .strength-fair { background: var(--warning); width: 50%; }
        .strength-good { background: var(--info); width: 75%; }
        .strength-strong { background: var(--secondary); width: 100%; }

        .audit-panel {
            background: var(--bg);
            border-radius: var(--border-radius-sm);
            padding: 14px;
            border: 1px solid var(--card-border);
        }

        .toast-container {
            position: fixed; bottom: calc(20px + var(--safe-bottom)); right: calc(20px + var(--safe-right));
            left: 20px;
            z-index: 3000;
            display: flex; flex-direction: column; gap: 10px;
            pointer-events: none;
            align-items: flex-end;
        }
        .toast {
            min-width: 280px; max-width: 400px;
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            display: flex;
            align-items: center;
            padding: 14px 16px;
            gap: 12px;
            animation: slideIn 0.3s ease;
            color: var(--text-main);
            border: 1px solid var(--card-border);
            pointer-events: auto;
        }
        .toast.success { border-left: 4px solid var(--secondary); }
        .toast.error { border-left: 4px solid var(--danger); }
        .toast.warning { border-left: 4px solid var(--warning); }
        .toast.info { border-left: 4px solid var(--info); }
        .toast i { font-size: 20px; flex-shrink: 0; }
        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        .toast.info i { color: var(--info); }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        .notifications-flyout {
            position: absolute; top: 75px; right: 30px; width: 380px;
            background: var(--card-bg); border: 1px solid var(--card-border);
            border-radius: var(--border-radius); box-shadow: var(--shadow-lg);
            z-index: 1100; display: none; overflow: hidden;
            animation: fadeInDown 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .notifications-flyout.active { display: block; }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .flyout-header {
            padding: 16px 20px; background: var(--bg);
            border-bottom: 1px solid var(--card-border);
            display: flex; justify-content: space-between; align-items: center;
        }
        .flyout-header h6 { margin: 0; font-weight: 700; color: var(--text-main); }
        .flyout-body { max-height: 350px; overflow-y: auto; -webkit-overflow-scrolling: touch; }
        .flyout-item {
            padding: 14px 20px; border-bottom: 1px solid var(--card-border);
            cursor: pointer; transition: var(--transition);
        }
        .flyout-item:hover { background: var(--bg); }
        .flyout-item.unread { border-left: 4px solid var(--primary); background: var(--primary-light); }
        .flyout-item strong { font-size: 13px; color: var(--text-main); }
        .flyout-item p { margin: 2px 0 0 0; font-size: 12px; color: var(--text-muted); }

        .btn {
            padding: 11px 20px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            min-height: 44px;
            touch-action: manipulation;
            justify-content: center;
        }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(58,94,199,0.3); }
        .btn-secondary { background: var(--gray-light); color: var(--text-main); }
        .btn-secondary:hover { background: var(--gray); color: white; }
        .btn-warning { background: var(--warning); color: #000; }
        .btn-warning:hover { background: #d97706; color: white; transform: translateY(-2px); }
        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: #dc2626; transform: translateY(-2px); }
        .btn-outline {
            background: transparent;
            border: 1px solid var(--card-border);
            color: var(--text-main);
        }
        .btn-outline:hover { background: var(--primary); color: white; border-color: var(--primary); }
        .btn-sm { padding: 7px 12px; font-size: 12px; min-height: 36px; }

        /* ✅ CORREGIDO: Botón móvil con pointer-events explícito */
        .mobile-nav-toggle {
            display: none; 
            position: fixed; 
            bottom: calc(20px + var(--safe-bottom));
            right: calc(20px + var(--safe-right));
            width: 56px; 
            height: 56px; 
            border-radius: 50%; 
            background: var(--primary);
            color: white; 
            border: none; 
            box-shadow: var(--shadow-lg);
            z-index: 1100; 
            align-items: center; 
            justify-content: center;
            font-size: 22px; 
            cursor: pointer;
            pointer-events: auto;
            touch-action: manipulation;
            transition: var(--transition);
        }
        .mobile-nav-toggle:active { transform: scale(0.92); }

        /* ============================================================
           RESPONSIVE - TABLET (≤1200px)
           ============================================================ */
        @media (max-width: 1200px) {
            .security-row { grid-template-columns: 1fr; }
        }

        /* ============================================================
           RESPONSIVE - TABLET (≤992px)
           ============================================================ */
        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); width: var(--sidebar-width); }
            .sidebar.mobile-open { transform: translateX(0); }
            .sidebar-close-btn { display: flex; }

            .main-content {
                margin-left: 0;
                padding: 20px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .mobile-nav-toggle { display: flex; }

            .top-header { flex-direction: column; align-items: stretch; gap: 16px; padding: 16px 20px; }
            .header-controls { justify-content: space-between; flex-wrap: wrap; }
            .global-search { order: -1; width: 100%; }
            .notifications-flyout { width: calc(100% - 40px); right: 20px; top: 130px; }
        }

        /* ============================================================
           RESPONSIVE - MÓVIL (≤768px)
           ============================================================ */
        @media (max-width: 768px) {
            .main-content {
                padding: 16px;
                padding-top: calc(16px + var(--safe-top));
                padding-bottom: calc(90px + var(--safe-bottom));
            }

            .sidebar { width: 88vw; max-width: 320px; padding: 20px 12px; padding-top: calc(20px + var(--safe-top)); padding-bottom: calc(20px + var(--safe-bottom)); }

            .top-header { padding: 14px 16px; border-radius: var(--border-radius-sm); gap: 12px; }
            .user-avatar { width: 44px; height: 44px; font-size: 16px; }
            .user-details h5 { font-size: 14px; }
            .user-details p { font-size: 12px; }
            .control-btn { width: 40px; height: 40px; font-size: 14px; }
            .global-search input { font-size: 16px; min-height: 42px; padding: 10px 38px 10px 14px; }

            .page-title-bar { flex-direction: column; align-items: stretch; gap: 12px; }
            .page-title-bar h1 { font-size: 20px; gap: 8px; }
            .page-title-bar h1 i { font-size: 22px; }

            .security-indicators { grid-template-columns: 1fr; }
            .security-section { padding: 20px 16px; border-radius: var(--border-radius-sm); }
            .security-tabs { flex-direction: column; }
            .security-tab { border-bottom: 1px solid var(--card-border); border-left: 3px solid transparent; border-radius: 0; padding: 12px 16px; }
            .security-tab.active { border-left-color: var(--primary); border-bottom-color: var(--card-border); }
            .security-row { grid-template-columns: 1fr; gap: 16px; }
            .security-actions { flex-direction: column; }
            .security-actions .btn { width: 100%; }
            .security-group-title { font-size: 15px; }
            .security-group-title i { width: 28px; height: 28px; font-size: 13px; }

            .log-entry { flex-direction: column; align-items: flex-start; }
            .log-severity { align-self: flex-end; }

            .toast-container { top: calc(12px + var(--safe-top)); bottom: auto; right: 12px; left: 12px; align-items: stretch; }
            .toast { min-width: 0; max-width: 100%; width: 100%; padding: 12px 14px; font-size: 13px; }

            .notifications-flyout { width: calc(100% - 24px); right: 12px; top: 120px; }
        }

        /* ============================================================
           RESPONSIVE - MÓVIL PEQUEÑO (≤380px)
           ============================================================ */
        @media (max-width: 380px) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); padding-bottom: calc(80px + var(--safe-bottom)); }
            .page-title-bar h1 { font-size: 17px; }
            .indicator-value { font-size: 22px; }
            .security-tab { padding: 10px 12px; font-size: 12px; }
            .btn { padding: 10px 14px; font-size: 12px; }
        }

        /* ============================================================
           LANDSCAPE MÓVIL
           ============================================================ */
        @media (max-height: 500px) and (orientation: landscape) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); }
            .top-header { padding: 10px 16px; margin-bottom: 12px; }
            .sidebar { padding: 16px 12px; padding-top: calc(16px + var(--safe-top)); }
        }

        /* ============================================================
           PANTALLAS GRANDES
           ============================================================ */
        @media (min-width: 1440px) {
            .main-content { padding: 40px; }
        }
        @media (min-width: 1920px) {
            .main-content { padding: 48px 60px; max-width: 1800px; margin-left: auto; margin-right: auto; }
        }

        /* ============================================================
           TOUCH
           ============================================================ */
        @media (hover: none) {
            .control-btn:hover { transform: none; background: var(--bg); color: var(--text-main); border-color: var(--card-border); box-shadow: none; }
            .btn:hover { transform: none; box-shadow: none; }
            .btn-primary:hover { background: var(--primary); }
            .btn-outline:hover { background: transparent; color: var(--text-main); }
            .sidebar-menu a:hover { transform: none; background: transparent; }
            .sidebar-menu a.active:hover { background: var(--primary); }
            .security-indicator:hover { transform: none; box-shadow: var(--shadow); }
            .log-entry:hover { background: transparent; }
        }

        /* ============================================================
           REDUCED MOTION
           ============================================================ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        /* ============================================================
           PRINT
           ============================================================ */
        @media print {
            .sidebar, .top-header, .mobile-nav-toggle, .security-actions,
            .notifications-flyout, .toast-container, .sidebar-overlay { display: none !important; }
            .main-content { margin-left: 0 !important; padding: 0 !important; }
            .security-section { box-shadow: none; border: 1px solid #ddd; page-break-inside: avoid; }
            .security-content { display: block !important; }
        }
    </style>
</head>
<body>

    <div class="app-container">

        <!-- OVERLAY MÓVIL -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <!-- SIDEBAR -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-brain"></i></div>
                    <span class="system-name-display">SmartStock AI</span>
                </div>
                <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a data-page="admin"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                    <li><a data-page="inventario"><i class="fas fa-boxes-stacked"></i> Inventario</a></li>
                    <li><a data-page="Transacciones"><i class="fas fa-right-left"></i> Transacciones</a></li>
                    <li><a data-page="Reportes"><i class="fas fa-chart-column"></i> Reportes</a></li>
                </ul>

                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a data-page="clientes"><i class="fas fa-address-book"></i> Clientes</a></li>
                    <li><a data-page="proveedores"><i class="fas fa-truck-field"></i> Proveedores</a></li>
                </ul>

                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a data-page="usuarios"><i class="fas fa-users-gear"></i> Usuarios</a></li>
                    <li><a data-page="seguridad" class="active"><i class="fas fa-shield-halved"></i> Seguridad</a></li>
                    <li><a data-page="perfil"><i class="fas fa-circle-user"></i> Mi Perfil</a></li>
                    <li><a data-page="configuracion"><i class="fas fa-sliders"></i> Configuración</a></li>
                </ul>
            </div>

            <div class="sidebar-footer">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    <span>Cerrar Sesión</span>
                </button>
            </div>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="main-content">

            <header class="top-header">
                <div class="user-profile-summary">
                    <div class="avatar-wrapper">
                        <div class="user-avatar" id="userAvatar"></div>
                        <div class="status-indicator"></div>
                    </div>
                    <div class="user-details">
                        <h5 id="userName"></h5>
                        <p id="userEmail"></p>
                        <span class="user-badge" id="userRoleBadge"></span>
                    </div>
                </div>

                <div class="header-controls">
                    <div class="global-search">
                        <input type="text" id="globalSearchInput" placeholder="Buscar en el sistema...">
                        <i class="fas fa-magnifying-glass"></i>
                    </div>

                    <button class="control-btn" id="themeToggleBtn" title="Cambiar Tema Visual">
                        <i class="fas fa-moon"></i>
                    </button>

                    <button class="control-btn" id="notificationsBtn" title="Notificaciones">
                        <i class="fas fa-bell"></i>
                        <span class="btn-badge" id="notifBadge">3</span>
                    </button>
                </div>
            </header>

            <div class="notifications-flyout" id="notificationsFlyout">
                <div class="flyout-header">
                    <h6>Centro de Notificaciones</h6>
                    <button class="btn btn-sm btn-outline" id="markAllReadBtn" style="padding: 4px 10px; font-size: 11px;">Marcar leídas</button>
                </div>
                <div class="flyout-body" id="notifListContainer">
                    <div class="flyout-item unread">
                        <strong>Alerta de Seguridad</strong>
                        <p>Se detectaron 3 intentos de acceso fallidos.</p>
                    </div>
                    <div class="flyout-item unread">
                        <strong>Rotación de Claves</strong>
                        <p>Las API keys serán rotadas en 5 días.</p>
                    </div>
                    <div class="flyout-item">
                        <strong>Backup Completado</strong>
                        <p>Backup automático cifrado finalizado.</p>
                    </div>
                </div>
            </div>

            <div class="page-title-bar">
                <h1>
                    <i class="fas fa-shield-halved"></i>
                    Seguridad Avanzada
                    <span class="security-level-badge level-high" id="securityLevelBadge">
                        <i class="fas fa-shield-alt"></i> ALTA SEGURIDAD
                    </span>
                </h1>
                <button class="btn btn-outline btn-sm" id="exportSecurityBtn">
                    <i class="fas fa-download"></i> Exportar Reporte
                </button>
            </div>

            <div class="security-indicators">
                <div class="security-indicator indicator-good">
                    <div class="indicator-icon" style="background: var(--secondary-light); color: var(--secondary);">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="indicator-value" id="securityScore">92%</div>
                    <div class="indicator-title">Puntuación de Seguridad</div>
                </div>
                <div class="security-indicator indicator-good">
                    <div class="indicator-icon" style="background: var(--primary-light); color: var(--primary);">
                        <i class="fas fa-bug-slash"></i>
                    </div>
                    <div class="indicator-value" id="threatsBlocked">1,247</div>
                    <div class="indicator-title">Amenazas Bloqueadas</div>
                </div>
                <div class="security-indicator indicator-good">
                    <div class="indicator-icon" style="background: var(--info-light); color: var(--info);">
                        <i class="fas fa-lock"></i>
                    </div>
                    <div class="indicator-value" id="encryptionStatus">AES-256</div>
                    <div class="indicator-title">Cifrado Activo</div>
                </div>
                <div class="security-indicator indicator-good">
                    <div class="indicator-icon" style="background: var(--warning-light); color: var(--warning);">
                        <i class="fas fa-clock-rotate-left"></i>
                    </div>
                    <div class="indicator-value" id="lastBreach">Nunca</div>
                    <div class="indicator-title">Última Brecha</div>
                </div>
            </div>

            <div class="security-section">
                <div class="security-tabs">
                    <button class="security-tab active" data-tab="autenticacion">
                        <i class="fas fa-fingerprint"></i> Autenticación
                    </button>
                    <button class="security-tab" data-tab="accesos">
                        <i class="fas fa-lock"></i> Control de Accesos
                    </button>
                    <button class="security-tab" data-tab="cifrado">
                        <i class="fas fa-key"></i> Cifrado de Datos
                    </button>
                    <button class="security-tab" data-tab="monitoreo">
                        <i class="fas fa-radar"></i> Monitoreo
                    </button>
                    <button class="security-tab" data-tab="auditoria">
                        <i class="fas fa-clipboard-list"></i> Auditoría
                    </button>
                    <button class="security-tab" data-tab="respuesta">
                        <i class="fas fa-bug"></i> Respuesta a Incidentes
                    </button>
                </div>

                <!-- TAB: AUTENTICACIÓN -->
                <div class="security-content active" id="autenticacion-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-user-shield"></i> Autenticación Multi-Factor
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Autenticación de Dos Factores (2FA)</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="twoFactorAuth" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="twoFactorAuthStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Requerir verificación en dos pasos para todos los usuarios</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Método de 2FA</label>
                                <select class="form-select" id="twoFactorMethod">
                                    <option value="app">Aplicación Authenticator</option>
                                    <option value="sms">SMS</option>
                                    <option value="email">Email</option>
                                    <option value="hardware">Token Hardware</option>
                                </select>
                                <div class="security-description">Método preferido para autenticación de dos factores</div>
                            </div>
                        </div>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Biometría</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="biometricAuth">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="biometricAuthStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">Permitir autenticación mediante huella digital o reconocimiento facial</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Tiempo de Sesión</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="sessionTimeout" min="5" max="480" value="30">
                                    <span class="input-group-text">minutos</span>
                                </div>
                                <div class="security-description">Tiempo máximo de inactividad antes de cerrar sesión</div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-key"></i> Política de Contraseñas
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Fortaleza Mínima</label>
                                <select class="form-select" id="passwordStrength">
                                    <option value="low">Baja (6 caracteres)</option>
                                    <option value="medium">Media (8 caracteres, letras y números)</option>
                                    <option value="high" selected>Alta (12 caracteres, complejidad)</option>
                                    <option value="very-high">Muy Alta (16 caracteres, máxima complejidad)</option>
                                </select>
                                <div class="security-description">Nivel de complejidad requerido para las contraseñas</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Caducidad de Contraseñas</label>
                                <select class="form-select" id="passwordExpiration">
                                    <option value="0">Nunca</option>
                                    <option value="30">30 días</option>
                                    <option value="60">60 días</option>
                                    <option value="90" selected>90 días</option>
                                    <option value="180">180 días</option>
                                </select>
                                <div class="security-description">Tiempo después del cual las contraseñas deben cambiarse</div>
                            </div>
                        </div>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Historial de Contraseñas</label>
                                <input type="number" class="form-control" id="passwordHistory" min="0" max="24" value="5">
                                <div class="security-description">Número de contraseñas anteriores que no se pueden reutilizar</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Bloqueo por Intentos Fallidos</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="maxLoginAttempts" min="1" max="10" value="5">
                                    <span class="input-group-text">intentos</span>
                                </div>
                                <div class="security-description">Número máximo de intentos fallidos antes de bloquear la cuenta</div>
                            </div>
                        </div>

                        <div class="security-row">
                            <div class="security-item" style="grid-column: 1 / -1;">
                                <label class="security-label">Generador de Contraseña Segura</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="generatedPassword" placeholder="Haz clic en Generar" readonly>
                                    <button class="btn btn-primary" type="button" id="generatePasswordBtn">
                                        <i class="fas fa-dice"></i> Generar
                                    </button>
                                    <button class="btn btn-outline" type="button" id="copyPasswordBtn">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </div>
                                <div class="password-strength">
                                    <div class="password-strength-fill" id="generatedPasswordStrength" style="width: 0%"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-sync-alt"></i> Rotación de Claves
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Rotación Automática de API Keys</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="apiKeyRotation" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="apiKeyRotationStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Rotar automáticamente las claves API cada 90 días</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Frecuencia de Rotación</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="rotationFrequency" min="7" max="365" value="90">
                                    <span class="input-group-text">días</span>
                                </div>
                                <div class="security-description">Frecuencia para rotar claves y certificados</div>
                            </div>
                        </div>

                        <div class="security-row">
                            <div class="security-item" style="grid-column: 1 / -1;">
                                <button class="btn btn-warning" id="forceRotationBtn">
                                    <i class="fas fa-rotate"></i> Forzar Rotación Ahora
                                </button>
                                <div class="security-description">Ejecuta inmediatamente la rotación de claves API y certificados</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB: CONTROL DE ACCESOS -->
                <div class="security-content" id="accesos-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-network-wired"></i> Control de Acceso Basado en Roles (RBAC)
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Política de Mínimo Privilegio</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="leastPrivilege" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="leastPrivilegeStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Los usuarios solo tienen acceso a lo estrictamente necesario</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Separación de Funciones</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="separationOfDuties" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="separationOfDutiesStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Prevenir conflictos de interés mediante separación de funciones críticas</div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-globe"></i> Control de Acceso por IP y Geolocalización
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Lista Blanca de IPs</label>
                                <textarea class="form-control" id="allowedIPs" rows="3" placeholder="Ej: 192.168.1.0/24, 10.0.0.1"></textarea>
                                <div class="security-description">Solo permitir acceso desde estas IPs o rangos (separados por coma)</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Bloqueo por Geolocalización</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="geoBlocking">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="geoBlockingStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">Bloquear acceso desde países específicos</div>
                            </div>
                        </div>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Países Permitidos</label>
                                <select class="form-select" id="allowedCountries" multiple size="4">
                                    <option value="MX" selected>México</option>
                                    <option value="US">Estados Unidos</option>
                                    <option value="CA">Canadá</option>
                                    <option value="ES">España</option>
                                </select>
                                <div class="security-description">Mantener CTRL para seleccionar múltiples países</div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-clock"></i> Control de Acceso Temporal
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Horario de Acceso</label>
                                <div class="row g-2">
                                    <div class="col">
                                        <label class="form-label" style="font-size: 11px; color: var(--text-muted);">Desde</label>
                                        <input type="time" class="form-control" id="accessTimeStart" value="08:00">
                                    </div>
                                    <div class="col">
                                        <label class="form-label" style="font-size: 11px; color: var(--text-muted);">Hasta</label>
                                        <input type="time" class="form-control" id="accessTimeEnd" value="18:00">
                                    </div>
                                </div>
                                <div class="security-description">Horario permitido para acceder al sistema</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Días de Acceso</label>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px;">
                                    <div class="form-check"><input class="form-check-input" type="checkbox" id="accessMonday" checked><label class="form-check-label" for="accessMonday">Lunes</label></div>
                                    <div class="form-check"><input class="form-check-input" type="checkbox" id="accessTuesday" checked><label class="form-check-label" for="accessTuesday">Martes</label></div>
                                    <div class="form-check"><input class="form-check-input" type="checkbox" id="accessWednesday" checked><label class="form-check-label" for="accessWednesday">Miércoles</label></div>
                                    <div class="form-check"><input class="form-check-input" type="checkbox" id="accessThursday" checked><label class="form-check-label" for="accessThursday">Jueves</label></div>
                                    <div class="form-check"><input class="form-check-input" type="checkbox" id="accessFriday" checked><label class="form-check-label" for="accessFriday">Viernes</label></div>
                                    <div class="form-check"><input class="form-check-input" type="checkbox" id="accessSaturday"><label class="form-check-label" for="accessSaturday">Sábado</label></div>
                                    <div class="form-check"><input class="form-check-input" type="checkbox" id="accessSunday"><label class="form-check-label" for="accessSunday">Domingo</label></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB: CIFRADO -->
                <div class="security-content" id="cifrado-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-lock"></i> Cifrado en Reposo
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Algoritmo de Cifrado</label>
                                <select class="form-select" id="encryptionAlgorithm">
                                    <option value="aes-256">AES-256-GCM</option>
                                    <option value="aes-192">AES-192</option>
                                    <option value="aes-128">AES-128</option>
                                    <option value="chacha20">ChaCha20-Poly1305</option>
                                </select>
                                <div class="security-description">Algoritmo utilizado para cifrar datos en la base de datos</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Cifrado de Base de Datos</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="databaseEncryption" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="databaseEncryptionStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Cifrar toda la base de datos en reposo</div>
                            </div>
                        </div>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Cifrado a Nivel de Campo</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="fieldLevelEncryption">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="fieldLevelEncryptionStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">Cifrar campos sensibles individualmente</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Rotación de Claves de Cifrado</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="keyRotationDays" min="30" max="365" value="90">
                                    <span class="input-group-text">días</span>
                                </div>
                                <div class="security-description">Frecuencia para rotar las claves de cifrado</div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-exchange-alt"></i> Cifrado en Tránsito
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Protocolo TLS</label>
                                <select class="form-select" id="tlsVersion">
                                    <option value="1.3">TLS 1.3</option>
                                    <option value="1.2">TLS 1.2</option>
                                    <option value="1.1">TLS 1.1 (No recomendado)</option>
                                </select>
                                <div class="security-description">Versión de TLS para comunicaciones seguras</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Perfect Forward Secrecy</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="forwardSecrecy" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="forwardSecrecyStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Garantizar que las sesiones pasadas no puedan ser descifradas</div>
                            </div>
                        </div>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">HSTS (HTTP Strict Transport Security)</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="hstsEnabled" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="hstsEnabledStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Forzar siempre conexiones HTTPS</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Certificados SSL</label>
                                <div class="audit-panel">
                                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                                        <span style="font-size: 13px;">Let's Encrypt RSA-2048</span>
                                        <span class="encryption-status encryption-active">Válido</span>
                                    </div>
                                    <div style="margin-top: 8px; font-size: 11px; color: var(--text-muted);">
                                        <i class="fas fa-calendar"></i> Expira: 2024-12-31
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-mask"></i> Enmascaramiento de Datos
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Enmascaramiento Dinámico</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="dataMasking" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="dataMaskingStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Enmascarar datos sensibles en interfaces según permisos</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Tokenización de Datos</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="dataTokenization">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="dataTokenizationStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">Reemplazar datos sensibles con tokens no sensibles</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB: MONITOREO -->
                <div class="security-content" id="monitoreo-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-radar"></i> Detección de Intrusos (IDS)
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Sistema de Detección de Intrusos</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="intrusionDetection" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="intrusionDetectionStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Monitorear y analizar actividad sospechosa en tiempo real</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Umbral de Alerta</label>
                                <select class="form-select" id="alertThreshold">
                                    <option value="low">Bajo (más alertas)</option>
                                    <option value="medium" selected>Medio</option>
                                    <option value="high">Alto (solo amenazas críticas)</option>
                                </select>
                                <div class="security-description">Sensibilidad del sistema de detección</div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-shield-alt"></i> Prevención de Intrusos (IPS)
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Sistema de Prevención de Intrusos</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="intrusionPrevention" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="intrusionPreventionStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Bloquear automáticamente actividades maliciosas detectadas</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Modo de Operación</label>
                                <select class="form-select" id="ipsMode">
                                    <option value="prevention">Prevención (bloquear)</option>
                                    <option value="detection">Detección (solo alertar)</option>
                                </select>
                                <div class="security-description">Comportamiento del sistema cuando detecta amenazas</div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-brain"></i> Machine Learning para Seguridad
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Detección de Anomalías con IA</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="aiAnomalyDetection" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="aiAnomalyDetectionStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Usar machine learning para detectar comportamientos anómalos</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Análisis de Comportamiento de Usuarios</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="userBehaviorAnalysis">
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="userBehaviorAnalysisStatus" class="encryption-status encryption-inactive">Desactivado</span>
                                </div>
                                <div class="security-description">Analizar patrones para detectar cuentas comprometidas</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB: AUDITORÍA -->
                <div class="security-content" id="auditoria-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-clipboard-check"></i> Registro de Auditoría
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Registro Completo de Actividad</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="fullActivityLogging" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="fullActivityLoggingStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Registrar todas las actividades del sistema y usuarios</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Retención de Logs</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="logRetention" min="30" max="1095" value="365">
                                    <span class="input-group-text">días</span>
                                </div>
                                <div class="security-description">Tiempo que se mantienen los registros de auditoría</div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-history"></i> Logs de Seguridad Recientes
                        </h3>

                        <div class="security-row" style="margin-bottom: 12px;">
                            <div class="security-item">
                                <input type="text" class="form-control" id="logSearchInput" placeholder="🔍 Buscar en logs...">
                            </div>
                            <div class="security-item">
                                <select class="form-select" id="logSeverityFilter">
                                    <option value="all">Todas las severidades</option>
                                    <option value="high">Alta</option>
                                    <option value="medium">Media</option>
                                    <option value="low">Baja</option>
                                </select>
                            </div>
                            <div class="security-item" style="display: flex; align-items: center;">
                                <button class="btn btn-outline btn-sm" id="clearLogsBtn" style="width: 100%;">
                                    <i class="fas fa-trash"></i> Limpiar Logs
                                </button>
                            </div>
                        </div>

                        <div class="security-logs" id="securityLogs"></div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-file-export"></i> Reportes de Auditoría
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Reportes Automáticos</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="autoReports" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoReportsStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Generar reportes de seguridad automáticamente</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Frecuencia de Reportes</label>
                                <select class="form-select" id="reportFrequency">
                                    <option value="daily">Diario</option>
                                    <option value="weekly" selected>Semanal</option>
                                    <option value="monthly">Mensual</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB: RESPUESTA A INCIDENTES -->
                <div class="security-content" id="respuesta-tab">
                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-first-aid"></i> Plan de Respuesta a Incidentes
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Respuesta Automática</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="autoIncidentResponse" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoIncidentResponseStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Ejecutar automáticamente acciones ante incidentes</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Umbral de Activación</label>
                                <select class="form-select" id="incidentThreshold">
                                    <option value="low">Bajo (respuesta temprana)</option>
                                    <option value="medium" selected>Medio</option>
                                    <option value="high">Alto (solo amenazas confirmadas)</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-user-slash"></i> Contención de Amenazas
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Aislamiento Automático</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="autoIsolation" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoIsolationStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Aislar automáticamente sistemas o usuarios comprometidos</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Bloqueo de Cuentas</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="autoAccountLock" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoAccountLockStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Bloquear automáticamente cuentas comprometidas</div>
                            </div>
                        </div>
                    </div>

                    <div class="security-group">
                        <h3 class="security-group-title">
                            <i class="fas fa-database"></i> Recuperación de Desastres
                        </h3>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Backups Automáticos</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="autoBackups" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="autoBackupsStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Realizar backups automáticos regulares</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">Frecuencia de Backup</label>
                                <select class="form-select" id="backupFrequency">
                                    <option value="hourly">Cada hora</option>
                                    <option value="daily" selected>Diario</option>
                                    <option value="weekly">Semanal</option>
                                </select>
                            </div>
                        </div>

                        <div class="security-row">
                            <div class="security-item">
                                <label class="security-label">Backups Cifrados</label>
                                <div class="toggle-with-status">
                                    <label class="toggle-switch">
                                        <input type="checkbox" id="encryptedBackups" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                    <span id="encryptedBackupsStatus" class="encryption-status encryption-active">Activado</span>
                                </div>
                                <div class="security-description">Cifrar todos los backups para proteger datos sensibles</div>
                            </div>
                            <div class="security-item">
                                <label class="security-label">RTO (Recovery Time Objective)</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="rto" min="1" max="72" value="4">
                                    <span class="input-group-text">horas</span>
                                </div>
                                <div class="security-description">Tiempo máximo aceptable para restaurar operaciones</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="security-actions">
                    <button type="button" class="btn btn-secondary" id="testSecurityBtn">
                        <i class="fas fa-vial"></i> Probar Configuración
                    </button>
                    <button type="button" class="btn btn-warning" id="resetSecurityBtn">
                        <i class="fas fa-undo"></i> Restablecer
                    </button>
                    <button type="button" class="btn btn-primary" id="saveSecurityBtn">
                        <i class="fas fa-save"></i> Guardar Configuración
                    </button>
                </div>
            </div>

        </main>
    </div>

    <!-- MOBILE NAV TOGGLE -->
    <button class="mobile-nav-toggle" id="mobileNavToggle" aria-label="Abrir menú">
        <i class="fas fa-bars"></i>
    </button>

    <div class="toast-container" id="toastContainer"></div>

    <script>
        // ============================================================
        // ✅ CORREGIDO: Funciones dinámicas para responsive
        // ============================================================
        function isMobileView() {
            return window.matchMedia('(max-width: 992px)').matches;
        }

        function isTouchDevice() {
            return ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
        }

        // ============================================================
        // ✅ CORREGIDO: Sidebar móvil
        // ============================================================
        function openMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.add('mobile-open');
            if (ov) ov.classList.add('active');
            document.body.style.overflow = 'hidden';
            if (isTouchDevice() && navigator.vibrate) navigator.vibrate(5);
        }

        function closeMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) {
                sb.classList.remove('mobile-open');
                sb.style.transform = '';
            }
            if (ov) ov.classList.remove('active');
            document.body.style.overflow = '';
        }

        function toggleMobileSidebar() {
            const sb = document.getElementById('sidebar');
            if (!sb) return;
            if (sb.classList.contains('mobile-open')) {
                closeMobileSidebar();
            } else {
                openMobileSidebar();
            }
        }

        let sidebarInitialized = false;
        function setupMobileSidebar() {
            if (sidebarInitialized) return;
            sidebarInitialized = true;

            const overlay = document.getElementById('sidebarOverlay');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.getElementById('mobileNavToggle');

            if (overlay) overlay.addEventListener('click', closeMobileSidebar);
            if (closeBtn) closeBtn.addEventListener('click', closeMobileSidebar);

            if (menuToggle) {
                menuToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    toggleMobileSidebar();
                });
            }

            // Swipe para cerrar
            if (sidebar) {
                let touchStartX = 0, touchCurrentX = 0;
                sidebar.addEventListener('touchstart', (e) => {
                    touchStartX = e.touches[0].clientX;
                }, { passive: true });
                sidebar.addEventListener('touchmove', (e) => {
                    touchCurrentX = e.touches[0].clientX;
                    const diff = touchCurrentX - touchStartX;
                    if (diff < 0 && diff > -100) sidebar.style.transform = `translateX(${diff}px)`;
                }, { passive: true });
                sidebar.addEventListener('touchend', () => {
                    const diff = touchCurrentX - touchStartX;
                    sidebar.style.transform = '';
                    if (diff < -60) closeMobileSidebar();
                    touchStartX = 0;
                    touchCurrentX = 0;
                });
            }
        }

        // ============================================================
        // RUTAS DEL SISTEMA
        // ============================================================
        const SYSTEM_ROUTES = {
            'admin': 'http://localhost/SmartStockAI/admin.php',
            'inventario': 'http://localhost/SmartStockAI/inventario1.php',
            'Reportes': 'http://localhost/SmartStockAI/Reportes.php',
            'Transacciones': 'http://localhost/SmartStockAI/Trassanciones.php',
            'clientes': 'http://localhost/SmartStockAI/clientes.php',
            'proveedores': 'http://localhost/SmartStockAI/proveedores.php',
            'usuarios': 'http://localhost/SmartStockAI/usuarios.php',
            'seguridad': 'http://localhost/SmartStockAI/seguridad.php',
            'perfil': 'http://localhost/SmartStockAI/perfil.php',
            'configuracion': 'http://localhost/SmartStockAI/configuracion.php'
        };

        function navigateTo(pageKey) {
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            const restrictedAdminPages = ['usuarios', 'seguridad', 'configuracion'];

            if (restrictedAdminPages.includes(pageKey) && currentUser.role !== 'admin') {
                alert('Acceso Denegado: Esta sección requiere privilegios de Administrador.');
                return;
            }

            const targetUrl = SYSTEM_ROUTES[pageKey];
            if (targetUrl) window.location.href = targetUrl;
        }

        function setupNavigationListeners() {
            document.querySelectorAll('[data-page]').forEach(element => {
                element.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (isMobileView()) closeMobileSidebar();
                    navigateTo(this.getAttribute('data-page'));
                });
            });
        }

        // ============================================================
        // CONFIGURACIÓN GLOBAL
        // ============================================================
        function hexToRgba(hex, alpha = 0.12) {
            if (!hex) return `rgba(58, 94, 199, ${alpha})`;
            let c = hex.replace('#', '');
            if (c.length === 3) c = c.split('').map(char => char + char).join('');
            const num = parseInt(c, 16);
            return `rgba(${(num >> 16) & 255}, ${(num >> 8) & 255}, ${num & 255}, ${alpha})`;
        }

        function applyGlobalConfig() {
            const settings = JSON.parse(localStorage.getItem('globalSettings')) || {};
            const legacySettings = JSON.parse(localStorage.getItem('appSettings')) || {};
            const savedTheme = settings.darkMode ? 'dark' : (localStorage.getItem('theme') || legacySettings.theme || 'light');
            const colors = {
                blue: '#3a5ec7', green: '#28a745', red: '#dc3545',
                purple: '#6f42c1', orange: '#fd7e14', teal: '#20c997'
            };
            const primaryColor = colors[settings.themeColor] || legacySettings.primaryColor || localStorage.getItem('primaryColor') || '#3a5ec7';

            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
                const themeBtn = document.querySelector('#themeToggleBtn i');
                if (themeBtn) themeBtn.className = 'fas fa-sun';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#0b0f19');
            } else {
                document.body.classList.remove('dark-mode');
                const themeBtn = document.querySelector('#themeToggleBtn i');
                if (themeBtn) themeBtn.className = 'fas fa-moon';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#3a5ec7');
            }

            const primaryLight = hexToRgba(primaryColor, 0.12);
            document.documentElement.style.setProperty('--primary', primaryColor);
            document.documentElement.style.setProperty('--primary-dark', primaryColor);
            document.documentElement.style.setProperty('--primary-light', primaryLight);

            document.querySelectorAll('.system-name-display').forEach(element => {
                element.textContent = settings.systemName || 'SmartStock AI';
            });

            if (settings.sidebarTheme === 'dark') {
                document.documentElement.style.setProperty('--sidebar-bg', 'linear-gradient(180deg, #111827 0%, #030712 100%)');
            } else if (settings.sidebarTheme === 'light') {
                document.documentElement.style.setProperty('--sidebar-bg', '#ffffff');
            } else {
                document.documentElement.style.setProperty('--sidebar-bg', `linear-gradient(180deg, ${primaryColor} 0%, ${primaryColor} 100%)`);
            }
        }

        // ============================================================
        // SESIÓN DE USUARIO
        // ============================================================
        function setupUserSession() {
            const user = JSON.parse(localStorage.getItem('currentUser') || '{"name":"","email":"","role":"","avatar":""}');
            document.getElementById('userName').textContent = user.name || 'Invitado';
            document.getElementById('userEmail').textContent = user.email || '';
            document.getElementById('userAvatar').textContent = user.avatar || (user.name ? user.name.charAt(0).toUpperCase() : '?');

            const roleBadge = document.getElementById('userRoleBadge');
            if (user.role === 'admin') {
                roleBadge.textContent = 'Administrador';
                roleBadge.className = 'user-badge badge-admin';
            } else if (user.role === 'employee') {
                roleBadge.textContent = 'Empleado';
                roleBadge.className = 'user-badge badge-employee';
            } else {
                roleBadge.textContent = '';
                roleBadge.className = 'user-badge';
            }
        }

        // ============================================================
        // SISTEMA DE NOTIFICACIONES
        // ============================================================
        function setupNotificationsEngine() {
            const btn = document.getElementById('notificationsBtn');
            const flyout = document.getElementById('notificationsFlyout');
            const markReadBtn = document.getElementById('markAllReadBtn');

            if (btn && flyout) {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    flyout.classList.toggle('active');
                });

                document.addEventListener('click', (e) => {
                    if (!flyout.contains(e.target) && !btn.contains(e.target)) {
                        flyout.classList.remove('active');
                    }
                });
            }

            if (markReadBtn) {
                markReadBtn.addEventListener('click', () => {
                    document.querySelectorAll('.flyout-item.unread').forEach(item => item.classList.remove('unread'));
                    document.getElementById('notifBadge').textContent = '0';
                });
            }
        }

        // ============================================================
        // GESTOR DE SEGURIDAD AVANZADA
        // ============================================================
        class AdvancedSecurityManager {
            constructor() {
                this.securityConfig = this.loadConfig();
                this.encryptionKey = this.getOrCreateEncryptionKey();
                this.securityLogs = this.loadLogs();
                this.threatIntelligence = new Set();
            }

            loadConfig() {
                try {
                    const stored = localStorage.getItem('securityConfig');
                    if (stored) {
                        try {
                            const parsed = JSON.parse(stored);
                            if (typeof parsed === 'string') {
                                const key = this.getOrCreateEncryptionKey();
                                const bytes = CryptoJS.AES.decrypt(parsed, key);
                                return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
                            }
                            return parsed;
                        } catch (e) {
                            return this.getDefaultConfig();
                        }
                    }
                } catch (e) {}
                return this.getDefaultConfig();
            }

            getOrCreateEncryptionKey() {
                let key = localStorage.getItem('securityEncryptionKey');
                if (!key) {
                    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
                    let raw = '';
                    for (let i = 0; i < 64; i++) raw += chars.charAt(Math.floor(Math.random() * chars.length));
                    key = CryptoJS.SHA256(raw).toString();
                    localStorage.setItem('securityEncryptionKey', key);
                }
                return key;
            }

            loadLogs() {
                try {
                    const stored = localStorage.getItem('securityLogs');
                    if (stored) return JSON.parse(stored);
                } catch (e) {}
                return [];
            }

            getDefaultConfig() {
                return {
                    twoFactorAuth: true, twoFactorMethod: 'app', biometricAuth: false,
                    sessionTimeout: 30, passwordStrength: 'high', passwordExpiration: 90,
                    passwordHistory: 5, maxLoginAttempts: 5, apiKeyRotation: true, rotationFrequency: 90,
                    leastPrivilege: true, separationOfDuties: true, allowedIPs: '', geoBlocking: false,
                    allowedCountries: ['MX'], accessTimeStart: '08:00', accessTimeEnd: '18:00',
                    accessDays: ['monday','tuesday','wednesday','thursday','friday'],
                    encryptionAlgorithm: 'aes-256', databaseEncryption: true, fieldLevelEncryption: false,
                    keyRotationDays: 90, tlsVersion: '1.3', forwardSecrecy: true, hstsEnabled: true,
                    dataMasking: true, dataTokenization: false,
                    intrusionDetection: true, alertThreshold: 'medium', intrusionPrevention: true,
                    ipsMode: 'prevention', aiAnomalyDetection: true, userBehaviorAnalysis: false,
                    fullActivityLogging: true, logRetention: 365, autoReports: true, reportFrequency: 'weekly',
                    autoIncidentResponse: true, incidentThreshold: 'medium', autoIsolation: true,
                    autoAccountLock: true, autoBackups: true, backupFrequency: 'daily',
                    encryptedBackups: true, rto: 4
                };
            }

            encryptData(data) {
                try {
                    return CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptionKey).toString();
                } catch (e) { return null; }
            }

            decryptData(encrypted) {
                try {
                    const bytes = CryptoJS.AES.decrypt(encrypted, this.encryptionKey);
                    return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
                } catch (e) { return null; }
            }

            getSecurityConfig() { return this.securityConfig; }

            updateSecurityConfig(newConfig) {
                this.securityConfig = { ...this.securityConfig, ...newConfig };
                const encrypted = this.encryptData(this.securityConfig);
                if (encrypted) localStorage.setItem('securityConfig', encrypted);
                this.logSecurityEvent('CONFIGURATION', 'Configuración de seguridad actualizada', 'Administrator', 'medium');
                return this.securityConfig;
            }

            resetSecurityConfig() {
                this.securityConfig = this.getDefaultConfig();
                const encrypted = this.encryptData(this.securityConfig);
                if (encrypted) localStorage.setItem('securityConfig', encrypted);
                this.logSecurityEvent('CONFIGURATION', 'Configuración restablecida', 'Administrator', 'high');
                return this.securityConfig;
            }

            logSecurityEvent(type, action, user, severity) {
                const entry = {
                    timestamp: new Date().toISOString(),
                    type, action, user, severity,
                    ip: '192.168.1.1',
                    userAgent: navigator.userAgent.substring(0, 80)
                };
                this.securityLogs.push(entry);
                if (this.securityLogs.length > 1000) this.securityLogs = this.securityLogs.slice(-1000);
                localStorage.setItem('securityLogs', JSON.stringify(this.securityLogs));
                if (typeof updateSecurityLogsUI === 'function') updateSecurityLogsUI();
                return entry;
            }

            getSecurityLogs(limit = 50) {
                return this.securityLogs.slice(-limit).reverse();
            }

            clearLogs() {
                this.securityLogs = [];
                localStorage.setItem('securityLogs', JSON.stringify([]));
            }

            testSecurityConfiguration() {
                const tests = [
                    { name: 'Cifrado de datos', result: this.testEncryption() },
                    { name: 'Política de contraseñas', result: this.testPasswordPolicy() },
                    { name: 'Configuración TLS', result: this.testTLSConfig() },
                    { name: 'Control de accesos', result: this.testAccessControl() },
                    { name: 'Detección de intrusiones', result: this.testIntrusionDetection() },
                    { name: 'Respuesta a incidentes', result: this.testIncidentResponse() },
                    { name: 'Backups cifrados', result: this.testBackups() }
                ];
                const passed = tests.filter(t => t.result).length;
                const score = Math.round((passed / tests.length) * 100);
                return { score, tests, passed, total: tests.length };
            }

            testEncryption() {
                try {
                    const test = { test: 'security_test' };
                    const enc = this.encryptData(test);
                    const dec = this.decryptData(enc);
                    return dec && dec.test === test.test;
                } catch (e) { return false; }
            }
            testPasswordPolicy() {
                return ['high','very-high'].includes(this.securityConfig.passwordStrength);
            }
            testTLSConfig() {
                return this.securityConfig.tlsVersion === '1.3' && this.securityConfig.forwardSecrecy;
            }
            testAccessControl() {
                return this.securityConfig.leastPrivilege && this.securityConfig.twoFactorAuth;
            }
            testIntrusionDetection() {
                return this.securityConfig.intrusionDetection && this.securityConfig.intrusionPrevention;
            }
            testIncidentResponse() {
                return this.securityConfig.autoIncidentResponse && this.securityConfig.autoIsolation;
            }
            testBackups() {
                return this.securityConfig.autoBackups && this.securityConfig.encryptedBackups;
            }
        }

        const securityManager = new AdvancedSecurityManager();

        // ============================================================
        // UI HELPERS
        // ============================================================
        function showToast(message, type = 'success') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            const icons = {
                success: 'fa-check-circle', error: 'fa-exclamation-circle',
                warning: 'fa-exclamation-triangle', info: 'fa-info-circle'
            };
            toast.innerHTML = `<i class="fas ${icons[type]}"></i><span>${message}</span>`;
            container.appendChild(toast);
            setTimeout(() => {
                toast.style.animation = 'slideOut 0.3s forwards';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // ============================================================
        // TOGGLE STATUS UPDATER
        // ============================================================
        function updateToggleStatus(checkboxId) {
            const checkbox = document.getElementById(checkboxId);
            const statusSpan = document.getElementById(checkboxId + 'Status');
            if (checkbox && statusSpan) {
                statusSpan.textContent = checkbox.checked ? 'Activado' : 'Desactivado';
                statusSpan.className = `encryption-status ${checkbox.checked ? 'encryption-active' : 'encryption-inactive'}`;
            }
        }

        function updateAllToggleStatuses(config) {
            const toggleKeys = [
                'twoFactorAuth','biometricAuth','apiKeyRotation','leastPrivilege','separationOfDuties',
                'geoBlocking','databaseEncryption','fieldLevelEncryption','forwardSecrecy','hstsEnabled',
                'dataMasking','dataTokenization','intrusionDetection','intrusionPrevention',
                'aiAnomalyDetection','userBehaviorAnalysis','fullActivityLogging','autoReports',
                'autoIncidentResponse','autoIsolation','autoAccountLock','autoBackups','encryptedBackups'
            ];
            toggleKeys.forEach(key => {
                const cb = document.getElementById(key);
                if (cb) cb.checked = !!config[key];
                updateToggleStatus(key);
            });
        }

        // ============================================================
        // LOAD CONFIG TO FORM
        // ============================================================
        function loadSecurityConfigToForm() {
            const config = securityManager.getSecurityConfig();
            updateAllToggleStatuses(config);

            const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
            const setChk = (id, val) => { const el = document.getElementById(id); if (el) el.checked = val; };

            setVal('twoFactorMethod', config.twoFactorMethod);
            setVal('sessionTimeout', config.sessionTimeout);
            setVal('passwordStrength', config.passwordStrength);
            setVal('passwordExpiration', config.passwordExpiration);
            setVal('passwordHistory', config.passwordHistory);
            setVal('maxLoginAttempts', config.maxLoginAttempts);
            setVal('rotationFrequency', config.rotationFrequency);

            setVal('allowedIPs', config.allowedIPs);
            setVal('accessTimeStart', config.accessTimeStart);
            setVal('accessTimeEnd', config.accessTimeEnd);

            const accessDays = config.accessDays || [];
            ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'].forEach(day => {
                const el = document.getElementById('access' + day.charAt(0).toUpperCase() + day.slice(1));
                if (el) el.checked = accessDays.includes(day);
            });

            const allowedCountries = config.allowedCountries || [];
            document.querySelectorAll('#allowedCountries option').forEach(opt => {
                opt.selected = allowedCountries.includes(opt.value);
            });

            setVal('encryptionAlgorithm', config.encryptionAlgorithm);
            setVal('keyRotationDays', config.keyRotationDays);
            setVal('tlsVersion', config.tlsVersion);
            setVal('alertThreshold', config.alertThreshold);
            setVal('ipsMode', config.ipsMode);
            setVal('logRetention', config.logRetention);
            setVal('reportFrequency', config.reportFrequency);
            setVal('incidentThreshold', config.incidentThreshold);
            setVal('backupFrequency', config.backupFrequency);
            setVal('rto', config.rto);

            updateSecurityLogsUI();
            updateSecurityScore();
        }

        // ============================================================
        // SAVE CONFIG FROM FORM
        // ============================================================
        function saveSecurityConfigFromForm() {
            const config = {};
            const getChk = id => document.getElementById(id)?.checked || false;
            const getVal = id => document.getElementById(id)?.value || '';
            const getNum = id => parseInt(document.getElementById(id)?.value) || 0;

            config.twoFactorAuth = getChk('twoFactorAuth');
            config.twoFactorMethod = getVal('twoFactorMethod');
            config.biometricAuth = getChk('biometricAuth');
            config.sessionTimeout = getNum('sessionTimeout');
            config.passwordStrength = getVal('passwordStrength');
            config.passwordExpiration = getNum('passwordExpiration');
            config.passwordHistory = getNum('passwordHistory');
            config.maxLoginAttempts = getNum('maxLoginAttempts');
            config.apiKeyRotation = getChk('apiKeyRotation');
            config.rotationFrequency = getNum('rotationFrequency');

            config.leastPrivilege = getChk('leastPrivilege');
            config.separationOfDuties = getChk('separationOfDuties');
            config.allowedIPs = getVal('allowedIPs');
            config.geoBlocking = getChk('geoBlocking');
            config.accessTimeStart = getVal('accessTimeStart');
            config.accessTimeEnd = getVal('accessTimeEnd');

            config.accessDays = [];
            ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'].forEach(day => {
                if (getChk('access' + day.charAt(0).toUpperCase() + day.slice(1))) config.accessDays.push(day);
            });

            config.allowedCountries = Array.from(document.getElementById('allowedCountries').selectedOptions).map(o => o.value);

            config.encryptionAlgorithm = getVal('encryptionAlgorithm');
            config.databaseEncryption = getChk('databaseEncryption');
            config.fieldLevelEncryption = getChk('fieldLevelEncryption');
            config.keyRotationDays = getNum('keyRotationDays');
            config.tlsVersion = getVal('tlsVersion');
            config.forwardSecrecy = getChk('forwardSecrecy');
            config.hstsEnabled = getChk('hstsEnabled');
            config.dataMasking = getChk('dataMasking');
            config.dataTokenization = getChk('dataTokenization');

            config.intrusionDetection = getChk('intrusionDetection');
            config.alertThreshold = getVal('alertThreshold');
            config.intrusionPrevention = getChk('intrusionPrevention');
            config.ipsMode = getVal('ipsMode');
            config.aiAnomalyDetection = getChk('aiAnomalyDetection');
            config.userBehaviorAnalysis = getChk('userBehaviorAnalysis');

            config.fullActivityLogging = getChk('fullActivityLogging');
            config.logRetention = getNum('logRetention');
            config.autoReports = getChk('autoReports');
            config.reportFrequency = getVal('reportFrequency');

            config.autoIncidentResponse = getChk('autoIncidentResponse');
            config.incidentThreshold = getVal('incidentThreshold');
            config.autoIsolation = getChk('autoIsolation');
            config.autoAccountLock = getChk('autoAccountLock');
            config.autoBackups = getChk('autoBackups');
            config.backupFrequency = getVal('backupFrequency');
            config.encryptedBackups = getChk('encryptedBackups');
            config.rto = getNum('rto');

            securityManager.updateSecurityConfig(config);
            showToast('Configuración de seguridad guardada correctamente', 'success');
            updateSecurityScore();
        }

        // ============================================================
        // SECURITY SCORE
        // ============================================================
        function updateSecurityScore() {
            const results = securityManager.testSecurityConfiguration();
            const scoreEl = document.getElementById('securityScore');
            if (scoreEl) scoreEl.textContent = `${results.score}%`;

            const badge = document.getElementById('securityLevelBadge');
            if (badge) {
                if (results.score >= 85) {
                    badge.className = 'security-level-badge level-high';
                    badge.innerHTML = '<i class="fas fa-shield-alt"></i> ALTA SEGURIDAD';
                } else if (results.score >= 60) {
                    badge.className = 'security-level-badge level-medium';
                    badge.innerHTML = '<i class="fas fa-shield-alt"></i> SEGURIDAD MEDIA';
                } else {
                    badge.className = 'security-level-badge level-low';
                    badge.innerHTML = '<i class="fas fa-shield-alt"></i> SEGURIDAD BAJA';
                }
            }

            const indicator = document.querySelector('.security-indicator');
            if (indicator) {
                indicator.className = 'security-indicator ' +
                    (results.score >= 85 ? 'indicator-good' : results.score >= 60 ? 'indicator-warning' : 'indicator-danger');
            }
        }

        // ============================================================
        // SECURITY LOGS UI
        // ============================================================
        function updateSecurityLogsUI() {
            const container = document.getElementById('securityLogs');
            if (!container) return;

            const search = (document.getElementById('logSearchInput')?.value || '').toLowerCase();
            const severityFilter = document.getElementById('logSeverityFilter')?.value || 'all';

            let logs = securityManager.getSecurityLogs(50);

            if (severityFilter !== 'all') {
                logs = logs.filter(l => l.severity === severityFilter);
            }
            if (search) {
                logs = logs.filter(l =>
                    (l.action || '').toLowerCase().includes(search) ||
                    (l.user || '').toLowerCase().includes(search) ||
                    (l.type || '').toLowerCase().includes(search)
                );
            }

            if (logs.length === 0) {
                container.innerHTML = '<div style="padding: 24px; text-align: center; color: var(--text-muted); font-size: 13px;">No hay registros de seguridad que coincidan</div>';
                return;
            }

            container.innerHTML = logs.map(log => {
                const time = new Date(log.timestamp).toLocaleString('es-ES');
                return `<div class="log-entry">
                    <div class="log-info">
                        <div class="log-action">${log.action}</div>
                        <div class="log-time"><span class="log-user">${log.user}</span> · ${time}</div>
                    </div>
                    <span class="log-severity severity-${log.severity}">${log.severity.toUpperCase()}</span>
                </div>`;
            }).join('');
        }

        // ============================================================
        // PASSWORD GENERATOR
        // ============================================================
        function generateSecurePassword(length = 16) {
            const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            const lower = 'abcdefghijklmnopqrstuvwxyz';
            const digits = '0123456789';
            const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
            const all = upper + lower + digits + symbols;

            let password = '';
            password += upper[Math.floor(Math.random() * upper.length)];
            password += lower[Math.floor(Math.random() * lower.length)];
            password += digits[Math.floor(Math.random() * digits.length)];
            password += symbols[Math.floor(Math.random() * symbols.length)];

            for (let i = password.length; i < length; i++) {
                password += all[Math.floor(Math.random() * all.length)];
            }

            return password.split('').sort(() => Math.random() - 0.5).join('');
        }

        function calculatePasswordStrength(password) {
            let strength = 0;
            if (password.length >= 8) strength++;
            if (password.length >= 12) strength++;
            if (password.length >= 16) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[a-z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            return Math.min(strength, 7);
        }

        // ============================================================
        // EXPORT SECURITY REPORT
        // ============================================================
        function exportSecurityReport() {
            const config = securityManager.getSecurityConfig();
            const results = securityManager.testSecurityConfiguration();
            const logs = securityManager.getSecurityLogs(100);

            const report = {
                generatedAt: new Date().toISOString(),
                systemName: 'SmartStock AI',
                securityScore: results.score,
                securityLevel: results.score >= 85 ? 'ALTA' : results.score >= 60 ? 'MEDIA' : 'BAJA',
                tests: results.tests,
                configuration: config,
                recentLogs: logs.slice(0, 50)
            };

            const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `reporte_seguridad_${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            URL.revokeObjectURL(url);

            securityManager.logSecurityEvent('REPORT', 'Reporte de seguridad exportado', 'Administrator', 'low');
            showToast('Reporte de seguridad exportado correctamente', 'success');
        }

        // ============================================================
        // INITIALIZATION
        // ============================================================
        document.addEventListener('DOMContentLoaded', function() {
            applyGlobalConfig();
            setupUserSession();
            setupNavigationListeners();
            setupNotificationsEngine();
            setupMobileSidebar();

            // Cerrar sidebar al navegar
            document.querySelectorAll('.sidebar-menu a').forEach(a => {
                a.addEventListener('click', () => {
                    if (isMobileView()) closeMobileSidebar();
                });
            });

            // Prevenir zoom doble-tap iOS
            if (isTouchDevice()) {
                let lastTouchEnd = 0;
                document.addEventListener('touchend', (e) => {
                    const now = Date.now();
                    if (now - lastTouchEnd <= 300) e.preventDefault();
                    lastTouchEnd = now;
                }, { passive: false });
            }

            // Detectar orientación
            window.addEventListener('orientationchange', () => {
                setTimeout(() => {
                    if (!isMobileView()) closeMobileSidebar();
                }, 150);
            });

            // Cargar configuración de seguridad
            loadSecurityConfigToForm();

            // Logout
            document.getElementById('logoutBtn').addEventListener('click', function() {
                if (confirm('¿Desea cerrar la sesión actual?')) {
                    localStorage.removeItem('currentUser');
                    window.location.href = 'http://localhost/SmartStockAI/login.php';
                }
            });

            // Theme toggle
            document.getElementById('themeToggleBtn').addEventListener('click', function() {
                const isDark = document.body.classList.toggle('dark-mode');
                const settings = JSON.parse(localStorage.getItem('globalSettings')) || {};
                settings.darkMode = isDark;
                localStorage.setItem('globalSettings', JSON.stringify(settings));
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
                this.querySelector('i').className = isDark ? 'fas fa-sun' : 'fas fa-moon';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', isDark ? '#0b0f19' : '#3a5ec7');
                if (isTouchDevice() && navigator.vibrate) navigator.vibrate(10);
            });

            // Security tabs
            document.querySelectorAll('.security-tab').forEach(tab => {
                tab.addEventListener('click', function() {
                    document.querySelectorAll('.security-tab').forEach(t => t.classList.remove('active'));
                    document.querySelectorAll('.security-content').forEach(c => c.classList.remove('active'));
                    this.classList.add('active');
                    const tabId = this.getAttribute('data-tab');
                    const content = document.getElementById(`${tabId}-tab`);
                    if (content) content.classList.add('active');
                });
            });

            // Toggle status updater
            document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    updateToggleStatus(this.id);
                });
            });

            // Save config
            document.getElementById('saveSecurityBtn').addEventListener('click', saveSecurityConfigFromForm);

            // Test config
            document.getElementById('testSecurityBtn').addEventListener('click', function() {
                const results = securityManager.testSecurityConfiguration();
                const type = results.score >= 80 ? 'success' : results.score >= 60 ? 'warning' : 'error';
                showToast(`Prueba completada: ${results.score}% de efectividad (${results.passed}/${results.total} pruebas)`, type);
                updateSecurityScore();
            });

            // Reset config
            document.getElementById('resetSecurityBtn').addEventListener('click', function() {
                if (confirm('¿Estás seguro de restablecer toda la configuración de seguridad a valores predeterminados?')) {
                    securityManager.resetSecurityConfig();
                    loadSecurityConfigToForm();
                    showToast('Configuración restablecida correctamente', 'success');
                }
            });

            // Force rotation
            const forceRotBtn = document.getElementById('forceRotationBtn');
            if (forceRotBtn) {
                forceRotBtn.addEventListener('click', function() {
                    if (confirm('¿Forzar rotación inmediata de claves API y certificados?')) {
                        securityManager.logSecurityEvent('ROTATION', 'Rotación manual de claves ejecutada', 'Administrator', 'medium');
                        showToast('Rotación de claves completada correctamente', 'success');
                        updateSecurityLogsUI();
                    }
                });
            }

            // Password generator
            const genPassBtn = document.getElementById('generatePasswordBtn');
            if (genPassBtn) {
                genPassBtn.addEventListener('click', function() {
                    const password = generateSecurePassword(16);
                    const input = document.getElementById('generatedPassword');
                    input.value = password;
                    const strength = calculatePasswordStrength(password);
                    const fill = document.getElementById('generatedPasswordStrength');
                    fill.className = 'password-strength-fill ' +
                        (strength <= 3 ? 'strength-weak' :
                         strength <= 5 ? 'strength-good' : 'strength-strong');
                });
            }

            const copyPassBtn = document.getElementById('copyPasswordBtn');
            if (copyPassBtn) {
                copyPassBtn.addEventListener('click', function() {
                    const input = document.getElementById('generatedPassword');
                    if (input.value) {
                        navigator.clipboard.writeText(input.value).then(() => {
                            showToast('Contraseña copiada al portapapeles', 'success');
                        });
                    } else {
                        showToast('Primero genera una contraseña', 'warning');
                    }
                });
            }

            // Export security report
            document.getElementById('exportSecurityBtn').addEventListener('click', exportSecurityReport);

            // Log filters
            const logSearch = document.getElementById('logSearchInput');
            const logSeverity = document.getElementById('logSeverityFilter');
            if (logSearch) logSearch.addEventListener('input', updateSecurityLogsUI);
            if (logSeverity) logSeverity.addEventListener('change', updateSecurityLogsUI);

            // Clear logs
            const clearLogsBtn = document.getElementById('clearLogsBtn');
            if (clearLogsBtn) {
                clearLogsBtn.addEventListener('click', function() {
                    if (confirm('¿Limpiar todos los registros de seguridad?')) {
                        securityManager.clearLogs();
                        updateSecurityLogsUI();
                        showToast('Registros de seguridad limpiados', 'success');
                    }
                });
            }

            // Simular logs iniciales
            setTimeout(() => {
                securityManager.logSecurityEvent('LOGIN_SUCCESS', 'Inicio de sesión exitoso', 'admin', 'low');
                securityManager.logSecurityEvent('CONFIGURATION', 'Política de contraseñas actualizada', 'admin', 'medium');
                securityManager.logSecurityEvent('BACKUP', 'Backup automático cifrado completado', 'System', 'low');
                securityManager.logSecurityEvent('THREAT', 'Intento de acceso no autorizado bloqueado', 'System', 'high');
                updateSecurityLogsUI();
            }, 500);

            // Escuchar cambios globales
            window.addEventListener('storage', function(e) {
                if (e.key === 'globalSettings' || e.key === 'theme' || e.key === 'primaryColor') {
                    applyGlobalConfig();
                }
            });
            window.addEventListener('focus', function() { applyGlobalConfig(); });

            // Escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    closeMobileSidebar();
                }
            });

            console.log('%c✅ SmartStock AI - Seguridad cargada', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (isMobileView() ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>