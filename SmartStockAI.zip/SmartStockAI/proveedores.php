<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Gestión de Proveedores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --bg: #f5f7fb;
            --card-bg: #ffffff;
            --text: #000000;
            --border-radius: 12px;
            --transition: all 0.3s ease;
            --sidebar-width: 270px;
            --sidebar-collapsed: 80px;
            --primary-rgb: 58, 94, 199;
            --font-main: 'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .dark-mode {
            --bg: #1a2235;
            --card-bg: #212b45;
            --text: #ffffff;
            --gray: #adb5bd;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: var(--font-main); }

        body {
            background: var(--bg);
            color: var(--text);
            transition: var(--transition);
            min-height: 100vh;
            overflow-x: hidden;
        }

        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary-dark); }

        .app-container { display: flex; min-height: 100vh; }

        /* ============================================
           SIDEBAR (estilo principal.php)
           ============================================ */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            color: #ffffff;
            height: 100vh;
            position: fixed;
            left: 0; top: 0;
            padding: 24px 16px;
            transition: var(--transition);
            z-index: 1050;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 25px rgba(0,0,0,0.15);
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 12px 24px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar .logo {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -0.5px;
            background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .sidebar .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            -webkit-text-fill-color: white;
        }

        .sidebar .sidebar-toggle {
            background: rgba(255,255,255,0.15);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            font-size: 12px;
        }

        .sidebar .sidebar-toggle:hover {
            background: rgba(255,255,255,0.25);
            transform: scale(1.1);
        }

        .sidebar-nav-container {
            flex: 1;
            overflow-y: auto;
            padding-right: 4px;
        }

        .menu-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #64748b;
            font-weight: 700;
            margin: 16px 12px 8px 12px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li { margin-bottom: 4px; }

        .sidebar-menu a {
            color: #94a3b8;
            text-decoration: none;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border-radius: 8px;
            transition: var(--transition);
            font-weight: 500;
            font-size: 14px;
            cursor: pointer;
            gap: 12px;
            border-left: none;
        }

        .sidebar-menu a:hover {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.06);
            transform: translateX(3px);
        }

        .sidebar-menu a.active {
            color: #ffffff;
            background: var(--primary);
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .sidebar-menu i {
            font-size: 18px;
            width: 22px;
            text-align: center;
        }

        .sidebar-footer {
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            margin-top: auto;
        }

        .logout-btn {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
            width: 100%;
            padding: 12px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: var(--transition);
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
        }

        .logout-btn:hover {
            background: var(--danger);
            color: white;
            border-color: var(--danger);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .sidebar.collapsed { width: var(--sidebar-collapsed); }
        .sidebar.collapsed .menu-label,
        .sidebar.collapsed .logo span,
        .sidebar.collapsed .sidebar-menu a span,
        .sidebar.collapsed .logout-btn span { display: none; }
        .sidebar.collapsed .sidebar-menu a { justify-content: center; padding: 12px; }
        .sidebar.collapsed .sidebar-menu i { margin: 0; }
        .sidebar.collapsed .sidebar-header { justify-content: center; }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: var(--transition);
            min-width: 0;
        }

        .main-content.expanded { margin-left: var(--sidebar-collapsed); }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray);
        }

        .page-title { font-size: 24px; font-weight: 600; color: var(--text); }

        .controls { display: flex; align-items: center; gap: 15px; }

        .theme-switcher, .notifications {
            background: var(--card-bg);
            width: 40px; height: 40px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            color: var(--text);
            position: relative;
        }

        .theme-switcher:hover, .notifications:hover { transform: translateY(-3px); }

        .filters-section {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .search-box { position: relative; }
        .search-box input { padding-left: 40px; color: var(--text); }
        .search-box input::placeholder { color: var(--gray); }
        .search-box i {
            position: absolute;
            left: 15px; top: 12px;
            color: var(--text);
        }

        .products-table {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid var(--gray);
        }

        .table-title { font-size: 18px; font-weight: 600; color: var(--text); }
        .table-responsive { overflow-x: auto; }

        table { width: 100%; border-collapse: collapse; }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            color: var(--text);
        }
        th { font-weight: 600; background: rgba(0,0,0,0.03); color: var(--text); }

        .action-btn {
            padding: 5px 10px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            transition: var(--transition);
            color: white;
        }

        .btn-edit { background: var(--primary); }
        .btn-delete { background: var(--danger); }
        .btn-view { background: var(--secondary); }
        .action-btn:hover { opacity: 0.8; transform: translateY(-2px); }

        .modal-content {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            color: var(--text) !important;
            background-color: var(--card-bg) !important;
        }

        .modal-header {
            background: var(--primary);
            color: white;
            border-top-left-radius: var(--border-radius);
            border-top-right-radius: var(--border-radius);
        }

        .btn-close-white { filter: invert(1); }

        .modal-body, .modal-body *:not(.badge):not(button) { color: var(--text) !important; }
        .modal-body p, .modal-body span, .modal-body strong { color: var(--text) !important; }

        .pagination { display: flex; justify-content: center; margin-top: 20px; }
        .page-item { margin: 0 5px; }
        .page-link {
            border-radius: 5px;
            border: 1px solid var(--gray);
            padding: 8px 15px;
            color: var(--text);
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
        }
        .page-link:hover, .page-item.active .page-link {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .notification-container { position: relative; }

        .notification-dropdown {
            position: absolute;
            top: 50px; right: 0;
            width: 300px;
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            z-index: 1000;
            display: none;
            color: var(--text);
        }

        .notification-dropdown.show { display: block; animation: slideDown 0.3s ease; }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .notification-header {
            padding: 15px;
            border-bottom: 1px solid var(--gray);
            font-weight: 600;
            color: var(--text);
        }

        .notification-list { max-height: 300px; overflow-y: auto; }

        .notification-item {
            padding: 10px 15px;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            color: var(--text);
            cursor: pointer;
            transition: var(--transition);
        }

        .notification-item:hover { background: rgba(var(--primary-rgb), 0.05); }
        .notification-item:last-child { border-bottom: none; }
        .notification-item.unread {
            background: rgba(var(--primary-rgb), 0.1);
            border-left: 3px solid var(--primary);
        }

        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .dashboard-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: var(--transition);
        }

        .dashboard-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }

        .card-icon {
            width: 50px; height: 50px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 24px;
            margin-bottom: 15px;
        }

        .card-icon.primary { background: rgba(var(--primary-rgb), 0.1); color: var(--primary); }
        .card-icon.success { background: rgba(40, 167, 69, 0.1); color: var(--secondary); }
        .card-icon.warning { background: rgba(255, 193, 7, 0.1); color: var(--warning); }
        .card-icon.danger { background: rgba(220, 53, 69, 0.1); color: var(--danger); }
        .card-icon.info { background: rgba(23, 162, 184, 0.1); color: var(--info); }

        .card-value { font-size: 24px; font-weight: 700; margin-bottom: 5px; }
        .card-label { color: var(--gray); font-size: 14px; }

        .supplier-status {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .status-active { background-color: var(--secondary); color: white; }
        .status-inactive { background-color: var(--gray); color: white; }
        .status-pending { background-color: var(--warning); color: white; }

        .chart-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .chart-title { font-size: 18px; font-weight: 600; margin-bottom: 15px; color: var(--text); }

        .rating-stars { color: #ffc107; font-size: 14px; }

        .evaluation-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
            transition: var(--transition);
        }

        .evaluation-card:hover { transform: translateX(5px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }

        .evaluation-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .evaluation-title { font-weight: 600; color: var(--text); }
        .evaluation-date { color: var(--gray); font-size: 12px; }
        .evaluation-comment { color: var(--text); margin-top: 10px; font-style: italic; }

        .order-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
            transition: var(--transition);
        }

        .order-card:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }

        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .order-title { font-weight: 600; color: var(--text); }

        .order-status {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-pending { background-color: var(--warning); color: white; }
        .status-approved { background-color: var(--info); color: white; }
        .status-shipped { background-color: var(--primary); color: white; }
        .status-delivered { background-color: var(--secondary); color: white; }
        .status-cancelled { background-color: var(--danger); color: white; }

        .order-details { display: flex; justify-content: space-between; margin-top: 10px; }
        .order-info { color: var(--text); }
        .order-amount { font-weight: 600; color: var(--text); }

        .evaluation-panel {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .criteria-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .criteria-name { font-weight: 500; color: var(--text); }
        .criteria-rating { display: flex; gap: 5px; }

        .star {
            color: #ddd;
            cursor: pointer;
            font-size: 18px;
            transition: var(--transition);
        }

        .star.active { color: #ffc107; }
        .star:hover { color: #ffc107; transform: scale(1.2); }

        .communication-panel {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .message-list {
            max-height: 300px;
            overflow-y: auto;
            margin-bottom: 15px;
        }

        .message-item {
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 10px;
            background: rgba(var(--primary-rgb), 0.05);
        }

        .message-header { display: flex; justify-content: space-between; margin-bottom: 5px; }
        .message-sender { font-weight: 600; color: var(--text); }
        .message-date { color: var(--gray); font-size: 12px; }
        .message-content { color: var(--text); }
        .message-input { display: flex; gap: 10px; }
        .message-input textarea { flex: 1; resize: none; }

        .documents-panel {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .document-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
        }

        .document-item {
            background: rgba(var(--primary-rgb), 0.05);
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            transition: var(--transition);
            cursor: pointer;
        }

        .document-item:hover { transform: translateY(-3px); box-shadow: 0 5px 10px rgba(0,0,0,0.1); }
        .document-icon { font-size: 30px; color: var(--primary); margin-bottom: 10px; }
        .document-name { font-weight: 500; color: var(--text); margin-bottom: 5px; }
        .document-supplier { color: var(--gray); font-size: 12px; margin-bottom: 5px; }
        .document-date { color: var(--gray); font-size: 12px; }

        .custom-tabs {
            display: flex;
            border-bottom: 1px solid var(--gray);
            margin-bottom: 20px;
            overflow-x: auto;
            padding-bottom: 5px;
        }

        .custom-tab {
            padding: 10px 20px;
            cursor: pointer;
            transition: var(--transition);
            border-bottom: 3px solid transparent;
            color: var(--text);
            white-space: nowrap;
        }

        .custom-tab.active {
            border-bottom-color: var(--primary);
            color: var(--primary);
            font-weight: 600;
        }

        .custom-tab:hover { background: rgba(var(--primary-rgb), 0.05); }

        .tab-content { display: none; }
        .tab-content.active { display: block; animation: fadeIn 0.3s ease; }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .alert-card {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
            border-left: 4px solid var(--danger);
            transition: var(--transition);
        }

        .alert-card:hover { transform: translateX(5px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .alert-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .alert-title { font-weight: 600; color: var(--text); }
        .alert-priority {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            background-color: var(--danger);
            color: white;
        }
        .alert-content { color: var(--text); }

        .performance-panel {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .performance-metrics {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .metric-card {
            background: rgba(var(--primary-rgb), 0.05);
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            transition: var(--transition);
        }

        .metric-card:hover { transform: translateY(-3px); background: rgba(var(--primary-rgb), 0.1); }
        .metric-value { font-size: 24px; font-weight: 700; margin-bottom: 5px; color: var(--primary); }
        .metric-label { color: var(--gray); font-size: 12px; }

        .contacts-panel {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .contact-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
        }

        .contact-item {
            background: rgba(var(--primary-rgb), 0.05);
            border-radius: 8px;
            padding: 15px;
            transition: var(--transition);
        }

        .contact-item:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .contact-name { font-weight: 600; color: var(--text); margin-bottom: 5px; }
        .contact-role { color: var(--gray); font-size: 14px; margin-bottom: 10px; }
        .contact-info { color: var(--text); font-size: 14px; }

        .transactions-panel {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .transaction-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            transition: var(--transition);
        }

        .transaction-item:hover { background: rgba(var(--primary-rgb), 0.02); padding-left: 10px; }
        .transaction-info { color: var(--text); }
        .transaction-amount { font-weight: 600; color: var(--text); }
        .transaction-positive { color: var(--secondary); }
        .transaction-negative { color: var(--danger); }

        .reminders-panel {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .reminder-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            gap: 15px;
        }

        .reminder-info { color: var(--text); flex: 1; }
        .reminder-date { color: var(--gray); font-size: 12px; white-space: nowrap; }
        .reminder-actions { display: flex; gap: 5px; }

        .toast-container { position: fixed; top: 20px; right: 20px; z-index: 1100; }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s forwards;
            color: var(--text);
            min-width: 300px;
        }

        .toast.success { border-left: 4px solid var(--secondary); }
        .toast.error { border-left: 4px solid var(--danger); }
        .toast.warning { border-left: 4px solid var(--warning); }
        .toast.info { border-left: 4px solid var(--info); }
        .toast i { margin-right: 10px; font-size: 20px; }
        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        .toast.info i { color: var(--info); }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }

        .badge.bg-success { background-color: var(--secondary); }
        .badge.bg-warning { background-color: var(--warning); }
        .badge.bg-danger { background-color: var(--danger); }
        .badge.bg-info { background-color: var(--info); }
        .badge.bg-primary { background-color: var(--primary); }

        .action-buttons { display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 600;
        }

        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(var(--primary-rgb), 0.3); }
        .btn-secondary { background: var(--gray); color: white; }
        .btn-secondary:hover { background: #5a6268; transform: translateY(-2px); }
        .btn-success { background: var(--secondary); color: white; }
        .btn-success:hover { background: #218838; transform: translateY(-2px); }
        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: #c82333; transform: translateY(-2px); }
        .btn-warning { background: var(--warning); color: #000; }
        .btn-warning:hover { background: #e0a800; transform: translateY(-2px); }
        .btn-info { background: var(--info); color: white; }
        .btn-info:hover { background: #138496; transform: translateY(-2px); }

        .form-control, .form-select {
            background: var(--bg);
            border: 1px solid var(--gray);
            color: var(--text);
            border-radius: 8px;
            padding: 10px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(var(--primary-rgb), 0.25);
            outline: none;
        }

        .form-label { color: var(--text); margin-bottom: 5px; font-weight: 500; }

        [data-tooltip] { position: relative; cursor: help; }

        [data-tooltip]:before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 5px 10px;
            background: var(--dark);
            color: white;
            border-radius: 4px;
            font-size: 12px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 1000;
        }

        [data-tooltip]:hover:before {
            opacity: 1;
            visibility: visible;
            bottom: 120%;
        }

        .empty-state { text-align: center; padding: 40px; color: var(--gray); }
        .empty-state i { font-size: 48px; margin-bottom: 15px; }

        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 50px; height: 50px;
            border-radius: 50%;
            position: fixed;
            bottom: 20px; left: 20px;
            z-index: 1001;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            cursor: pointer;
            transition: var(--transition);
            align-items: center;
            justify-content: center;
        }

        .menu-toggle:hover { transform: scale(1.1); background: var(--primary-dark); }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .menu-toggle { display: flex; }
        }

        @media (max-width: 768px) {
            .header { flex-direction: column; align-items: flex-start; }
            .controls { margin-top: 15px; width: 100%; justify-content: space-between; }
            .action-buttons { flex-direction: column; }
            .action-buttons .btn { width: 100%; }
            .dashboard-cards { grid-template-columns: 1fr; }
            .custom-tabs { flex-wrap: nowrap; overflow-x: auto; }
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-brain"></i></div>
                    <span class="system-name-display">SmartStock AI</span>
                </div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>

            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/principal.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes-stacked"></i> <span>Inventario</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-right-left"></i> <span>Transacciones</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-column"></i> <span>Reportes</span></a></li>
                </ul>

                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/clientes.php"><i class="fas fa-address-book"></i> <span>Clientes</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/proveedores.php" class="active"><i class="fas fa-truck-field"></i> <span>Proveedores</span></a></li>
                </ul>

                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users-gear"></i> <span>Usuarios</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-halved"></i> <span>Seguridad</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-circle-user"></i> <span>Mi Perfil</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-sliders"></i> <span>Configuración</span></a></li>
                </ul>
            </div>

            <div class="sidebar-footer">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    <span>Cerrar Sesión</span>
                </button>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="main-content" id="mainContent">
            <div id="suppliersView">
                <div class="header">
                    <h1 class="page-title">
                        <i class="fas fa-truck me-2"></i>
                        Gestión de Proveedores
                    </h1>

                    <div class="controls">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" class="form-control" id="globalSearch" placeholder="Buscar proveedores...">
                        </div>
                        <div class="theme-switcher" id="themeToggle">
                            <i class="fas fa-moon"></i>
                        </div>
                        <div class="notification-container">
                            <div class="notifications" id="notificationBtn">
                                <i class="fas fa-bell"></i>
                                <span class="badge bg-danger" id="notificationCount" style="position:absolute;top:-5px;right:-5px;font-size:10px;">0</span>
                            </div>
                            <div class="notification-dropdown" id="notificationDropdown">
                                <div class="notification-header">
                                    <i class="fas fa-bell me-2"></i>
                                    Notificaciones
                                </div>
                                <div class="notification-list" id="notificationList">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="dashboard-cards">
                    <div class="dashboard-card">
                        <div class="card-icon primary">
                            <i class="fas fa-truck"></i>
                        </div>
                        <div class="card-value" id="totalSuppliers">0</div>
                        <div class="card-label">Total Proveedores</div>
                    </div>
                    <div class="dashboard-card">
                        <div class="card-icon success">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="card-value" id="activeSuppliers">0</div>
                        <div class="card-label">Proveedores Activos</div>
                    </div>
                    <div class="dashboard-card">
                        <div class="card-icon info">
                            <i class="fas fa-boxes"></i>
                        </div>
                        <div class="card-value" id="totalProducts">0</div>
                        <div class="card-label">Productos Totales</div>
                    </div>
                    <div class="dashboard-card">
                        <div class="card-icon warning">
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="card-value" id="avgRating">0.0</div>
                        <div class="card-label">Calificación Promedio</div>
                    </div>
                </div>

                <div class="action-buttons">
                    <button class="btn btn-primary" id="newSupplierBtn">
                        <i class="fas fa-plus me-2"></i>Nuevo Proveedor
                    </button>
                    <button class="btn btn-success" id="importSuppliersBtn">
                        <i class="fas fa-file-import me-2"></i>Importar CSV
                    </button>
                    <button class="btn btn-info" id="exportPdfBtn">
                        <i class="fas fa-file-pdf me-2"></i>Exportar PDF
                    </button>
                    <button class="btn btn-warning" id="exportCsvBtn">
                        <i class="fas fa-file-csv me-2"></i>Exportar CSV
                    </button>
                    <button class="btn btn-secondary" id="exportExcelBtn">
                        <i class="fas fa-file-excel me-2"></i>Exportar Excel
                    </button>
                </div>

                <div class="custom-tabs">
                    <div class="custom-tab active" data-tab="suppliers">Lista de Proveedores</div>
                    <div class="custom-tab" data-tab="analytics">Análisis y Reportes</div>
                    <div class="custom-tab" data-tab="evaluation">Evaluación</div>
                    <div class="custom-tab" data-tab="orders">Pedidos</div>
                    <div class="custom-tab" data-tab="documents">Documentos</div>
                    <div class="custom-tab" data-tab="communication">Comunicación</div>
                    <div class="custom-tab" data-tab="transactions">Transacciones</div>
                    <div class="custom-tab" data-tab="reminders">Recordatorios</div>
                </div>

                <div class="tab-content active" id="suppliers-tab">
                    <div class="filters-section">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="search-box">
                                    <i class="fas fa-search"></i>
                                    <input type="text" class="form-control" id="searchSupplierInput" placeholder="Buscar proveedores...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="statusFilter">
                                    <option value="all">Estado: Todos</option>
                                    <option value="active">Activos</option>
                                    <option value="inactive">Inactivos</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" id="categoryFilter">
                                    <option value="all">Categoría: Todas</option>
                                    <option value="Electrónicos">Electrónicos</option>
                                    <option value="Ropa">Ropa</option>
                                    <option value="Hogar">Hogar</option>
                                    <option value="Deportes">Deportes</option>
                                    <option value="Alimentos">Alimentos</option>
                                    <option value="Otros">Otros</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-secondary w-100" id="clearFilters">
                                    <i class="fas fa-times me-2"></i>Limpiar
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="products-table">
                        <div class="table-header">
                            <h3 class="table-title">
                                <i class="fas fa-list me-2"></i>
                                Lista de Proveedores
                            </h3>
                            <span id="supplierCount">Mostrando 0 de 0 proveedores</span>
                        </div>

                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nombre</th>
                                        <th>Contacto</th>
                                        <th>Teléfono</th>
                                        <th>Email</th>
                                        <th>Productos</th>
                                        <th>Calificación</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="suppliersTableBody">
                                </tbody>
                            </table>
                        </div>

                        <nav class="pagination" id="paginationContainer">
                            <ul class="pagination" id="pagination">
                            </ul>
                        </nav>
                    </div>
                </div>

                <div class="tab-content" id="analytics-tab">
                    <div class="performance-panel">
                        <h3 class="chart-title">
                            <i class="fas fa-chart-line me-2"></i>
                            Métricas de Rendimiento
                        </h3>
                        <div class="performance-metrics">
                            <div class="metric-card">
                                <div class="metric-value" id="avgDeliveryTime">0</div>
                                <div class="metric-label">Tiempo Entrega (días)</div>
                            </div>
                            <div class="metric-card">
                                <div class="metric-value" id="fulfillmentRate">0%</div>
                                <div class="metric-label">Tasa de Cumplimiento</div>
                            </div>
                            <div class="metric-card">
                                <div class="metric-value" id="qualityScore">0</div>
                                <div class="metric-label">Calidad Promedio</div>
                            </div>
                            <div class="metric-card">
                                <div class="metric-value" id="responseTime">0h</div>
                                <div class="metric-label">Tiempo de Respuesta</div>
                            </div>
                        </div>
                    </div>

                    <div class="chart-card">
                        <h3 class="chart-title">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Alertas de Stock Bajo
                        </h3>
                        <div id="lowStockAlerts">
                        </div>
                    </div>
                </div>

                <div class="tab-content" id="evaluation-tab">
                    <div class="evaluation-panel">
                        <h3 class="chart-title">
                            <i class="fas fa-star me-2"></i>
                            Evaluación de Proveedores
                        </h3>
                        <div class="mb-3">
                            <label for="evaluationSupplier" class="form-label">Seleccionar Proveedor</label>
                            <select class="form-select" id="evaluationSupplier">
                                <option value="">Seleccionar proveedor...</option>
                            </select>
                        </div>

                        <div id="evaluationForm" style="display: none;">
                            <div class="criteria-row">
                                <div class="criteria-name">Calidad del Producto</div>
                                <div class="criteria-rating" id="qualityRating">
                                    <span class="star" data-value="1">★</span>
                                    <span class="star" data-value="2">★</span>
                                    <span class="star" data-value="3">★</span>
                                    <span class="star" data-value="4">★</span>
                                    <span class="star" data-value="5">★</span>
                                </div>
                            </div>
                            <div class="criteria-row">
                                <div class="criteria-name">Tiempo de Entrega</div>
                                <div class="criteria-rating" id="deliveryRating">
                                    <span class="star" data-value="1">★</span>
                                    <span class="star" data-value="2">★</span>
                                    <span class="star" data-value="3">★</span>
                                    <span class="star" data-value="4">★</span>
                                    <span class="star" data-value="5">★</span>
                                </div>
                            </div>
                            <div class="criteria-row">
                                <div class="criteria-name">Servicio al Cliente</div>
                                <div class="criteria-rating" id="serviceRating">
                                    <span class="star" data-value="1">★</span>
                                    <span class="star" data-value="2">★</span>
                                    <span class="star" data-value="3">★</span>
                                    <span class="star" data-value="4">★</span>
                                    <span class="star" data-value="5">★</span>
                                </div>
                            </div>
                            <div class="criteria-row">
                                <div class="criteria-name">Precio Competitivo</div>
                                <div class="criteria-rating" id="priceRating">
                                    <span class="star" data-value="1">★</span>
                                    <span class="star" data-value="2">★</span>
                                    <span class="star" data-value="3">★</span>
                                    <span class="star" data-value="4">★</span>
                                    <span class="star" data-value="5">★</span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="evaluationComment" class="form-label">Comentarios</label>
                                <textarea class="form-control" id="evaluationComment" rows="3" placeholder="Comentarios adicionales sobre el proveedor..."></textarea>
                            </div>
                            <button class="btn btn-primary" id="saveEvaluation">
                                <i class="fas fa-save me-2"></i>
                                Guardar Evaluación
                            </button>
                        </div>
                    </div>

                    <div class="chart-card">
                        <h3 class="chart-title">
                            <i class="fas fa-history me-2"></i>
                            Historial de Evaluaciones
                        </h3>
                        <div id="evaluationHistory">
                        </div>
                    </div>
                </div>

                <div class="tab-content" id="orders-tab">
                    <div class="action-buttons">
                        <button class="btn btn-primary" id="newOrderBtn">
                            <i class="fas fa-plus me-2"></i>Nuevo Pedido
                        </button>
                    </div>

                    <div class="chart-card">
                        <h3 class="chart-title">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Pedidos Recientes
                        </h3>
                        <div id="ordersList">
                        </div>
                    </div>
                </div>

                <div class="tab-content" id="documents-tab">
                    <div class="action-buttons">
                        <button class="btn btn-primary" id="uploadDocumentBtn">
                            <i class="fas fa-upload me-2"></i>Subir Documento
                        </button>
                    </div>

                    <div class="documents-panel">
                        <h3 class="chart-title">
                            <i class="fas fa-file me-2"></i>
                            Documentos de Proveedores
                        </h3>
                        <div class="document-list" id="documentsList">
                        </div>
                    </div>
                </div>

                <div class="tab-content" id="communication-tab">
                    <div class="communication-panel">
                        <h3 class="chart-title">
                            <i class="fas fa-comments me-2"></i>
                            Comunicación con Proveedores
                        </h3>
                        <div class="mb-3">
                            <label for="communicationSupplier" class="form-label">Seleccionar Proveedor</label>
                            <select class="form-select" id="communicationSupplier">
                                <option value="">Seleccionar proveedor...</option>
                            </select>
                        </div>

                        <div id="communicationArea" style="display: none;">
                            <div class="message-list" id="messageList">
                            </div>
                            <div class="message-input">
                                <textarea class="form-control" id="messageText" rows="3" placeholder="Escribe tu mensaje..."></textarea>
                                <button class="btn btn-primary" id="sendMessageBtn">
                                    <i class="fas fa-paper-plane me-2"></i>
                                    Enviar
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="contacts-panel">
                        <h3 class="chart-title">
                            <i class="fas fa-address-book me-2"></i>
                            Contactos de Proveedores
                        </h3>
                        <div class="contact-list" id="contactsList">
                        </div>
                    </div>
                </div>

                <div class="tab-content" id="transactions-tab">
                    <div class="transactions-panel">
                        <h3 class="chart-title">
                            <i class="fas fa-exchange-alt me-2"></i>
                            Historial de Transacciones
                        </h3>
                        <div id="transactionsList">
                        </div>
                    </div>
                </div>

                <div class="tab-content" id="reminders-tab">
                    <div class="action-buttons">
                        <button class="btn btn-primary" id="newReminderBtn">
                            <i class="fas fa-plus me-2"></i>Nuevo Recordatorio
                        </button>
                    </div>
                    <div class="reminders-panel">
                        <h3 class="chart-title">
                            <i class="fas fa-clock me-2"></i>
                            Recordatorios y Alertas
                        </h3>
                        <div id="remindersList">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Proveedor -->
    <div class="modal fade" id="supplierModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="supplierModalTitle">Agregar Nuevo Proveedor</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="supplierForm">
                        <input type="hidden" id="supplierId">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplierName" class="form-label">Nombre del Proveedor *</label>
                                    <input type="text" class="form-control" id="supplierName" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplierContact" class="form-label">Persona de Contacto *</label>
                                    <input type="text" class="form-control" id="supplierContact" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplierPhone" class="form-label">Teléfono *</label>
                                    <input type="text" class="form-control" id="supplierPhone" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplierEmail" class="form-label">Email *</label>
                                    <input type="email" class="form-control" id="supplierEmail" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplierWebsite" class="form-label">Sitio Web</label>
                                    <input type="url" class="form-control" id="supplierWebsite" placeholder="https://...">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplierStatus" class="form-label">Estado</label>
                                    <select class="form-select" id="supplierStatus" required>
                                        <option value="active">Activo</option>
                                        <option value="inactive">Inactivo</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="supplierAddress" class="form-label">Dirección *</label>
                            <textarea class="form-control" id="supplierAddress" rows="3" required></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="supplierNotes" class="form-label">Notas Adicionales</label>
                            <textarea class="form-control" id="supplierNotes" rows="2" placeholder="Información adicional sobre el proveedor..."></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplierRating" class="form-label">Calificación Inicial</label>
                                    <select class="form-select" id="supplierRating">
                                        <option value="5">★★★★★ Excelente</option>
                                        <option value="4">★★★★ Muy Bueno</option>
                                        <option value="3">★★★ Bueno</option>
                                        <option value="2">★★ Regular</option>
                                        <option value="1">★ Bajo</option>
                                        <option value="0" selected>Sin calificar</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="supplierCategory" class="form-label">Categoría</label>
                                    <select class="form-select" id="supplierCategory">
                                        <option value="">Seleccionar categoría</option>
                                        <option value="Electrónicos">Electrónicos</option>
                                        <option value="Ropa">Ropa</option>
                                        <option value="Hogar">Hogar</option>
                                        <option value="Deportes">Deportes</option>
                                        <option value="Alimentos">Alimentos</option>
                                        <option value="Otros">Otros</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveSupplier">
                        <i class="fas fa-save me-2"></i>Guardar Proveedor
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Ver Proveedor -->
    <div class="modal fade" id="viewSupplierModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-info-circle me-2"></i>
                        Detalles del Proveedor
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>ID:</strong> <span id="viewSupplierId"></span></p>
                            <p><strong>Nombre:</strong> <span id="viewSupplierName"></span></p>
                            <p><strong>Contacto:</strong> <span id="viewSupplierContact"></span></p>
                            <p><strong>Teléfono:</strong> <span id="viewSupplierPhone"></span></p>
                            <p><strong>Email:</strong> <span id="viewSupplierEmail"></span></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Sitio Web:</strong> <span id="viewSupplierWebsite">-</span></p>
                            <p><strong>Estado:</strong> <span id="viewSupplierStatus" class="supplier-status"></span></p>
                            <p><strong>Calificación:</strong> <span id="viewSupplierRating"></span></p>
                            <p><strong>Categoría:</strong> <span id="viewSupplierCategory">-</span></p>
                            <p><strong>Productos:</strong> <span id="viewSupplierProducts">0</span></p>
                        </div>
                    </div>
                    <div class="mt-3">
                        <strong>Dirección:</strong>
                        <p id="viewSupplierAddress" class="mt-1"></p>
                    </div>
                    <div class="mt-3" id="viewSupplierNotesSection">
                        <strong>Notas:</strong>
                        <p id="viewSupplierNotes" class="mt-1">-</p>
                    </div>
                    <div class="mt-4">
                        <h6>
                            <i class="fas fa-box me-2"></i>
                            Productos de este Proveedor
                        </h6>
                        <div id="supplierProductsList" class="mt-2">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Pedido -->
    <div class="modal fade" id="orderModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-shopping-cart me-2"></i>
                        Nuevo Pedido
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="orderForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="orderSupplier" class="form-label">Proveedor *</label>
                                    <select class="form-select" id="orderSupplier" required>
                                        <option value="">Seleccionar proveedor...</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="orderDate" class="form-label">Fecha de Pedido *</label>
                                    <input type="date" class="form-control" id="orderDate" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="deliveryDate" class="form-label">Fecha de Entrega Esperada</label>
                                    <input type="date" class="form-control" id="deliveryDate">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="orderStatus" class="form-label">Estado</label>
                                    <select class="form-select" id="orderStatus">
                                        <option value="pending">Pendiente</option>
                                        <option value="approved">Aprobado</option>
                                        <option value="shipped">Enviado</option>
                                        <option value="delivered">Entregado</option>
                                        <option value="cancelled">Cancelado</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Productos</label>
                            <div id="orderProductsList">
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addProductBtn">
                                <i class="fas fa-plus me-1"></i>Agregar Producto
                            </button>
                        </div>
                        <div class="mb-3">
                            <label for="orderNotes" class="form-label">Notas</label>
                            <textarea class="form-control" id="orderNotes" rows="3" placeholder="Notas adicionales sobre el pedido..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveOrder">
                        <i class="fas fa-save me-2"></i>Guardar Pedido
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Documento -->
    <div class="modal fade" id="documentModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-upload me-2"></i>
                        Subir Documento
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="documentForm">
                        <div class="mb-3">
                            <label for="documentSupplier" class="form-label">Proveedor *</label>
                            <select class="form-select" id="documentSupplier" required>
                                <option value="">Seleccionar proveedor...</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="documentName" class="form-label">Nombre del Documento *</label>
                            <input type="text" class="form-control" id="documentName" required>
                        </div>
                        <div class="mb-3">
                            <label for="documentType" class="form-label">Tipo de Documento</label>
                            <select class="form-select" id="documentType">
                                <option value="pdf">PDF</option>
                                <option value="xlsx">Excel</option>
                                <option value="docx">Word</option>
                                <option value="jpg">Imagen</option>
                                <option value="txt">Texto</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="documentFile" class="form-label">Archivo *</label>
                            <input type="file" class="form-control" id="documentFile" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="uploadDocument">
                        <i class="fas fa-upload me-2"></i>Subir
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Recordatorio -->
    <div class="modal fade" id="reminderModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-clock me-2"></i>
                        Nuevo Recordatorio
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="reminderForm">
                        <div class="mb-3">
                            <label for="reminderSupplier" class="form-label">Proveedor *</label>
                            <select class="form-select" id="reminderSupplier" required>
                                <option value="">Seleccionar proveedor...</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="reminderTitle" class="form-label">Título *</label>
                            <input type="text" class="form-control" id="reminderTitle" required>
                        </div>
                        <div class="mb-3">
                            <label for="reminderDate" class="form-label">Fecha *</label>
                            <input type="date" class="form-control" id="reminderDate" required>
                        </div>
                        <div class="mb-3">
                            <label for="reminderDescription" class="form-label">Descripción</label>
                            <textarea class="form-control" id="reminderDescription" rows="3"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveReminder">
                        <i class="fas fa-save me-2"></i>Guardar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        class SupplierManager {
            constructor() {
                this.suppliers = JSON.parse(localStorage.getItem('suppliers')) || [];
                this.products = JSON.parse(localStorage.getItem('products')) || [];
                this.orders = JSON.parse(localStorage.getItem('supplierOrders')) || [];
                this.evaluations = JSON.parse(localStorage.getItem('supplierEvaluations')) || [];
                this.documents = JSON.parse(localStorage.getItem('supplierDocuments')) || [];
                this.messages = JSON.parse(localStorage.getItem('supplierMessages')) || [];
                this.contacts = JSON.parse(localStorage.getItem('supplierContacts')) || [];
                this.transactions = JSON.parse(localStorage.getItem('supplierTransactions')) || [];
                this.reminders = JSON.parse(localStorage.getItem('supplierReminders')) || [];
                this.currentPage = 1;
                this.itemsPerPage = 5;
                this.filteredSuppliers = [];

                if (this.suppliers.length === 0) {
                    this.initializeSampleData();
                }
            }

            initializeSampleData() {
                this.suppliers = [
                    { id: 'SUP-001', name: 'TecnoImport S.A.', contact: 'Juan Pérez', phone: '+1 234 567 890', email: 'juan@tecnoimport.com', website: 'https://tecnoimport.com', address: 'Av. Tecnología 123, Ciudad Industrial', notes: 'Proveedor confiable con más de 10 años en el mercado', status: 'active', rating: 5, category: 'Electrónicos' },
                    { id: 'SUP-002', name: 'DeportesMax', contact: 'María González', phone: '+1 345 678 901', email: 'maria@deportesmax.com', website: 'https://deportesmax.com', address: 'Calle Deportiva 456, Zona Comercial', notes: 'Especialistas en equipamiento deportivo', status: 'active', rating: 4, category: 'Deportes' },
                    { id: 'SUP-003', name: 'Textiles del Norte', contact: 'Carlos Rodríguez', phone: '+1 456 789 012', email: 'carlos@textilesnorte.com', website: '', address: 'Zona Industrial Norte, Bodega 15', notes: '', status: 'active', rating: 3, category: 'Ropa' },
                    { id: 'SUP-004', name: 'Hogar y Más', contact: 'Ana Martínez', phone: '+1 567 890 123', email: 'ana@hogarymas.com', website: 'https://hogarymas.com', address: 'Centro Comercial Plaza, Local 15', notes: 'Amplia variedad en productos para el hogar', status: 'active', rating: 4, category: 'Hogar' },
                    { id: 'SUP-005', name: 'Alimentos Naturales S.A.', contact: 'Roberto Sánchez', phone: '+1 678 901 234', email: 'roberto@alimentosnaturales.com', website: 'https://alimentosnaturales.com', address: 'Av. Salud 789, Distrito Ecológico', notes: 'Productos orgánicos y naturales', status: 'inactive', rating: 2, category: 'Alimentos' }
                ];

                this.products = [
                    { id: 'PROD-001', name: 'Smartphone X10', category: 'Electrónicos', price: 599.99, stock: 25, minStock: 10, supplier: 'SUP-001' },
                    { id: 'PROD-002', name: 'Tablet Pro', category: 'Electrónicos', price: 399.99, stock: 15, minStock: 5, supplier: 'SUP-001' },
                    { id: 'PROD-003', name: 'Balón de Fútbol', category: 'Deportes', price: 29.99, stock: 50, minStock: 20, supplier: 'SUP-002' },
                    { id: 'PROD-004', name: 'Raqueta Tenis', category: 'Deportes', price: 89.99, stock: 12, minStock: 5, supplier: 'SUP-002' },
                    { id: 'PROD-005', name: 'Camiseta Algodón', category: 'Ropa', price: 19.99, stock: 100, minStock: 30, supplier: 'SUP-003' },
                    { id: 'PROD-006', name: 'Jeans Clásicos', category: 'Ropa', price: 49.99, stock: 40, minStock: 15, supplier: 'SUP-003' },
                    { id: 'PROD-007', name: 'Juego de Sábanas', category: 'Hogar', price: 39.99, stock: 30, minStock: 10, supplier: 'SUP-004' },
                    { id: 'PROD-008', name: 'Set de Toallas', category: 'Hogar', price: 29.99, stock: 25, minStock: 8, supplier: 'SUP-004' },
                    { id: 'PROD-009', name: 'Miel Orgánica', category: 'Alimentos', price: 12.99, stock: 60, minStock: 20, supplier: 'SUP-005' },
                    { id: 'PROD-010', name: 'Granola Natural', category: 'Alimentos', price: 8.99, stock: 45, minStock: 15, supplier: 'SUP-005' }
                ];

                this.orders = [
                    { id: 'ORD-001', supplierId: 'SUP-001', date: '2023-10-15', deliveryDate: '2023-10-22', status: 'delivered', products: [{ productId: 'PROD-001', quantity: 10, price: 599.99 }, { productId: 'PROD-002', quantity: 5, price: 399.99 }], total: 7999.85, notes: 'Pedido regular de reposición' },
                    { id: 'ORD-002', supplierId: 'SUP-002', date: '2023-10-18', deliveryDate: '2023-10-25', status: 'shipped', products: [{ productId: 'PROD-003', quantity: 20, price: 29.99 }, { productId: 'PROD-004', quantity: 8, price: 89.99 }], total: 1239.72, notes: 'Pedido para temporada navideña' }
                ];

                this.evaluations = [
                    { id: 'EVAL-001', supplierId: 'SUP-001', date: '2023-10-25', quality: 5, delivery: 4, service: 5, price: 4, comment: 'Excelente proveedor, productos de alta calidad y buen servicio.' },
                    { id: 'EVAL-002', supplierId: 'SUP-002', date: '2023-10-20', quality: 4, delivery: 3, service: 4, price: 5, comment: 'Buenos precios pero tiempos de entrega podrían mejorar.' }
                ];

                this.documents = [
                    { id: 'DOC-001', supplierId: 'SUP-001', name: 'Contrato de Servicios', type: 'pdf', uploadDate: '2023-09-15' },
                    { id: 'DOC-002', supplierId: 'SUP-001', name: 'Certificación de Calidad', type: 'pdf', uploadDate: '2023-08-20' },
                    { id: 'DOC-003', supplierId: 'SUP-002', name: 'Lista de Precios 2023', type: 'xlsx', uploadDate: '2023-10-05' }
                ];

                this.messages = [
                    { id: 'MSG-001', supplierId: 'SUP-001', sender: 'Empresa', date: '2023-10-26 10:30', content: 'Hola, necesitamos confirmar la fecha de entrega del próximo pedido.' },
                    { id: 'MSG-002', supplierId: 'SUP-001', sender: 'Proveedor', date: '2023-10-26 11:15', content: 'Buenos días, el pedido está programado para entrega el próximo viernes.' }
                ];

                this.contacts = [
                    { id: 'CONT-001', supplierId: 'SUP-001', name: 'Juan Pérez', role: 'Gerente de Ventas', email: 'juan@tecnoimport.com', phone: '+1 234 567 890' },
                    { id: 'CONT-002', supplierId: 'SUP-001', name: 'Laura Gómez', role: 'Soporte Técnico', email: 'laura@tecnoimport.com', phone: '+1 234 567 891' },
                    { id: 'CONT-003', supplierId: 'SUP-002', name: 'María González', role: 'Directora Comercial', email: 'maria@deportesmax.com', phone: '+1 345 678 901' }
                ];

                this.transactions = [
                    { id: 'TRX-001', supplierId: 'SUP-001', date: '2023-10-15', type: 'payment', amount: 7999.85, description: 'Pago pedido ORD-001' },
                    { id: 'TRX-002', supplierId: 'SUP-002', date: '2023-10-18', type: 'payment', amount: 1239.72, description: 'Pago pedido ORD-002' }
                ];

                this.reminders = [
                    { id: 'REM-001', supplierId: 'SUP-001', date: '2023-11-15', title: 'Revisión de contrato', description: 'Revisar términos del contrato para renovación' },
                    { id: 'REM-002', supplierId: 'SUP-002', date: '2023-11-20', title: 'Evaluación trimestral', description: 'Realizar evaluación de desempeño del proveedor' }
                ];

                this.saveAllData();
            }

            generateId(prefix) {
                const items = { 'SUP': this.suppliers, 'ORD': this.orders, 'EVAL': this.evaluations, 'DOC': this.documents, 'MSG': this.messages, 'CONT': this.contacts, 'TRX': this.transactions, 'REM': this.reminders };
                const itemList = items[prefix] || [];
                const lastId = itemList.length > 0 ? Math.max(...itemList.map(s => parseInt(s.id.split('-')[1]))) : 0;
                return `${prefix}-${String(lastId + 1).padStart(3, '0')}`;
            }

            addSupplier(supplier) {
                supplier.id = this.generateId('SUP');
                this.suppliers.push(supplier);
                this.saveSuppliers();
                this.showNotification('Proveedor agregado correctamente', 'success');
                return supplier.id;
            }

            updateSupplier(id, updatedSupplier) {
                const index = this.suppliers.findIndex(s => s.id === id);
                if (index !== -1) {
                    this.suppliers[index] = {...updatedSupplier, id};
                    this.saveSuppliers();
                    this.showNotification('Proveedor actualizado correctamente', 'success');
                    return true;
                }
                return false;
            }

            deleteSupplier(id) {
                const index = this.suppliers.findIndex(s => s.id === id);
                if (index !== -1) {
                    const productCount = this.getProductsBySupplier(id).length;
                    if (productCount > 0) {
                        this.showNotification(`No se puede eliminar. El proveedor tiene ${productCount} producto(s) asociado(s)`, 'error');
                        return false;
                    }
                    this.suppliers.splice(index, 1);
                    this.saveSuppliers();
                    this.showNotification('Proveedor eliminado correctamente', 'success');
                    return true;
                }
                return false;
            }

            getSupplierById(id) { return this.suppliers.find(s => s.id === id); }
            getAllSuppliers() { return this.suppliers; }
            getProductsBySupplier(supplierId) { return this.products.filter(p => p.supplier === supplierId); }
            getOrdersBySupplier(supplierId) { return this.orders.filter(o => o.supplierId === supplierId); }
            getEvaluationsBySupplier(supplierId) { return this.evaluations.filter(e => e.supplierId === supplierId); }
            getDocumentsBySupplier(supplierId) { return this.documents.filter(d => d.supplierId === supplierId); }
            getMessagesBySupplier(supplierId) { return this.messages.filter(m => m.supplierId === supplierId); }
            getContactsBySupplier(supplierId) { return this.contacts.filter(c => c.supplierId === supplierId); }
            getTransactionsBySupplier(supplierId) { return this.transactions.filter(t => t.supplierId === supplierId); }
            getRemindersBySupplier(supplierId) { return this.reminders.filter(r => r.supplierId === supplierId); }

            addOrder(order) {
                order.id = this.generateId('ORD');
                this.orders.push(order);
                this.saveOrders();
                this.showNotification('Pedido agregado correctamente', 'success');
                return order.id;
            }

            addEvaluation(evaluation) {
                evaluation.id = this.generateId('EVAL');
                evaluation.date = new Date().toISOString().split('T')[0];
                this.evaluations.push(evaluation);

                const supplier = this.getSupplierById(evaluation.supplierId);
                if (supplier) {
                    const supplierEvaluations = this.getEvaluationsBySupplier(evaluation.supplierId);
                    const avgRating = supplierEvaluations.reduce((sum, e) => sum + (e.quality + e.delivery + e.service + e.price) / 4, 0) / supplierEvaluations.length;
                    supplier.rating = Math.round(avgRating);
                    const index = this.suppliers.findIndex(s => s.id === supplier.id);
                    this.suppliers[index] = supplier;
                    this.saveSuppliers();
                }

                this.saveEvaluations();
                this.showNotification('Evaluación guardada correctamente', 'success');
                return evaluation.id;
            }

            addDocument(document) {
                document.id = this.generateId('DOC');
                document.uploadDate = new Date().toISOString().split('T')[0];
                this.documents.push(document);
                this.saveDocuments();
                this.showNotification('Documento subido correctamente', 'success');
                return document.id;
            }

            addMessage(message) {
                message.id = this.generateId('MSG');
                message.date = new Date().toLocaleString();
                this.messages.push(message);
                this.saveMessages();
                return message.id;
            }

            addTransaction(transaction) {
                transaction.id = this.generateId('TRX');
                transaction.date = new Date().toISOString().split('T')[0];
                this.transactions.push(transaction);
                this.saveTransactions();
                return transaction.id;
            }

            addReminder(reminder) {
                reminder.id = this.generateId('REM');
                this.reminders.push(reminder);
                this.saveReminders();
                this.showNotification('Recordatorio agregado correctamente', 'success');
                return reminder.id;
            }

            getSupplierStats() {
                const totalSuppliers = this.suppliers.length;
                const activeSuppliers = this.suppliers.filter(s => s.status === 'active').length;
                const totalProducts = this.products.length;
                const suppliersWithRating = this.suppliers.filter(s => s.rating > 0);
                const avgRating = suppliersWithRating.length > 0 ? (suppliersWithRating.reduce((sum, s) => sum + s.rating, 0) / suppliersWithRating.length).toFixed(1) : '0.0';
                return { totalSuppliers, activeSuppliers, totalProducts, avgRating };
            }

            getPerformanceMetrics() {
                const orders = this.orders;
                const deliveredOrders = orders.filter(o => o.status === 'delivered' && o.deliveryDate);
                let avgDeliveryTime = 0;
                if (deliveredOrders.length > 0) {
                    const totalDays = deliveredOrders.reduce((sum, order) => {
                        const orderDate = new Date(order.date);
                        const deliveryDate = new Date(order.deliveryDate);
                        return sum + Math.round((deliveryDate - orderDate) / (1000 * 60 * 60 * 24));
                    }, 0);
                    avgDeliveryTime = Math.round(totalDays / deliveredOrders.length);
                }
                const totalOrders = orders.length;
                const completedOrders = orders.filter(o => o.status === 'delivered').length;
                const fulfillmentRate = totalOrders > 0 ? Math.round((completedOrders / totalOrders) * 100) : 0;
                const evaluations = this.evaluations;
                let qualityScore = 0;
                if (evaluations.length > 0) {
                    qualityScore = (evaluations.reduce((sum, e) => sum + e.quality, 0) / evaluations.length).toFixed(1);
                }
                const responseTime = Math.floor(Math.random() * 12) + 4;
                return { avgDeliveryTime, fulfillmentRate, qualityScore, responseTime };
            }

            getLowStockAlerts() {
                const alerts = [];
                this.suppliers.forEach(supplier => {
                    const products = this.getProductsBySupplier(supplier.id);
                    const lowStockProducts = products.filter(p => p.stock <= p.minStock);
                    if (lowStockProducts.length > 0) {
                        alerts.push({ supplierId: supplier.id, supplierName: supplier.name, products: lowStockProducts });
                    }
                });
                return alerts;
            }

            filterSuppliers(searchTerm = '', status = 'all', category = 'all') {
                this.filteredSuppliers = this.suppliers.filter(supplier => {
                    const matchesSearch = supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                         supplier.contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                         supplier.id.toLowerCase().includes(searchTerm.toLowerCase());
                    const matchesStatus = status === 'all' || supplier.status === status;
                    const matchesCategory = category === 'all' || supplier.category === category;
                    return matchesSearch && matchesStatus && matchesCategory;
                });
                return this.filteredSuppliers;
            }

            getPaginatedSuppliers(page = 1) {
                const startIndex = (page - 1) * this.itemsPerPage;
                return this.filteredSuppliers.slice(startIndex, startIndex + this.itemsPerPage);
            }

            getTotalPages() { return Math.ceil(this.filteredSuppliers.length / this.itemsPerPage); }

            saveAllData() {
                this.saveSuppliers(); this.saveProducts(); this.saveOrders(); this.saveEvaluations();
                this.saveDocuments(); this.saveMessages(); this.saveContacts(); this.saveTransactions(); this.saveReminders();
            }

            saveSuppliers() { localStorage.setItem('suppliers', JSON.stringify(this.suppliers)); }
            saveProducts() { localStorage.setItem('products', JSON.stringify(this.products)); }
            saveOrders() { localStorage.setItem('supplierOrders', JSON.stringify(this.orders)); }
            saveEvaluations() { localStorage.setItem('supplierEvaluations', JSON.stringify(this.evaluations)); }
            saveDocuments() { localStorage.setItem('supplierDocuments', JSON.stringify(this.documents)); }
            saveMessages() { localStorage.setItem('supplierMessages', JSON.stringify(this.messages)); }
            saveContacts() { localStorage.setItem('supplierContacts', JSON.stringify(this.contacts)); }
            saveTransactions() { localStorage.setItem('supplierTransactions', JSON.stringify(this.transactions)); }
            saveReminders() { localStorage.setItem('supplierReminders', JSON.stringify(this.reminders)); }

            exportToPDF() {
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();
                doc.setFontSize(20);
                doc.setTextColor(40, 40, 40);
                doc.text('Reporte de Proveedores - SmartStock AI', 105, 15, { align: 'center' });
                doc.setFontSize(10);
                doc.setTextColor(100, 100, 100);
                doc.text(`Generado el: ${new Date().toLocaleDateString()}`, 105, 22, { align: 'center' });

                const stats = this.getSupplierStats();
                doc.setFontSize(12);
                doc.setTextColor(40, 40, 40);
                doc.text(`Total de Proveedores: ${stats.totalSuppliers}`, 20, 35);
                doc.text(`Proveedores Activos: ${stats.activeSuppliers}`, 20, 42);
                doc.text(`Total de Productos: ${stats.totalProducts}`, 20, 49);
                doc.text(`Calificación Promedio: ${stats.avgRating}`, 20, 56);

                doc.autoTable({
                    startY: 65,
                    head: [['ID', 'Nombre', 'Contacto', 'Teléfono', 'Estado', 'Calificación']],
                    body: this.suppliers.map(s => [s.id, s.name, s.contact, s.phone, s.status === 'active' ? 'Activo' : 'Inactivo', s.rating ? '★'.repeat(s.rating) : 'Sin calificar']),
                    styles: { fontSize: 10, cellPadding: 5 },
                    headStyles: { fillColor: [58, 94, 199], textColor: [255, 255, 255] },
                    alternateRowStyles: { fillColor: [240, 240, 240] }
                });

                const pageCount = doc.internal.getNumberOfPages();
                for (let i = 1; i <= pageCount; i++) {
                    doc.setPage(i);
                    doc.setFontSize(10);
                    doc.setTextColor(100, 100, 100);
                    doc.text(`Página ${i} de ${pageCount}`, 105, 285, { align: 'center' });
                    doc.text('SmartStock AI - Sistema de Gestión de Proveedores', 105, 290, { align: 'center' });
                }

                doc.save(`proveedores_smartstock_${new Date().toISOString().split('T')[0]}.pdf`);
                this.showNotification('PDF de proveedores generado correctamente', 'success');
            }

            exportToCSV() {
                const headers = ['ID', 'Nombre', 'Contacto', 'Teléfono', 'Email', 'Sitio Web', 'Dirección', 'Estado', 'Calificación', 'Categoría', 'Notas'];
                const csvContent = [
                    headers.join(','),
                    ...this.suppliers.map(supplier => [
                        supplier.id, `"${supplier.name}"`, `"${supplier.contact}"`, supplier.phone, supplier.email,
                        supplier.website || '', `"${supplier.address}"`, supplier.status, supplier.rating || 0,
                        supplier.category || '', `"${supplier.notes || ''}"`
                    ].join(','))
                ].join('\n');

                const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', `proveedores_smartstock_${new Date().toISOString().split('T')[0]}.csv`);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                this.showNotification('CSV de proveedores exportado correctamente', 'success');
            }

            exportToExcel() {
                const wb = XLSX.utils.book_new();
                const suppliersData = this.suppliers.map(s => ({
                    'ID': s.id, 'Nombre': s.name, 'Contacto': s.contact, 'Teléfono': s.phone,
                    'Email': s.email, 'Sitio Web': s.website || '', 'Dirección': s.address,
                    'Estado': s.status === 'active' ? 'Activo' : 'Inactivo', 'Calificación': s.rating || 0,
                    'Categoría': s.category || '', 'Notas': s.notes || ''
                }));
                const wsSuppliers = XLSX.utils.json_to_sheet(suppliersData);
                XLSX.utils.book_append_sheet(wb, wsSuppliers, 'Proveedores');

                const productsData = this.products.map(p => {
                    const supplier = this.getSupplierById(p.supplier);
                    return {
                        'ID': p.id, 'Producto': p.name, 'Categoría': p.category, 'Precio': p.price,
                        'Stock': p.stock, 'Stock Mínimo': p.minStock, 'Proveedor': supplier ? supplier.name : ''
                    };
                });
                const wsProducts = XLSX.utils.json_to_sheet(productsData);
                XLSX.utils.book_append_sheet(wb, wsProducts, 'Productos');

                XLSX.writeFile(wb, `proveedores_smartstock_${new Date().toISOString().split('T')[0]}.xlsx`);
                this.showNotification('Excel exportado correctamente', 'success');
            }

            importFromCSV(csvText) {
                try {
                    const lines = csvText.split('\n');
                    const newSuppliers = [];
                    for (let i = 1; i < lines.length; i++) {
                        if (lines[i].trim() === '') continue;
                        const values = [];
                        let inQuote = false, currentValue = '';
                        for (let char of lines[i]) {
                            if (char === '"') inQuote = !inQuote;
                            else if (char === ',' && !inQuote) { values.push(currentValue); currentValue = ''; }
                            else currentValue += char;
                        }
                        values.push(currentValue);

                        newSuppliers.push({
                            id: this.generateId('SUP'),
                            name: values[1] || '',
                            contact: values[2] || '',
                            phone: values[3] || '',
                            email: values[4] || '',
                            website: values[5] || '',
                            address: values[6] || '',
                            status: values[7] === 'Activo' ? 'active' : 'inactive',
                            rating: parseInt(values[8]) || 0,
                            category: values[9] || '',
                            notes: values[10] || ''
                        });
                    }
                    this.suppliers = [...this.suppliers, ...newSuppliers];
                    this.saveSuppliers();
                    this.showNotification(`${newSuppliers.length} proveedores importados correctamente`, 'success');
                    return true;
                } catch (error) {
                    this.showNotification('Error al importar datos: ' + error.message, 'error');
                    return false;
                }
            }

            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                toast.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'}"></i><span>${message}</span>`;
                document.getElementById('toastContainer').appendChild(toast);
                setTimeout(() => {
                    toast.style.animation = 'slideOut 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }
        }

        const supplierManager = new SupplierManager();

        // ============ RENDERIZADO ============
        function renderSuppliersTable() {
            const tableBody = document.getElementById('suppliersTableBody');
            if (!tableBody) return;
            tableBody.innerHTML = '';

            const searchTerm = document.getElementById('searchSupplierInput')?.value || '';
            const status = document.getElementById('statusFilter')?.value || 'all';
            const category = document.getElementById('categoryFilter')?.value || 'all';

            supplierManager.filterSuppliers(searchTerm, status, category);
            const suppliers = supplierManager.getPaginatedSuppliers(supplierManager.currentPage);

            const countElement = document.getElementById('supplierCount');
            if (countElement) {
                countElement.textContent = `Mostrando ${suppliers.length} de ${supplierManager.filteredSuppliers.length} proveedores`;
            }

            if (suppliers.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="9" class="text-center py-4">
                            <div class="empty-state">
                                <i class="fas fa-truck"></i>
                                <p>No se encontraron proveedores</p>
                                <button class="btn btn-primary btn-sm" onclick="openNewSupplierModal()">
                                    <i class="fas fa-plus me-2"></i>Agregar Proveedor
                                </button>
                            </div>
                        </td>
                    </tr>`;
            } else {
                suppliers.forEach(supplier => {
                    const productCount = supplierManager.getProductsBySupplier(supplier.id).length;
                    const statusClass = supplier.status === 'active' ? 'status-active' : 'status-inactive';
                    const statusText = supplier.status === 'active' ? 'Activo' : 'Inactivo';
                    const ratingStars = '★'.repeat(supplier.rating || 0) + '☆'.repeat(5 - (supplier.rating || 0));

                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td><span class="badge bg-primary">${supplier.id}</span></td>
                        <td><strong>${supplier.name}</strong></td>
                        <td>${supplier.contact}</td>
                        <td>${supplier.phone}</td>
                        <td>${supplier.email}</td>
                        <td><span class="badge bg-info">${productCount}</span></td>
                        <td><span class="rating-stars" data-tooltip="${supplier.rating || 0} estrellas">${ratingStars}</span></td>
                        <td><span class="supplier-status ${statusClass}">${statusText}</span></td>
                        <td>
                            <button class="action-btn btn-view" data-id="${supplier.id}" data-tooltip="Ver detalles"><i class="fas fa-eye"></i></button>
                            <button class="action-btn btn-edit" data-id="${supplier.id}" data-tooltip="Editar"><i class="fas fa-edit"></i></button>
                            <button class="action-btn btn-delete" data-id="${supplier.id}" data-tooltip="Eliminar"><i class="fas fa-trash"></i></button>
                        </td>`;
                    tableBody.appendChild(row);
                });
            }
            renderPagination();
            addTableEventListeners();
        }

        function renderPagination() {
            const pagination = document.getElementById('pagination');
            const paginationContainer = document.getElementById('paginationContainer');
            if (!pagination || !paginationContainer) return;
            pagination.innerHTML = '';

            const totalPages = supplierManager.getTotalPages();
            if (totalPages <= 1) { paginationContainer.style.display = 'none'; return; }
            paginationContainer.style.display = 'flex';

            const prevLi = document.createElement('li');
            prevLi.className = `page-item ${supplierManager.currentPage === 1 ? 'disabled' : ''}`;
            prevLi.innerHTML = `<a class="page-link"><i class="fas fa-chevron-left"></i></a>`;
            prevLi.addEventListener('click', (e) => {
                e.preventDefault();
                if (supplierManager.currentPage > 1) { supplierManager.currentPage--; renderSuppliersTable(); }
            });
            pagination.appendChild(prevLi);

            for (let i = 1; i <= totalPages; i++) {
                const pageLi = document.createElement('li');
                pageLi.className = `page-item ${supplierManager.currentPage === i ? 'active' : ''}`;
                pageLi.innerHTML = `<a class="page-link">${i}</a>`;
                pageLi.addEventListener('click', (e) => {
                    e.preventDefault();
                    supplierManager.currentPage = i;
                    renderSuppliersTable();
                });
                pagination.appendChild(pageLi);
            }

            const nextLi = document.createElement('li');
            nextLi.className = `page-item ${supplierManager.currentPage === totalPages ? 'disabled' : ''}`;
            nextLi.innerHTML = `<a class="page-link"><i class="fas fa-chevron-right"></i></a>`;
            nextLi.addEventListener('click', (e) => {
                e.preventDefault();
                if (supplierManager.currentPage < totalPages) { supplierManager.currentPage++; renderSuppliersTable(); }
            });
            pagination.appendChild(nextLi);
        }

        function addTableEventListeners() {
            document.querySelectorAll('.btn-view').forEach(btn => {
                btn.onclick = function() { viewSupplier(this.getAttribute('data-id')); };
            });
            document.querySelectorAll('.btn-edit').forEach(btn => {
                btn.onclick = function() { openEditSupplierModal(this.getAttribute('data-id')); };
            });
            document.querySelectorAll('.btn-delete').forEach(btn => {
                btn.onclick = function() { deleteSupplier(this.getAttribute('data-id')); };
            });
        }

        function openEditSupplierModal(supplierId) {
            const supplier = supplierManager.getSupplierById(supplierId);
            if (!supplier) return;
            document.getElementById('supplierModalTitle').textContent = 'Editar Proveedor';
            document.getElementById('supplierId').value = supplier.id;
            document.getElementById('supplierName').value = supplier.name;
            document.getElementById('supplierContact').value = supplier.contact;
            document.getElementById('supplierPhone').value = supplier.phone;
            document.getElementById('supplierEmail').value = supplier.email;
            document.getElementById('supplierWebsite').value = supplier.website || '';
            document.getElementById('supplierAddress').value = supplier.address;
            document.getElementById('supplierNotes').value = supplier.notes || '';
            document.getElementById('supplierStatus').value = supplier.status;
            document.getElementById('supplierRating').value = supplier.rating || 0;
            document.getElementById('supplierCategory').value = supplier.category || '';
            new bootstrap.Modal(document.getElementById('supplierModal')).show();
        }

        function viewSupplier(supplierId) {
            const supplier = supplierManager.getSupplierById(supplierId);
            if (!supplier) return;
            const products = supplierManager.getProductsBySupplier(supplierId);
            const ratingStars = '★'.repeat(supplier.rating || 0) + '☆'.repeat(5 - (supplier.rating || 0));

            document.getElementById('viewSupplierId').textContent = supplier.id;
            document.getElementById('viewSupplierName').textContent = supplier.name;
            document.getElementById('viewSupplierContact').textContent = supplier.contact;
            document.getElementById('viewSupplierPhone').textContent = supplier.phone;
            document.getElementById('viewSupplierEmail').textContent = supplier.email;
            document.getElementById('viewSupplierWebsite').textContent = supplier.website || '-';
            document.getElementById('viewSupplierAddress').textContent = supplier.address;
            document.getElementById('viewSupplierNotes').textContent = supplier.notes || '-';
            document.getElementById('viewSupplierCategory').textContent = supplier.category || '-';
            document.getElementById('viewSupplierRating').innerHTML = ratingStars;
            document.getElementById('viewSupplierProducts').textContent = products.length;

            const statusElement = document.getElementById('viewSupplierStatus');
            statusElement.textContent = supplier.status === 'active' ? 'Activo' : 'Inactivo';
            statusElement.className = `supplier-status ${supplier.status === 'active' ? 'status-active' : 'status-inactive'}`;

            const notesSection = document.getElementById('viewSupplierNotesSection');
            if (notesSection) notesSection.style.display = supplier.notes ? 'block' : 'none';

            const productsList = document.getElementById('supplierProductsList');
            if (productsList) {
                if (products.length > 0) {
                    let html = '<div class="list-group">';
                    products.forEach(product => {
                        const stockClass = product.stock <= product.minStock ? 'bg-danger' : 'bg-success';
                        html += `<div class="list-group-item"><div class="d-flex justify-content-between align-items-center"><div><strong>${product.name}</strong><br><small class="text-muted">${product.category} - $${product.price.toFixed(2)}</small></div><span class="badge ${stockClass}">Stock: ${product.stock}</span></div></div>`;
                    });
                    html += '</div>';
                    productsList.innerHTML = html;
                } else {
                    productsList.innerHTML = '<p class="text-muted">Este proveedor no tiene productos asociados.</p>';
                }
            }
            new bootstrap.Modal(document.getElementById('viewSupplierModal')).show();
        }

        function deleteSupplier(supplierId) {
            if (confirm('¿Estás seguro de que deseas eliminar este proveedor?')) {
                if (supplierManager.deleteSupplier(supplierId)) {
                    renderSuppliersTable();
                    updateDashboardStats();
                    populateDropdowns();
                }
            }
        }

        function saveSupplier() {
            const form = document.getElementById('supplierForm');
            if (!form.checkValidity()) { form.reportValidity(); return; }

            const supplierId = document.getElementById('supplierId').value;
            const supplier = {
                name: document.getElementById('supplierName').value,
                contact: document.getElementById('supplierContact').value,
                phone: document.getElementById('supplierPhone').value,
                email: document.getElementById('supplierEmail').value,
                website: document.getElementById('supplierWebsite').value,
                address: document.getElementById('supplierAddress').value,
                notes: document.getElementById('supplierNotes').value,
                status: document.getElementById('supplierStatus').value,
                rating: parseInt(document.getElementById('supplierRating').value),
                category: document.getElementById('supplierCategory').value
            };

            if (supplierId) supplierManager.updateSupplier(supplierId, supplier);
            else supplierManager.addSupplier(supplier);

            bootstrap.Modal.getInstance(document.getElementById('supplierModal')).hide();
            renderSuppliersTable();
            updateDashboardStats();
            populateDropdowns();
        }

        function updateDashboardStats() {
            const stats = supplierManager.getSupplierStats();
            document.getElementById('totalSuppliers').textContent = stats.totalSuppliers;
            document.getElementById('activeSuppliers').textContent = stats.activeSuppliers;
            document.getElementById('totalProducts').textContent = stats.totalProducts;
            document.getElementById('avgRating').textContent = stats.avgRating;
        }

        function openNewSupplierModal() {
            document.getElementById('supplierModalTitle').textContent = 'Agregar Nuevo Proveedor';
            document.getElementById('supplierForm').reset();
            document.getElementById('supplierId').value = '';
            document.getElementById('supplierStatus').value = 'active';
            document.getElementById('supplierRating').value = '0';
            new bootstrap.Modal(document.getElementById('supplierModal')).show();
        }

        function importSuppliers() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.csv';
            input.onchange = e => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = function(event) {
                    if (supplierManager.importFromCSV(event.target.result)) {
                        renderSuppliersTable();
                        updateDashboardStats();
                        populateDropdowns();
                    }
                };
                reader.readAsText(file);
            };
            input.click();
        }

        function updateNotifications() {
            const notificationCount = document.getElementById('notificationCount');
            const notificationList = document.getElementById('notificationList');
            if (!notificationCount || !notificationList) return;

            const alerts = supplierManager.getLowStockAlerts();
            const pendingEvaluations = supplierManager.suppliers.filter(s => {
                const evaluations = supplierManager.getEvaluationsBySupplier(s.id);
                return evaluations.length === 0 && s.status === 'active';
            });

            const notifications = [
                ...alerts.map(alert => ({ title: 'Stock Bajo', message: `${alert.supplierName} tiene ${alert.products.length} producto(s) con stock bajo`, date: 'Ahora', unread: true })),
                ...pendingEvaluations.map(supplier => ({ title: 'Evaluación Pendiente', message: `${supplier.name} no ha sido evaluado aún`, date: 'Pendiente', unread: true }))
            ];

            notificationCount.textContent = notifications.length;
            notificationCount.style.display = notifications.length === 0 ? 'none' : 'inline-block';

            if (notifications.length === 0) {
                notificationList.innerHTML = '<div class="notification-item">No hay notificaciones nuevas</div>';
            } else {
                notificationList.innerHTML = '';
                notifications.forEach(notification => {
                    const item = document.createElement('div');
                    item.className = `notification-item ${notification.unread ? 'unread' : ''}`;
                    item.innerHTML = `<strong>${notification.title}</strong><p>${notification.message}</p><small>${notification.date}</small>`;
                    notificationList.appendChild(item);
                });
            }
        }

        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            const themeIcon = document.querySelector('#themeToggle i');
            if (document.body.classList.contains('dark-mode')) {
                themeIcon.className = 'fas fa-sun';
                localStorage.setItem('theme', 'dark');
            } else {
                themeIcon.className = 'fas fa-moon';
                localStorage.setItem('theme', 'light');
            }
        }

        function toggleMenu() { document.getElementById('sidebar').classList.toggle('open'); }
        function toggleNotifications() { document.getElementById('notificationDropdown').classList.toggle('show'); }

        function toggleSidebarSimple() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const icon = document.querySelector('#sidebarToggle i');
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            if (sidebar.classList.contains('collapsed')) {
                icon.className = 'fas fa-chevron-right';
            } else {
                icon.className = 'fas fa-chevron-left';
            }
        }

        function switchTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            const tabElement = document.getElementById(`${tabName}-tab`);
            if (tabElement) tabElement.classList.add('active');

            document.querySelectorAll('.custom-tab').forEach(tab => tab.classList.remove('active'));
            const activeTab = document.querySelector(`.custom-tab[data-tab="${tabName}"]`);
            if (activeTab) activeTab.classList.add('active');

            if (tabName === 'analytics') { renderPerformanceMetrics(); renderLowStockAlerts(); }
            else if (tabName === 'evaluation') { populateEvaluationDropdown(); renderEvaluationHistory(); }
            else if (tabName === 'orders') { renderOrdersList(); }
            else if (tabName === 'documents') { renderDocumentsList(); }
            else if (tabName === 'communication') { populateCommunicationDropdown(); renderContactsList(); }
            else if (tabName === 'transactions') { renderTransactionsList(); }
            else if (tabName === 'reminders') { renderRemindersList(); }
        }

        function populateDropdowns() {
            const suppliers = supplierManager.getAllSuppliers();
            const dropdowns = ['evaluationSupplier', 'communicationSupplier', 'orderSupplier', 'documentSupplier', 'reminderSupplier'];
            dropdowns.forEach(id => {
                const dropdown = document.getElementById(id);
                if (dropdown) {
                    dropdown.innerHTML = '<option value="">Seleccionar proveedor...</option>';
                    suppliers.forEach(supplier => {
                        const option = document.createElement('option');
                        option.value = supplier.id;
                        option.textContent = `${supplier.name} (${supplier.id})`;
                        dropdown.appendChild(option);
                    });
                }
            });
        }

        function populateEvaluationDropdown() { populateDropdowns(); }
        function populateCommunicationDropdown() { populateDropdowns(); }

        function renderPerformanceMetrics() {
            const metrics = supplierManager.getPerformanceMetrics();
            document.getElementById('avgDeliveryTime').textContent = metrics.avgDeliveryTime;
            document.getElementById('fulfillmentRate').textContent = `${metrics.fulfillmentRate}%`;
            document.getElementById('qualityScore').textContent = metrics.qualityScore;
            document.getElementById('responseTime').textContent = `${metrics.responseTime}h`;
        }

        function renderLowStockAlerts() {
            const alerts = supplierManager.getLowStockAlerts();
            const alertsContainer = document.getElementById('lowStockAlerts');
            if (!alertsContainer) return;

            if (alerts.length === 0) {
                alertsContainer.innerHTML = '<p class="text-muted">No hay alertas de stock bajo en este momento.</p>';
                return;
            }

            let html = '';
            alerts.forEach(alert => {
                html += `
                    <div class="alert-card">
                        <div class="alert-header">
                            <div class="alert-title">${alert.supplierName}</div>
                            <span class="alert-priority">${alert.products.length} producto(s)</span>
                        </div>
                        <div class="alert-content">
                            <p>Los siguientes productos tienen stock bajo:</p>
                            <ul>
                                ${alert.products.map(p => `<li>${p.name} - Stock actual: ${p.stock} (Mínimo: ${p.minStock})</li>`).join('')}
                            </ul>
                            <button class="btn btn-sm btn-warning mt-2" onclick="reorderProducts('${alert.supplierId}')">
                                <i class="fas fa-shopping-cart me-2"></i>Reordenar
                            </button>
                        </div>
                    </div>`;
            });
            alertsContainer.innerHTML = html;
        }

        function reorderProducts(supplierId) {
            switchTab('orders');
            setTimeout(() => {
                openNewOrderModal();
                document.getElementById('orderSupplier').value = supplierId;
                document.getElementById('orderDate').value = new Date().toISOString().split('T')[0];
            }, 100);
        }

        // ============ EVALUACIÓN ============
        function handleEvaluationSupplierChange() {
            const supplierId = document.getElementById('evaluationSupplier').value;
            const evaluationForm = document.getElementById('evaluationForm');
            if (evaluationForm) {
                if (supplierId) { evaluationForm.style.display = 'block'; resetStarRatings(); }
                else evaluationForm.style.display = 'none';
            }
        }

        function resetStarRatings() {
            document.querySelectorAll('.criteria-rating .star').forEach(star => star.classList.remove('active'));
        }

        function handleStarClick(event) {
            const stars = event.target.parentElement.querySelectorAll('.star');
            const value = parseInt(event.target.getAttribute('data-value'));
            stars.forEach((star, index) => {
                if (index < value) star.classList.add('active');
                else star.classList.remove('active');
            });
        }

        function saveEvaluation() {
            const supplierId = document.getElementById('evaluationSupplier').value;
            if (!supplierId) { supplierManager.showNotification('Por favor selecciona un proveedor', 'error'); return; }

            const quality = document.querySelectorAll('#qualityRating .star.active').length;
            const delivery = document.querySelectorAll('#deliveryRating .star.active').length;
            const service = document.querySelectorAll('#serviceRating .star.active').length;
            const price = document.querySelectorAll('#priceRating .star.active').length;
            const comment = document.getElementById('evaluationComment').value;

            if (quality === 0 || delivery === 0 || service === 0 || price === 0) {
                supplierManager.showNotification('Por favor califica todos los criterios', 'error');
                return;
            }

            supplierManager.addEvaluation({ supplierId, quality, delivery, service, price, comment });
            resetStarRatings();
            document.getElementById('evaluationComment').value = '';
            renderEvaluationHistory();
            renderSuppliersTable();
            updateDashboardStats();
        }

        function renderEvaluationHistory() {
            const historyContainer = document.getElementById('evaluationHistory');
            if (!historyContainer) return;

            const evaluations = [...supplierManager.evaluations].sort((a, b) => new Date(b.date) - new Date(a.date));

            if (evaluations.length === 0) {
                historyContainer.innerHTML = '<p class="text-muted">No hay evaluaciones registradas.</p>';
                return;
            }

            let html = '';
            evaluations.forEach(evaluation => {
                const supplier = supplierManager.getSupplierById(evaluation.supplierId);
                if (!supplier) return;
                const totalScore = (evaluation.quality + evaluation.delivery + evaluation.service + evaluation.price) / 4;
                html += `
                    <div class="evaluation-card">
                        <div class="evaluation-header">
                            <div class="evaluation-title">${supplier.name}</div>
                            <div class="evaluation-date">${evaluation.date}</div>
                        </div>
                        <div class="rating-stars">
                            ${'★'.repeat(Math.round(totalScore))}${'☆'.repeat(5 - Math.round(totalScore))}
                            <span class="ms-2">(${totalScore.toFixed(1)})</span>
                        </div>
                        <div class="evaluation-comment">${evaluation.comment || 'Sin comentarios'}</div>
                    </div>`;
            });
            historyContainer.innerHTML = html;
        }

        // ============ PEDIDOS ============
        function renderOrdersList() {
            const ordersContainer = document.getElementById('ordersList');
            if (!ordersContainer) return;

            const orders = [...supplierManager.orders].sort((a, b) => new Date(b.date) - new Date(a.date));

            if (orders.length === 0) {
                ordersContainer.innerHTML = '<p class="text-muted">No hay pedidos registrados.</p>';
                return;
            }

            let html = '';
            orders.forEach(order => {
                const supplier = supplierManager.getSupplierById(order.supplierId);
                if (!supplier) return;
                const statusClass = `status-${order.status}`;
                const statusText = { 'pending': 'Pendiente', 'approved': 'Aprobado', 'shipped': 'Enviado', 'delivered': 'Entregado', 'cancelled': 'Cancelado' }[order.status] || order.status;

                html += `
                    <div class="order-card">
                        <div class="order-header">
                            <div class="order-title">Pedido ${order.id} - ${supplier.name}</div>
                            <span class="order-status ${statusClass}">${statusText}</span>
                        </div>
                        <div class="order-details">
                            <div class="order-info">
                                <div><i class="fas fa-calendar me-2"></i>Fecha: ${order.date}</div>
                                <div><i class="fas fa-clock me-2"></i>Entrega: ${order.deliveryDate || 'No especificada'}</div>
                                <div><i class="fas fa-box me-2"></i>Productos: ${order.products.length}</div>
                            </div>
                            <div class="order-amount">$${order.total.toFixed(2)}</div>
                        </div>
                        ${order.notes ? `<div class="mt-2"><small class="text-muted">${order.notes}</small></div>` : ''}
                    </div>`;
            });
            ordersContainer.innerHTML = html;
        }

        function openNewOrderModal() {
            document.getElementById('orderForm').reset();
            document.getElementById('orderDate').value = new Date().toISOString().split('T')[0];
            document.getElementById('orderStatus').value = 'pending';
            const productsList = document.getElementById('orderProductsList');
            if (productsList) productsList.innerHTML = '';
            addProductToOrder();
            new bootstrap.Modal(document.getElementById('orderModal')).show();
        }

        function addProductToOrder() {
            const productsList = document.getElementById('orderProductsList');
            if (!productsList) return;

            const productHTML = `
                <div class="row mb-2 product-row">
                    <div class="col-md-5">
                        <select class="form-select product-select" required>
                            <option value="">Seleccionar producto...</option>
                            ${supplierManager.products.map(p => `<option value="${p.id}" data-price="${p.price}">${p.name} - $${p.price.toFixed(2)}</option>`).join('')}
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="number" class="form-control quantity-input" min="1" value="1" required>
                    </div>
                    <div class="col-md-3">
                        <input type="number" class="form-control price-input" step="0.01" min="0" placeholder="Precio" required>
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-sm btn-danger remove-product-btn">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>`;

            productsList.insertAdjacentHTML('beforeend', productHTML);

            const lastRow = productsList.lastElementChild;
            lastRow.querySelector('.remove-product-btn').onclick = function() { this.closest('.product-row').remove(); };
            lastRow.querySelector('.product-select').onchange = function() {
                const selectedOption = this.options[this.selectedIndex];
                if (selectedOption.value) {
                    const priceInput = this.closest('.product-row').querySelector('.price-input');
                    if (priceInput) priceInput.value = selectedOption.dataset.price;
                }
            };
        }

        function saveOrder() {
            const form = document.getElementById('orderForm');
            if (!form.checkValidity()) { form.reportValidity(); return; }

            const supplierId = document.getElementById('orderSupplier').value;
            const date = document.getElementById('orderDate').value;
            const deliveryDate = document.getElementById('deliveryDate').value;
            const status = document.getElementById('orderStatus').value;
            const notes = document.getElementById('orderNotes').value;

            if (!supplierId) { supplierManager.showNotification('Debe seleccionar un proveedor', 'error'); return; }

            const productRows = document.querySelectorAll('.product-row');
            if (productRows.length === 0) { supplierManager.showNotification('Debe agregar al menos un producto', 'error'); return; }

            const products = [];
            let total = 0;

            for (const row of productRows) {
                const productSelect = row.querySelector('.product-select');
                const quantity = parseInt(row.querySelector('.quantity-input').value);
                const price = parseFloat(row.querySelector('.price-input').value);

                if (!productSelect.value) { supplierManager.showNotification('Debe seleccionar un producto en cada fila', 'error'); return; }
                if (isNaN(quantity) || quantity < 1) { supplierManager.showNotification('La cantidad debe ser mayor a 0', 'error'); return; }
                if (isNaN(price) || price < 0) { supplierManager.showNotification('El precio debe ser válido', 'error'); return; }

                products.push({ productId: productSelect.value, quantity, price });
                total += quantity * price;
            }

            supplierManager.addOrder({ supplierId, date, deliveryDate: deliveryDate || null, status, products, total, notes });
            supplierManager.addTransaction({ supplierId, type: 'order', amount: total, description: `Pedido - ${supplierManager.getSupplierById(supplierId)?.name}` });

            bootstrap.Modal.getInstance(document.getElementById('orderModal')).hide();
            renderOrdersList();
            renderTransactionsList();
        }

        // ============ DOCUMENTOS ============
        function renderDocumentsList() {
            const documentsContainer = document.getElementById('documentsList');
            if (!documentsContainer) return;

            const documents = [...supplierManager.documents].sort((a, b) => new Date(b.uploadDate) - new Date(a.uploadDate));

            if (documents.length === 0) {
                documentsContainer.innerHTML = '<p class="text-muted">No hay documentos registrados.</p>';
                return;
            }

            let html = '';
            documents.forEach(doc => {
                const supplier = supplierManager.getSupplierById(doc.supplierId);
                if (!supplier) return;
                const iconClass = doc.type === 'pdf' ? 'fa-file-pdf' : doc.type === 'xlsx' ? 'fa-file-excel' : doc.type === 'docx' ? 'fa-file-word' : doc.type === 'jpg' ? 'fa-file-image' : 'fa-file';
                const iconColor = doc.type === 'pdf' ? '#dc3545' : doc.type === 'xlsx' ? '#28a745' : doc.type === 'docx' ? '#17a2b8' : '#3a5ec7';

                html += `
                    <div class="document-item" onclick="downloadDocument('${doc.id}')">
                        <div class="document-icon" style="color: ${iconColor}"><i class="fas ${iconClass}"></i></div>
                        <div class="document-name">${doc.name}</div>
                        <div class="document-supplier">${supplier.name}</div>
                        <div class="document-date">${doc.uploadDate}</div>
                    </div>`;
            });
            documentsContainer.innerHTML = html;
        }

        function downloadDocument(documentId) {
            const doc = supplierManager.documents.find(d => d.id === documentId);
            if (doc) supplierManager.showNotification(`Descargando: ${doc.name}`, 'info');
        }

        function openUploadDocumentModal() {
            document.getElementById('documentForm').reset();
            new bootstrap.Modal(document.getElementById('documentModal')).show();
        }

        function uploadDocument() {
            const form = document.getElementById('documentForm');
            if (!form.checkValidity()) { form.reportValidity(); return; }

            const supplierId = document.getElementById('documentSupplier').value;
            const name = document.getElementById('documentName').value;
            const type = document.getElementById('documentType').value;

            supplierManager.addDocument({ supplierId, name, type });
            bootstrap.Modal.getInstance(document.getElementById('documentModal')).hide();
            renderDocumentsList();
        }

        // ============ COMUNICACIÓN ============
        function handleCommunicationSupplierChange() {
            const supplierId = document.getElementById('communicationSupplier').value;
            const communicationArea = document.getElementById('communicationArea');
            if (communicationArea) {
                if (supplierId) { communicationArea.style.display = 'block'; renderMessages(supplierId); }
                else communicationArea.style.display = 'none';
            }
        }

        function renderMessages(supplierId) {
            const messageList = document.getElementById('messageList');
            if (!messageList) return;

            const messages = supplierManager.getMessagesBySupplier(supplierId).sort((a, b) => new Date(a.date) - new Date(b.date));

            if (messages.length === 0) {
                messageList.innerHTML = '<p class="text-muted">No hay mensajes con este proveedor.</p>';
                return;
            }

            let html = '';
            messages.forEach(message => {
                const isOutgoing = message.sender === 'Empresa';
                html += `
                    <div class="message-item" style="text-align: ${isOutgoing ? 'right' : 'left'}">
                        <div class="message-header">
                            <div class="message-sender">${message.sender}</div>
                            <div class="message-date">${message.date}</div>
                        </div>
                        <div class="message-content">${message.content}</div>
                    </div>`;
            });
            messageList.innerHTML = html;
            messageList.scrollTop = messageList.scrollHeight;
        }

        function sendMessage() {
            const supplierId = document.getElementById('communicationSupplier').value;
            const messageText = document.getElementById('messageText')?.value.trim();

            if (!supplierId) { supplierManager.showNotification('Por favor selecciona un proveedor', 'error'); return; }
            if (!messageText) { supplierManager.showNotification('Por favor escribe un mensaje', 'error'); return; }

            supplierManager.addMessage({ supplierId, sender: 'Empresa', content: messageText });
            document.getElementById('messageText').value = '';
            renderMessages(supplierId);
            supplierManager.showNotification('Mensaje enviado correctamente', 'success');
        }

        function renderContactsList() {
            const contactsContainer = document.getElementById('contactsList');
            if (!contactsContainer) return;

            const contacts = supplierManager.contacts;
            if (contacts.length === 0) {
                contactsContainer.innerHTML = '<p class="text-muted">No hay contactos registrados.</p>';
                return;
            }

            let html = '';
            contacts.forEach(contact => {
                const supplier = supplierManager.getSupplierById(contact.supplierId);
                if (!supplier) return;
                html += `
                    <div class="contact-item">
                        <div class="contact-name">${contact.name}</div>
                        <div class="contact-role">${contact.role} - ${supplier.name}</div>
                        <div class="contact-info">
                            <div><i class="fas fa-phone me-2"></i>${contact.phone}</div>
                            <div><i class="fas fa-envelope me-2"></i>${contact.email}</div>
                        </div>
                    </div>`;
            });
            contactsContainer.innerHTML = html;
        }

        // ============ TRANSACCIONES ============
        function renderTransactionsList() {
            const transactionsContainer = document.getElementById('transactionsList');
            if (!transactionsContainer) return;

            const transactions = [...supplierManager.transactions].sort((a, b) => new Date(b.date) - new Date(a.date));
            if (transactions.length === 0) {
                transactionsContainer.innerHTML = '<p class="text-muted">No hay transacciones registradas.</p>';
                return;
            }

            let html = '';
            transactions.forEach(transaction => {
                const supplier = supplierManager.getSupplierById(transaction.supplierId);
                if (!supplier) return;
                const amountClass = transaction.type === 'payment' ? 'transaction-negative' : 'transaction-positive';
                html += `
                    <div class="transaction-item">
                        <div class="transaction-info">
                            <div><strong>${transaction.description}</strong></div>
                            <div class="text-muted small">${supplier.name} - ${transaction.date}</div>
                        </div>
                        <div class="transaction-amount ${amountClass}">
                            ${transaction.type === 'payment' ? '-' : '+'}$${transaction.amount.toFixed(2)}
                        </div>
                    </div>`;
            });
            transactionsContainer.innerHTML = html;
        }

        // ============ RECORDATORIOS ============
        function renderRemindersList() {
            const remindersContainer = document.getElementById('remindersList');
            if (!remindersContainer) return;

            const reminders = [...supplierManager.reminders].sort((a, b) => new Date(a.date) - new Date(b.date));
            if (reminders.length === 0) {
                remindersContainer.innerHTML = '<p class="text-muted">No hay recordatorios registrados.</p>';
                return;
            }

            let html = '';
            reminders.forEach(reminder => {
                const supplier = supplierManager.getSupplierById(reminder.supplierId);
                if (!supplier) return;
                const isOverdue = new Date(reminder.date) < new Date();
                html += `
                    <div class="reminder-item">
                        <div class="reminder-info">
                            <div><strong>${reminder.title}</strong></div>
                            <div class="text-muted small">${supplier.name}</div>
                            <div class="small">${reminder.description || ''}</div>
                        </div>
                        <div class="reminder-date ${isOverdue ? 'text-danger' : ''}">
                            ${isOverdue ? 'Vencido: ' : 'Vence: '}${reminder.date}
                        </div>
                        <div class="reminder-actions">
                            <button class="btn btn-sm btn-success" onclick="completeReminder('${reminder.id}')">
                                <i class="fas fa-check"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deleteReminder('${reminder.id}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>`;
            });
            remindersContainer.innerHTML = html;
        }

        function completeReminder(reminderId) {
            const index = supplierManager.reminders.findIndex(r => r.id === reminderId);
            if (index !== -1) {
                supplierManager.reminders.splice(index, 1);
                supplierManager.saveReminders();
                renderRemindersList();
                supplierManager.showNotification('Recordatorio completado', 'success');
            }
        }

        function deleteReminder(reminderId) {
            if (confirm('¿Estás seguro de que deseas eliminar este recordatorio?')) {
                const index = supplierManager.reminders.findIndex(r => r.id === reminderId);
                if (index !== -1) {
                    supplierManager.reminders.splice(index, 1);
                    supplierManager.saveReminders();
                    renderRemindersList();
                    supplierManager.showNotification('Recordatorio eliminado', 'success');
                }
            }
        }

        function openNewReminderModal() {
            document.getElementById('reminderForm').reset();
            new bootstrap.Modal(document.getElementById('reminderModal')).show();
        }

        function saveReminder() {
            const form = document.getElementById('reminderForm');
            if (!form.checkValidity()) { form.reportValidity(); return; }

            supplierManager.addReminder({
                supplierId: document.getElementById('reminderSupplier').value,
                title: document.getElementById('reminderTitle').value,
                date: document.getElementById('reminderDate').value,
                description: document.getElementById('reminderDescription').value
            });

            bootstrap.Modal.getInstance(document.getElementById('reminderModal')).hide();
            renderRemindersList();
        }

        // ============ FILTROS ============
        function clearFilters() {
            document.getElementById('searchSupplierInput').value = '';
            document.getElementById('statusFilter').value = 'all';
            document.getElementById('categoryFilter').value = 'all';
            supplierManager.currentPage = 1;
            renderSuppliersTable();
        }

        function globalSearch() {
            document.getElementById('searchSupplierInput').value = document.getElementById('globalSearch').value;
            supplierManager.currentPage = 1;
            renderSuppliersTable();
            switchTab('suppliers');
        }

        // Cerrar dropdown de notificaciones al hacer clic fuera
        document.addEventListener('click', function(event) {
            const notificationBtn = document.getElementById('notificationBtn');
            const notificationDropdown = document.getElementById('notificationDropdown');
            if (notificationBtn && notificationDropdown) {
                if (!notificationBtn.contains(event.target) && !notificationDropdown.contains(event.target)) {
                    notificationDropdown.classList.remove('show');
                }
            }
        });

        // ============ INICIALIZACIÓN ============
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            }

            // Renderizado inicial
            renderSuppliersTable();
            updateDashboardStats();
            updateNotifications();
            populateDropdowns();
            renderPerformanceMetrics();
            renderLowStockAlerts();
            renderEvaluationHistory();
            renderOrdersList();
            renderDocumentsList();
            renderContactsList();
            renderTransactionsList();
            renderRemindersList();

            // ============ EVENT LISTENERS ============

            // Tema y menú
            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            document.getElementById('menuToggle').addEventListener('click', toggleMenu);
            document.getElementById('sidebarToggle').addEventListener('click', toggleSidebarSimple);
            document.getElementById('notificationBtn').addEventListener('click', function(e) {
                e.stopPropagation();
                toggleNotifications();
            });

            // Logout
            document.getElementById('logoutBtn').addEventListener('click', function() {
                if (confirm('¿Desea cerrar la sesión actual?')) {
                    localStorage.removeItem('currentUser');
                    window.location.href = 'http://localhost/SmartStockAI/login.php';
                }
            });

            // Botones de proveedor
            document.getElementById('saveSupplier').addEventListener('click', saveSupplier);
            document.getElementById('newSupplierBtn').addEventListener('click', openNewSupplierModal);
            document.getElementById('importSuppliersBtn').addEventListener('click', importSuppliers);
            document.getElementById('exportPdfBtn').addEventListener('click', () => supplierManager.exportToPDF());
            document.getElementById('exportCsvBtn').addEventListener('click', () => supplierManager.exportToCSV());
            document.getElementById('exportExcelBtn').addEventListener('click', () => supplierManager.exportToExcel());
            document.getElementById('clearFilters').addEventListener('click', clearFilters);

            // Búsqueda global
            document.getElementById('globalSearch').addEventListener('keyup', function(e) {
                if (e.key === 'Enter') globalSearch();
            });

            // Filtros de la tabla
            document.getElementById('searchSupplierInput').addEventListener('input', function() {
                supplierManager.currentPage = 1;
                renderSuppliersTable();
            });
            document.getElementById('statusFilter').addEventListener('change', function() {
                supplierManager.currentPage = 1;
                renderSuppliersTable();
            });
            document.getElementById('categoryFilter').addEventListener('change', function() {
                supplierManager.currentPage = 1;
                renderSuppliersTable();
            });

            // Tabs
            document.querySelectorAll('.custom-tab').forEach(tab => {
                tab.addEventListener('click', function() {
                    switchTab(this.getAttribute('data-tab'));
                });
            });

            // Evaluación
            document.getElementById('evaluationSupplier').addEventListener('change', handleEvaluationSupplierChange);
            document.querySelectorAll('.criteria-rating .star').forEach(star => {
                star.addEventListener('click', handleStarClick);
            });
            document.getElementById('saveEvaluation').addEventListener('click', saveEvaluation);

            // Pedidos
            document.getElementById('newOrderBtn').addEventListener('click', openNewOrderModal);
            document.getElementById('addProductBtn').addEventListener('click', addProductToOrder);
            document.getElementById('saveOrder').addEventListener('click', saveOrder);

            // Documentos
            document.getElementById('uploadDocumentBtn').addEventListener('click', openUploadDocumentModal);
            document.getElementById('uploadDocument').addEventListener('click', uploadDocument);

            // Comunicación
            document.getElementById('communicationSupplier').addEventListener('change', handleCommunicationSupplierChange);
            document.getElementById('sendMessageBtn').addEventListener('click', sendMessage);

            // Recordatorios
            document.getElementById('newReminderBtn').addEventListener('click', openNewReminderModal);
            document.getElementById('saveReminder').addEventListener('click', saveReminder);

            // Modal de proveedor - resetear al abrir para nuevo
            document.getElementById('supplierModal').addEventListener('show.bs.modal', function(event) {
                if (!event.relatedTarget || !event.relatedTarget.classList.contains('btn-edit')) {
                    document.getElementById('supplierModalTitle').textContent = 'Agregar Nuevo Proveedor';
                }
            });

            // Actualizar notificaciones cada 30 segundos
            setInterval(updateNotifications, 30000);
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>