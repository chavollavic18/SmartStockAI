<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>SmartStock AI - Iniciar Sesión</title>
    <meta name="description" content="Sistema de Gestión de Inventarios Inteligente con IA Predictiva">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* ============================================================
           VARIABLES
           ============================================================ */
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --primary-light: rgba(58, 94, 199, 0.12);
            --secondary: #10b981;
            --secondary-light: rgba(16, 185, 129, 0.12);
            --danger: #ef4444;
            --danger-light: rgba(239, 68, 68, 0.12);
            --warning: #f59e0b;
            --warning-light: rgba(245, 158, 11, 0.12);
            --info: #06b6d4;
            --info-light: rgba(6, 182, 212, 0.12);

            --bg: #f3f4f6;
            --card-bg: #ffffff;
            --card-border: #e2e8f0;
            --text-main: #1e293b;
            --text-muted: #64748b;

            --gradient-brand: linear-gradient(135deg, #3a5ec7 0%, #6d28d9 50%, #ec4899 100%);
            --gradient-dark: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #312e81 100%);

            --border-radius-sm: 10px;
            --border-radius: 16px;
            --border-radius-lg: 24px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --transition-fast: all 0.15s cubic-bezier(0.4, 0, 0.2, 1);
            --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.04);
            --shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.18);
            --font-main: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;

            /* Safe areas para iPhone */
            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }

        .dark-mode {
            --bg: #0b0f19;
            --card-bg: #151c2c;
            --card-border: #232d42;
            --text-main: #f1f5f9;
            --text-muted: #94a3b8;
            --shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.5);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.8);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: var(--font-main); }

        html, body { height: 100%; }

        body {
            background: var(--bg);
            color: var(--text-main);
            transition: var(--transition);
            min-height: 100vh;
            min-height: 100dvh;
            overflow-x: hidden;
            /* Prevenir zoom en iOS al tocar inputs */
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: transparent;
        }

        /* ============================================================
           LAYOUT PRINCIPAL (Split Screen en desktop)
           ============================================================ */
        .login-wrapper {
            display: grid;
            grid-template-columns: 1.1fr 1fr;
            min-height: 100vh;
            min-height: 100dvh;
            position: relative;
        }

        /* ============================================================
           PANEL IZQUIERDO (Branding)
           ============================================================ */
        .brand-panel {
            background: var(--gradient-dark);
            color: white;
            padding: 48px 56px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        .brand-panel::before {
            content: '';
            position: absolute;
            top: -20%;
            right: -20%;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(58, 94, 199, 0.35) 0%, transparent 70%);
            border-radius: 50%;
            animation: pulseGlow 8s ease-in-out infinite;
        }

        .brand-panel::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -20%;
            width: 500px;
            height: 500px;
            background: radial-gradient(circle, rgba(236, 72, 153, 0.25) 0%, transparent 70%);
            border-radius: 50%;
            animation: pulseGlow 10s ease-in-out infinite reverse;
        }

        @keyframes pulseGlow {
            0%, 100% { transform: scale(1); opacity: 0.8; }
            50% { transform: scale(1.15); opacity: 1; }
        }

        .brand-content {
            position: relative;
            z-index: 2;
            max-width: 520px;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 14px;
            font-size: 24px;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 48px;
        }

        .brand-logo-icon {
            width: 52px;
            height: 52px;
            border-radius: 14px;
            background: var(--gradient-brand);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            box-shadow: 0 8px 24px rgba(58, 94, 199, 0.4);
            animation: floatIcon 4s ease-in-out infinite;
            flex-shrink: 0;
        }

        @keyframes floatIcon {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-6px) rotate(3deg); }
        }

        .brand-headline {
            font-size: 42px;
            font-weight: 800;
            line-height: 1.15;
            letter-spacing: -1px;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #ffffff 0%, #93c5fd 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .brand-subheadline {
            font-size: 16px;
            line-height: 1.6;
            color: rgba(255, 255, 255, 0.75);
            max-width: 480px;
            margin-bottom: 40px;
        }

        /* Features list */
        .brand-features {
            display: flex;
            flex-direction: column;
            gap: 18px;
        }

        .brand-feature {
            display: flex;
            align-items: center;
            gap: 14px;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.9);
            opacity: 0;
            animation: slideInLeft 0.5s ease forwards;
        }

        .brand-feature:nth-child(1) { animation-delay: 0.15s; }
        .brand-feature:nth-child(2) { animation-delay: 0.3s; }
        .brand-feature:nth-child(3) { animation-delay: 0.45s; }
        .brand-feature:nth-child(4) { animation-delay: 0.6s; }

        @keyframes slideInLeft {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .brand-feature-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            color: #93c5fd;
            flex-shrink: 0;
        }

        /* ============================================================
           PANEL DERECHO (Formulario)
           ============================================================ */
        .form-panel {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px;
            padding-top: calc(40px + var(--safe-top));
            padding-bottom: calc(40px + var(--safe-bottom));
            background: var(--bg);
            position: relative;
        }

        .form-container {
            width: 100%;
            max-width: 420px;
            animation: fadeInUp 0.6s ease;
        }

        .form-header {
            margin-bottom: 32px;
        }

        .form-header h1 {
            font-size: 30px;
            font-weight: 800;
            letter-spacing: -0.5px;
            color: var(--text-main);
            margin-bottom: 8px;
        }

        .form-header p {
            font-size: 14px;
            color: var(--text-muted);
            margin: 0;
        }

        .form-header-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: var(--secondary-light);
            color: var(--secondary);
            margin-bottom: 16px;
        }

        /* Form fields */
        .field-group {
            margin-bottom: 20px;
            opacity: 0;
            animation: fadeInUp 0.5s ease forwards;
        }
        .field-group:nth-child(1) { animation-delay: 0.1s; }
        .field-group:nth-child(2) { animation-delay: 0.2s; }
        .field-group:nth-child(3) { animation-delay: 0.3s; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .field-label {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-main);
            margin-bottom: 8px;
            gap: 8px;
            flex-wrap: wrap;
        }

        .field-label a {
            font-size: 12px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition-fast);
        }

        .field-label a:hover { color: var(--primary-dark); text-decoration: underline; }

        .input-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-wrapper i.input-icon {
            position: absolute;
            left: 16px;
            color: var(--text-muted);
            font-size: 15px;
            pointer-events: none;
            transition: var(--transition-fast);
            z-index: 1;
        }

        .form-input {
            width: 100%;
            padding: 14px 16px 14px 46px;
            border: 1.5px solid var(--card-border);
            border-radius: var(--border-radius-sm);
            background: var(--card-bg);
            color: var(--text-main);
            /* 16px previene zoom automático en iOS */
            font-size: 16px;
            font-weight: 500;
            transition: var(--transition-fast);
            outline: none;
            min-height: 52px;
        }

        .form-input::placeholder { color: var(--text-muted); font-weight: 400; }

        .form-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px var(--primary-light);
            background: var(--card-bg);
        }

        .form-input:focus ~ i.input-icon { color: var(--primary); }

        .form-input.error {
            border-color: var(--danger);
            box-shadow: 0 0 0 4px var(--danger-light);
        }

        .form-input.success {
            border-color: var(--secondary);
            box-shadow: 0 0 0 4px var(--secondary-light);
        }

        .input-action {
            position: absolute;
            right: 8px;
            background: transparent;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition-fast);
            z-index: 2;
            touch-action: manipulation;
        }

        .input-action:hover { background: var(--primary-light); color: var(--primary); }
        .input-action:active { background: var(--primary-light); transform: scale(0.95); }

        /* Caps Lock Warning */
        .caps-warning {
            display: none;
            align-items: center;
            gap: 6px;
            font-size: 11px;
            color: var(--warning);
            margin-top: 6px;
            font-weight: 600;
        }
        .caps-warning.show { display: flex; }

        /* Password strength */
        .password-strength-bar {
            height: 4px;
            background: var(--card-border);
            border-radius: 2px;
            overflow: hidden;
            margin-top: 8px;
            display: none;
        }
        .password-strength-bar.show { display: block; }
        .password-strength-fill {
            height: 100%;
            width: 0%;
            transition: width 0.3s ease, background 0.3s ease;
            border-radius: 2px;
        }
        .strength-weak { background: var(--danger); }
        .strength-fair { background: var(--warning); }
        .strength-good { background: var(--info); }
        .strength-strong { background: var(--secondary); }

        .password-strength-text {
            font-size: 11px;
            margin-top: 6px;
            font-weight: 600;
            display: none;
        }
        .password-strength-text.show { display: block; }

        /* Row with remember */
        .form-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
        }

        .checkbox-wrapper {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            user-select: none;
            padding: 4px 0;
            touch-action: manipulation;
        }

        .checkbox-wrapper input[type="checkbox"] {
            appearance: none;
            -webkit-appearance: none;
            width: 20px;
            height: 20px;
            border: 1.5px solid var(--card-border);
            border-radius: 5px;
            background: var(--card-bg);
            cursor: pointer;
            position: relative;
            transition: var(--transition-fast);
            flex-shrink: 0;
        }

        .checkbox-wrapper input[type="checkbox"]:checked {
            background: var(--primary);
            border-color: var(--primary);
        }

        .checkbox-wrapper input[type="checkbox"]:checked::after {
            content: '';
            position: absolute;
            left: 6px;
            top: 2px;
            width: 5px;
            height: 10px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }

        .checkbox-wrapper span {
            font-size: 13px;
            color: var(--text-main);
            font-weight: 500;
        }

        /* Submit button */
        .btn-submit {
            width: 100%;
            padding: 14px 20px;
            border: none;
            border-radius: var(--border-radius-sm);
            background: var(--gradient-brand);
            background-size: 200% 200%;
            color: white;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 8px 20px -5px rgba(58, 94, 199, 0.5);
            letter-spacing: 0.3px;
            min-height: 52px;
            touch-action: manipulation;
        }

        .btn-submit::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent);
            transition: left 0.5s;
        }

        .btn-submit:hover:not(:disabled)::before { left: 100%; }

        .btn-submit:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 12px 28px -5px rgba(58, 94, 199, 0.6);
            background-position: 100% 0;
        }

        .btn-submit:active:not(:disabled) { transform: translateY(0) scale(0.98); }

        .btn-submit:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }

        .spinner {
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            display: none;
        }
        .spinner.show { display: inline-block; }

        @keyframes spin { to { transform: rotate(360deg); } }

        /* Sign up link */
        .signup-prompt {
            text-align: center;
            margin-top: 24px;
            font-size: 13px;
            color: var(--text-muted);
        }

        .signup-prompt a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 700;
            transition: var(--transition-fast);
        }

        .signup-prompt a:hover { color: var(--primary-dark); text-decoration: underline; }

        /* Security badge */
        .security-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-top: 24px;
            padding: 10px 16px;
            border-radius: 20px;
            background: var(--secondary-light);
            color: var(--secondary);
            font-size: 12px;
            font-weight: 600;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
        }

        /* Floating controls */
        .floating-controls {
            position: fixed;
            top: calc(20px + var(--safe-top));
            right: calc(20px + var(--safe-right));
            z-index: 100;
            display: flex;
            gap: 10px;
        }

        .floating-btn {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            color: var(--text-main);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            transition: var(--transition);
            box-shadow: var(--shadow);
            backdrop-filter: blur(10px);
            position: relative;
            touch-action: manipulation;
        }

        .floating-btn:hover {
            transform: translateY(-3px) rotate(8deg);
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .floating-btn:active { transform: scale(0.92); }

        /* Language dropdown */
        .lang-dropdown {
            position: absolute;
            top: 55px;
            right: 0;
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow-lg);
            min-width: 160px;
            overflow: hidden;
            display: none;
            animation: dropdownIn 0.2s ease;
            z-index: 200;
        }

        .lang-dropdown.show { display: block; }

        @keyframes dropdownIn {
            from { opacity: 0; transform: translateY(-8px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .lang-option {
            padding: 12px 16px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: var(--transition-fast);
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--text-main);
        }

        .lang-option:hover { background: var(--primary-light); color: var(--primary); }
        .lang-option.active { background: var(--primary-light); color: var(--primary); font-weight: 700; }

        /* Toast */
        .toast-container {
            position: fixed;
            top: calc(20px + var(--safe-top));
            left: 50%;
            transform: translateX(-50%);
            z-index: 2000;
            display: flex;
            flex-direction: column;
            gap: 10px;
            pointer-events: none;
            max-width: calc(100vw - 32px);
            width: 100%;
            align-items: center;
        }

        .toast {
            background: var(--card-bg);
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow-lg);
            padding: 14px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 280px;
            max-width: 500px;
            width: fit-content;
            animation: toastIn 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
            pointer-events: auto;
            border-left: 4px solid var(--primary);
            color: var(--text-main);
            font-size: 13px;
            font-weight: 600;
        }

        .toast.success { border-left-color: var(--secondary); }
        .toast.error { border-left-color: var(--danger); }
        .toast.warning { border-left-color: var(--warning); }
        .toast.info { border-left-color: var(--info); }

        .toast i { font-size: 18px; flex-shrink: 0; }
        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        .toast.info i { color: var(--info); }

        @keyframes toastIn {
            from { opacity: 0; transform: translateY(-20px) scale(0.95); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes toastOut {
            from { opacity: 1; transform: translateY(0) scale(1); }
            to { opacity: 0; transform: translateY(-20px) scale(0.95); }
        }

        /* Modal */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 1500;
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
            animation: fadeIn 0.25s ease;
        }

        .modal-overlay.show { display: flex; }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        .modal-card {
            background: var(--card-bg);
            border-radius: var(--border-radius-lg);
            border: 1px solid var(--card-border);
            width: 100%;
            max-width: 440px;
            max-height: calc(100vh - 40px);
            max-height: calc(100dvh - 40px);
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            animation: modalPop 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            display: flex;
            flex-direction: column;
        }

        @keyframes modalPop {
            from { opacity: 0; transform: scale(0.92); }
            to { opacity: 1; transform: scale(1); }
        }

        .modal-header {
            padding: 24px 28px 16px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            flex-shrink: 0;
        }

        .modal-header h3 {
            font-size: 19px;
            font-weight: 800;
            color: var(--text-main);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-header h3 i { color: var(--primary); }

        .modal-close {
            background: transparent;
            border: none;
            color: var(--text-muted);
            font-size: 24px;
            cursor: pointer;
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition-fast);
            flex-shrink: 0;
            touch-action: manipulation;
        }

        .modal-close:hover { background: var(--danger-light); color: var(--danger); }
        .modal-close:active { background: var(--danger-light); color: var(--danger); }

        .modal-body {
            padding: 0 28px 24px;
            overflow-y: auto;
            flex: 1;
        }

        .modal-body p {
            font-size: 13px;
            color: var(--text-muted);
            line-height: 1.6;
            margin-bottom: 16px;
        }

        .modal-footer {
            padding: 16px 28px 24px;
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            flex-shrink: 0;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 20px;
            border-radius: var(--border-radius-sm);
            border: none;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: var(--transition-fast);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 8px 20px -5px rgba(58,94,199,0.5); }
        .btn-primary:active { transform: translateY(0) scale(0.98); }
        .btn-secondary { background: var(--card-border); color: var(--text-main); }
        .btn-secondary:hover { background: var(--gray); color: white; }
        .btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

        /* 2FA Step */
        .twofa-container {
            display: none;
            animation: fadeInUp 0.4s ease;
        }
        .twofa-container.show { display: block; }

        .twofa-inputs {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin: 20px 0;
        }

        .twofa-input {
            width: 46px;
            height: 54px;
            border: 1.5px solid var(--card-border);
            border-radius: var(--border-radius-sm);
            background: var(--card-bg);
            color: var(--text-main);
            text-align: center;
            font-size: 20px;
            font-weight: 700;
            transition: var(--transition-fast);
            outline: none;
        }

        .twofa-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px var(--primary-light);
        }

        /* Particles */
        .particles-bg {
            position: absolute;
            inset: 0;
            overflow: hidden;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
            animation: floatUp linear infinite;
        }

        @keyframes floatUp {
            0% { transform: translateY(100vh) scale(0); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100px) scale(1); opacity: 0; }
        }

        /* Loading state for page */
        .page-loader {
            position: fixed;
            inset: 0;
            background: var(--gradient-dark);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.4s ease, visibility 0.4s ease;
        }

        .page-loader.hidden { opacity: 0; visibility: hidden; }

        .loader-logo {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 16px;
            color: white;
        }

        .loader-spinner {
            width: 48px;
            height: 48px;
            border: 3px solid rgba(255, 255, 255, 0.15);
            border-top-color: #60a5fa;
            border-radius: 50%;
            animation: spin 0.9s linear infinite;
        }

        /* ============================================================
           RESPONSIVE - TABLET (≤1024px)
           Branding se convierte en header compacto superior
           ============================================================ */
        @media (max-width: 1024px) {
            .login-wrapper {
                grid-template-columns: 1fr;
                grid-template-rows: auto 1fr;
                min-height: 100vh;
                min-height: 100dvh;
            }

            .brand-panel {
                padding: 32px 32px 24px;
                padding-top: calc(32px + var(--safe-top));
                justify-content: flex-start;
                min-height: auto;
            }

            .brand-content {
                max-width: 100%;
                text-align: center;
            }

            .brand-logo {
                justify-content: center;
                margin-bottom: 20px;
                font-size: 22px;
            }

            .brand-logo-icon {
                width: 44px;
                height: 44px;
                font-size: 20px;
            }

            .brand-headline {
                font-size: 26px;
                margin-bottom: 12px;
                line-height: 1.2;
            }

            .brand-subheadline {
                font-size: 14px;
                margin-bottom: 0;
                max-width: 600px;
                margin-left: auto;
                margin-right: auto;
            }

            .brand-features {
                display: none;
            }

            .form-panel {
                padding: 32px 24px;
                padding-bottom: calc(32px + var(--safe-bottom));
                align-items: flex-start;
            }

            .form-container {
                max-width: 460px;
                padding-top: 16px;
            }

            .floating-controls {
                top: calc(16px + var(--safe-top));
                right: calc(16px + var(--safe-right));
            }
        }

        /* ============================================================
           RESPONSIVE - MÓVIL (≤640px)
           ============================================================ */
        @media (max-width: 640px) {
            .brand-panel {
                padding: 24px 20px 18px;
                padding-top: calc(24px + var(--safe-top));
            }

            .brand-logo {
                margin-bottom: 14px;
                font-size: 20px;
                gap: 10px;
            }

            .brand-logo-icon {
                width: 40px;
                height: 40px;
                font-size: 18px;
                border-radius: 12px;
            }

            .brand-headline {
                font-size: 22px;
                margin-bottom: 8px;
                letter-spacing: -0.5px;
            }

            .brand-subheadline {
                font-size: 13px;
                line-height: 1.5;
            }

            .form-panel {
                padding: 24px 20px;
                padding-bottom: calc(24px + var(--safe-bottom));
            }

            .form-container {
                padding-top: 8px;
            }

            .form-header {
                margin-bottom: 24px;
            }

            .form-header h1 {
                font-size: 24px;
            }

            .form-header p {
                font-size: 13px;
            }

            .form-header-badge {
                font-size: 10px;
                padding: 3px 10px;
            }

            .field-group {
                margin-bottom: 16px;
            }

            .form-input {
                padding: 13px 14px 13px 44px;
                font-size: 16px; /* evita zoom en iOS */
                min-height: 50px;
            }

            .input-wrapper i.input-icon {
                left: 14px;
                font-size: 14px;
            }

            .input-action {
                width: 38px;
                height: 38px;
                right: 6px;
            }

            .form-row {
                margin-bottom: 20px;
            }

            .checkbox-wrapper span {
                font-size: 13px;
            }

            .btn-submit {
                font-size: 14px;
                min-height: 50px;
                padding: 13px 16px;
            }

            .signup-prompt {
                font-size: 12.5px;
                margin-top: 20px;
            }

            .security-badge {
                font-size: 11px;
                padding: 8px 14px;
                margin-top: 20px;
            }

            /* Floating controls más pequeños y compactos */
            .floating-controls {
                top: calc(12px + var(--safe-top));
                right: calc(12px + var(--safe-right));
                gap: 8px;
            }

            .floating-btn {
                width: 40px;
                height: 40px;
                font-size: 14px;
            }

            /* Toast full width */
            .toast-container {
                top: calc(12px + var(--safe-top));
                max-width: calc(100vw - 24px);
                padding: 0 12px;
            }

            .toast {
                min-width: auto;
                width: 100%;
                max-width: 100%;
                padding: 12px 16px;
                font-size: 12.5px;
            }

            /* Modales compactos */
            .modal-overlay {
                padding: 16px;
                padding-top: calc(16px + var(--safe-top));
                padding-bottom: calc(16px + var(--safe-bottom));
                align-items: flex-end;
            }

            .modal-card {
                max-width: 100%;
                border-radius: 20px 20px 0 0;
                max-height: calc(100dvh - 32px);
            }

            .modal-header {
                padding: 20px 20px 12px;
            }

            .modal-header h3 {
                font-size: 17px;
            }

            .modal-body {
                padding: 0 20px 16px;
            }

            .modal-footer {
                padding: 12px 20px 20px;
                flex-direction: column-reverse;
            }

            .modal-footer .btn {
                width: 100%;
            }

            /* 2FA inputs más compactos */
            .twofa-inputs {
                gap: 6px;
                margin: 16px 0;
            }

            .twofa-input {
                width: 42px;
                height: 50px;
                font-size: 18px;
            }
        }

        /* ============================================================
           RESPONSIVE - MÓVIL PEQUEÑO (≤380px)
           ============================================================ */
        @media (max-width: 380px) {
            .brand-headline {
                font-size: 19px;
            }

            .brand-subheadline {
                font-size: 12px;
            }

            .form-header h1 {
                font-size: 22px;
            }

            .twofa-input {
                width: 36px;
                height: 46px;
                font-size: 16px;
            }

            .twofa-inputs {
                gap: 4px;
            }
        }

        /* ============================================================
           LANDSCAPE EN MÓVIL - Optimización
           ============================================================ */
        @media (max-height: 500px) and (orientation: landscape) {
            .brand-panel {
                padding: 16px 24px;
                padding-top: calc(16px + var(--safe-top));
            }

            .brand-logo {
                margin-bottom: 8px;
                font-size: 18px;
            }

            .brand-logo-icon {
                width: 34px;
                height: 34px;
                font-size: 15px;
            }

            .brand-headline {
                font-size: 18px;
                margin-bottom: 4px;
            }

            .brand-subheadline {
                display: none;
            }

            .form-panel {
                padding: 16px 20px;
                padding-bottom: calc(16px + var(--safe-bottom));
            }

            .form-header {
                margin-bottom: 16px;
            }

            .form-header h1 {
                font-size: 20px;
            }

            .field-group {
                margin-bottom: 12px;
            }

            .form-input {
                min-height: 44px;
                padding: 10px 14px 10px 42px;
            }

            .btn-submit {
                min-height: 44px;
            }

            .brand-features { display: none; }
        }

        /* ============================================================
           PANTALLAS GRANDES (≥1440px) - Más espaciado
           ============================================================ */
        @media (min-width: 1440px) {
            .brand-panel {
                padding: 60px 80px;
            }

            .brand-headline {
                font-size: 48px;
            }

            .brand-subheadline {
                font-size: 17px;
            }

            .form-panel {
                padding: 60px;
            }

            .form-container {
                max-width: 440px;
            }

            .form-header h1 {
                font-size: 32px;
            }
        }

        /* ============================================================
           REDUCED MOTION - Accesibilidad
           ============================================================ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }

        /* ============================================================
           HOVER DESHABILITADO EN TOUCH
           ============================================================ */
        @media (hover: none) {
            .floating-btn:hover {
                transform: none;
                background: var(--card-bg);
                color: var(--text-main);
                border-color: var(--card-border);
            }

            .btn-submit:hover:not(:disabled) {
                transform: none;
                box-shadow: 0 8px 20px -5px rgba(58, 94, 199, 0.5);
            }

            .brand-feature:hover { transform: none; }
        }
    </style>
</head>
<body>

    <!-- Page Loader -->
    <div class="page-loader" id="pageLoader">
        <div class="loader-logo">
            <div class="loader-spinner"></div>
            <span style="font-weight: 700; font-size: 14px; letter-spacing: 1px;">Cargando SmartStock AI...</span>
        </div>
    </div>

    <!-- Floating controls -->
    <div class="floating-controls">
        <button class="floating-btn" id="themeToggle" title="Cambiar tema" aria-label="Cambiar tema">
            <i class="fas fa-moon"></i>
        </button>
        <div style="position: relative;">
            <button class="floating-btn" id="langToggle" title="Cambiar idioma" aria-label="Cambiar idioma">
                <i class="fas fa-globe"></i>
            </button>
            <div class="lang-dropdown" id="langDropdown">
                <div class="lang-option active" data-lang="es"><span>🇲🇽</span> Español</div>
                <div class="lang-option" data-lang="en"><span>🇺🇸</span> English</div>
                <div class="lang-option" data-lang="pt"><span>🇧🇷</span> Português</div>
            </div>
        </div>
        <button class="floating-btn" id="helpBtn" title="Centro de ayuda" aria-label="Centro de ayuda">
            <i class="fas fa-question"></i>
        </button>
    </div>

    <!-- Login Layout -->
    <div class="login-wrapper">

        <!-- ============================================================
             PANEL IZQUIERDO - Branding
             ============================================================ -->
        <div class="brand-panel">
            <div class="particles-bg" id="particles"></div>

            <div class="brand-content">
                <div class="brand-logo">
                    <div class="brand-logo-icon">
                        <i class="fas fa-brain"></i>
                    </div>
                    <span>SmartStock AI</span>
                </div>

                <h1 class="brand-headline">
                    Gestiona tu inventario con el poder de la Inteligencia Artificial
                </h1>

                <p class="brand-subheadline">
                    Sistema empresarial de gestión de inventarios con predicciones inteligentes,
                    análisis en tiempo real y control total de tus operaciones.
                </p>

                <div class="brand-features">
                    <div class="brand-feature">
                        <div class="brand-feature-icon"><i class="fas fa-chart-line"></i></div>
                        <span>Predicciones de demanda con Machine Learning</span>
                    </div>
                    <div class="brand-feature">
                        <div class="brand-feature-icon"><i class="fas fa-bolt"></i></div>
                        <span>Procesamiento en tiempo real de transacciones</span>
                    </div>
                    <div class="brand-feature">
                        <div class="brand-feature-icon"><i class="fas fa-shield-halved"></i></div>
                        <span>Seguridad de nivel empresarial AES-256</span>
                    </div>
                    <div class="brand-feature">
                        <div class="brand-feature-icon"><i class="fas fa-cloud"></i></div>
                        <span>Sincronización multi-sucursal en la nube</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- ============================================================
             PANEL DERECHO - Formulario
             ============================================================ -->
        <div class="form-panel">
            <div class="form-container">

                <div class="form-header">
                    <div class="form-header-badge">
                        <i class="fas fa-lock"></i> Acceso Seguro
                    </div>
                    <h1 id="welcomeTitle">Bienvenido de nuevo</h1>
                    <p id="welcomeSubtitle">Ingresa tus credenciales para continuar</p>
                </div>

                <!-- ============ FORMULARIO LOGIN ============ -->
                <form id="loginForm" autocomplete="on">

                    <!-- Usuario -->
                    <div class="field-group">
                        <label class="field-label" for="nombre_usuario">
                            <span data-i18n="username">Usuario</span>
                        </label>
                        <div class="input-wrapper">
                            <i class="fas fa-user input-icon"></i>
                            <input
                                type="text"
                                class="form-input"
                                id="nombre_usuario"
                                name="nombre_usuario"
                                placeholder="Ingresa tu usuario"
                                autocomplete="username"
                                autocapitalize="off"
                                autocorrect="off"
                                spellcheck="false"
                                required
                            >
                        </div>
                    </div>

                    <!-- Contraseña -->
                    <div class="field-group">
                        <label class="field-label" for="password">
                            <span data-i18n="password">Contraseña</span>
                            <a href="#" id="forgotPassword" data-i18n="forgot">¿Olvidaste tu contraseña?</a>
                        </label>
                        <div class="input-wrapper">
                            <i class="fas fa-lock input-icon"></i>
                            <input
                                type="password"
                                class="form-input"
                                id="password"
                                name="password"
                                placeholder="Ingresa tu contraseña"
                                autocomplete="current-password"
                                required
                            >
                            <button type="button" class="input-action" id="togglePassword" aria-label="Mostrar contraseña">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="caps-warning" id="capsWarning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span>Bloq Mayús está activado</span>
                        </div>
                        <div class="password-strength-bar" id="passwordStrengthBar">
                            <div class="password-strength-fill" id="passwordStrengthFill"></div>
                        </div>
                        <div class="password-strength-text" id="passwordStrengthText"></div>
                    </div>

                    <!-- Remember -->
                    <div class="form-row">
                        <label class="checkbox-wrapper">
                            <input type="checkbox" id="rememberMe" name="rememberMe">
                            <span data-i18n="remember">Recordar mi usuario</span>
                        </label>
                    </div>

                    <!-- Submit -->
                    <button type="submit" class="btn-submit" id="loginButton">
                        <span class="spinner" id="loginSpinner"></span>
                        <i class="fas fa-right-to-bracket" id="loginIcon"></i>
                        <span id="loginButtonText" data-i18n="signin">Iniciar Sesión</span>
                    </button>
                </form>

                <!-- ============ 2FA STEP (oculto por defecto) ============ -->
                <div class="twofa-container" id="twofaContainer">
                    <div style="text-align: center; margin-bottom: 8px;">
                        <div style="width: 64px; height: 64px; margin: 0 auto 16px; border-radius: 50%; background: var(--primary-light); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 26px;">
                            <i class="fas fa-shield-halved"></i>
                        </div>
                        <h3 style="font-size: 20px; font-weight: 800; margin-bottom: 6px; color: var(--text-main);">
                            Verificación en 2 pasos
                        </h3>
                        <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 4px;">
                            Ingresa el código de 6 dígitos de tu aplicación autenticadora
                        </p>
                    </div>

                    <div class="twofa-inputs">
                        <input type="text" maxlength="1" class="twofa-input" inputmode="numeric" pattern="[0-9]" data-index="0">
                        <input type="text" maxlength="1" class="twofa-input" inputmode="numeric" pattern="[0-9]" data-index="1">
                        <input type="text" maxlength="1" class="twofa-input" inputmode="numeric" pattern="[0-9]" data-index="2">
                        <input type="text" maxlength="1" class="twofa-input" inputmode="numeric" pattern="[0-9]" data-index="3">
                        <input type="text" maxlength="1" class="twofa-input" inputmode="numeric" pattern="[0-9]" data-index="4">
                        <input type="text" maxlength="1" class="twofa-input" inputmode="numeric" pattern="[0-9]" data-index="5">
                    </div>

                    <button type="button" class="btn-submit" id="verify2faBtn">
                        <i class="fas fa-check"></i>
                        <span>Verificar Código</span>
                    </button>

                    <div style="text-align: center; margin-top: 16px;">
                        <a href="#" id="backToLogin" style="font-size: 13px; color: var(--primary); text-decoration: none; font-weight: 600;">
                            <i class="fas fa-arrow-left"></i> Volver al inicio de sesión
                        </a>
                    </div>
                </div>

                <!-- Sign up -->
                <div class="signup-prompt">
                    <span data-i18n="noaccount">¿No tienes una cuenta?</span>
                    <a href="#" id="requestAccess" data-i18n="requestaccess">Solicitar acceso</a>
                </div>

                <!-- Security badge -->
                <div class="security-badge">
                    <i class="fas fa-shield-alt"></i>
                    <span data-i18n="secured">Sistema protegido con encriptación SSL</span>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================
         MODAL: RECUPERAR CONTRASEÑA
         ============================================================ -->
    <div class="modal-overlay" id="forgotModal">
        <div class="modal-card">
            <div class="modal-header">
                <h3><i class="fas fa-key"></i> Recuperar Contraseña</h3>
                <button class="modal-close" data-close="forgotModal" aria-label="Cerrar">&times;</button>
            </div>
            <div class="modal-body">
                <p>Ingresa tu correo corporativo y te enviaremos un enlace seguro para restablecer tu contraseña.</p>
                <div class="field-group" style="animation: none; opacity: 1;">
                    <label class="field-label" for="recoveryEmail">Correo Corporativo</label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope input-icon"></i>
                        <input type="email" class="form-input" id="recoveryEmail" placeholder="tu@empresa.com" inputmode="email" autocapitalize="off" autocorrect="off">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-close="forgotModal">Cancelar</button>
                <button class="btn btn-primary" id="sendRecoveryBtn">
                    <i class="fas fa-paper-plane"></i> Enviar Enlace
                </button>
            </div>
        </div>
    </div>

    <!-- ============================================================
         MODAL: SOLICITAR ACCESO
         ============================================================ -->
    <div class="modal-overlay" id="requestAccessModal">
        <div class="modal-card">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> Solicitar Acceso</h3>
                <button class="modal-close" data-close="requestAccessModal" aria-label="Cerrar">&times;</button>
            </div>
            <div class="modal-body">
                <p>Completa el formulario y un administrador revisará tu solicitud en las próximas 24 horas.</p>
                <div class="field-group" style="animation: none; opacity: 1; margin-bottom: 12px;">
                    <label class="field-label" for="reqName">Nombre Completo</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" class="form-input" id="reqName" placeholder="Juan Pérez" autocapitalize="words">
                    </div>
                </div>
                <div class="field-group" style="animation: none; opacity: 1;">
                    <label class="field-label" for="reqEmail">Correo Corporativo</label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope input-icon"></i>
                        <input type="email" class="form-input" id="reqEmail" placeholder="tu@empresa.com" inputmode="email" autocapitalize="off" autocorrect="off">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-close="requestAccessModal">Cancelar</button>
                <button class="btn btn-primary" id="sendRequestBtn">
                    <i class="fas fa-paper-plane"></i> Enviar Solicitud
                </button>
            </div>
        </div>
    </div>

    <!-- ============================================================
         MODAL: CENTRO DE AYUDA
         ============================================================ -->
    <div class="modal-overlay" id="helpModal">
        <div class="modal-card">
            <div class="modal-header">
                <h3><i class="fas fa-life-ring"></i> Centro de Ayuda</h3>
                <button class="modal-close" data-close="helpModal" aria-label="Cerrar">&times;</button>
            </div>
            <div class="modal-body">
                <div style="display: grid; gap: 12px;">
                    <a href="#" style="display: flex; align-items: center; gap: 12px; padding: 14px; border-radius: 10px; background: var(--bg); text-decoration: none; color: var(--text-main); transition: all 0.2s;" onmouseover="this.style.background='var(--primary-light)'" onmouseout="this.style.background='var(--bg)'">
                        <i class="fas fa-book" style="color: var(--primary); font-size: 18px;"></i>
                        <div style="flex: 1;">
                            <div style="font-weight: 700; font-size: 13px;">Documentación</div>
                            <div style="font-size: 11px; color: var(--text-muted);">Guías y manuales del sistema</div>
                        </div>
                        <i class="fas fa-chevron-right" style="color: var(--text-muted); font-size: 12px;"></i>
                    </a>
                    <a href="#" style="display: flex; align-items: center; gap: 12px; padding: 14px; border-radius: 10px; background: var(--bg); text-decoration: none; color: var(--text-main); transition: all 0.2s;" onmouseover="this.style.background='var(--primary-light)'" onmouseout="this.style.background='var(--bg)'">
                        <i class="fas fa-headset" style="color: var(--secondary); font-size: 18px;"></i>
                        <div style="flex: 1;">
                            <div style="font-weight: 700; font-size: 13px;">Soporte Técnico</div>
                            <div style="font-size: 11px; color: var(--text-muted);">Contacta a nuestro equipo 24/7</div>
                        </div>
                        <i class="fas fa-chevron-right" style="color: var(--text-muted); font-size: 12px;"></i>
                    </a>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" data-close="helpModal">Cerrar</button>
            </div>
        </div>
    </div>

    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // ============================================================
        // ESTADO GLOBAL
        // ============================================================
        const APP_STATE = {
            currentLang: localStorage.getItem('appLanguage') || 'es',
            loginAttempts: parseInt(sessionStorage.getItem('loginAttempts') || '0'),
            lockedUntil: parseInt(sessionStorage.getItem('lockedUntil') || '0'),
            currentUser: null,
            isMobile: window.matchMedia('(max-width: 640px)').matches
        };

        const MAX_ATTEMPTS = 5;
        const LOCK_DURATION_MS = 30 * 1000;

        // Traducciones
        const TRANSLATIONS = {
            es: {
                username: 'Usuario',
                password: 'Contraseña',
                forgot: '¿Olvidaste tu contraseña?',
                remember: 'Recordar mi usuario',
                signin: 'Iniciar Sesión',
                noaccount: '¿No tienes una cuenta?',
                requestaccess: 'Solicitar acceso',
                secured: 'Sistema protegido con encriptación SSL',
                welcomeTitle: 'Bienvenido de nuevo',
                welcomeSubtitle: 'Ingresa tus credenciales para continuar'
            },
            en: {
                username: 'Username',
                password: 'Password',
                forgot: 'Forgot your password?',
                remember: 'Remember me',
                signin: 'Sign In',
                noaccount: "Don't have an account?",
                requestaccess: 'Request access',
                secured: 'System protected with SSL encryption',
                welcomeTitle: 'Welcome back',
                welcomeSubtitle: 'Enter your credentials to continue'
            },
            pt: {
                username: 'Usuário',
                password: 'Senha',
                forgot: 'Esqueceu sua senha?',
                remember: 'Lembrar de mim',
                signin: 'Entrar',
                noaccount: 'Não tem uma conta?',
                requestaccess: 'Solicitar acesso',
                secured: 'Sistema protegido com criptografia SSL',
                welcomeTitle: 'Bem-vindo de volta',
                welcomeSubtitle: 'Insira suas credenciais para continuar'
            }
        };

        // ============================================================
        // HELPERS
        // ============================================================
        const $ = (sel, ctx = document) => ctx.querySelector(sel);
        const $$ = (sel, ctx = document) => ctx.querySelectorAll(sel);

        // ============================================================
        // TOAST SYSTEM
        // ============================================================
        function showToast(message, type = 'info', duration = 3500) {
            const container = $('#toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;

            const icons = {
                success: 'fa-check-circle',
                error: 'fa-exclamation-circle',
                warning: 'fa-exclamation-triangle',
                info: 'fa-info-circle'
            };

            toast.innerHTML = `
                <i class="fas ${icons[type] || icons.info}"></i>
                <span>${message}</span>
            `;

            container.appendChild(toast);

            setTimeout(() => {
                toast.style.animation = 'toastOut 0.3s forwards';
                setTimeout(() => toast.remove(), 300);
            }, duration);
        }

        // ============================================================
        // THEME
        // ============================================================
        function applyTheme() {
            const settings = JSON.parse(localStorage.getItem('globalSettings')) || {};
            const savedTheme = settings.darkMode ? 'dark' : (localStorage.getItem('theme') || 'light');

            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
                const icon = $('#themeToggle i');
                if (icon) icon.className = 'fas fa-sun';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#0b0f19');
            } else {
                document.body.classList.remove('dark-mode');
                const icon = $('#themeToggle i');
                if (icon) icon.className = 'fas fa-moon';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#3a5ec7');
            }

            const colors = {
                blue: '#3a5ec7', green: '#28a745', red: '#dc3545',
                purple: '#6f42c1', orange: '#fd7e14', teal: '#20c997'
            };
            const primaryColor = colors[settings.themeColor] || localStorage.getItem('primaryColor') || '#3a5ec7';
            document.documentElement.style.setProperty('--primary', primaryColor);
            document.documentElement.style.setProperty('--primary-dark', primaryColor);
        }

        function toggleTheme() {
            const isDark = document.body.classList.toggle('dark-mode');
            const icon = $('#themeToggle i');
            if (icon) icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';

            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            const settings = JSON.parse(localStorage.getItem('globalSettings')) || {};
            settings.darkMode = isDark;
            localStorage.setItem('globalSettings', JSON.stringify(settings));

            document.querySelector('meta[name="theme-color"]')?.setAttribute('content', isDark ? '#0b0f19' : '#3a5ec7');

            showToast(isDark ? 'Modo oscuro activado' : 'Modo claro activado', 'info', 2000);

            // Vibración en móvil (si está soportado)
            if (APP_STATE.isMobile && navigator.vibrate) navigator.vibrate(10);
        }

        // ============================================================
        // LANGUAGE
        // ============================================================
        function applyLanguage(lang) {
            APP_STATE.currentLang = lang;
            localStorage.setItem('appLanguage', lang);

            const t = TRANSLATIONS[lang] || TRANSLATIONS.es;

            $$('[data-i18n]').forEach(el => {
                const key = el.getAttribute('data-i18n');
                if (t[key]) el.textContent = t[key];
            });

            const usernameInput = $('#nombre_usuario');
            const passwordInput = $('#password');
            if (usernameInput) {
                usernameInput.placeholder = {
                    es: 'Ingresa tu usuario',
                    en: 'Enter your username',
                    pt: 'Digite seu usuário'
                }[lang] || 'Ingresa tu usuario';
            }
            if (passwordInput) {
                passwordInput.placeholder = {
                    es: 'Ingresa tu contraseña',
                    en: 'Enter your password',
                    pt: 'Digite sua senha'
                }[lang] || 'Ingresa tu contraseña';
            }

            $$('.lang-option').forEach(opt => {
                opt.classList.toggle('active', opt.dataset.lang === lang);
            });

            document.documentElement.lang = lang;
        }

        // ============================================================
        // PARTICLES - Reducido en móvil para rendimiento
        // ============================================================
        function createParticles() {
            const container = $('#particles');
            if (!container) return;

            // Menos partículas en móvil para mejor rendimiento
            const count = APP_STATE.isMobile ? 8 : 20;

            for (let i = 0; i < count; i++) {
                const p = document.createElement('div');
                p.className = 'particle';
                const size = Math.random() * 6 + 2;
                p.style.width = size + 'px';
                p.style.height = size + 'px';
                p.style.left = Math.random() * 100 + '%';
                p.style.animationDuration = (Math.random() * 15 + 12) + 's';
                p.style.animationDelay = (Math.random() * 10) + 's';
                container.appendChild(p);
            }
        }

        // ============================================================
        // COOKIES
        // ============================================================
        function setCookie(name, value, days = 30) {
            const expires = new Date(Date.now() + days * 864e5).toUTCString();
            document.cookie = `${name}=${encodeURIComponent(value)}; expires=${expires}; path=/; SameSite=Lax`;
        }

        function getCookie(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) return decodeURIComponent(parts.pop().split(';').shift());
            return null;
        }

        function deleteCookie(name) {
            document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
        }

        // ============================================================
        // PASSWORD STRENGTH
        // ============================================================
        function checkPasswordStrength(password) {
            const bar = $('#passwordStrengthBar');
            const fill = $('#passwordStrengthFill');
            const text = $('#passwordStrengthText');

            if (!password) {
                bar.classList.remove('show');
                text.classList.remove('show');
                return 0;
            }

            bar.classList.add('show');
            text.classList.add('show');

            let score = 0;
            if (password.length >= 8) score += 20;
            if (password.length >= 12) score += 10;
            if (/\d/.test(password)) score += 20;
            if (/[a-z]/.test(password)) score += 15;
            if (/[A-Z]/.test(password)) score += 15;
            if (/[^A-Za-z0-9]/.test(password)) score += 20;

            fill.style.width = Math.min(score, 100) + '%';

            let cls, label;
            if (score < 40) { cls = 'strength-weak'; label = 'Contraseña débil'; }
            else if (score < 65) { cls = 'strength-fair'; label = 'Contraseña regular'; }
            else if (score < 85) { cls = 'strength-good'; label = 'Contraseña buena'; }
            else { cls = 'strength-strong'; label = 'Contraseña fuerte'; }

            fill.className = 'password-strength-fill ' + cls;
            text.textContent = label;
            text.style.color = `var(--${cls === 'strength-weak' ? 'danger' : cls === 'strength-fair' ? 'warning' : cls === 'strength-good' ? 'info' : 'secondary'})`;

            return score;
        }

        // ============================================================
        // CAPS LOCK DETECTION
        // ============================================================
        function handleCapsLock(e) {
            const warning = $('#capsWarning');
            if (!warning) return;

            if (e.getModifierState && e.getModifierState('CapsLock')) {
                warning.classList.add('show');
            } else {
                warning.classList.remove('show');
            }
        }

        // ============================================================
        // LOGIN LOCKOUT
        // ============================================================
        function checkLockout() {
            const now = Date.now();
            if (APP_STATE.lockedUntil > now) {
                const remaining = Math.ceil((APP_STATE.lockedUntil - now) / 1000);
                showToast(`Demasiados intentos. Espera ${remaining} segundos.`, 'error', 4000);
                disableLoginButton(true, `Bloqueado (${remaining}s)`);

                setTimeout(() => {
                    checkLockout();
                }, 1000);
                return true;
            } else if (APP_STATE.lockedUntil > 0) {
                APP_STATE.lockedUntil = 0;
                APP_STATE.loginAttempts = 0;
                sessionStorage.setItem('loginAttempts', '0');
                sessionStorage.removeItem('lockedUntil');
                disableLoginButton(false);
            }
            return false;
        }

        function disableLoginButton(disabled, customText = null) {
            const btn = $('#loginButton');
            const textSpan = $('#loginButtonText');
            if (!btn || !textSpan) return;

            btn.disabled = disabled;
            if (customText) {
                textSpan.textContent = customText;
            } else {
                const t = TRANSLATIONS[APP_STATE.currentLang] || TRANSLATIONS.es;
                textSpan.textContent = t.signin;
            }
        }

        function registerFailedAttempt() {
            APP_STATE.loginAttempts++;
            sessionStorage.setItem('loginAttempts', String(APP_STATE.loginAttempts));

            if (APP_STATE.loginAttempts >= MAX_ATTEMPTS) {
                APP_STATE.lockedUntil = Date.now() + LOCK_DURATION_MS;
                sessionStorage.setItem('lockedUntil', String(APP_STATE.lockedUntil));
                showToast(`Cuenta bloqueada por ${LOCK_DURATION_MS / 1000} segundos`, 'error', 4000);
            } else {
                const remaining = MAX_ATTEMPTS - APP_STATE.loginAttempts;
                showToast(`Credenciales incorrectas. Intentos restantes: ${remaining}`, 'error');
            }
        }

        function resetLoginAttempts() {
            APP_STATE.loginAttempts = 0;
            APP_STATE.lockedUntil = 0;
            sessionStorage.removeItem('loginAttempts');
            sessionStorage.removeItem('lockedUntil');
        }

        // ============================================================
        // VALIDACIÓN
        // ============================================================
        function validateInputs(username, password) {
            let valid = true;

            const userInput = $('#nombre_usuario');
            const passInput = $('#password');

            userInput.classList.remove('error', 'success');
            passInput.classList.remove('error', 'success');

            if (!username || username.trim().length < 2) {
                userInput.classList.add('error');
                valid = false;
            } else {
                userInput.classList.add('success');
            }

            if (!password || password.length < 4) {
                passInput.classList.add('error');
                valid = false;
            } else {
                passInput.classList.add('success');
            }

            if (!valid) {
                showToast('Por favor, completa correctamente los campos', 'warning');
                if (APP_STATE.isMobile && navigator.vibrate) navigator.vibrate([50, 30, 50]);
            }

            return valid;
        }

        // ============================================================
        // SUBMIT LOGIN
        // ============================================================
        async function submitLoginForm() {
            if (checkLockout()) return;

            const username = $('#nombre_usuario').value.trim();
            const password = $('#password').value;
            const rememberMe = $('#rememberMe').checked;

            if (!validateInputs(username, password)) return;

            const btn = $('#loginButton');
            const spinner = $('#loginSpinner');
            const icon = $('#loginIcon');
            const text = $('#loginButtonText');

            btn.disabled = true;
            spinner.classList.add('show');
            icon.style.display = 'none';
            text.textContent = 'Verificando...';

            try {
                const response = await fetch('login_process.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password, rememberMe })
                });

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }

                const result = await response.json();

                if (result.success) {
                    if (rememberMe) {
                        setCookie('remembered_user', username, 30);
                    } else {
                        deleteCookie('remembered_user');
                    }

                    const userData = result.user || {
                        name: username,
                        email: result.email || '',
                        role: result.role || 'employee',
                        avatar: username.charAt(0).toUpperCase()
                    };
                    localStorage.setItem('currentUser', JSON.stringify(userData));

                    resetLoginAttempts();
                    showToast(result.message || '¡Bienvenido!', 'success');

                    if (APP_STATE.isMobile && navigator.vibrate) navigator.vibrate(30);

                    setTimeout(() => {
                        window.location.href = result.redirect || 'principal.php';
                    }, 1000);
                } else {
                    if (result.requires2FA) {
                        showTwoFAStep();
                        return;
                    }

                    registerFailedAttempt();
                    showToast(result.message || 'Credenciales incorrectas', 'error');
                }
            } catch (error) {
                console.error('Login error:', error);
                if (error.message.includes('Failed to fetch') || error.message.includes('HTTP')) {
                    console.warn('Backend no disponible. Simulando login demo...');
                    handleDemoLogin(username, password, rememberMe);
                    return;
                }
                showToast('Error de conexión: ' + error.message, 'error');
            } finally {
                btn.disabled = false;
                spinner.classList.remove('show');
                icon.style.display = '';
                text.textContent = (TRANSLATIONS[APP_STATE.currentLang] || TRANSLATIONS.es).signin;
            }
        }

        function handleDemoLogin(username, password, rememberMe) {
            if (username && password && password.length >= 4) {
                if (rememberMe) {
                    setCookie('remembered_user', username, 30);
                }

                const userData = {
                    name: username,
                    email: username + '@smartstock.ai',
                    role: username.toLowerCase().includes('admin') ? 'admin' : 'employee',
                    avatar: username.charAt(0).toUpperCase()
                };
                localStorage.setItem('currentUser', JSON.stringify(userData));
                resetLoginAttempts();

                showToast('¡Bienvenido! (Modo Demo)', 'success');
                setTimeout(() => {
                    window.location.href = 'principal.php';
                }, 1200);
            } else {
                registerFailedAttempt();
                showToast('Credenciales inválidas', 'error');
            }
        }

        // ============================================================
        // 2FA STEP
        // ============================================================
        function showTwoFAStep() {
            $('#loginForm').style.display = 'none';
            $('#twofaContainer').classList.add('show');

            const firstInput = $('.twofa-input[data-index="0"]');
            if (firstInput) setTimeout(() => firstInput.focus(), 100);

            showToast('Ingresa el código de 6 dígitos', 'info');
        }

        function hideTwoFAStep() {
            $('#loginForm').style.display = '';
            $('#twofaContainer').classList.remove('show');
            $$('.twofa-input').forEach(i => i.value = '');
        }

        function setup2FAInputs() {
            const inputs = $$('.twofa-input');

            inputs.forEach((input, idx) => {
                input.addEventListener('input', (e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    e.target.value = val.charAt(0);

                    if (val && idx < inputs.length - 1) {
                        inputs[idx + 1].focus();
                    }
                });

                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Backspace' && !e.target.value && idx > 0) {
                        inputs[idx - 1].focus();
                    }
                    if (e.key === 'ArrowLeft' && idx > 0) {
                        inputs[idx - 1].focus();
                    }
                    if (e.key === 'ArrowRight' && idx < inputs.length - 1) {
                        inputs[idx + 1].focus();
                    }
                });

                input.addEventListener('paste', (e) => {
                    e.preventDefault();
                    const pasted = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
                    pasted.split('').forEach((ch, i) => {
                        if (inputs[i]) inputs[i].value = ch;
                    });
                    if (pasted.length > 0) {
                        const nextIdx = Math.min(pasted.length, inputs.length - 1);
                        inputs[nextIdx].focus();
                    }
                });
            });
        }

        function verify2FACode() {
            const code = Array.from($$('.twofa-input')).map(i => i.value).join('');

            if (code.length !== 6) {
                showToast('Ingresa los 6 dígitos del código', 'warning');
                return;
            }

            showToast('Código verificado correctamente', 'success');
            if (APP_STATE.isMobile && navigator.vibrate) navigator.vibrate(30);

            setTimeout(() => {
                window.location.href = 'principal.php';
            }, 1000);
        }

        // ============================================================
        // MODALES
        // ============================================================
        function openModal(id) {
            const modal = document.getElementById(id);
            if (modal) {
                modal.classList.add('show');
                // Prevenir scroll del body cuando el modal está abierto (especialmente en móvil)
                document.body.style.overflow = 'hidden';
            }
        }

        function closeModal(id) {
            const modal = document.getElementById(id);
            if (modal) {
                modal.classList.remove('show');
                document.body.style.overflow = '';
            }
        }

        // ============================================================
        // INIT
        // ============================================================
        document.addEventListener('DOMContentLoaded', function() {
            // Ocultar loader (más rápido en móvil)
            setTimeout(() => {
                $('#pageLoader').classList.add('hidden');
                setTimeout(() => $('#pageLoader').remove(), 500);
            }, APP_STATE.isMobile ? 150 : 300);

            applyTheme();
            applyLanguage(APP_STATE.currentLang);
            createParticles();

            // Recordar usuario
            const rememberedUser = getCookie('remembered_user');
            if (rememberedUser) {
                $('#nombre_usuario').value = rememberedUser;
                $('#rememberMe').checked = true;
                // No hacer focus automático en móvil (evita que salte el teclado)
                if (!APP_STATE.isMobile) {
                    setTimeout(() => $('#password').focus(), 400);
                }
            } else {
                if (!APP_STATE.isMobile) {
                    setTimeout(() => $('#nombre_usuario').focus(), 400);
                }
            }

            checkLockout();

            // Event: Theme toggle
            $('#themeToggle').addEventListener('click', toggleTheme);

            // Event: Lang toggle
            $('#langToggle').addEventListener('click', (e) => {
                e.stopPropagation();
                $('#langDropdown').classList.toggle('show');
            });

            // Event: Lang option
            $$('.lang-option').forEach(opt => {
                opt.addEventListener('click', () => {
                    applyLanguage(opt.dataset.lang);
                    $('#langDropdown').classList.remove('show');
                    showToast('Idioma cambiado', 'info', 1500);
                });
            });

            // Cerrar dropdown al hacer clic fuera
            document.addEventListener('click', (e) => {
                if (!e.target.closest('#langDropdown') && !e.target.closest('#langToggle')) {
                    $('#langDropdown').classList.remove('show');
                }
            });

            // Event: Password toggle
            $('#togglePassword').addEventListener('click', function() {
                const input = $('#password');
                const icon = this.querySelector('i');
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.className = 'fas fa-eye-slash';
                } else {
                    input.type = 'password';
                    icon.className = 'fas fa-eye';
                }
            });

            // Event: Password input
            $('#password').addEventListener('input', function() {
                checkPasswordStrength(this.value);
            });

            // Event: Caps lock
            $('#password').addEventListener('keyup', handleCapsLock);
            $('#password').addEventListener('keydown', handleCapsLock);

            // Event: Form submit
            $('#loginForm').addEventListener('submit', (e) => {
                e.preventDefault();
                submitLoginForm();
            });

            // Event: 2FA verify
            $('#verify2faBtn').addEventListener('click', verify2FACode);
            setup2FAInputs();

            // Event: Back to login
            $('#backToLogin').addEventListener('click', (e) => {
                e.preventDefault();
                hideTwoFAStep();
            });

            // Event: Forgot password
            $('#forgotPassword').addEventListener('click', (e) => {
                e.preventDefault();
                openModal('forgotModal');
            });

            // Event: Send recovery
            $('#sendRecoveryBtn').addEventListener('click', () => {
                const email = $('#recoveryEmail').value.trim();
                if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    showToast('Ingresa un correo válido', 'warning');
                    return;
                }
                showToast('Enlace de recuperación enviado a ' + email, 'success');
                closeModal('forgotModal');
                $('#recoveryEmail').value = '';
            });

            // Event: Request access
            $('#requestAccess').addEventListener('click', (e) => {
                e.preventDefault();
                openModal('requestAccessModal');
            });

            // Event: Send request
            $('#sendRequestBtn').addEventListener('click', () => {
                const name = $('#reqName').value.trim();
                const email = $('#reqEmail').value.trim();

                if (!name || name.length < 3) {
                    showToast('Ingresa tu nombre completo', 'warning');
                    return;
                }
                if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    showToast('Ingresa un correo válido', 'warning');
                    return;
                }

                showToast('Solicitud enviada. Recibirás respuesta en 24h', 'success');
                closeModal('requestAccessModal');
                $('#reqName').value = '';
                $('#reqEmail').value = '';
            });

            // Event: Help
            $('#helpBtn').addEventListener('click', () => openModal('helpModal'));

            // Event: Close modals
            $$('[data-close]').forEach(btn => {
                btn.addEventListener('click', () => {
                    closeModal(btn.getAttribute('data-close'));
                });
            });

            // Event: Click overlay para cerrar
            $$('.modal-overlay').forEach(overlay => {
                overlay.addEventListener('click', (e) => {
                    if (e.target === overlay) {
                        overlay.classList.remove('show');
                        document.body.style.overflow = '';
                    }
                });
            });

            // Keyboard shortcuts
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    $$('.modal-overlay.show').forEach(m => {
                        m.classList.remove('show');
                        document.body.style.overflow = '';
                    });
                    $('#langDropdown').classList.remove('show');
                }
            });

            // Storage sync
            window.addEventListener('storage', (e) => {
                if (e.key === 'globalSettings' || e.key === 'theme' || e.key === 'primaryColor') {
                    applyTheme();
                }
            });

            // Detectar cambio de orientación para actualizar estado
            window.addEventListener('orientationchange', () => {
                setTimeout(() => {
                    APP_STATE.isMobile = window.matchMedia('(max-width: 640px)').matches;
                }, 100);
            });

            // Prevenir zoom con doble tap en iOS
            let lastTouchEnd = 0;
            document.addEventListener('touchend', (e) => {
                const now = Date.now();
                if (now - lastTouchEnd <= 300) {
                    e.preventDefault();
                }
                lastTouchEnd = now;
            }, { passive: false });

            console.log('%c🚀 SmartStock AI - Login cargado', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (APP_STATE.isMobile ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });
    </script>

    <script src="public/js/global-settings.js"></script>
</body>
</html>