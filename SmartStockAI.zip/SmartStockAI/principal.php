<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>SmartStock AI - Panel de Control Inteligente</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style id="dynamicThemeStyles">
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --primary-light: rgba(58, 94, 199, 0.12);
            --secondary: #10b981;
            --secondary-light: rgba(16, 185, 129, 0.12);
            --dark: #0f172a;
            --light: #f8fafc;
            --gray: #64748b;
            --gray-light: #f1f5f9;
            --danger: #ef4444;
            --danger-light: rgba(239, 68, 68, 0.12);
            --warning: #f59e0b;
            --warning-light: rgba(245, 158, 11, 0.12);
            --info: #06b6d4;
            --info-light: rgba(6, 182, 212, 0.12);

            --bg: #f3f4f6;
            --card-bg: #ffffff;
            --card-border: #e2e8f0;
            --text-main: #1e293b;
            --text-muted: #64748b;

            --border-radius-sm: 8px;
            --border-radius: 16px;
            --border-radius-lg: 24px;
            --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            --sidebar-width: 270px;
            --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.02);
            --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
            --shadow-lg: 0 20px 35px -10px rgba(0, 0, 0, 0.12);
            --font-main: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;

            /* Safe areas para dispositivos con notch */
            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }

        .dark-mode {
            --bg: #0b0f19;
            --card-bg: #151c2c;
            --card-border: #232d42;
            --text-main: #f1f5f9;
            --text-muted: #94a3b8;
            --gray-light: #1e293b;
            --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-main);
        }

        html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }

        body {
            background-color: var(--bg);
            color: var(--text-main);
            transition: var(--transition);
            min-height: 100vh;
            min-height: 100dvh;
            overflow-x: hidden;
            -webkit-tap-highlight-color: transparent;
            -webkit-font-smoothing: antialiased;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--gray); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary); }

        .app-container { display: flex; min-height: 100vh; min-height: 100dvh; }

        /* --- OVERLAY para móvil --- */
        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.55);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
            z-index: 1040;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .sidebar-overlay.active { display: block; opacity: 1; }

        /* --- SIDEBAR --- */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--sidebar-bg, linear-gradient(180deg, #1e293b 0%, #0f172a 100%));
            color: #ffffff;
            height: 100vh;
            height: 100dvh;
            position: fixed;
            left: 0; top: 0;
            padding: 24px 16px;
            padding-top: calc(24px + var(--safe-top));
            padding-bottom: calc(24px + var(--safe-bottom));
            transition: var(--transition);
            z-index: 1050;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 25px rgba(0,0,0,0.15);
            will-change: transform;
        }

        .sidebar-header {
            padding: 0 12px 24px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
        }

        .logo {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -0.5px;
            background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }
        .logo span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: var(--transition);
            flex-shrink: 0;
        }

        .sidebar-close-btn {
            display: none;
            background: rgba(255, 255, 255, 0.08);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            transition: var(--transition);
            flex-shrink: 0;
        }
        .sidebar-close-btn:hover { background: var(--danger); }

        .sidebar-nav-container { flex: 1; overflow-y: auto; padding-right: 4px; -webkit-overflow-scrolling: touch; }
        .menu-label { font-size: 11px; text-transform: uppercase; letter-spacing: 1.2px; color: #64748b; font-weight: 700; margin: 16px 12px 8px 12px; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li { margin-bottom: 4px; }
        .sidebar-menu a {
            color: #94a3b8; text-decoration: none; padding: 12px 16px;
            display: flex; align-items: center; border-radius: var(--border-radius-sm);
            transition: var(--transition); font-weight: 500; font-size: 14px; cursor: pointer; gap: 12px;
            min-height: 44px;
            touch-action: manipulation;
        }
        .sidebar-menu a:hover { color: #ffffff; background: rgba(255, 255, 255, 0.06); transform: translateX(3px); }
        .sidebar-menu a.active { color: #ffffff; background: var(--primary); font-weight: 600; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); }
        .sidebar-menu i { font-size: 18px; width: 22px; text-align: center; flex-shrink: 0; }

        .sidebar-footer { padding-top: 16px; border-top: 1px solid rgba(255, 255, 255, 0.08); }
        .logout-btn {
            background: rgba(239, 68, 68, 0.1); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.2);
            width: 100%; padding: 12px 16px; border-radius: var(--border-radius-sm);
            display: flex; align-items: center; justify-content: center; gap: 10px;
            transition: var(--transition); cursor: pointer; font-weight: 600; font-size: 14px;
            min-height: 44px;
            touch-action: manipulation;
        }
        .logout-btn:hover { background: var(--danger); color: white; border-color: var(--danger); box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3); }

        /* --- MAIN CONTENT LAYOUT --- */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 30px;
            padding-top: calc(30px + var(--safe-top));
            padding-bottom: calc(30px + var(--safe-bottom));
            transition: var(--transition);
            min-width: 0;
            overflow-x: hidden;
        }

        /* --- TOP HEADER --- */
        .top-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px; background: var(--card-bg); padding: 16px 28px;
            border-radius: var(--border-radius); box-shadow: var(--shadow); border: 1px solid var(--card-border);
            gap: 16px;
            flex-wrap: wrap;
        }

        .user-profile-summary { display: flex; align-items: center; gap: 16px; min-width: 0; }
        .avatar-wrapper { position: relative; flex-shrink: 0; }
        .user-avatar {
            width: 50px; height: 50px; border-radius: 50%; background: var(--primary);
            color: white; display: flex; align-items: center; justify-content: center;
            font-size: 18px; font-weight: 700; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15); transition: var(--transition);
        }
        .status-indicator {
            width: 14px; height: 14px; background-color: var(--secondary);
            border: 2.5px solid var(--card-bg); border-radius: 50%; position: absolute; bottom: 0; right: 0;
        }
        .user-details { min-width: 0; }
        .user-details h5 { margin: 0; font-weight: 700; font-size: 16px; color: var(--text-main); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .user-details p { margin: 0; color: var(--text-muted); font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .user-badge {
            display: inline-block; padding: 2px 10px; border-radius: 20px;
            font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 4px;
        }
        .badge-admin { background: var(--warning-light); color: #d97706; }
        .badge-employee { background: var(--secondary-light); color: var(--secondary); }

        .header-controls { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
        .branch-selector {
            background: var(--bg); border: 1px solid var(--card-border); border-radius: 20px;
            padding: 10px 14px; font-size: 13px; font-weight: 600; color: var(--text-main); outline: none; cursor: pointer;
            min-height: 44px;
            transition: var(--transition);
        }
        .branch-selector:focus { border-color: var(--primary); box-shadow: 0 0 0 4px var(--primary-light); }

        .global-search { position: relative; width: 240px; }
        .global-search input {
            width: 100%; padding: 11px 40px 11px 16px; border: 1px solid var(--card-border);
            border-radius: 30px; background: var(--bg); color: var(--text-main); font-size: 16px; transition: var(--transition);
            min-height: 44px;
        }
        .global-search input:focus { outline: none; border-color: var(--primary); background: var(--card-bg); box-shadow: 0 0 0 4px var(--primary-light); }
        .global-search i { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-size: 14px; }

        .control-btn {
            width: 44px; height: 44px; border-radius: 50%; background: var(--bg);
            border: 1px solid var(--card-border); color: var(--text-main); display: flex;
            align-items: center; justify-content: center; cursor: pointer; transition: var(--transition); position: relative;
            flex-shrink: 0;
            touch-action: manipulation;
        }
        .control-btn:hover { background: var(--primary); color: white; border-color: var(--primary); transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .control-btn:active { transform: scale(0.95); }
        .btn-badge {
            position: absolute; top: -2px; right: -2px; background: var(--danger);
            color: white; font-size: 10px; font-weight: 700; width: 18px; height: 18px;
            border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid var(--card-bg);
        }

        /* --- CONFIG-STYLE TABS NAVIGATION --- */
        .config-style-tabs {
            display: flex; gap: 10px; margin-bottom: 24px; border-bottom: 1px solid var(--card-border); padding-bottom: 12px;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
            scroll-snap-type: x proximity;
        }
        .config-style-tabs::-webkit-scrollbar { display: none; }

        .tab-item {
            padding: 10px 16px; border-radius: var(--border-radius-sm); font-size: 14px; font-weight: 600;
            color: var(--text-muted); cursor: pointer; transition: var(--transition); display: flex; align-items: center; gap: 8px;
            white-space: nowrap;
            flex-shrink: 0;
            scroll-snap-align: start;
            min-height: 44px;
            touch-action: manipulation;
        }
        .tab-item:hover { color: var(--text-main); background: var(--card-bg); }
        .tab-item.active { background: var(--primary-light); color: var(--primary); }

        /* --- QUICK ACTIONS BAR --- */
        .section-title-sm { font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; color: var(--text-muted); margin-bottom: 14px; }
        .quick-actions-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 30px; }
        .action-card {
            background: var(--card-bg); border: 1px solid var(--card-border); border-radius: var(--border-radius);
            padding: 20px; display: flex; flex-direction: column; align-items: center; justify-content: center;
            gap: 12px; cursor: pointer; transition: var(--transition); box-shadow: var(--shadow-sm); text-align: center;
            min-height: 120px;
            touch-action: manipulation;
        }
        .action-card:hover { transform: translateY(-5px); box-shadow: var(--shadow); border-color: var(--primary); }
        .action-card:active { transform: scale(0.98); }
        .action-icon-box { width: 52px; height: 52px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 22px; transition: var(--transition); }
        .action-card:hover .action-icon-box { transform: scale(1.1) rotate(4deg); }
        .action-title { font-size: 14px; font-weight: 700; color: var(--text-main); }

        /* --- METRIC CARDS --- */
        .metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .metric-card {
            background: var(--card-bg); border: 1px solid var(--card-border); border-radius: var(--border-radius);
            padding: 24px; position: relative; overflow: hidden; box-shadow: var(--shadow); transition: var(--transition);
        }
        .metric-card:hover { transform: translateY(-4px); }
        .metric-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; gap: 12px; }
        .metric-title { font-size: 13px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
        .metric-icon { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0; }
        .metric-value { font-size: 32px; font-weight: 800; color: var(--text-main); line-height: 1.1; margin-bottom: 12px; }
        .metric-footer { display: flex; align-items: center; gap: 8px; font-size: 13px; flex-wrap: wrap; }
        .trend-badge { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: 700; }
        .trend-up { background: var(--secondary-light); color: var(--secondary); }
        .trend-down { background: var(--danger-light); color: var(--danger); }

        /* --- CHARTS & CONTENT GRID --- */
        .dashboard-content-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 24px; margin-bottom: 30px; }
        .panel-box { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: var(--border-radius); padding: 24px; box-shadow: var(--shadow); min-width: 0; }
        .panel-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--card-border); gap: 12px; flex-wrap: wrap; }
        .panel-title { font-size: 18px; font-weight: 700; color: var(--text-main); display: flex; align-items: center; gap: 10px; min-width: 0; }

        .chart-controls { display: flex; gap: 6px; background: var(--bg); padding: 4px; border-radius: 20px; flex-shrink: 0; }
        .chart-filter-btn { border: none; background: transparent; color: var(--text-muted); padding: 6px 14px; border-radius: 16px; font-size: 12px; font-weight: 600; cursor: pointer; transition: var(--transition); white-space: nowrap; min-height: 32px; }
        .chart-filter-btn.active { background: var(--card-bg); color: var(--primary); box-shadow: var(--shadow-sm); }
        .canvas-container { position: relative; width: 100%; height: 280px; }

        /* Config-like Switch Controls Panel */
        .setting-toggle-item {
            display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid var(--card-border);
            gap: 12px;
        }
        .setting-toggle-item:last-child { border-bottom: none; }
        .setting-info { min-width: 0; }
        .setting-info h6 { margin: 0; font-size: 14px; font-weight: 700; color: var(--text-main); }
        .setting-info p { margin: 2px 0 0 0; font-size: 12px; color: var(--text-muted); }
        .form-check-input:checked { background-color: var(--primary); border-color: var(--primary); }
        .form-check-input { width: 42px; height: 24px; cursor: pointer; }

        /* Stock Warning Table Panel */
        .stock-table-wrapper { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        .stock-table { width: 100%; font-size: 13px; border-collapse: separate; border-spacing: 0 8px; min-width: 320px; }
        .stock-table tr { background: var(--bg); border-radius: var(--border-radius-sm); }
        .stock-table td { padding: 10px 14px; }

        /* --- MODULE SECTIONS --- */
        .modules-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .module-item-card {
            background: var(--card-bg); border: 1px solid var(--card-border); border-radius: var(--border-radius);
            padding: 20px; display: flex; align-items: center; gap: 16px; cursor: pointer; transition: var(--transition);
            touch-action: manipulation;
        }
        .module-item-card:hover { transform: translateX(6px); border-color: var(--primary); box-shadow: var(--shadow); }
        .module-item-card:active { transform: scale(0.99); }
        .module-icon-wrapper {
            width: 48px; height: 48px; border-radius: 12px; background: var(--primary-light);
            color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0;
        }
        .module-text { min-width: 0; }
        .module-text h6 { margin: 0 0 4px 0; font-weight: 700; color: var(--text-main); font-size: 15px; }
        .module-text p { margin: 0; color: var(--text-muted); font-size: 12px; line-height: 1.4; }

        /* --- NOTIFICATIONS FLYOUT --- */
        .notifications-flyout {
            position: absolute; top: 75px; right: 30px; width: 380px; background: var(--card-bg);
            border: 1px solid var(--card-border); border-radius: var(--border-radius); box-shadow: var(--shadow-lg);
            z-index: 1100; display: none; overflow: hidden; animation: fadeInDown 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .notifications-flyout.active { display: block; }
        @keyframes fadeInDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .flyout-header { padding: 16px 20px; background: var(--bg); border-bottom: 1px solid var(--card-border); display: flex; justify-content: space-between; align-items: center; }
        .flyout-header h6 { margin: 0; font-weight: 700; }
        .flyout-body { max-height: 350px; overflow-y: auto; }
        .flyout-item { padding: 14px 20px; border-bottom: 1px solid var(--card-border); cursor: pointer; transition: var(--transition); }
        .flyout-item:hover { background: var(--bg); }
        .flyout-item.unread { border-left: 4px solid var(--primary); background: var(--primary-light); }
        .flyout-item p { margin: 2px 0 0 0; font-size: 12px; color: var(--text-muted); }

        /* --- MODALS STYLING --- */
        .modal-custom-overlay {
            position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px);
            display: none; align-items: center; justify-content: center; z-index: 2000;
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
        }
        .modal-custom-overlay.active { display: flex; }
        .modal-custom-card {
            background: var(--card-bg); border-radius: var(--border-radius-lg); border: 1px solid var(--card-border);
            width: 100%; max-width: 650px; max-height: calc(100vh - 40px); max-height: calc(100dvh - 40px);
            box-shadow: var(--shadow-lg); overflow: hidden; animation: modalPop 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
            display: flex;
            flex-direction: column;
        }
        @keyframes modalPop { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        .modal-custom-header { padding: 20px 28px; border-bottom: 1px solid var(--card-border); display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-shrink: 0; }
        .modal-custom-header h5 { margin: 0; font-weight: 800; color: var(--text-main); font-size: 17px; }
        .modal-custom-body { padding: 28px; overflow-y: auto; flex: 1; -webkit-overflow-scrolling: touch; }
        .modal-custom-footer { padding: 16px 28px; border-top: 1px solid var(--card-border); background: var(--bg); display: flex; justify-content: flex-end; gap: 12px; flex-shrink: 0; flex-wrap: wrap; }

        .mobile-nav-toggle {
            display: none; position: fixed;
            bottom: calc(20px + var(--safe-bottom));
            right: calc(20px + var(--safe-right));
            width: 56px; height: 56px;
            border-radius: 50%; background: var(--primary); color: white; border: none; box-shadow: var(--shadow-lg);
            z-index: 1100; align-items: center; justify-content: center; font-size: 22px; cursor: pointer;
            touch-action: manipulation;
            transition: var(--transition);
        }
        .mobile-nav-toggle:active { transform: scale(0.92); }

        /* ============================================================
           RESPONSIVE - LAPTOP / DESKTOP MEDIANO (≤1200px)
           ============================================================ */
        @media (max-width: 1200px) {
            .dashboard-content-grid { grid-template-columns: 1fr; }
            .global-search { width: 200px; }
        }

        /* ============================================================
           RESPONSIVE - TABLET (≤992px)
           ============================================================ */
        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.mobile-open { transform: translateX(0); }
            .sidebar-close-btn { display: flex; }
            .main-content { margin-left: 0; padding: 20px; padding-top: calc(20px + var(--safe-top)); padding-bottom: calc(20px + var(--safe-bottom)); }
            .mobile-nav-toggle { display: flex; }

            .top-header {
                flex-direction: column;
                align-items: stretch;
                gap: 16px;
                padding: 16px 20px;
            }
            .header-controls { justify-content: space-between; flex-wrap: wrap; }
            .global-search { width: 100%; order: -1; }

            .quick-actions-grid { grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; }
            .action-card { padding: 16px; min-height: 110px; }
            .action-icon-box { width: 46px; height: 46px; font-size: 20px; }
            .action-title { font-size: 13px; }

            .metrics-grid { grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; }
            .metric-card { padding: 20px; }
            .metric-value { font-size: 26px; }

            .modules-grid { grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px; }

            .notifications-flyout {
                position: fixed;
                top: auto;
                bottom: calc(90px + var(--safe-bottom));
                left: 16px;
                right: 16px;
                width: auto;
                max-width: 440px;
                margin-left: auto;
                margin-right: auto;
            }
        }

        /* ============================================================
           RESPONSIVE - MÓVIL (≤640px)
           ============================================================ */
        @media (max-width: 640px) {
            .main-content { padding: 16px; padding-top: calc(16px + var(--safe-top)); padding-bottom: calc(90px + var(--safe-bottom)); }

            .sidebar { width: 88vw; max-width: 320px; }

            .top-header { padding: 14px 16px; border-radius: var(--border-radius-sm); gap: 12px; }
            .user-avatar { width: 44px; height: 44px; font-size: 16px; }
            .user-details h5 { font-size: 14px; }
            .user-details p { font-size: 12px; }
            .branch-selector { display: none; }
            .control-btn { width: 40px; height: 40px; font-size: 14px; }
            .global-search input { font-size: 16px; min-height: 42px; padding: 10px 38px 10px 14px; }

            .config-style-tabs { gap: 6px; padding-bottom: 10px; margin-bottom: 16px; }
            .tab-item { padding: 8px 12px; font-size: 12px; min-height: 38px; }
            .tab-item i { font-size: 12px; }

            .section-title-sm { font-size: 12px; margin-bottom: 10px; }

            .quick-actions-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 20px; }
            .action-card { padding: 14px 10px; min-height: 100px; gap: 8px; border-radius: var(--border-radius-sm); }
            .action-icon-box { width: 42px; height: 42px; font-size: 18px; border-radius: 12px; }
            .action-title { font-size: 12px; }

            .metrics-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 20px; }
            .metric-card { padding: 16px; border-radius: var(--border-radius-sm); }
            .metric-header { margin-bottom: 12px; }
            .metric-title { font-size: 11px; }
            .metric-icon { width: 36px; height: 36px; font-size: 16px; border-radius: 10px; }
            .metric-value { font-size: 22px; margin-bottom: 8px; }
            .metric-footer { font-size: 11px; gap: 6px; }
            .trend-badge { font-size: 10px; padding: 2px 6px; }

            .panel-box { padding: 18px; border-radius: var(--border-radius-sm); }
            .panel-header { margin-bottom: 16px; padding-bottom: 10px; }
            .panel-title { font-size: 15px; gap: 8px; }
            .panel-title i { font-size: 14px; }
            .chart-controls { padding: 3px; }
            .chart-filter-btn { padding: 5px 10px; font-size: 11px; min-height: 28px; }
            .canvas-container { height: 220px; }

            .setting-info h6 { font-size: 13px; }
            .setting-info p { font-size: 11px; }
            .form-check-input { width: 38px; height: 22px; }

            .stock-table { font-size: 12px; min-width: 280px; }
            .stock-table td { padding: 8px 10px; }

            .modules-grid { grid-template-columns: 1fr; gap: 12px; margin-bottom: 20px; }
            .module-item-card { padding: 16px; border-radius: var(--border-radius-sm); }
            .module-icon-wrapper { width: 42px; height: 42px; font-size: 18px; border-radius: 10px; }
            .module-text h6 { font-size: 14px; }
            .module-text p { font-size: 11px; }

            /* Modales como Bottom Sheet en móvil */
            .modal-custom-overlay {
                align-items: flex-end;
                padding: 0;
                padding-top: calc(20px + var(--safe-top));
            }
            .modal-custom-card {
                max-width: 100%;
                max-height: calc(100dvh - 60px);
                border-radius: var(--border-radius-lg) var(--border-radius-lg) 0 0;
                animation: modalSlideUp 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            }
            @keyframes modalSlideUp {
                from { opacity: 0; transform: translateY(30px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .modal-custom-header { padding: 18px 20px; }
            .modal-custom-header h5 { font-size: 15px; }
            .modal-custom-body { padding: 20px; }
            .modal-custom-footer { padding: 14px 20px calc(14px + var(--safe-bottom)); flex-direction: column-reverse; }
            .modal-custom-footer .btn { width: 100%; min-height: 46px; }

            .mobile-nav-toggle {
                width: 52px;
                height: 52px;
                font-size: 20px;
                bottom: calc(16px + var(--safe-bottom));
                right: calc(16px + var(--safe-right));
            }

            /* Tablas responsive */
            .table-responsive-mobile { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        }

        /* ============================================================
           RESPONSIVE - MÓVIL PEQUEÑO (≤380px)
           ============================================================ */
        @media (max-width: 380px) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); padding-bottom: calc(80px + var(--safe-bottom)); }
            .metrics-grid { grid-template-columns: 1fr; }
            .quick-actions-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
            .action-card { padding: 12px 8px; min-height: 90px; }
            .action-icon-box { width: 38px; height: 38px; font-size: 16px; }
            .action-title { font-size: 11px; }
            .metric-value { font-size: 20px; }
            .user-details h5 { font-size: 13px; }
            .user-details p { font-size: 11px; }
            .panel-title { font-size: 14px; }
            .canvas-container { height: 200px; }
            .tab-item { font-size: 11px; padding: 6px 10px; }
        }

        /* ============================================================
           LANDSCAPE MÓVIL
           ============================================================ */
        @media (max-height: 500px) and (orientation: landscape) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); }
            .top-header { padding: 10px 16px; margin-bottom: 12px; }
            .user-avatar { width: 40px; height: 40px; font-size: 14px; }
            .metrics-grid { margin-bottom: 12px; }
            .quick-actions-grid { margin-bottom: 12px; }
            .canvas-container { height: 180px; }
            .sidebar { padding: 16px 12px; padding-top: calc(16px + var(--safe-top)); }
        }

        /* ============================================================
           PANTALLAS GRANDES (≥1440px) - Más espaciado
           ============================================================ */
        @media (min-width: 1440px) {
            .main-content { padding: 40px; }
            .metrics-grid { grid-template-columns: repeat(4, 1fr); }
            .quick-actions-grid { grid-template-columns: repeat(5, 1fr); }
            .metric-value { font-size: 36px; }
            .canvas-container { height: 340px; }
        }

        @media (min-width: 1920px) {
            .main-content { padding: 48px 60px; max-width: 1800px; margin-left: auto; margin-right: auto; }
        }

        /* ============================================================
           TOUCH / HOVER - Deshabilitar hover en touch
           ============================================================ */
        @media (hover: none) {
            .action-card:hover { transform: none; box-shadow: var(--shadow-sm); border-color: var(--card-border); }
            .action-card:hover .action-icon-box { transform: none; }
            .metric-card:hover { transform: none; }
            .module-item-card:hover { transform: none; border-color: var(--card-border); box-shadow: none; }
            .control-btn:hover { background: var(--bg); color: var(--text-main); border-color: var(--card-border); transform: none; }
            .sidebar-menu a:hover { transform: none; background: transparent; }
            .logout-btn:hover { background: rgba(239, 68, 68, 0.1); color: #f87171; border-color: rgba(239, 68, 68, 0.2); box-shadow: none; }
        }

        /* ============================================================
           REDUCED MOTION - Accesibilidad
           ============================================================ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        /* Restricted Banner */
        .restricted-banner {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 20px;
            background: var(--warning-light);
            border-radius: var(--border-radius);
            border: 1px solid var(--warning);
            margin-bottom: 24px;
        }
        .restricted-banner i { font-size: 28px; color: var(--warning); flex-shrink: 0; }
    </style>
</head>
<body>

    <div class="app-container">

        <!-- SIDEBAR OVERLAY (móvil) -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <!-- SIDEBAR NAV -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-brain"></i></div>
                    <span class="system-name-display">SmartStock AI</span>
                </div>
                <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a data-page="admin" class="active"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                    <li><a data-page="inventario"><i class="fas fa-boxes-stacked"></i> Inventario</a></li>
                    <li><a data-page="Transacciones"><i class="fas fa-right-left"></i> Transacciones</a></li>
                    <li><a data-page="Reportes"><i class="fas fa-chart-column"></i> Reportes</a></li>
                </ul>

                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a data-page="clientes"><i class="fas fa-address-book"></i> Clientes</a></li>
                    <li><a data-page="proveedores"><i class="fas fa-truck-field"></i> Proveedores</a></li>
                </ul>

                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a data-page="usuarios"><i class="fas fa-users-gear"></i> Usuarios</a></li>
                    <li><a data-page="seguridad"><i class="fas fa-shield-halved"></i> Seguridad</a></li>
                    <li><a data-page="perfil"><i class="fas fa-circle-user"></i> Mi Perfil</a></li>
                    <li><a data-page="configuracion"><i class="fas fa-sliders"></i> Configuración</a></li>
                </ul>
            </div>

            <div class="sidebar-footer">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    <span>Cerrar Sesión</span>
                </button>
            </div>
        </aside>

        <!-- MAIN CONTENT AREA -->
        <main class="main-content">

            <!-- TOP BAR -->
            <header class="top-header">
                <div class="user-profile-summary">
                    <div class="avatar-wrapper">
                        <div class="user-avatar" id="userAvatar"></div>
                        <div class="status-indicator"></div>
                    </div>
                    <div class="user-details">
                        <h5 id="userName"></h5>
                        <p id="userEmail"></p>
                        <span class="user-badge" id="userRoleBadge"></span>
                    </div>
                </div>

                <div class="header-controls">
                    <select class="branch-selector" title="Seleccionar Sucursal Activa">
                        <option value="main">Sucursal Central</option>
                        <option value="north">Sucursal Norte</option>
                        <option value="south">Sucursal Sur</option>
                    </select>

                    <div class="global-search">
                        <input type="text" id="globalSearchInput" placeholder="Buscar en el sistema...">
                        <i class="fas fa-magnifying-glass"></i>
                    </div>

                    <button class="control-btn" id="themeToggleBtn" title="Cambiar Tema Visual">
                        <i class="fas fa-moon"></i>
                    </button>

                    <button class="control-btn" id="notificationsBtn" title="Notificaciones">
                        <i class="fas fa-bell"></i>
                        <span class="btn-badge" id="notifBadge">3</span>
                    </button>
                </div>
            </header>

            <!-- CONFIG-STYLE SUB-TABS -->
            <div class="config-style-tabs">
                <div class="tab-item active" onclick="switchMainTab('summary', event)"><i class="fas fa-grip"></i> Resumen General</div>
                <div class="tab-item" onclick="switchMainTab('inventory', event)"><i class="fas fa-boxes-stacked"></i> Estado de Inventario</div>
                <div class="tab-item" onclick="switchMainTab('alerts', event)"><i class="fas fa-bell"></i> Control de Alertas</div>
            </div>

            <!-- NOTIFICATIONS FLYOUT PANEL -->
            <div class="notifications-flyout" id="notificationsFlyout">
                <div class="flyout-header">
                    <h6>Centro de Notificaciones</h6>
                    <button class="btn btn-sm btn-link text-decoration-none p-0" id="markAllReadBtn">Marcar leídas</button>
                </div>
                <div class="flyout-body" id="notifListContainer">
                    <div class="flyout-item unread">
                        <strong>Alerta de Almacén: Stock Crítico</strong>
                        <p>5 productos han caído por debajo del margen de seguridad.</p>
                    </div>
                    <div class="flyout-item unread">
                        <strong>Venta Grande Detectada</strong>
                        <p>Se registró una venta por $1,250.00 USD por Cliente Corp.</p>
                    </div>
                    <div class="flyout-item">
                        <strong>Sincronización Completada</strong>
                        <p>La base de datos se actualizó correctamente con el servidor.</p>
                    </div>
                </div>
            </div>

            <!-- QUICK ACTIONS SECTION -->
            <div class="section-title-sm">Acciones Rápidas</div>
            <div class="quick-actions-grid">
                <div class="action-card" id="btnQuickSale">
                    <div class="action-icon-box" style="background: var(--primary-light); color: var(--primary);">
                        <i class="fas fa-cash-register"></i>
                    </div>
                    <span class="action-title">Venta Rápida</span>
                </div>

                <div class="action-card" id="btnAddProduct">
                    <div class="action-icon-box" style="background: var(--secondary-light); color: var(--secondary);">
                        <i class="fas fa-folder-plus"></i>
                    </div>
                    <span class="action-title">Nuevo Producto</span>
                </div>

                <div class="action-card" id="btnGenerateReport">
                    <div class="action-icon-box" style="background: var(--warning-light); color: var(--warning);">
                        <i class="fas fa-file-invoice-dollar"></i>
                    </div>
                    <span class="action-title">Generar Reporte</span>
                </div>

                <div class="action-card" id="btnCheckInventory">
                    <div class="action-icon-box" style="background: var(--info-light); color: var(--info);">
                        <i class="fas fa-boxes-packing"></i>
                    </div>
                    <span class="action-title">Audit. Stock</span>
                </div>

                <div class="action-card" id="btnAIAdvisor">
                    <div class="action-icon-box" style="background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white;">
                        <i class="fas fa-wand-magic-sparkles"></i>
                    </div>
                    <span class="action-title">Asistente IA</span>
                </div>
            </div>

            <!-- METRIC CARDS -->
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-header">
                        <span class="metric-title">Ventas de Hoy</span>
                        <div class="metric-icon" style="background: var(--primary-light); color: var(--primary);">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                    </div>
                    <div class="metric-value">$3,840.50</div>
                    <div class="metric-footer">
                        <span class="trend-badge trend-up"><i class="fas fa-arrow-up"></i> +14.2%</span>
                        <span class="text-muted">vs ayer</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-header">
                        <span class="metric-title">Stock Almacenado</span>
                        <div class="metric-icon" style="background: var(--secondary-light); color: var(--secondary);">
                            <i class="fas fa-cubes"></i>
                        </div>
                    </div>
                    <div class="metric-value">1,420</div>
                    <div class="metric-footer">
                        <span class="trend-badge trend-up"><i class="fas fa-check"></i> Óptimo</span>
                        <span class="text-muted">82% Capacidad</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-header">
                        <span class="metric-title">Alertas Bajo Stock</span>
                        <div class="metric-icon" style="background: var(--danger-light); color: var(--danger);">
                            <i class="fas fa-triangle-exclamation"></i>
                        </div>
                    </div>
                    <div class="metric-value">08</div>
                    <div class="metric-footer">
                        <span class="trend-badge trend-down"><i class="fas fa-arrow-down"></i> Crítico</span>
                        <span class="text-muted">Requiere Reorden</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-header">
                        <span class="metric-title">Clientes Activos</span>
                        <div class="metric-icon" style="background: var(--info-light); color: var(--info);">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    <div class="metric-value">342</div>
                    <div class="metric-footer">
                        <span class="trend-badge trend-up"><i class="fas fa-arrow-up"></i> +5</span>
                        <span class="text-muted">Esta semana</span>
                    </div>
                </div>
            </div>

            <!-- CHARTS & CONFIGURABLE PANELS GRID -->
            <div class="dashboard-content-grid">
                <!-- Interactive Canvas Panel -->
                <div class="panel-box">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="fas fa-chart-line text-primary"></i> Rendimiento de Ventas
                        </div>
                        <div class="chart-controls">
                            <button class="chart-filter-btn active" onclick="updateChartData('week', event)">Semana</button>
                            <button class="chart-filter-btn" onclick="updateChartData('month', event)">Mes</button>
                            <button class="chart-filter-btn" onclick="updateChartData('year', event)">Año</button>
                        </div>
                    </div>
                    <div class="canvas-container">
                        <canvas id="salesCanvas"></canvas>
                    </div>
                </div>

                <!-- Config-Style Controls & Stock Table Panel -->
                <div class="panel-box">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="fas fa-sliders text-primary"></i> Ajustes Rápido & Stock
                        </div>
                    </div>

                    <!-- Config Switch Toggles -->
                    <div class="setting-toggle-item">
                        <div class="setting-info">
                            <h6>Notificaciones en Vivo</h6>
                            <p>Alertas instantáneas en pantalla</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="liveNotifSwitch" checked>
                        </div>
                    </div>

                    <div class="setting-toggle-item">
                        <div class="setting-info">
                            <h6>Predicción IA Activa</h6>
                            <p>Sugerencias dinámicas de reorden</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="aiPredictSwitch" checked>
                        </div>
                    </div>

                    <div class="mt-3">
                        <div class="fw-bold mb-2 fs-6">Stock en Riesgo</div>
                        <div class="stock-table-wrapper">
                            <table class="stock-table">
                                <tr>
                                    <td><strong>Mouse Inalámbrico</strong></td>
                                    <td><span class="badge bg-danger">2 unic.</span></td>
                                    <td class="text-end"><button class="btn btn-sm btn-outline-primary" onclick="navigateTo('inventario')">Pedir</button></td>
                                </tr>
                                <tr>
                                    <td><strong>Cables HDMI 2m</strong></td>
                                    <td><span class="badge bg-warning text-dark">4 unic.</span></td>
                                    <td class="text-end"><button class="btn btn-sm btn-outline-primary" onclick="navigateTo('inventario')">Pedir</button></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ADMIN ONLY MODULES -->
            <div id="adminModulesSection">
                <div class="section-title-sm">Administración Avanzada del Sistema</div>
                <div class="modules-grid">
                    <div class="module-item-card" data-page="usuarios">
                        <div class="module-icon-wrapper">
                            <i class="fas fa-user-gear"></i>
                        </div>
                        <div class="module-text">
                            <h6>Gestión de Usuarios</h6>
                            <p>Administra permisos, roles y acceso del personal.</p>
                        </div>
                    </div>

                    <div class="module-item-card" data-page="seguridad">
                        <div class="module-icon-wrapper" style="background: var(--warning-light); color: var(--warning);">
                            <i class="fas fa-shield-cat"></i>
                        </div>
                        <div class="module-text">
                            <h6>Seguridad & Auditoría</h6>
                            <p>Revisa logs de acceso y políticas de contraseñas.</p>
                        </div>
                    </div>

                    <div class="module-item-card" data-page="configuracion">
                        <div class="module-icon-wrapper" style="background: var(--info-light); color: var(--info);">
                            <i class="fas fa-sliders"></i>
                        </div>
                        <div class="module-text">
                            <h6>Parámetros Globales</h6>
                            <p>Personaliza moneda, impuestos e integración IA.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RESTRICTED ACCESS WARNING -->
            <div id="restrictedAccessBanner" class="restricted-banner" style="display: none;">
                <i class="fas fa-lock"></i>
                <div>
                    <h5 class="m-0 font-weight-bold">Modo Empleado Activado</h5>
                    <p class="m-0 text-muted fs-6">Las funciones avanzadas de administración están ocultas para tu rol actual.</p>
                </div>
            </div>

            <!-- COMMON SYSTEM MODULES -->
            <div class="section-title-sm">Módulos Operativos</div>
            <div class="modules-grid">
                <div class="module-item-card" data-page="inventario">
                    <div class="module-icon-wrapper" style="background: var(--secondary-light); color: var(--secondary);">
                        <i class="fas fa-warehouse"></i>
                    </div>
                    <div class="module-text">
                        <h6>Control de Inventarios</h6>
                        <p>Catálogo general de productos, precios y almacenes.</p>
                    </div>
                </div>

                <div class="module-item-card" data-page="Reportes">
                    <div class="module-icon-wrapper">
                        <i class="fas fa-file-chart-column"></i>
                    </div>
                    <div class="module-text">
                        <h6>Centro de Reportes</h6>
                        <p>Exportación de balances y métricas de rendimiento.</p>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <!-- MOBILE NAVIGATION TOGGLE -->
    <button class="mobile-nav-toggle" id="mobileNavToggle" aria-label="Abrir menú">
        <i class="fas fa-bars"></i>
    </button>

    <!-- MODALS -->

    <!-- QUICK SALE MODAL -->
    <div class="modal-custom-overlay" id="quickSaleModal">
        <div class="modal-custom-card">
            <div class="modal-custom-header">
                <h5><i class="fas fa-cash-register text-primary me-2"></i> Módulo de Venta Rápida</h5>
                <button class="btn-close" onclick="closeModal('quickSaleModal')" aria-label="Cerrar"></button>
            </div>
            <div class="modal-custom-body">
                <div class="mb-3">
                    <label class="form-label fw-bold">Buscar Producto</label>
                    <select class="form-select" id="saleProductSelect" onchange="addSaleItem()">
                        <option value="">-- Seleccionar Producto --</option>
                        <option value="150|Laptop Gamer XT">Laptop Gamer XT - $150.00</option>
                        <option value="25|Mouse Inalámbrico Pro">Mouse Inalámbrico Pro - $25.00</option>
                        <option value="80|Teclado Mecánico RGB">Teclado Mecánico RGB - $80.00</option>
                        <option value="210|Monitor 27 Pulgadas 144Hz">Monitor 27" 144Hz - $210.00</option>
                    </select>
                </div>

                <div class="table-responsive-mobile">
                    <table class="table align-middle mt-3">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th style="width: 80px;">Cant.</th>
                                <th>Precio</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody id="quickSaleTableBody">
                            <tr>
                                <td colspan="4" class="text-center text-muted py-3">No hay productos en el carrito</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="p-3 bg-light rounded-3 mt-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span>Subtotal:</span>
                        <span id="saleSubtotal">$0.00</span>
                    </div>
                    <div class="d-flex justify-content-between mb-1">
                        <span>IVA (16%):</span>
                        <span id="saleTax">$0.00</span>
                    </div>
                    <div class="d-flex justify-content-between fw-bold fs-5 text-primary">
                        <span>Total a Pagar:</span>
                        <span id="saleTotal">$0.00</span>
                    </div>
                </div>

                <div class="mt-3">
                    <label class="form-label fw-bold">Paga con ($)</label>
                    <input type="number" class="form-input form-control" id="cashReceived" placeholder="0.00" oninput="calculateChange()" inputmode="decimal">
                    <div class="mt-2 fw-bold text-success" id="changeAmountText">Cambio: $0.00</div>
                </div>
            </div>
            <div class="modal-custom-footer">
                <button class="btn btn-secondary" onclick="closeModal('quickSaleModal')">Cancelar</button>
                <button class="btn btn-primary" onclick="processQuickSale()"><i class="fas fa-check me-1"></i> Procesar Venta</button>
            </div>
        </div>
    </div>

    <!-- AI ADVISOR MODAL -->
    <div class="modal-custom-overlay" id="aiAdvisorModal">
        <div class="modal-custom-card">
            <div class="modal-custom-header" style="background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%); color: white;">
                <h5 class="text-white"><i class="fas fa-wand-magic-sparkles me-2"></i> SmartStock Brain - IA Predictiva</h5>
                <button class="btn-close btn-close-white" onclick="closeModal('aiAdvisorModal')" aria-label="Cerrar"></button>
            </div>
            <div class="modal-custom-body">
                <div class="d-flex align-items-center gap-3 p-3 bg-light rounded-3 mb-3">
                    <i class="fas fa-brain fs-1 text-purple" style="color: #a855f7;"></i>
                    <div>
                        <h6 class="m-0 fw-bold">Análisis del Algoritmo en Tiempo Real</h6>
                        <small class="text-muted">Basado en tendencias de ventas e inventario actual</small>
                    </div>
                </div>

                <div id="aiAnalysisOutput">
                    <div class="alert alert-info">
                        <h6><i class="fas fa-lightbulb me-2"></i> Sugerencia de Reabastecimiento</h6>
                        <p class="m-0 fs-6">Se pronostica un incremento del 35% en la demanda de <strong>Teclados Mecánicos RGB</strong> durante los próximos 15 días.</p>
                    </div>

                    <div class="alert alert-warning">
                        <h6><i class="fas fa-triangle-exclamation me-2"></i> Exceso de Stock Detectado</h6>
                        <p class="m-0 fs-6">El producto <strong>Cables HDMI 2m</strong> no ha registrado movimiento en los últimos 45 días.</p>
                    </div>
                </div>
            </div>
            <div class="modal-custom-footer">
                <button class="btn btn-primary" onclick="closeModal('aiAdvisorModal')">Entendido</button>
            </div>
        </div>
    </div>

    <!-- JAVASCRIPT ENGINE -->
    <script>
        const SYSTEM_ROUTES = {
            'admin': 'http://localhost/SmartStockAI/admin.php',
            'inventario': 'http://localhost/SmartStockAI/inventario1.php',
            'Reportes': 'http://localhost/SmartStockAI/Reportes.php',
            'Transacciones': 'http://localhost/SmartStockAI/Trassanciones.php',
            'clientes': 'http://localhost/SmartStockAI/clientes.php',
            'proveedores': 'http://localhost/SmartStockAI/proveedores.php',
            'usuarios': 'http://localhost/SmartStockAI/usuarios.php',
            'seguridad': 'http://localhost/SmartStockAI/seguridad.php',
            'perfil': 'http://localhost/SmartStockAI/perfil.php',
            'configuracion': 'http://localhost/SmartStockAI/configuracion.php'
        };

        const APP_STATE = {
            isMobile: window.matchMedia('(max-width: 992px)').matches,
            isTouch: ('ontouchstart' in window) || (navigator.maxTouchPoints > 0)
        };

        function hexToRgba(hex, alpha = 0.12) {
            if (!hex) return `rgba(58, 94, 199, ${alpha})`;
            let c = hex.replace('#', '');
            if (c.length === 3) c = c.split('').map(char => char + char).join('');
            const num = parseInt(c, 16);
            return `rgba(${(num >> 16) & 255}, ${(num >> 8) & 255}, ${num & 255}, ${alpha})`;
        }

        document.addEventListener('DOMContentLoaded', function() {
            applyGlobalConfig();
            setupUserSession();
            setupNavigationListeners();
            setupNotificationsEngine();
            setupMobileSidebar();
            initSalesChartCanvas();

            window.addEventListener('storage', function(e) {
                if (e.key === 'globalSettings' || e.key === 'appSettings' || e.key === 'theme' || e.key === 'primaryColor') {
                    applyGlobalConfig();
                }
            });

            window.addEventListener('focus', function() { applyGlobalConfig(); });

            document.getElementById('mobileNavToggle').addEventListener('click', function() {
                openMobileSidebar();
            });

            document.getElementById('logoutBtn').addEventListener('click', function() {
                if (confirm('¿Desea cerrar la sesión actual?')) {
                    localStorage.removeItem('currentUser');
                    window.location.href = 'http://localhost/SmartStockAI/login.php';
                }
            });

            document.getElementById('themeToggleBtn').addEventListener('click', function() {
                const isDark = document.body.classList.toggle('dark-mode');
                const settings = JSON.parse(localStorage.getItem('globalSettings')) || {};
                settings.darkMode = isDark;
                settings.autoDarkMode = 'disabled';
                localStorage.setItem('globalSettings', JSON.stringify(settings));
                localStorage.setItem('theme', isDark ? 'dark' : 'light');

                this.querySelector('i').className = isDark ? 'fas fa-sun' : 'fas fa-moon';

                // Actualizar theme-color meta
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', isDark ? '#0b0f19' : '#3a5ec7');

                // Vibración háptica en móvil
                if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(10);

                initSalesChartCanvas();
            });

            document.getElementById('btnQuickSale').addEventListener('click', () => openModal('quickSaleModal'));
            document.getElementById('btnAddProduct').addEventListener('click', () => navigateTo('inventario'));
            document.getElementById('btnGenerateReport').addEventListener('click', () => navigateTo('Reportes'));
            document.getElementById('btnCheckInventory').addEventListener('click', () => navigateTo('inventario'));
            document.getElementById('btnAIAdvisor').addEventListener('click', () => openModal('aiAdvisorModal'));

            // Cerrar modales al hacer clic en overlay
            document.querySelectorAll('.modal-custom-overlay').forEach(overlay => {
                overlay.addEventListener('click', (e) => {
                    if (e.target === overlay) {
                        overlay.classList.remove('active');
                        document.body.style.overflow = '';
                    }
                });
            });

            // Cerrar sidebar al presionar Escape
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    closeMobileSidebar();
                    document.querySelectorAll('.modal-custom-overlay.active').forEach(m => {
                        m.classList.remove('active');
                        document.body.style.overflow = '';
                    });
                }
            });

            // Detectar cambio de orientación
            window.addEventListener('orientationchange', () => {
                setTimeout(() => {
                    APP_STATE.isMobile = window.matchMedia('(max-width: 992px)').matches;
                    if (!APP_STATE.isMobile) closeMobileSidebar();
                    initSalesChartCanvas();
                }, 150);
            });

            // Redibujar canvas en resize (debounced)
            let resizeTimeout;
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(() => {
                    APP_STATE.isMobile = window.matchMedia('(max-width: 992px)').matches;
                    initSalesChartCanvas();
                }, 200);
            });

            // Prevenir zoom con doble tap en iOS
            if (APP_STATE.isTouch) {
                let lastTouchEnd = 0;
                document.addEventListener('touchend', (e) => {
                    const now = Date.now();
                    if (now - lastTouchEnd <= 300) e.preventDefault();
                    lastTouchEnd = now;
                }, { passive: false });
            }

            console.log('%c🚀 SmartStock AI - Dashboard cargado', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (APP_STATE.isMobile ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });

        // ============================================================
        // MOBILE SIDEBAR MANAGEMENT
        // ============================================================
        function setupMobileSidebar() {
            const overlay = document.getElementById('sidebarOverlay');
            const closeBtn = document.getElementById('sidebarCloseBtn');

            if (overlay) overlay.addEventListener('click', closeMobileSidebar);
            if (closeBtn) closeBtn.addEventListener('click', closeMobileSidebar);

            // Swipe para cerrar sidebar (touch gestures)
            let touchStartX = 0;
            let touchCurrentX = 0;
            const sidebar = document.getElementById('sidebar');

            sidebar.addEventListener('touchstart', (e) => {
                touchStartX = e.touches[0].clientX;
            }, { passive: true });

            sidebar.addEventListener('touchmove', (e) => {
                touchCurrentX = e.touches[0].clientX;
                const diff = touchCurrentX - touchStartX;
                if (diff < 0 && diff > -100) {
                    sidebar.style.transform = `translateX(${diff}px)`;
                }
            }, { passive: true });

            sidebar.addEventListener('touchend', () => {
                const diff = touchCurrentX - touchStartX;
                sidebar.style.transform = '';
                if (diff < -60) closeMobileSidebar();
                touchStartX = 0;
                touchCurrentX = 0;
            });
        }

        function openMobileSidebar() {
            document.getElementById('sidebar').classList.add('mobile-open');
            document.getElementById('sidebarOverlay').classList.add('active');
            document.body.style.overflow = 'hidden';
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(5);
        }

        function closeMobileSidebar() {
            document.getElementById('sidebar').classList.remove('mobile-open');
            document.getElementById('sidebarOverlay').classList.remove('active');
            document.body.style.overflow = '';
        }

        // ============================================================
        // GLOBAL CONFIG
        // ============================================================
        function applyGlobalConfig() {
            const settings = JSON.parse(localStorage.getItem('globalSettings')) || {};
            const legacySettings = JSON.parse(localStorage.getItem('appSettings')) || {};
            const savedTheme = settings.darkMode ? 'dark' : (localStorage.getItem('theme') || legacySettings.theme || 'light');
            const colors = {
                blue: '#3a5ec7',
                green: '#28a745',
                red: '#dc3545',
                purple: '#6f42c1',
                orange: '#fd7e14',
                teal: '#20c997'
            };
            const primaryColor = colors[settings.themeColor] || legacySettings.primaryColor || localStorage.getItem('primaryColor') || '#3a5ec7';

            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggleBtn i').className = 'fas fa-sun';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#0b0f19');
            } else {
                document.body.classList.remove('dark-mode');
                document.querySelector('#themeToggleBtn i').className = 'fas fa-moon';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', primaryColor);
            }

            const primaryLight = hexToRgba(primaryColor, 0.12);
            document.documentElement.style.setProperty('--primary', primaryColor);
            document.documentElement.style.setProperty('--primary-dark', primaryColor);
            document.documentElement.style.setProperty('--primary-light', primaryLight);

            document.documentElement.style.setProperty('--font-main', settings.fontFamily || "'Plus Jakarta Sans', sans-serif");
            document.documentElement.style.setProperty('--border-radius', settings.borderRadius || '12px');
            document.documentElement.style.setProperty('--font-size', settings.uiDensity === 'compact' ? '13px' : '14px');
            document.documentElement.style.setProperty('--transition', settings.enableAnimations === false ? 'none' : 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)');

            document.querySelectorAll('.system-name-display').forEach(element => {
                element.textContent = settings.systemName || 'SmartStock AI';
            });

            if (settings.sidebarTheme === 'dark') {
                document.documentElement.style.setProperty('--sidebar-bg', 'linear-gradient(180deg, #111827 0%, #030712 100%)');
                document.documentElement.style.setProperty('--sidebar-text', '#ffffff');
            } else if (settings.sidebarTheme === 'light') {
                document.documentElement.style.setProperty('--sidebar-bg', '#ffffff');
                document.documentElement.style.setProperty('--sidebar-text', '#333333');
            } else {
                document.documentElement.style.setProperty('--sidebar-bg', `linear-gradient(180deg, ${primaryColor} 0%, ${primaryColor} 100%)`);
                document.documentElement.style.setProperty('--sidebar-text', '#ffffff');
            }
            document.documentElement.style.setProperty('--sidebar-opacity', String(parseInt(settings.sidebarOpacity || 100, 10) / 100));

            if (settings.modules) {
                Object.keys(settings.modules).forEach(module => {
                    const pageName = module === 'transacciones' ? 'Transacciones' : module === 'reportes' ? 'Reportes' : module;
                    const menuItem = document.querySelector(`[data-page="${pageName}"]`);
                    if (menuItem) menuItem.style.display = settings.modules[module] ? 'block' : 'none';
                });
            }

            initSalesChartCanvas();
        }

        // ============================================================
        // USER SESSION
        // ============================================================
        function setupUserSession() {
            const user = {
                email: "",
                name: "",
                role: "",
                avatar: ""
            };

            document.getElementById('userName').textContent = user.name;
            document.getElementById('userEmail').textContent = user.email;
            document.getElementById('userAvatar').textContent = user.avatar;

            const roleBadge = document.getElementById('userRoleBadge');
            const adminSection = document.getElementById('adminModulesSection');
            const restrictedBanner = document.getElementById('restrictedAccessBanner');

            roleBadge.textContent = '';
            roleBadge.className = 'user-badge';
            adminSection.style.display = 'none';
            restrictedBanner.style.display = 'none';
        }

        function navigateTo(pageKey) {
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            const restrictedAdminPages = ['usuarios', 'seguridad', 'configuracion'];

            if (restrictedAdminPages.includes(pageKey) && currentUser.role !== 'admin') {
                alert('Acceso Denegado: Esta sección requiere privilegios de Administrador.');
                return;
            }

            const targetUrl = SYSTEM_ROUTES[pageKey];
            if (targetUrl) window.location.href = targetUrl;
        }

        function setupNavigationListeners() {
            document.querySelectorAll('[data-page]').forEach(element => {
                element.addEventListener('click', function(e) {
                    e.preventDefault();
                    // Cerrar sidebar en móvil al navegar
                    if (APP_STATE.isMobile) closeMobileSidebar();
                    navigateTo(this.getAttribute('data-page'));
                });
            });
        }

        function setupNotificationsEngine() {
            const btn = document.getElementById('notificationsBtn');
            const flyout = document.getElementById('notificationsFlyout');
            const markReadBtn = document.getElementById('markAllReadBtn');

            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                flyout.classList.toggle('active');
            });

            document.addEventListener('click', (e) => {
                if (!flyout.contains(e.target) && !btn.contains(e.target)) {
                    flyout.classList.remove('active');
                }
            });

            markReadBtn.addEventListener('click', () => {
                document.querySelectorAll('.flyout-item.unread').forEach(item => item.classList.remove('unread'));
                document.getElementById('notifBadge').textContent = '0';
            });
        }

        function switchMainTab(tabName, event) {
            document.querySelectorAll('.tab-item').forEach(t => t.classList.remove('active'));
            if (event && event.currentTarget) {
                event.currentTarget.classList.add('active');
            }
        }

        let chartDataset = [1200, 1900, 1500, 2200, 2800, 2400, 3840];
        let chartLabels = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

        function initSalesChartCanvas() {
            const canvas = document.getElementById('salesCanvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');

            // Usar devicePixelRatio para mejor nitidez en pantallas Retina
            const dpr = window.devicePixelRatio || 1;
            const rect = canvas.parentElement.getBoundingClientRect();

            canvas.width = rect.width * dpr;
            canvas.height = rect.height * dpr;
            canvas.style.width = rect.width + 'px';
            canvas.style.height = rect.height + 'px';

            ctx.scale(dpr, dpr);

            const width = rect.width;
            const height = rect.height;
            const isDark = document.body.classList.contains('dark-mode');
            const primaryColor = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim() || '#3a5ec7';

            ctx.clearRect(0, 0, width, height);

            // Padding adaptativo según tamaño de pantalla
            const padding = width < 400 ? 28 : 40;
            const graphWidth = width - padding * 2;
            const graphHeight = height - padding * 2;
            const maxValue = Math.max(...chartDataset) * 1.2;

            ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)';
            ctx.lineWidth = 1;
            for (let i = 0; i <= 4; i++) {
                const y = padding + (graphHeight / 4) * i;
                ctx.beginPath();
                ctx.moveTo(padding, y);
                ctx.lineTo(width - padding, y);
                ctx.stroke();
            }

            const points = chartDataset.map((val, index) => {
                const x = padding + (graphWidth / (chartDataset.length - 1)) * index;
                const y = height - padding - (val / maxValue) * graphHeight;
                return { x, y };
            });

            const fillGradient = ctx.createLinearGradient(0, 0, 0, height);
            fillGradient.addColorStop(0, hexToRgba(primaryColor, 0.35));
            fillGradient.addColorStop(1, hexToRgba(primaryColor, 0.0));

            ctx.beginPath();
            ctx.moveTo(points[0].x, height - padding);
            points.forEach(pt => ctx.lineTo(pt.x, pt.y));
            ctx.lineTo(points[points.length - 1].x, height - padding);
            ctx.closePath();
            ctx.fillStyle = fillGradient;
            ctx.fill();

            ctx.beginPath();
            ctx.strokeStyle = primaryColor;
            ctx.lineWidth = width < 400 ? 2.5 : 3;
            points.forEach((pt, idx) => {
                if (idx === 0) ctx.moveTo(pt.x, pt.y);
                else ctx.lineTo(pt.x, pt.y);
            });
            ctx.stroke();

            points.forEach((pt, idx) => {
                const dotRadius = width < 400 ? 4 : 6;
                const innerRadius = width < 400 ? 2 : 3;

                ctx.beginPath();
                ctx.arc(pt.x, pt.y, dotRadius, 0, Math.PI * 2);
                ctx.fillStyle = primaryColor;
                ctx.fill();

                ctx.beginPath();
                ctx.arc(pt.x, pt.y, innerRadius, 0, Math.PI * 2);
                ctx.fillStyle = '#ffffff';
                ctx.fill();

                ctx.fillStyle = isDark ? '#94a3b8' : '#64748b';
                ctx.font = `${width < 400 ? 10 : 12}px Plus Jakarta Sans`;
                ctx.textAlign = 'center';
                ctx.fillText(chartLabels[idx], pt.x, height - (width < 400 ? 6 : 10));
            });
        }

        function updateChartData(filter, event) {
            document.querySelectorAll('.chart-filter-btn').forEach(b => b.classList.remove('active'));
            if (event && event.target) event.target.classList.add('active');

            if (filter === 'week') {
                chartDataset = [1200, 1900, 1500, 2200, 2800, 2400, 3840];
                chartLabels = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
            } else if (filter === 'month') {
                chartDataset = [8000, 12000, 15000, 24000];
                chartLabels = ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4'];
            } else {
                chartDataset = [45000, 52000, 61000, 80000];
                chartLabels = ['Q1', 'Q2', 'Q3', 'Q4'];
            }
            initSalesChartCanvas();
        }

        let cartItems = [];

        function addSaleItem() {
            const select = document.getElementById('saleProductSelect');
            if (!select.value) return;

            const [price, name] = select.value.split('|');
            const numericPrice = parseFloat(price);

            const existing = cartItems.find(i => i.name === name);
            if (existing) {
                existing.qty++;
            } else {
                cartItems.push({ name, price: numericPrice, qty: 1 });
            }

            select.value = '';
            renderSaleCart();
        }

        function renderSaleCart() {
            const tbody = document.getElementById('quickSaleTableBody');
            if (cartItems.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-3">No hay productos en el carrito</td></tr>';
                updateSaleTotals(0);
                return;
            }

            let html = '';
            let subtotal = 0;

            cartItems.forEach((item, index) => {
                const itemTotal = item.price * item.qty;
                subtotal += itemTotal;
                html += `
                    <tr>
                        <td>${item.name}</td>
                        <td>
                            <input type="number" min="1" inputmode="numeric" class="form-control form-control-sm" value="${item.qty}" onchange="updateQty(${index}, this.value)">
                        </td>
                        <td>$${item.price.toFixed(2)}</td>
                        <td class="fw-bold">$${itemTotal.toFixed(2)}</td>
                    </tr>
                `;
            });

            tbody.innerHTML = html;
            updateSaleTotals(subtotal);
        }

        function updateQty(index, newQty) {
            cartItems[index].qty = parseInt(newQty) || 1;
            renderSaleCart();
        }

        function updateSaleTotals(subtotal) {
            const tax = subtotal * 0.16;
            const total = subtotal + tax;

            document.getElementById('saleSubtotal').textContent = `$${subtotal.toFixed(2)}`;
            document.getElementById('saleTax').textContent = `$${tax.toFixed(2)}`;
            document.getElementById('saleTotal').textContent = `$${total.toFixed(2)}`;
            calculateChange();
        }

        function calculateChange() {
            const totalText = document.getElementById('saleTotal').textContent.replace('$', '');
            const total = parseFloat(totalText) || 0;
            const cash = parseFloat(document.getElementById('cashReceived').value) || 0;
            const change = cash - total;

            const changeEl = document.getElementById('changeAmountText');
            if (change >= 0) {
                changeEl.textContent = `Cambio: $${change.toFixed(2)}`;
                changeEl.className = 'mt-2 fw-bold text-success';
            } else {
                changeEl.textContent = `Faltante: $${Math.abs(change).toFixed(2)}`;
                changeEl.className = 'mt-2 fw-bold text-danger';
            }
        }

        function processQuickSale() {
            if (cartItems.length === 0) {
                alert('El carrito se encuentra vacío.');
                return;
            }
            alert('Venta procesada exitosamente. Factura generada.');
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(30);
            cartItems = [];
            renderSaleCart();
            closeModal('quickSaleModal');
        }

        function openModal(id) {
            document.getElementById(id).classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeModal(id) {
            document.getElementById(id).classList.remove('active');
            document.body.style.overflow = '';
        }
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>