<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>SmartStock AI - Reportes Inteligentes v7.1</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.10.0/dist/tf.min.js"></script>
    <style>
        :root {
            --primary: #3a5ec7; --primary-dark: #2a4bb0; --secondary: #28a745;
            --dark: #2c3e50; --light: #f8f9fa; --gray: #6c757d; --danger: #dc3545;
            --warning: #ffc107; --info: #17a2b8; --bg: #f5f7fb; --card-bg: #ffffff;
            --text: #000000; --border-radius: 12px; --transition: all 0.3s ease;
            --sidebar-width: 270px; --sidebar-collapsed: 80px; --primary-rgb: 58, 94, 199;
            --font-main: 'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            --sidebar-opacity: 1;
            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }
        .dark-mode { --bg: #1a2235; --card-bg: #212b45; --text: #ffffff; --gray: #adb5bd; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: var(--font-main); }
        html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }
        body { background: var(--bg); color: var(--text); transition: var(--transition); min-height: 100vh; min-height: 100dvh; overflow-x: hidden; -webkit-tap-highlight-color: transparent; -webkit-font-smoothing: antialiased; }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary-dark); }
        .app-container { display: flex; min-height: 100vh; min-height: 100dvh; }
        .sidebar-overlay { display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.55); backdrop-filter: blur(3px); -webkit-backdrop-filter: blur(3px); z-index: 1040; opacity: 0; transition: opacity 0.3s ease; }
        .sidebar-overlay.active { display: block; opacity: 1; }
        .sidebar { width: var(--sidebar-width); background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%); color: #ffffff; height: 100vh; height: 100dvh; position: fixed; left: 0; top: 0; padding: 24px 16px; padding-top: calc(24px + var(--safe-top)); padding-bottom: calc(24px + var(--safe-bottom)); transition: var(--transition); z-index: 1050; display: flex; flex-direction: column; box-shadow: 4px 0 25px rgba(0,0,0,0.15); overflow-y: auto; opacity: var(--sidebar-opacity); will-change: transform; }
        .sidebar-header { padding: 0 12px 24px 12px; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; gap: 12px; }
        .sidebar .logo { font-size: 22px; font-weight: 800; letter-spacing: -0.5px; background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; display: flex; align-items: center; gap: 12px; min-width: 0; }
        .sidebar .logo span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .sidebar .logo-icon { width: 40px; height: 40px; background: var(--primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-size: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); -webkit-text-fill-color: white; flex-shrink: 0; }
        .sidebar .sidebar-toggle { background: rgba(255,255,255,0.15); border: none; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: var(--transition); font-size: 12px; flex-shrink: 0; }
        .sidebar .sidebar-toggle:hover { background: rgba(255,255,255,0.25); transform: scale(1.1); }
        .sidebar-close-btn { display: none; background: rgba(255,255,255,0.08); border: none; color: white; width: 36px; height: 36px; border-radius: 10px; align-items: center; justify-content: center; cursor: pointer; font-size: 16px; transition: var(--transition); flex-shrink: 0; }
        .sidebar-close-btn:hover { background: var(--danger); }
        .sidebar-nav-container { flex: 1; overflow-y: auto; padding-right: 4px; -webkit-overflow-scrolling: touch; }
        .menu-label { font-size: 11px; text-transform: uppercase; letter-spacing: 1.2px; color: #64748b; font-weight: 700; margin: 16px 12px 8px 12px; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li { margin-bottom: 4px; }
        .sidebar-menu a { color: #94a3b8; text-decoration: none; padding: 12px 16px; display: flex; align-items: center; border-radius: 8px; transition: var(--transition); font-weight: 500; font-size: 14px; cursor: pointer; gap: 12px; min-height: 44px; touch-action: manipulation; }
        .sidebar-menu a:hover { color: #ffffff; background: rgba(255,255,255,0.06); transform: translateX(3px); }
        .sidebar-menu a.active { color: #ffffff; background: var(--primary); font-weight: 600; box-shadow: 0 4px 15px rgba(0,0,0,0.2); }
        .sidebar-menu i { font-size: 18px; width: 22px; text-align: center; flex-shrink: 0; }
        .sidebar-footer { padding-top: 16px; border-top: 1px solid rgba(255,255,255,0.08); margin-top: auto; }
        .logout-btn { background: rgba(239,68,68,0.1); color: #f87171; border: 1px solid rgba(239,68,68,0.2); width: 100%; padding: 12px 16px; border-radius: 8px; display: flex; align-items: center; justify-content: center; gap: 10px; transition: var(--transition); cursor: pointer; font-weight: 600; font-size: 14px; min-height: 44px; touch-action: manipulation; }
        .logout-btn:hover { background: var(--danger); color: white; border-color: var(--danger); }
        .sidebar.collapsed { width: var(--sidebar-collapsed); }
        .sidebar.collapsed .menu-label, .sidebar.collapsed .logo span, .sidebar.collapsed .sidebar-menu a span, .sidebar.collapsed .logout-btn span { display: none; }
        .sidebar.collapsed .sidebar-menu a { justify-content: center; padding: 12px; }
        .sidebar.collapsed .sidebar-menu i { margin: 0; }
        .sidebar.collapsed .sidebar-header { justify-content: center; }
        .main-content { flex: 1; margin-left: var(--sidebar-width); padding: 20px; padding-top: calc(20px + var(--safe-top)); padding-bottom: calc(20px + var(--safe-bottom)); transition: var(--transition); min-width: 0; overflow-x: hidden; }
        .main-content.expanded { margin-left: var(--sidebar-collapsed); }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 15px; border-bottom: 1px solid var(--gray); gap: 16px; flex-wrap: wrap; }
        .page-title { font-size: 24px; font-weight: 600; color: var(--text); display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .controls { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .theme-switcher, .notifications, .kiosk-btn, .autodark-btn { background: var(--card-bg); width: 44px; height: 44px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: var(--transition); box-shadow: 0 3px 10px rgba(0,0,0,0.1); color: var(--text); position: relative; border: 1px solid rgba(0,0,0,0.05); flex-shrink: 0; touch-action: manipulation; }
        .theme-switcher:hover, .notifications:hover, .kiosk-btn:hover, .autodark-btn:hover { transform: translateY(-3px); }
        .notification-badge { position: absolute; top: -5px; right: -5px; background-color: var(--danger); color: white; border-radius: 50%; width: 18px; height: 18px; font-size: 10px; display: flex; align-items: center; justify-content: center; }
        .notification-badge.hidden { display: none; }
        .notification-container { position: relative; }
        .notification-dropdown { position: absolute; top: 55px; right: 0; width: 340px; background: var(--card-bg); border-radius: var(--border-radius); box-shadow: 0 5px 20px rgba(0,0,0,0.15); z-index: 1000; display: none; border: 1px solid rgba(0,0,0,0.1); max-height: 500px; overflow-y: auto; }
        .notification-dropdown.show { display: block; animation: slideDown 0.3s ease; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .notification-header { padding: 15px; border-bottom: 1px solid var(--gray); font-weight: 600; background: var(--primary); color: white; border-radius: var(--border-radius) var(--border-radius) 0 0; display: flex; justify-content: space-between; align-items: center; }
        .notification-header button { background: rgba(255,255,255,0.2); border: none; color: white; padding: 4px 10px; border-radius: 6px; font-size: 0.75rem; cursor: pointer; }
        .notification-list { max-height: 400px; overflow-y: auto; }
        .notification-item { padding: 12px 15px; border-bottom: 1px solid rgba(0,0,0,0.05); transition: var(--transition); cursor: pointer; }
        .notification-item:hover { background: rgba(58,94,199,0.05); }
        .notification-item.unread { background: rgba(58,94,199,0.1); border-left: 3px solid var(--primary); }
        .notification-item strong { display: block; margin-bottom: 3px; }
        .notification-item small { color: var(--gray); font-size: 11px; }
        .search-global { position: relative; width: 280px; }
        .search-global input { width: 100%; padding: 11px 40px 11px 40px; border: 1px solid rgba(0,0,0,0.1); border-radius: 30px; background: var(--card-bg); color: var(--text); font-size: 16px; transition: var(--transition); min-height: 44px; }
        .search-global input:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 4px rgba(58,94,199,0.15); }
        .search-global .search-icon { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: var(--gray); }
        .search-global .search-clear { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: var(--gray); cursor: pointer; display: none; }
        .search-global.has-value .search-clear { display: block; }
        .reports-section { background: var(--card-bg); border-radius: var(--border-radius); padding: 20px; margin-bottom: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .advanced-filters { background: rgba(58,94,199,0.05); border-radius: var(--border-radius); padding: 20px; margin-bottom: 20px; border: 1px solid rgba(58,94,199,0.2); }
        .filter-row { display: flex; gap: 15px; margin-bottom: 15px; flex-wrap: wrap; }
        .filter-group { flex: 1; min-width: 200px; }
        .filter-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 10px; flex-wrap: wrap; }
        .report-controls { display: flex; gap: 15px; margin-bottom: 20px; flex-wrap: wrap; align-items: center; }

        /* ============================================================
           SELECTOR DE TIPOS DE REPORTE - CON SCROLL HORIZONTAL ROBUSTO
           ============================================================ */
        .report-type-selector {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            position: relative;
            width: 100%;
            min-width: 0;
        }
        .report-type-btn {
            padding: 10px 16px;
            border: 1px solid var(--primary);
            background: transparent;
            color: var(--primary);
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            min-height: 44px;
            touch-action: manipulation;
            white-space: nowrap;
            flex-shrink: 0;
        }
        .report-type-btn.active { background: var(--primary); color: white; box-shadow: 0 3px 10px rgba(58,94,199,0.3); }
        .report-type-btn:hover { background: var(--primary); color: white; transform: translateY(-2px); }
        .report-actions { display: flex; gap: 10px; margin-left: auto; flex-wrap: wrap; align-items: center; }
        .report-content { min-height: 400px; border: 1px solid rgba(0,0,0,0.1); border-radius: var(--border-radius); padding: 20px; background: var(--card-bg); margin-bottom: 20px; }

        /* ============================================================
           FAVORITOS - SCROLL HORIZONTAL
           ============================================================ */
        .favorites-bar {
            display: flex;
            gap: 8px;
            margin-bottom: 15px;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            padding: 4px 0;
            scrollbar-width: none;
            scroll-snap-type: x proximity;
        }
        .favorites-bar::-webkit-scrollbar { display: none; }
        .favorite-btn {
            padding: 8px 14px;
            border-radius: 20px;
            border: 1px solid rgba(0,0,0,0.1);
            background: var(--card-bg);
            color: var(--text);
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
            flex-shrink: 0;
            min-height: 40px;
            scroll-snap-align: start;
            touch-action: manipulation;
        }
        .favorite-btn:hover { background: rgba(58,94,199,0.1); border-color: var(--primary); }
        .favorite-btn.active { background: var(--primary); color: white; border-color: var(--primary); }

        .table-responsive, .table-responsive-mobile { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        .report-table { width: 100%; border-collapse: collapse; min-width: 600px; }
        .report-table th, .report-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid rgba(0,0,0,0.05); white-space: nowrap; }
        .report-table th { background-color: rgba(58,94,199,0.1); font-weight: 600; color: var(--primary); }
        .report-table tr:hover { background-color: rgba(0,0,0,0.02); }
        .chart-container { height: 300px; margin: 20px 0; position: relative; }
        .stats-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 18px; margin-bottom: 20px; }
        .stat-card { background: var(--card-bg); border-radius: var(--border-radius); padding: 20px; box-shadow: 0 3px 10px rgba(0,0,0,0.08); transition: var(--transition); border-bottom: 3px solid var(--primary); position: relative; overflow: hidden; }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 8px 20px rgba(0,0,0,0.12); }
        .stat-value { font-size: 2rem; font-weight: 700; margin: 10px 0; }
        .stat-title { color: var(--gray); font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; }
        .trend-up { color: var(--secondary); }
        .trend-down { color: var(--danger); }
        .badge { padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; color: white; display: inline-block; }
        .badge.bg-success { background-color: var(--secondary); }
        .badge.bg-warning { background-color: var(--warning); color: #000; }
        .badge.bg-danger { background-color: var(--danger); }
        .badge.bg-info { background-color: var(--info); }
        .badge.bg-primary { background-color: var(--primary); }
        .badge.bg-secondary { background-color: var(--gray); }
        .empty-state { text-align: center; padding: 60px 20px; color: var(--gray); }
        .empty-state i { font-size: 64px; margin-bottom: 20px; color: var(--gray); opacity: 0.5; }
        .empty-state h3 { font-size: 1.4rem; margin-bottom: 10px; color: var(--text); }
        .empty-state p { font-size: 0.95rem; max-width: 500px; margin: 0 auto 20px; line-height: 1.6; }
        .tensorflow-section { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: var(--border-radius); padding: 20px; margin: 20px 0; color: white; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
        .tensorflow-section h4, .tensorflow-section h5 { color: white; }
        .tensorflow-section p { color: rgba(255,255,255,0.9); }
        .model-controls { display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; }
        .progress-bar { height: 20px; background-color: rgba(255,255,255,0.2); border-radius: 10px; overflow: hidden; margin: 10px 0; }
        .progress-fill { height: 100%; background: linear-gradient(90deg, #ff6b6b, #feca57); transition: width 0.3s ease; border-radius: 10px; }
        .ia-metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; margin: 15px 0; }
        .ia-metric { background: rgba(255,255,255,0.15); border-radius: 10px; padding: 12px; text-align: center; backdrop-filter: blur(10px); }
        .ia-metric-value { font-size: 1.3rem; font-weight: 800; margin: 5px 0; }
        .ia-metric-label { font-size: 0.7rem; opacity: 0.85; text-transform: uppercase; letter-spacing: 0.5px; }
        .menu-toggle { display: none; background: var(--primary); color: white; border: none; width: 52px; height: 52px; border-radius: 50%; position: fixed; bottom: calc(20px + var(--safe-bottom)); right: calc(20px + var(--safe-right)); z-index: 1001; box-shadow: 0 5px 15px rgba(0,0,0,0.2); cursor: pointer; transition: var(--transition); align-items: center; justify-content: center; touch-action: manipulation; font-size: 20px; }
        .menu-toggle:hover { transform: scale(1.1); }
        .menu-toggle:active { transform: scale(0.92); }
        .toast-container { position: fixed; top: calc(20px + var(--safe-top)); right: calc(20px + var(--safe-right)); left: 20px; z-index: 1100; display: flex; flex-direction: column; gap: 10px; pointer-events: none; align-items: flex-end; }
        .toast { background: var(--card-bg); border-radius: var(--border-radius); box-shadow: 0 5px 15px rgba(0,0,0,0.2); padding: 15px 20px; margin-bottom: 10px; display: flex; align-items: center; animation: slideInRight 0.3s forwards; min-width: 280px; max-width: 500px; border-left: 4px solid var(--primary); color: var(--text); pointer-events: auto; }
        .toast.success { border-left-color: var(--secondary); }
        .toast.error { border-left-color: var(--danger); }
        .toast.warning { border-left-color: var(--warning); }
        .toast i { margin-right: 10px; font-size: 20px; flex-shrink: 0; }
        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        @keyframes slideInRight { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes slideOutRight { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }
        .form-control, .form-select { color: var(--text) !important; background-color: var(--card-bg) !important; border: 1px solid rgba(0,0,0,0.1); font-size: 16px; min-height: 44px; }
        .form-control:focus, .form-select:focus { border-color: var(--primary); box-shadow: 0 0 0 0.2rem rgba(58,94,199,0.25); }
        .btn { padding: 10px 20px; border: none; border-radius: var(--border-radius); cursor: pointer; transition: var(--transition); font-weight: 500; min-height: 44px; touch-action: manipulation; display: inline-flex; align-items: center; justify-content: center; }
        .btn-primary { background: var(--primary); color: white !important; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); }
        .btn-outline-primary { border: 1px solid var(--primary); color: var(--primary) !important; background: transparent; }
        .btn-outline-primary:hover { background: var(--primary); color: white !important; }
        .btn-secondary { background: var(--gray); color: white !important; }
        .btn-success { background: var(--secondary); color: white !important; }
        .btn-danger { background: var(--danger); color: white !important; }
        .btn-warning { background: var(--warning); color: #000 !important; }
        .btn-info { background: var(--info); color: white !important; }
        .btn-dark { background: #1e293b; color: white !important; }
        .btn-sm { padding: 6px 12px; font-size: 0.8rem; min-height: 36px; }
        .sync-bar { background: var(--card-bg); border-radius: var(--border-radius); padding: 16px 22px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; border-left: 5px solid var(--info); box-shadow: 0 4px 12px rgba(0,0,0,0.06); }
        .sync-bar.disconnected { border-left-color: var(--danger); }
        .sync-bar-content { display: flex; align-items: center; gap: 15px; min-width: 0; }
        .sync-bar-icon { width: 50px; height: 50px; border-radius: 14px; background: linear-gradient(135deg, #06b6d4, #0891b2); display: flex; align-items: center; justify-content: center; color: white; font-size: 22px; flex-shrink: 0; }
        .sync-bar.disconnected .sync-bar-icon { background: linear-gradient(135deg, #dc3545, #b91c1c); }
        .sync-bar-text { min-width: 0; }
        .sync-bar-text h5 { margin: 0; font-size: 1rem; font-weight: 700; }
        .sync-bar-text p { margin: 0; font-size: 0.85rem; color: var(--gray); }
        .sync-live-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 20px; font-size: 0.8rem; font-weight: 700; background: rgba(16,185,129,0.15); color: #10b981; }
        .sync-live-badge.disconnected { background: rgba(220,53,69,0.15); color: #dc3545; }
        .sync-live-dot { width: 8px; height: 8px; border-radius: 50%; background: currentColor; animation: pulse 1.5s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
        .live-clock { display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px; border-radius: 20px; background: linear-gradient(135deg, #1e293b, #0f172a); color: white; font-size: 0.85rem; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.15); min-height: 44px; }
        .live-clock i { color: #fbbf24; }
        .health-score { background: var(--card-bg); border-radius: 20px; padding: 24px; text-align: center; box-shadow: 0 8px 24px rgba(0,0,0,0.08); position: relative; overflow: hidden; }
        .health-score-circle { width: 160px; height: 160px; margin: 0 auto 15px; position: relative; max-width: 100%; }
        .health-score-circle svg { transform: rotate(-90deg); max-width: 100%; height: auto; }
        .health-score-value { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 2.2rem; font-weight: 800; }
        .health-score-label { font-size: 1rem; font-weight: 700; margin-bottom: 8px; }
        .health-score-desc { font-size: 0.85rem; color: var(--gray); }
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; margin: 20px 0; }
        .kpi-card { background: var(--card-bg); border-radius: 14px; padding: 18px; box-shadow: 0 3px 10px rgba(0,0,0,0.06); transition: var(--transition); border-left: 4px solid var(--primary); }
        .kpi-card:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(0,0,0,0.1); }
        .kpi-label { font-size: 0.75rem; text-transform: uppercase; color: var(--gray); font-weight: 600; letter-spacing: 0.5px; margin-bottom: 6px; }
        .kpi-value { font-size: 1.5rem; font-weight: 800; color: var(--text); }
        .kpi-trend { font-size: 0.8rem; font-weight: 700; margin-top: 6px; display: inline-flex; align-items: center; gap: 4px; }
        .month-hero { border-radius: 20px; padding: 30px; color: white; margin-bottom: 25px; position: relative; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.25); }
        .month-hero::before { content: ''; position: absolute; top: -50%; right: -20%; width: 400px; height: 400px; background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%); border-radius: 50%; }
        .month-hero h2 { font-size: 1.9rem; font-weight: 800; margin-bottom: 10px; display: flex; align-items: center; gap: 15px; position: relative; flex-wrap: wrap; }
        .month-hero p { font-size: 1rem; opacity: 0.95; max-width: 800px; line-height: 1.6; position: relative; }
        .month-hero .hero-badges { display: flex; gap: 10px; margin-top: 15px; flex-wrap: wrap; position: relative; }
        .month-hero .hero-badge { background: rgba(255,255,255,0.2); padding: 6px 14px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; backdrop-filter: blur(10px); display: inline-flex; align-items: center; gap: 6px; }
        .month-theme-enero { background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); }
        .month-theme-febrero { background: linear-gradient(135deg, #ec4899 0%, #be185d 100%); }
        .month-theme-marzo { background: linear-gradient(135deg, #10b981 0%, #047857 100%); }
        .month-theme-abril { background: linear-gradient(135deg, #f59e0b 0%, #b45309 100%); }
        .month-theme-mayo { background: linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%); }
        .month-theme-junio { background: linear-gradient(135deg, #06b6d4 0%, #0e7490 100%); }
        .month-theme-julio { background: linear-gradient(135deg, #f97316 0%, #c2410c 100%); }
        .month-theme-agosto { background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); }
        .month-theme-septiembre { background: linear-gradient(135deg, #84cc16 0%, #4d7c0f 100%); }
        .month-theme-octubre { background: linear-gradient(135deg, #ea580c 0%, #9a3412 100%); }
        .month-theme-noviembre { background: linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%); }
        .month-theme-diciembre { background: linear-gradient(135deg, #dc2626 0%, #7f1d1d 100%); }
        .trending-2025-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 20px; }
        .trending-card { border-radius: 18px; padding: 22px; color: white; position: relative; overflow: hidden; transition: var(--transition); box-shadow: 0 10px 25px rgba(0,0,0,0.15); }
        .trending-card:hover { transform: translateY(-8px) scale(1.02); }
        .trending-rank { display: inline-flex; align-items: center; justify-content: center; width: 40px; height: 40px; background: rgba(255,255,255,0.25); border-radius: 50%; font-size: 1.1rem; font-weight: 800; margin-bottom: 12px; backdrop-filter: blur(10px); }
        .trending-card h4 { font-size: 1.2rem; font-weight: 800; margin-bottom: 6px; }
        .trending-metrics { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 12px; }
        .trending-metric { background: rgba(255,255,255,0.2); border-radius: 10px; padding: 8px 12px; backdrop-filter: blur(10px); }
        .trending-metric .tm-value { font-size: 1.1rem; font-weight: 800; }
        .trending-metric .tm-label { font-size: 0.7rem; opacity: 0.85; text-transform: uppercase; }
        .trending-reason { margin-top: 15px; padding-top: 15px; border-top: 1px solid rgba(255,255,255,0.2); font-size: 0.85rem; line-height: 1.5; }
        .trend-status-badge { padding: 3px 10px; border-radius: 12px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        .trend-status-exploding { background: #ef4444; color: white; }
        .trend-status-rising { background: #f59e0b; color: white; }
        .trend-status-stable { background: #10b981; color: white; }
        .trend-status-declining { background: #64748b; color: white; }
        .trend-flame { display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px; border-radius: 12px; background: linear-gradient(135deg, #f59e0b, #ef4444); color: white; font-size: 0.7rem; font-weight: 700; animation: pulse 2s infinite; }
        .smart-alert { display: flex; gap: 15px; padding: 18px; border-radius: 14px; margin-bottom: 12px; align-items: flex-start; transition: var(--transition); border-left: 5px solid; }
        .smart-alert:hover { transform: translateX(5px); }
        .smart-alert.critical { background: rgba(220,53,69,0.08); border-left-color: #dc3545; }
        .smart-alert.warning { background: rgba(255,193,7,0.08); border-left-color: #ffc107; }
        .smart-alert.info { background: rgba(23,162,184,0.08); border-left-color: #17a2b8; }
        .smart-alert.success { background: rgba(40,167,69,0.08); border-left-color: #28a745; }
        .smart-alert-icon { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0; }
        .smart-alert.critical .smart-alert-icon { background: #dc3545; color: white; }
        .smart-alert.warning .smart-alert-icon { background: #ffc107; color: #000; }
        .smart-alert.info .smart-alert-icon { background: #17a2b8; color: white; }
        .smart-alert.success .smart-alert-icon { background: #28a745; color: white; }
        .smart-alert-content h6 { font-weight: 700; font-size: 0.95rem; margin-bottom: 4px; }
        .smart-alert-content p { font-size: 0.85rem; color: var(--gray); margin: 0; line-height: 1.5; }
        .concept-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 18px; margin-top: 20px; }
        .concept-card { background: linear-gradient(135deg, rgba(58,94,199,0.06), rgba(58,94,199,0.02)); border: 1px solid rgba(58,94,199,0.15); border-radius: 15px; padding: 20px; transition: var(--transition); }
        .concept-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(58,94,199,0.15); border-color: var(--primary); }
        .concept-card .concept-icon { width: 50px; height: 50px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 22px; color: white; margin-bottom: 15px; }
        .concept-card h5 { font-size: 1rem; font-weight: 700; margin-bottom: 8px; }
        .concept-card p { font-size: 0.85rem; color: var(--gray); line-height: 1.5; margin: 0; }
        .simulator-panel { background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); border-radius: 16px; padding: 22px; border: 1px solid #bae6fd; }
        .dark-mode .simulator-panel { background: linear-gradient(135deg, #1e3a5f 0%, #0c4a6e 100%); border-color: #0369a1; }
        .simulator-row { display: flex; align-items: center; gap: 15px; margin-bottom: 12px; flex-wrap: wrap; }
        .simulator-row label { min-width: 180px; font-weight: 600; font-size: 0.9rem; }
        .simulator-row input[type=range] { flex: 1; min-width: 150px; }
        .simulator-value { min-width: 80px; text-align: right; font-weight: 800; color: var(--primary); }
        .simulator-result { background: var(--card-bg); border-radius: 12px; padding: 18px; margin-top: 15px; border-left: 4px solid var(--primary); }
        .simulator-result .sim-result-value { font-size: 1.8rem; font-weight: 800; color: var(--primary); }
        .seasonal-month-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 10px; margin: 20px 0; }
        .seasonal-month { padding: 15px 10px; border-radius: 12px; text-align: center; background: rgba(58,94,199,0.06); transition: var(--transition); border: 2px solid transparent; cursor: pointer; }
        .seasonal-month:hover { transform: translateY(-3px); }
        .seasonal-month.current { border-color: var(--primary); background: rgba(58,94,199,0.15); box-shadow: 0 5px 15px rgba(58,94,199,0.2); }
        .seasonal-month .sm-name { font-weight: 700; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .seasonal-month .sm-index { font-size: 1.5rem; font-weight: 800; margin: 5px 0; color: var(--primary); }
        .seasonal-month .sm-desc { font-size: 0.7rem; color: var(--gray); }
        .abc-badge { padding: 4px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: 800; color: white; }
        .abc-a { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .abc-b { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .abc-c { background: linear-gradient(135deg, #10b981, #059669); }
        .view-mode-selector { display: inline-flex; background: var(--card-bg); border-radius: 20px; padding: 4px; border: 1px solid rgba(0,0,0,0.1); flex-wrap: wrap; }
        .view-mode-btn { padding: 6px 14px; border: none; background: transparent; color: var(--gray); border-radius: 16px; cursor: pointer; font-size: 0.8rem; font-weight: 600; transition: var(--transition); min-height: 36px; }
        .view-mode-btn.active { background: var(--primary); color: white; }
        .card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; margin: 20px 0; }
        .product-card { background: var(--card-bg); border-radius: 14px; padding: 18px; box-shadow: 0 3px 10px rgba(0,0,0,0.06); transition: var(--transition); border-top: 4px solid var(--primary); }
        .product-card:hover { transform: translateY(-4px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .product-card h5 { font-size: 1rem; font-weight: 700; margin-bottom: 8px; }
        .product-card .pc-metric { display: flex; justify-content: space-between; font-size: 0.85rem; padding: 5px 0; border-bottom: 1px dashed rgba(0,0,0,0.06); }
        .product-card .pc-metric:last-child { border-bottom: none; }
        .history-timeline { position: relative; padding-left: 30px; margin-top: 20px; }
        .history-timeline::before { content: ''; position: absolute; left: 10px; top: 0; bottom: 0; width: 2px; background: rgba(58,94,199,0.2); }
        .history-item { position: relative; padding: 12px 0; }
        .history-item::before { content: ''; position: absolute; left: -25px; top: 18px; width: 12px; height: 12px; border-radius: 50%; background: var(--primary); border: 3px solid var(--card-bg); box-shadow: 0 0 0 2px var(--primary); }
        .history-item h6 { font-size: 0.9rem; font-weight: 700; margin-bottom: 3px; }
        .history-item p { font-size: 0.8rem; color: var(--gray); margin: 0; }
        .history-item .history-time { font-size: 0.7rem; color: var(--gray); margin-top: 3px; }
        .comparison-side-by-side { display: grid; grid-template-columns: 1fr auto 1fr; gap: 20px; align-items: center; margin: 20px 0; }
        .comparison-side { text-align: center; padding: 20px; background: var(--card-bg); border-radius: 14px; box-shadow: 0 3px 10px rgba(0,0,0,0.06); }
        .comparison-side h6 { font-size: 0.9rem; text-transform: uppercase; color: var(--gray); letter-spacing: 1px; margin-bottom: 10px; }
        .comparison-side .comparison-value { font-size: 2rem; font-weight: 800; color: var(--text); }
        .comparison-vs { font-size: 1.5rem; font-weight: 800; color: var(--primary); }
        .kiosk-mode .sidebar, .kiosk-mode .header, .kiosk-mode .sync-bar { display: none !important; }
        .kiosk-mode .main-content { margin-left: 0 !important; }
        .kiosk-mode { background: #000; }
        .growing-message { padding: 20px; border-radius: 16px; background: linear-gradient(135deg, rgba(58,94,199,0.08), rgba(58,94,199,0.02)); border: 2px dashed rgba(58,94,199,0.3); text-align: center; margin: 20px 0; }
        .growing-message h4 { font-size: 1.1rem; font-weight: 700; color: var(--primary); margin-bottom: 8px; }
        .growing-message p { font-size: 0.9rem; color: var(--gray); margin: 0; }
        .highlight-search { background: linear-gradient(120deg, #fef08a, #fde047); padding: 2px 4px; border-radius: 4px; color: #000; font-weight: 700; }
        .profit-badge { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 12px; background: linear-gradient(135deg, #10b981, #059669); color: white; font-size: 0.75rem; font-weight: 700; }
        .top-product-item { display: flex; align-items: center; gap: 12px; padding: 12px 0; border-bottom: 1px solid rgba(0,0,0,0.05); }
        .top-product-item:last-child { border-bottom: none; }
        .top-product-rank { width: 36px; height: 36px; border-radius: 10px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 0.9rem; flex-shrink: 0; }
        .top-product-info { flex: 1; min-width: 0; }
        .top-product-name { font-weight: 700; font-size: 0.9rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .top-product-meta { font-size: 0.75rem; color: var(--gray); }
        .top-product-value { font-weight: 800; color: var(--secondary); font-size: 0.95rem; }
        .loading-overlay { position: fixed; inset: 0; background: var(--bg); display: none; align-items: center; justify-content: center; z-index: 9999; }
        .loading-overlay.active { display: flex; }
        .spinner { width: 48px; height: 48px; border: 4px solid rgba(58,94,199,0.2); border-top-color: var(--primary); border-radius: 50%; animation: spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .explain-section { margin-bottom: 30px; }

        /* ============================================================
           RESPONSIVE - LAPTOP (≤1200px)
           ============================================================ */
        @media (max-width: 1200px) {
            .search-global { width: 220px; }
        }

        /* ============================================================
           RESPONSIVE - TABLET (≤992px)
           ============================================================ */
        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); width: var(--sidebar-width); }
            .sidebar.mobile-open { transform: translateX(0); }
            .sidebar.collapsed { width: var(--sidebar-width); }
            .sidebar.collapsed .menu-label, .sidebar.collapsed .logo span, .sidebar.collapsed .sidebar-menu a span, .sidebar.collapsed .logout-btn span { display: inline; }
            .sidebar.collapsed .sidebar-menu a { justify-content: flex-start; padding: 12px 16px; }
            .sidebar.collapsed .sidebar-header { justify-content: space-between; }
            .sidebar-close-btn { display: flex; }
            .sidebar .sidebar-toggle { display: none; }
            .main-content { margin-left: 0; padding: 20px; padding-top: calc(20px + var(--safe-top)); padding-bottom: calc(20px + var(--safe-bottom)); }
            .main-content.expanded { margin-left: 0; }
            .menu-toggle { display: flex; }
            .header { flex-direction: column; align-items: stretch; gap: 14px; }
            .controls { justify-content: space-between; flex-wrap: wrap; width: 100%; gap: 8px; }
            .search-global { order: -1; width: 100%; }

            .report-controls { flex-direction: column; align-items: stretch; gap: 12px; }

            /* SELECTOR DE REPORTES: SCROLL HORIZONTAL CON SNAP */
            .report-type-selector {
                flex-wrap: nowrap;
                overflow-x: auto;
                overflow-y: hidden;
                -webkit-overflow-scrolling: touch;
                scroll-snap-type: x proximity;
                padding: 4px 40px 8px 0;
                scrollbar-width: thin;
                scrollbar-color: var(--primary) transparent;
            }
            .report-type-selector::-webkit-scrollbar { height: 4px; display: block; }
            .report-type-selector::-webkit-scrollbar-track { background: rgba(58,94,199,0.08); border-radius: 4px; }
            .report-type-selector::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
            .report-type-btn { flex-shrink: 0; scroll-snap-align: start; }
            .report-actions { margin-left: 0; justify-content: flex-end; flex-wrap: wrap; }

            .filter-row { flex-direction: column; }
            .filter-group { min-width: 100%; }
            .sync-bar { flex-direction: column; align-items: stretch; }
            .sync-bar > div:last-child { display: flex; flex-wrap: wrap; gap: 8px; }
            .sync-bar > div:last-child .btn { flex: 1; min-width: 140px; }
            .notification-dropdown { position: fixed; top: auto; bottom: calc(90px + var(--safe-bottom)); left: 16px; right: 16px; width: auto; max-width: 440px; margin: 0 auto; }
            .stats-cards { grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); }
            .kpi-grid { grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); }
        }

        /* ============================================================
           RESPONSIVE - MÓVIL (≤640px)
           ============================================================ */
        @media (max-width: 640px) {
            .main-content { padding: 16px; padding-top: calc(16px + var(--safe-top)); padding-bottom: calc(90px + var(--safe-bottom)); }
            .sidebar { width: 88vw; max-width: 320px; padding: 20px 12px; padding-top: calc(20px + var(--safe-top)); padding-bottom: calc(20px + var(--safe-bottom)); }
            .header { padding-bottom: 12px; margin-bottom: 16px; gap: 10px; }
            .page-title { font-size: 18px; gap: 8px; }
            .controls { gap: 6px; }
            .theme-switcher, .notifications, .kiosk-btn, .autodark-btn { width: 40px; height: 40px; font-size: 14px; }
            .live-clock { display: none; }
            .search-global input { min-height: 42px; padding: 10px 38px 10px 38px; }
            .search-global .search-icon, .search-global .search-clear { font-size: 14px; }

            /* SELECTOR DE REPORTES EN MÓVIL - MÁS COMPACTO Y CON SCROLL */
            .report-type-selector {
                gap: 6px;
                margin: 0 -16px;
                padding: 4px 32px 8px 16px;
                width: calc(100% + 32px);
                -webkit-mask-image: linear-gradient(to right, #000 0%, #000 calc(100% - 40px), transparent 100%);
                mask-image: linear-gradient(to right, #000 0%, #000 calc(100% - 40px), transparent 100%);
            }
            .report-type-btn {
                padding: 8px 12px;
                font-size: 0.75rem;
                gap: 4px;
                min-height: 40px;
            }
            .report-type-btn i { font-size: 0.85rem; }

            .report-actions {
                gap: 6px;
                flex-wrap: nowrap;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                padding-bottom: 4px;
                scrollbar-width: none;
            }
            .report-actions::-webkit-scrollbar { display: none; }
            .report-actions .btn { flex-shrink: 0; padding: 8px 12px; font-size: 0.8rem; }

            /* FAVORITOS - SCROLL CON DEGRADADO */
            .favorites-bar {
                gap: 6px;
                margin-bottom: 12px;
                margin: 0 -16px 12px -16px;
                padding: 4px 32px 4px 16px;
                width: calc(100% + 32px);
                -webkit-mask-image: linear-gradient(to right, #000 0%, #000 calc(100% - 40px), transparent 100%);
                mask-image: linear-gradient(to right, #000 0%, #000 calc(100% - 40px), transparent 100%);
            }
            .favorite-btn { padding: 7px 12px; font-size: 0.75rem; min-height: 36px; }

            .reports-section { padding: 14px; border-radius: 10px; }
            .advanced-filters { padding: 14px; }
            .filter-group { min-width: 100%; }
            .filter-actions { flex-direction: column; }
            .filter-actions .btn { width: 100%; }
            .report-content { padding: 14px; border-radius: 10px; min-height: 300px; }
            .sync-bar { padding: 14px; border-radius: 10px; }
            .sync-bar-icon { width: 40px; height: 40px; font-size: 18px; border-radius: 10px; }
            .sync-bar-text h5 { font-size: 0.9rem; }
            .sync-bar-text p { font-size: 0.75rem; }
            .sync-live-badge { font-size: 0.7rem; padding: 4px 10px; }
            .sync-bar > div:last-child { flex-direction: column; }
            .sync-bar > div:last-child .btn { width: 100%; }
            .stats-cards { grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 14px; }
            .stat-card { padding: 14px; border-radius: 10px; }
            .stat-card .stat-value { font-size: 1.4rem; }
            .stat-card .stat-title { font-size: 0.75rem; }
            .stat-card i.fa-2x { font-size: 1.3em !important; }
            .kpi-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
            .kpi-card { padding: 14px; border-radius: 10px; }
            .kpi-value { font-size: 1.2rem; }
            .kpi-label { font-size: 0.7rem; }
            .month-hero { padding: 20px; border-radius: 14px; margin-bottom: 16px; }
            .month-hero h2 { font-size: 1.25rem; gap: 8px; line-height: 1.25; }
            .month-hero p { font-size: 0.85rem; line-height: 1.5; }
            .month-hero .hero-badges { gap: 6px; margin-top: 12px; }
            .month-hero .hero-badge { font-size: 0.7rem; padding: 4px 10px; }
            .trending-2025-grid { grid-template-columns: 1fr; gap: 14px; }
            .trending-card { padding: 18px; border-radius: 14px; }
            .trending-card h4 { font-size: 1.05rem; }
            .trending-rank { width: 34px; height: 34px; font-size: 0.95rem; }
            .trending-metrics { gap: 8px; margin-top: 10px; }
            .trending-metric { padding: 6px 10px; }
            .trending-metric .tm-value { font-size: 0.95rem; }
            .chart-container { height: 220px; margin: 14px 0; }
            .health-score { padding: 18px; }
            .health-score-circle { width: 130px; height: 130px; }
            .health-score-circle svg { width: 130px; height: 130px; }
            .health-score-value { font-size: 1.7rem; }
            .concept-cards { grid-template-columns: 1fr; gap: 12px; }
            .concept-card { padding: 16px; }
            .simulator-panel { padding: 16px; border-radius: 12px; }
            .simulator-row { flex-direction: column; align-items: stretch; gap: 6px; }
            .simulator-row label { min-width: 100%; font-size: 0.85rem; }
            .simulator-row input[type=range] { width: 100%; }
            .simulator-value { text-align: left; min-width: 0; }
            .simulator-result .sim-result-value { font-size: 1.4rem; }
            .seasonal-month-grid { grid-template-columns: repeat(3, 1fr); gap: 8px; }
            .seasonal-month { padding: 12px 8px; }
            .seasonal-month .sm-name { font-size: 0.75rem; }
            .seasonal-month .sm-index { font-size: 1.2rem; }
            .comparison-side-by-side { grid-template-columns: 1fr; gap: 12px; }
            .comparison-vs { text-align: center; font-size: 1.2rem; }
            .comparison-side { padding: 16px; }
            .comparison-side .comparison-value { font-size: 1.5rem; }
            .report-table { font-size: 0.8rem; min-width: 500px; }
            .report-table th, .report-table td { padding: 8px 10px; }
            .smart-alert { padding: 14px; gap: 10px; }
            .smart-alert-icon { width: 36px; height: 36px; font-size: 16px; border-radius: 10px; }
            .smart-alert-content h6 { font-size: 0.85rem; }
            .smart-alert-content p { font-size: 0.78rem; }
            .ia-metrics-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
            .ia-metric { padding: 10px 8px; }
            .ia-metric-value { font-size: 1.05rem; }
            .ia-metric-label { font-size: 0.65rem; }
            .tensorflow-section { padding: 16px; border-radius: 12px; }
            .model-controls { flex-direction: column; }
            .model-controls .btn { width: 100%; }
            .top-product-item { gap: 10px; padding: 10px 0; }
            .top-product-rank { width: 32px; height: 32px; font-size: 0.8rem; }
            .top-product-name { font-size: 0.85rem; }
            .top-product-value { font-size: 0.85rem; }
            .notification-dropdown { bottom: calc(80px + var(--safe-bottom)); left: 12px; right: 12px; }
            .notification-item { padding: 10px 12px; }
            .toast-container { top: calc(12px + var(--safe-top)); right: 12px; left: 12px; align-items: stretch; }
            .toast { min-width: 0; max-width: 100%; width: 100%; padding: 12px 16px; font-size: 0.85rem; }
            .empty-state { padding: 40px 16px; }
            .empty-state i { font-size: 48px; }
            .empty-state h3 { font-size: 1.15rem; }
            .empty-state p { font-size: 0.85rem; }
            .btn { padding: 10px 16px; font-size: 0.85rem; }
            .btn-sm { padding: 6px 10px; font-size: 0.75rem; }
            .menu-toggle { width: 48px; height: 48px; font-size: 18px; }
        }

        /* ============================================================
           RESPONSIVE - MÓVIL PEQUEÑO (≤380px)
           ============================================================ */
        @media (max-width: 380px) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); padding-bottom: calc(80px + var(--safe-bottom)); }
            .page-title { font-size: 16px; }
            .theme-switcher, .notifications, .kiosk-btn, .autodark-btn { width: 36px; height: 36px; font-size: 13px; }
            .stats-cards { grid-template-columns: 1fr; }
            .kpi-grid { grid-template-columns: 1fr; }
            .seasonal-month-grid { grid-template-columns: repeat(2, 1fr); }
            .trending-card { padding: 14px; }
            .trending-card h4 { font-size: 0.95rem; }
            .month-hero h2 { font-size: 1.1rem; }
            .report-type-btn { padding: 7px 10px; font-size: 0.7rem; }
            .report-type-selector {
                margin: 0 -12px;
                padding: 4px 28px 8px 12px;
                width: calc(100% + 24px);
                -webkit-mask-image: linear-gradient(to right, #000 0%, #000 calc(100% - 32px), transparent 100%);
                mask-image: linear-gradient(to right, #000 0%, #000 calc(100% - 32px), transparent 100%);
            }
            .favorites-bar {
                margin: 0 -12px 12px -12px;
                padding: 4px 28px 4px 12px;
                width: calc(100% + 24px);
            }
            .ia-metrics-grid { grid-template-columns: 1fr 1fr; }
            .chart-container { height: 200px; }
        }

        /* ============================================================
           LANDSCAPE MÓVIL
           ============================================================ */
        @media (max-height: 500px) and (orientation: landscape) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); }
            .header { margin-bottom: 12px; padding-bottom: 10px; }
            .chart-container { height: 180px; }
            .month-hero { padding: 16px; margin-bottom: 12px; }
            .month-hero h2 { font-size: 1.1rem; }
            .sidebar { padding: 16px 12px; padding-top: calc(16px + var(--safe-top)); }
        }

        /* ============================================================
           PANTALLAS GRANDES
           ============================================================ */
        @media (min-width: 1440px) {
            .main-content { padding: 30px; }
            .chart-container { height: 340px; }
            .trending-2025-grid { grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); }
        }
        @media (min-width: 1920px) {
            .main-content { padding: 40px 60px; max-width: 1800px; margin-left: auto; margin-right: auto; }
        }

        /* ============================================================
           TOUCH
           ============================================================ */
        @media (hover: none) {
            .theme-switcher:hover, .notifications:hover, .kiosk-btn:hover, .autodark-btn:hover { transform: none; }
            .report-type-btn:hover { background: transparent; color: var(--primary); transform: none; }
            .report-type-btn.active:hover { background: var(--primary); color: white; }
            .stat-card:hover { transform: none; }
            .trending-card:hover { transform: none; }
            .kpi-card:hover { transform: none; }
            .concept-card:hover { transform: none; }
            .smart-alert:hover { transform: none; }
            .seasonal-month:hover { transform: none; }
            .product-card:hover { transform: none; }
            .sidebar-menu a:hover { transform: none; background: transparent; }
            .sidebar-menu a.active:hover { background: var(--primary); }
        }

        /* ============================================================
           REDUCED MOTION
           ============================================================ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        /* ============================================================
           PRINT
           ============================================================ */
        @media print {
            .sidebar, .header, .sync-bar, .menu-toggle, .report-actions, .favorites-bar, .advanced-filters, .report-type-selector { display: none !important; }
            .main-content { margin-left: 0 !important; }
        }
    </style>
</head>
<body>
    <div class="loading-overlay" id="loadingOverlay"><div class="spinner"></div></div>

    <div class="app-container">
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo"><div class="logo-icon"><i class="fas fa-brain"></i></div><span class="system-name-display">SmartStock AI</span></div>
                <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-chevron-left"></i></button>
                <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú"><i class="fas fa-times"></i></button>
            </div>
            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/principal.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes-stacked"></i> <span>Inventario</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-right-left"></i> <span>Transacciones</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Reportes.php" class="active"><i class="fas fa-chart-column"></i> <span>Reportes</span></a></li>
                </ul>
                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/clientes.php"><i class="fas fa-address-book"></i> <span>Clientes</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck-field"></i> <span>Proveedores</span></a></li>
                </ul>
                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users-gear"></i> <span>Usuarios</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-halved"></i> <span>Seguridad</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-circle-user"></i> <span>Mi Perfil</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-sliders"></i> <span>Configuración</span></a></li>
                </ul>
            </div>
            <div class="sidebar-footer"><button class="logout-btn" id="logoutBtn"><i class="fas fa-arrow-right-from-bracket"></i><span>Cerrar Sesión</span></button></div>
        </aside>

        <div class="main-content" id="mainContent">
            <div class="header">
                <h1 class="page-title">
                    <i class="fas fa-chart-line"></i>
                    Reportes Inteligentes <span class="real-time-badge" style="background: linear-gradient(135deg, #ff6b6b, #ee5253); color: white; padding: 3px 10px; border-radius: 15px; font-size: 0.8rem;">v7.1</span>
                </h1>
                <div class="controls">
                    <div class="live-clock" id="liveClock"><i class="fas fa-clock"></i> <span id="clockText">--:--:--</span></div>
                    <div class="search-global" id="searchGlobalWrapper">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" id="globalSearchInput" placeholder="Buscar productos...">
                        <i class="fas fa-times search-clear" id="searchClearBtn"></i>
                    </div>
                    <div class="theme-switcher" id="themeToggle"><i class="fas fa-moon"></i></div>
                    <div class="autodark-btn" id="autoDarkToggle" title="Modo oscuro automático"><i class="fas fa-adjust"></i></div>
                    <div class="kiosk-btn" id="kioskToggle" title="Modo Kiosco"><i class="fas fa-expand"></i></div>
                    <div class="notification-container">
                        <div class="notifications" id="notificationBtn">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge hidden" id="notificationBadge">0</span>
                        </div>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-header">
                                <span><i class="fas fa-bell me-2"></i>Notificaciones</span>
                                <button id="markAllReadBtn">Marcar todas</button>
                            </div>
                            <div class="notification-list" id="notificationList"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="sync-bar disconnected" id="syncBar">
                <div class="sync-bar-content">
                    <div class="sync-bar-icon"><i class="fas fa-sync-alt" id="syncIcon"></i></div>
                    <div class="sync-bar-text">
                        <h5 id="syncTitle">Verificando inventario...</h5>
                        <p id="syncSubtitle">Leyendo datos de inventario1.php</p>
                    </div>
                </div>
                <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                    <span class="sync-live-badge disconnected" id="syncLiveBadge"><span class="sync-live-dot"></span> Sin conexión</span>
                    <button class="btn btn-sm btn-outline-primary" id="syncNowBtn"><i class="fas fa-sync me-1"></i> Sincronizar</button>
                    <button class="btn btn-sm btn-primary" id="goToInventoryBtn"><i class="fas fa-plus me-1"></i> Agregar Productos</button>
                </div>
            </div>

            <div class="favorites-bar" id="favoritesBar">
                <button class="favorite-btn" data-report="trending"><i class="fas fa-fire"></i> Tendencias</button>
                <button class="favorite-btn" data-report="health"><i class="fas fa-heartbeat"></i> Salud Negocio</button>
                <button class="favorite-btn" data-report="abc"><i class="fas fa-sort-amount-down"></i> Análisis ABC</button>
                <button class="favorite-btn" data-report="profit"><i class="fas fa-dollar-sign"></i> Ganancias</button>
                <button class="favorite-btn" data-report="year-comparison"><i class="fas fa-calendar-check"></i> Año vs Año</button>
                <button class="favorite-btn" data-report="alerts"><i class="fas fa-bell"></i> Alertas</button>
            </div>

            <div class="advanced-filters no-print" id="filtersPanel" style="display: none;">
                <h5><i class="fas fa-filter me-2"></i>Filtros Avanzados</h5>
                <div class="filter-row">
                    <div class="filter-group">
                        <label class="form-label">Categoría</label>
                        <select class="form-select" id="categoryFilter"><option value="all">Todas</option></select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Estado de Stock</label>
                        <select class="form-select" id="stockStatusFilter">
                            <option value="all">Todos</option>
                            <option value="En stock">En stock</option>
                            <option value="Stock bajo">Stock bajo</option>
                            <option value="Stock crítico">Stock crítico</option>
                            <option value="Agotado">Agotado</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Rango de Precios</label>
                        <div class="input-group">
                            <input type="number" class="form-control" id="minPrice" placeholder="Mín">
                            <span class="input-group-text">-</span>
                            <input type="number" class="form-control" id="maxPrice" placeholder="Máx">
                        </div>
                    </div>
                </div>
                <div class="filter-row">
                    <div class="filter-group">
                        <label class="form-label">Rango de Stock</label>
                        <div class="input-group">
                            <input type="number" class="form-control" id="minStock" placeholder="Mín">
                            <span class="input-group-text">-</span>
                            <input type="number" class="form-control" id="maxStock" placeholder="Máx">
                        </div>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Ordenar por</label>
                        <select class="form-select" id="sortBy">
                            <option value="name">Nombre (A-Z)</option>
                            <option value="name_desc">Nombre (Z-A)</option>
                            <option value="price">Precio ↑</option>
                            <option value="price_desc">Precio ↓</option>
                            <option value="stock">Stock ↑</option>
                            <option value="stock_desc">Stock ↓</option>
                            <option value="value_desc">Valor ↓</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Vista</label>
                        <div class="view-mode-selector" id="viewModeSelector">
                            <button class="view-mode-btn active" data-view="table"><i class="fas fa-table"></i> Tabla</button>
                            <button class="view-mode-btn" data-view="cards"><i class="fas fa-th-large"></i> Tarjetas</button>
                        </div>
                    </div>
                </div>
                <div class="filter-actions">
                    <button class="btn btn-outline-secondary" id="resetFilters"><i class="fas fa-redo me-2"></i>Restablecer</button>
                    <button class="btn btn-primary" id="applyFilters"><i class="fas fa-check me-2"></i>Aplicar</button>
                </div>
            </div>

            <div class="reports-section">
                <div class="report-controls">
                    <div class="report-type-selector">
                        <button class="report-type-btn active" data-type="trending"><i class="fas fa-fire"></i> Tendencias</button>
                        <button class="report-type-btn" data-type="health"><i class="fas fa-heartbeat"></i> Salud</button>
                        <button class="report-type-btn" data-type="abc"><i class="fas fa-sort-amount-down"></i> ABC</button>
                        <button class="report-type-btn" data-type="profit"><i class="fas fa-dollar-sign"></i> Ganancias</button>
                        <button class="report-type-btn" data-type="year-comparison"><i class="fas fa-calendar-check"></i> Año vs Año</button>
                        <button class="report-type-btn" data-type="reorder"><i class="fas fa-shopping-cart"></i> Reorden</button>
                        <button class="report-type-btn" data-type="alerts"><i class="fas fa-bell"></i> Alertas</button>
                        <button class="report-type-btn" data-type="simulator"><i class="fas fa-gamepad"></i> Simulador</button>
                        <button class="report-type-btn" data-type="calendar"><i class="fas fa-calendar-alt"></i> Calendario</button>
                        <button class="report-type-btn" data-type="comparison"><i class="fas fa-balance-scale"></i> Comparar</button>
                        <button class="report-type-btn" data-type="history"><i class="fas fa-history"></i> Historial</button>
                        <button class="report-type-btn" data-type="top"><i class="fas fa-trophy"></i> Top Productos</button>
                        <button class="report-type-btn" data-type="explained"><i class="fas fa-graduation-cap"></i> Explicación IA</button>
                        <button class="report-type-btn" data-type="inventory"><i class="fas fa-boxes"></i> Inventario</button>
                        <button class="report-type-btn" data-type="ai"><i class="fas fa-brain"></i> IA Avanzada</button>
                    </div>
                    <div class="report-actions no-print">
                        <button class="btn btn-outline-primary btn-sm" id="printReport"><i class="fas fa-print"></i></button>
                        <div class="btn-group">
                            <button class="btn btn-primary btn-sm" id="exportDropdownBtn"><i class="fas fa-file-export me-1"></i>Exportar</button>
                            <button class="btn btn-primary btn-sm dropdown-toggle dropdown-toggle-split" type="button" data-bs-toggle="dropdown"><span class="visually-hidden">Toggle</span></button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#" data-format="pdf"><i class="fas fa-file-pdf me-2"></i>PDF</a></li>
                                <li><a class="dropdown-item" href="#" data-format="excel"><i class="fas fa-file-excel me-2"></i>Excel</a></li>
                                <li><a class="dropdown-item" href="#" data-format="csv"><i class="fas fa-file-csv me-2"></i>CSV</a></li>
                                <li><a class="dropdown-item" href="#" data-format="json"><i class="fas fa-file-code me-2"></i>JSON</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="report-content" id="reportContent"></div>
            </div>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============================================================
        // WORKER EMBEBIDO
        // ============================================================
        const WORKER_SOURCE = `
            importScripts('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.10.0/dist/tf.min.js');
            let model = null, ensembleModels = [], cancelled = false;
            function hasNaN(arr) { if (!Array.isArray(arr)) return false; for (let i = 0; i < arr.length; i++) { const v = arr[i]; if (Array.isArray(v)) { if (hasNaN(v)) return true; } else if (typeof v === 'number' && (!isFinite(v) || isNaN(v))) return true; } return false; }
            function sanitizeFeatures(f) { return f.map(r => r.map(v => (typeof v === 'number' && isFinite(v)) ? v : 0)); }
            function sanitizeLabels(l) { return l.map(v => (typeof v === 'number' && isFinite(v)) ? v : 1); }
            function createMainModel(fc) {
                const m = tf.sequential();
                m.add(tf.layers.dense({ units: 64, activation: 'relu', inputShape: [fc], kernelRegularizer: tf.regularizers.l2({ l2: 0.0005 }), kernelInitializer: 'heNormal' }));
                m.add(tf.layers.batchNormalization()); m.add(tf.layers.dropout({ rate: 0.15 }));
                m.add(tf.layers.dense({ units: 128, activation: 'relu', kernelRegularizer: tf.regularizers.l2({ l2: 0.0005 }), kernelInitializer: 'heNormal' }));
                m.add(tf.layers.batchNormalization()); m.add(tf.layers.dropout({ rate: 0.25 }));
                m.add(tf.layers.dense({ units: 96, activation: 'relu', kernelRegularizer: tf.regularizers.l2({ l2: 0.0005 }) }));
                m.add(tf.layers.batchNormalization()); m.add(tf.layers.dropout({ rate: 0.25 }));
                m.add(tf.layers.dense({ units: 64, activation: 'relu' })); m.add(tf.layers.dropout({ rate: 0.2 }));
                m.add(tf.layers.dense({ units: 32, activation: 'relu' }));
                m.add(tf.layers.dense({ units: 16, activation: 'relu' }));
                m.add(tf.layers.dense({ units: 1, activation: 'linear' }));
                const o = tf.train.adam(0.001); o.clipNorm = 1.0;
                m.compile({ optimizer: o, loss: 'meanSquaredError', metrics: ['mae'] });
                return m;
            }
            function createEnsemble(fc) {
                const models = [];
                const specs = [
                    { units: [96, 192, 96, 48], activation: 'relu', lr: 0.001 },
                    { units: [48, 96, 48], activation: 'relu', lr: 0.001, dropout: 0.5 },
                    { units: [32, 16, 8], activation: 'relu', lr: 0.0015 },
                    { units: [64, 64, 32], activation: 'tanh', lr: 0.001 },
                    { units: [128, 64, 32], activation: 'elu', lr: 0.0012 },
                    { units: [64, 64, 32, 16], activation: 'relu', lr: 0.0013 },
                    { units: [256, 128], activation: 'relu', lr: 0.0009, dropout: 0.3 }
                ];
                for (const s of specs) {
                    const m = tf.sequential();
                    s.units.forEach((u, i) => { const cfg = { units: u, activation: s.activation }; if (i === 0) cfg.inputShape = [fc]; m.add(tf.layers.dense(cfg)); if (s.dropout && i < s.units.length - 1) m.add(tf.layers.dropout({ rate: s.dropout })); });
                    m.add(tf.layers.dense({ units: 1 }));
                    const o = tf.train.adam(s.lr); o.clipNorm = 1.0;
                    m.compile({ optimizer: o, loss: 'meanSquaredError', metrics: ['mae'] });
                    models.push(m);
                }
                return models;
            }
            function safeDataSync(t) { try { return Array.from(t.dataSync()); } catch (e) { return null; } }
            async function safePredictData(m, t) { let o = null; try { o = m.predict(t); return Array.from(await o.data()); } finally { if (o && o.dispose) o.dispose(); } }
            self.onmessage = async (e) => {
                const msg = e.data || {};
                if (msg.type === 'cancel') { cancelled = true; return; }
                if (msg.type !== 'train') return;
                cancelled = false;
                const { featureCount, epochs, patience, augmentationFactor } = msg;
                let { features, labels } = msg;
                try {
                    if (!Array.isArray(features) || !Array.isArray(labels) || !features.length) throw new Error('Dataset vacío');
                    if (features.length !== labels.length) throw new Error('features.length ≠ labels.length');
                    if (features[0].length !== featureCount) throw new Error('Feature mismatch');
                    features = sanitizeFeatures(features); labels = sanitizeLabels(labels);
                    if (hasNaN(features)) throw new Error('Features NaN');
                    if (hasNaN(labels)) throw new Error('Labels NaN');
                    const augF = [], augL = [];
                    for (let i = 0; i < features.length; i++) {
                        augF.push(features[i]); augL.push(labels[i]);
                        for (let k = 0; k < augmentationFactor - 1; k++) {
                            const nl = 0.03 + k * 0.015;
                            augF.push(features[i].map(v => Math.max(0, Math.min(1.5, v + (Math.random() - 0.5) * 2 * nl))));
                            augL.push(Math.max(1, labels[i] * (1 + (Math.random() - 0.5) * 0.05)));
                        }
                    }
                    const total = augF.length;
                    const split = Math.max(2, Math.floor(total * 0.8));
                    const trainX = tf.tensor2d(augF.slice(0, split));
                    const trainY = tf.tensor1d(augL.slice(0, split));
                    const valX = tf.tensor2d(augF.slice(split));
                    const valY = tf.tensor1d(augL.slice(split));
                    const hasVal = valX.shape[0] > 0;
                    const trueVals = hasVal ? safeDataSync(valY) : safeDataSync(trainY);
                    const maxLabel = labels.reduce((m, v) => v > m ? v : m, -Infinity);
                    model = createMainModel(featureCount);
                    ensembleModels = createEnsemble(featureCount);
                    const hist = { loss: [], val_loss: [], mae: [], val_mae: [], accuracy: [], val_accuracy: [], lr: [] };
                    let lr = 0.002;
                    const minLR = 0.0001, decay = Math.pow(minLR / lr, 1 / epochs);
                    let bestVal = Infinity, bestW = null, bestE = 0, pat = 0;
                    for (let ep = 0; ep < epochs; ep++) {
                        if (cancelled) { try { trainX.dispose(); trainY.dispose(); valX.dispose(); valY.dispose(); } catch (e) {} self.postMessage({ type: 'cancelled' }); return; }
                        lr = Math.max(minLR, lr * decay);
                        model.optimizer.learningRate = lr;
                        const h = await model.fit(trainX, trainY, { epochs: 1, batchSize: Math.min(16, Math.max(2, Math.floor(total / 8))), validationData: hasVal ? [valX, valY] : undefined, shuffle: true, verbose: 0 });
                        const loss = h.history.loss[0], valLoss = hasVal ? h.history.val_loss[0] : loss;
                        const mae = h.history.mae[0], valMae = hasVal ? h.history.val_mae[0] : mae;
                        if (!isFinite(loss)) { self.postMessage({ type: 'error', message: 'Loss NaN' }); return; }
                        hist.loss.push(loss); hist.val_loss.push(valLoss); hist.mae.push(mae); hist.val_mae.push(valMae);
                        const acc = Math.max(0, 100 - (mae / Math.max(1, maxLabel)) * 100);
                        const vAcc = Math.max(0, 100 - (valMae / Math.max(1, maxLabel)) * 100);
                        hist.accuracy.push(acc); hist.val_accuracy.push(vAcc); hist.lr.push(lr);
                        if (valLoss < bestVal) { bestVal = valLoss; bestE = ep; pat = 0; if (bestW) bestW.forEach(w => w.dispose()); bestW = model.getWeights().map(w => w.clone()); } else pat++;
                        if (ep % 3 === 0 || ep === epochs - 1) self.postMessage({ type: 'progress', epoch: ep + 1, total: epochs, loss, valLoss, accuracy: acc, lr, patience: pat });
                        if (pat >= patience) { self.postMessage({ type: 'earlyStop', epoch: ep + 1 }); break; }
                    }
                    if (bestW) { model.setWeights(bestW); bestW.forEach(w => w.dispose()); }
                    const ensM = [];
                    for (let i = 0; i < ensembleModels.length; i++) {
                        self.postMessage({ type: 'ensembleProgress', current: i + 1, total: ensembleModels.length });
                        try {
                            await ensembleModels[i].fit(trainX, trainY, { epochs: Math.max(30, Math.min(80, epochs)), batchSize: Math.min(16, Math.max(2, Math.floor(total / 8))), validationData: hasVal ? [valX, valY] : undefined, shuffle: true, verbose: 0 });
                            const p = await safePredictData(ensembleModels[i], hasVal ? valX : trainX);
                            const t = trueVals || [];
                            let mse = 0, mae = 0; const n = Math.min(p.length, t.length);
                            for (let k = 0; k < n; k++) { const e = p[k] - t[k]; mse += e * e; mae += Math.abs(e); }
                            mse /= Math.max(1, n); mae /= Math.max(1, n);
                            let mn = 0; for (let k = 0; k < n; k++) mn += t[k]; mn /= Math.max(1, n);
                            let sr = 0, st = 0; for (let k = 0; k < n; k++) { sr += (p[k] - t[k]) ** 2; st += (t[k] - mn) ** 2; }
                            const r2 = st === 0 ? 0 : Math.max(0, Math.min(1, 1 - sr / st));
                            ensM.push({ index: i, mse, mae, r2 });
                        } catch (e) { ensM.push({ index: i, mse: 0, mae: 0, r2: 0 }); }
                    }
                    const pVals = await safePredictData(model, hasVal ? valX : trainX);
                    const tVals = trueVals || [];
                    let mse = 0, mae = 0, mape = 0;
                    const N = Math.min(pVals.length, tVals.length);
                    let sum = 0; for (let i = 0; i < N; i++) sum += tVals[i]; const mean = sum / Math.max(1, N);
                    let ssR = 0, ssT = 0;
                    for (let i = 0; i < N; i++) { const er = pVals[i] - tVals[i]; mse += er * er; mae += Math.abs(er); if (Math.abs(tVals[i]) > 0.001) mape += Math.abs(er / tVals[i]); ssR += er * er; ssT += (tVals[i] - mean) ** 2; }
                    mse /= Math.max(1, N); mae /= Math.max(1, N); mape = (mape / Math.max(1, N)) * 100;
                    const rmse = Math.sqrt(mse);
                    const rawR2 = ssT === 0 ? 0 : 1 - ssR / ssT;
                    const r2 = Number.isFinite(rawR2) ? Math.max(0, Math.min(1, rawR2)) : 0;
                    const conf = Math.round(Math.max(0, Math.min(100, r2 * 60 + Math.max(0, 100 - mape) * 0.3 + 10)));
                    const imp = new Array(featureCount).fill(0);
                    try {
                        const arr = (hasVal ? valX : trainX).arraySync();
                        for (let f = 0; f < featureCount; f++) {
                            const sh = arr.map(r => r.slice()); const col = sh.map(r => r[f]);
                            for (let i = 0; i < sh.length; i++) sh[i][f] = col[(i + 1) % col.length];
                            const st = tf.tensor2d(sh); const p = await safePredictData(model, st); st.dispose();
                            let e = 0; for (let i = 0; i < Math.min(p.length, tVals.length); i++) e += Math.abs(p[i] - tVals[i]);
                            e /= Math.max(1, Math.min(p.length, tVals.length)); imp[f] = e - mae;
                        }
                    } catch (e) {}
                    const tImp = imp.reduce((s, v) => s + Math.max(0, v), 0) || 1;
                    const nImp = imp.map(v => Math.max(0, v) / tImp);
                    const wd = model.getWeights().map(w => ({ shape: w.shape.slice(), data: Array.from(w.dataSync()) }));
                    try { trainX.dispose(); trainY.dispose(); valX.dispose(); valY.dispose(); } catch (e) {}
                    self.postMessage({ type: 'done', metrics: { mse, mae, rmse, mape, r2, confidence: conf, samplesTrained: features.length, samplesAugmented: total, epochsCompleted: hist.loss.length, bestEpoch: bestE + 1 }, history: hist, featureImportance: nImp, weightData: wd, modelConfig: { featureCount }, ensembleMetrics: ensM });
                } catch (error) { self.postMessage({ type: 'error', message: (error && error.message) || String(error) }); }
            };
        `;

        // ============================================================
        // UTILIDADES
        // ============================================================
        function getGlobalSettings() { try { return JSON.parse(localStorage.getItem('globalSettings')) || {}; } catch (e) { return {}; } }
        function getConfiguredMinimumStock(p) { const s = getGlobalSettings(); return Number.isFinite(Number(p.minStock)) ? Number(p.minStock) : Number(s.minStockAlert) || 5; }
        function getConfiguredCurrency() { return getGlobalSettings().currencySymbol || 'MXN'; }
        function formatReportCurrency(v) { return `${getConfiguredCurrency()} ${Number(v || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`; }
        function safeNumber(v, f = 0) { const n = Number(v); return Number.isFinite(n) ? n : f; }
        function sanitizeProduct(p) { return { ...p, price: safeNumber(p.price, 0), stock: Math.max(0, Math.floor(safeNumber(p.stock, 0))), minStock: Math.max(0, Math.floor(safeNumber(p.minStock, 5))) }; }
        function summarizeProducts(ps) { return ps.reduce((s, p) => { const v = Number(p.price || 0) * Number(p.stock || 0); const m = getConfiguredMinimumStock(p); s.totalProducts++; s.totalValue += v; if (p.stock === 0) s.outOfStock++; else if (p.stock <= m) s.lowStock++; s.byCategory[p.category] ||= { count: 0, value: 0 }; s.byCategory[p.category].count++; s.byCategory[p.category].value += v; return s; }, { totalProducts: 0, totalValue: 0, lowStock: 0, outOfStock: 0, byCategory: {} }); }

        const MONTH_NAMES_ES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
        const MONTH_THEMES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
        const MONTHLY_SEASONALITY = {
            0:  { index: 0.85, label: 'Post-navideño', desc: 'Bajón tras fiestas' },
            1:  { index: 0.80, label: 'Mes bajo', desc: 'Menor consumo general' },
            2:  { index: 0.95, label: 'Recuperación', desc: 'Inicio de primavera' },
            3:  { index: 1.00, label: 'Normal', desc: 'Mes neutro' },
            4:  { index: 1.10, label: 'Día de las Madres', desc: 'Auge en regalos' },
            5:  { index: 1.05, label: 'Verano inicia', desc: 'Buen consumo' },
            6:  { index: 1.15, label: 'Vacaciones', desc: 'Alta demanda turismo' },
            7:  { index: 1.10, label: 'Verano pleno', desc: 'Buen consumo' },
            8:  { index: 0.95, label: 'Regreso a clases', desc: 'Auge escolar' },
            9:  { index: 1.05, label: 'Halloween', desc: 'Auge disfraces' },
            10: { index: 1.30, label: 'Buen Fin / Black Friday', desc: '¡Máximo consumo!' },
            11: { index: 1.35, label: 'Navidad', desc: '¡Pico máximo del año!' }
        };
        const CATEGORY_BASE_TRENDS = {
            'Electrónicos': { name: 'Tecnología e Innovación', growth: 18.5, status: 'rising', statusLabel: 'EN AUGE', reason: 'Dispositivos con IA integrada, wearables inteligentes y gadgets de productividad dominan el mercado 2025-2026.', keywords: 'IA, Smart Home, Wearables', color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', monthly: { 0: 0.9, 1: 0.85, 2: 0.95, 3: 1.0, 4: 1.05, 5: 1.1, 6: 1.15, 7: 1.15, 8: 1.05, 9: 1.1, 10: 1.35, 11: 1.4 } },
            'Ropa': { name: 'Moda Circular', growth: -3.2, status: 'declining', statusLabel: 'DECLIVE', reason: 'El fast fashion pierde terreno frente a la ropa sostenible, vintage y de segunda mano.', keywords: 'Sostenible, Vintage, Eco', color: 'linear-gradient(135deg, #64748b 0%, #475569 100%)', monthly: { 0: 0.9, 1: 0.85, 2: 1.0, 3: 1.05, 4: 1.15, 5: 1.1, 6: 1.0, 7: 0.95, 8: 1.1, 9: 1.0, 10: 1.2, 11: 1.3 } },
            'Hogar': { name: 'Casa Inteligente', growth: 12.8, status: 'rising', statusLabel: 'EN AUGE', reason: 'Domótica accesible, asistentes de voz y electrodomésticos conectados son tendencia sostenida.', keywords: 'Smart Home, IoT, Domótica', color: 'linear-gradient(135deg, #10b981 0%, #059669 100%)', monthly: { 0: 1.0, 1: 0.95, 2: 1.05, 3: 1.1, 4: 1.15, 5: 1.1, 6: 1.05, 7: 1.0, 8: 1.05, 9: 1.1, 10: 1.2, 11: 1.25 } },
            'Deportes': { name: 'Fitness y Bienestar', growth: 15.3, status: 'rising', statusLabel: 'EN AUGE', reason: 'El boom del fitness en casa y gadgets de salud sigue creciendo tras la pandemia.', keywords: 'Fitness, Wearables, Salud', color: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)', monthly: { 0: 1.15, 1: 1.05, 2: 1.0, 3: 1.0, 4: 0.95, 5: 0.95, 6: 0.9, 7: 0.95, 8: 1.05, 9: 1.0, 10: 1.05, 11: 1.1 } },
            'Alimentos': { name: 'Saludables y Proteicos', growth: 6.5, status: 'stable', statusLabel: 'ESTABLE', reason: 'Snacks proteicos, comida orgánica y sustitutos vegetales mantienen buena demanda.', keywords: 'Proteico, Orgánico, Vegano', color: 'linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)', monthly: { 0: 1.0, 1: 0.95, 2: 1.0, 3: 1.0, 4: 1.05, 5: 1.0, 6: 0.95, 7: 1.0, 8: 1.0, 9: 1.0, 10: 1.15, 11: 1.25 } },
            'Juguetes': { name: 'Juguetes STEM', growth: 9.2, status: 'rising', statusLabel: 'EN AUGE', reason: 'Robots educativos, kits de ciencia y juguetes de programación mantienen buen ritmo.', keywords: 'STEM, Educativos, Robótica', color: 'linear-gradient(135deg, #ec4899 0%, #db2777 100%)', monthly: { 0: 1.3, 1: 0.9, 2: 0.9, 3: 0.85, 4: 1.15, 5: 0.95, 6: 0.9, 7: 0.85, 8: 0.95, 9: 1.0, 10: 1.2, 11: 1.5 } },
            'Belleza': { name: 'Belleza y Cuidado Personal', growth: 8.7, status: 'rising', statusLabel: 'EN AUGE', reason: 'Skincare coreano, productos naturales y cuidado personal son tendencia fuerte.', keywords: 'Skincare, Natural, K-Beauty', color: 'linear-gradient(135deg, #f472b6 0%, #be185d 100%)', monthly: { 0: 1.0, 1: 1.1, 2: 1.05, 3: 1.0, 4: 1.15, 5: 1.05, 6: 1.0, 7: 1.0, 8: 1.0, 9: 1.05, 10: 1.2, 11: 1.25 } },
            'Libros': { name: 'Libros y Educación', growth: 3.5, status: 'stable', statusLabel: 'ESTABLE', reason: 'Auge del audiolibro y regreso a la lectura física mantienen estable la categoría.', keywords: 'Audiolibros, Educación', color: 'linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%)', monthly: { 0: 1.0, 1: 0.95, 2: 1.0, 3: 1.0, 4: 1.05, 5: 1.0, 6: 0.95, 7: 1.0, 8: 1.15, 9: 1.0, 10: 1.05, 11: 1.2 } }
        };
        function getCurrentMonthInfo() {
            const now = new Date();
            const m = now.getMonth();
            return { monthIndex: m, monthName: MONTH_NAMES_ES[m], monthTheme: MONTH_THEMES[m], year: now.getFullYear(), seasonality: MONTHLY_SEASONALITY[m], date: now };
        }

        // ============================================================
        // PRODUCT MANAGER
        // ============================================================
        class ProductManager {
            constructor() {
                this.products = [];
                this.isConnected = false;
                this.loadFromInventory();
                window.addEventListener('storage', (e) => {
                    if (e.key === 'products') {
                        this.loadFromInventory();
                        if (window.onInventorySync) window.onInventorySync(this.products);
                    }
                });
            }
            loadFromInventory() {
                try {
                    const raw = localStorage.getItem('products');
                    if (raw) {
                        const parsed = JSON.parse(raw);
                        if (Array.isArray(parsed)) {
                            this.products = parsed.map(sanitizeProduct);
                            this.isConnected = true;
                            this.updateSyncBar(true, parsed.length);
                            return;
                        }
                    }
                } catch (e) { console.warn('Error leyendo:', e); }
                this.products = [];
                this.isConnected = false;
                this.updateSyncBar(false, 0);
            }
            updateSyncBar(connected, count) {
                const bar = document.getElementById('syncBar');
                const icon = document.getElementById('syncIcon');
                const title = document.getElementById('syncTitle');
                const subtitle = document.getElementById('syncSubtitle');
                const badge = document.getElementById('syncLiveBadge');
                if (!bar) return;
                bar.classList.toggle('disconnected', !connected);
                if (icon) icon.className = connected ? 'fas fa-sync-alt fa-spin' : 'fas fa-plug';
                if (title) title.textContent = connected ? (count > 0 ? `Conectado a inventario1.php · ${count} productos` : 'Conectado a inventario1.php · Sin productos') : 'Sin conexión con inventario1.php';
                if (subtitle) subtitle.textContent = connected ? (count > 0 ? 'Los datos se actualizan en tiempo real' : 'Agrega productos en inventario1.php para ver reportes') : 'No hay datos en localStorage. Abre inventario1.php para comenzar';
                if (badge) {
                    badge.classList.toggle('disconnected', !connected);
                    badge.innerHTML = connected ? `<span class="sync-live-dot"></span> En vivo · ${count} productos` : '<span class="sync-live-dot"></span> Sin datos';
                }
                const filtersPanel = document.getElementById('filtersPanel');
                if (filtersPanel) filtersPanel.style.display = count > 0 ? 'block' : 'none';
                const favoritesBar = document.getElementById('favoritesBar');
                if (favoritesBar) favoritesBar.style.display = count > 0 ? 'flex' : 'none';
            }
            forceSync() {
                this.loadFromInventory();
                if (window.onInventorySync) window.onInventorySync(this.products);
                return this.products;
            }
            getProductStatus(stock, minStock = null) {
                if (stock === 0) return 'Agotado';
                const th = minStock === null ? getGlobalSettings().minStockAlert || 5 : minStock;
                if (stock <= Math.max(1, th * 0.2)) return 'Stock crítico';
                if (stock <= th) return 'Stock bajo';
                return 'En stock';
            }
            getStatusClass(stock, minStock = null) {
                if (stock === 0) return 'bg-danger';
                const th = minStock === null ? getGlobalSettings().minStockAlert || 5 : minStock;
                if (stock <= Math.max(1, th * 0.2)) return 'bg-danger';
                if (stock <= th) return 'bg-warning';
                return 'bg-success';
            }
            getAllProducts() { return this.products; }
            getHistoricalSales(id) {
                try {
                    const txs = JSON.parse(localStorage.getItem('transactions')) || [];
                    return txs.reduce((t, x) => { if (x.type && x.type !== 'Venta') return t; const sp = (x.products || []).find(p => p.id === id); return t + (sp ? Number(sp.quantity) || 0 : 0); }, 0);
                } catch (e) { return 0; }
            }
            showNotification(msg, type = 'info') {
                const c = document.getElementById('toastContainer');
                if (!c) return;
                const t = document.createElement('div');
                t.className = `toast ${type}`;
                t.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'}"></i><span>${msg}</span>`;
                c.appendChild(t);
                setTimeout(() => { t.style.animation = 'slideOutRight 0.3s forwards'; setTimeout(() => t.remove(), 300); }, 3000);
            }
        }

        // ============================================================
        // TENSORFLOW ANALYZER
        // ============================================================
        const FEATURE_NAMES = ['Precio normalizado','Stock normalizado','Stock mínimo normalizado','Peso en inventario','Tendencia de mercado','Sentimiento de mercado','Volumen de mercado','Momentum de mercado','Sentimiento de noticias','Google Trends','Crecimiento PIB','Confianza consumidor','Crecimiento retail','Inflación','Desempleo','Producción industrial','Tasa de interés','Impacto climático','Cat: Electrónicos','Cat: Ropa','Cat: Hogar','Cat: Deportes','Cat: Alimentos','Ratio stock/demanda','Valor unitario','Demanda histórica','Ciclo seno mensual','Ciclo coseno mensual','Factor estacional','Momentum macro','Competitividad precio','Riesgo compuesto'];

        class AdvancedTensorFlowAnalyzer {
            constructor() {
                this.FEATURE_COUNT = 32;
                this.model = null; this.ensembleModels = []; this.modelsTrained = false; this.isTraining = false;
                this.trainingHistory = { loss: [], val_loss: [], accuracy: [], val_accuracy: [], mae: [], val_mae: [], lr: [] };
                this.externalData = null; this.lastUpdate = null; this.updateInterval = null;
                this.modelMetrics = { mse: 0, mae: 0, rmse: 0, mape: 0, r2: 0, confidence: 0, samplesTrained: 0, samplesAugmented: 0, epochsCompleted: 0, trainingTime: 0, bestEpoch: 0 };
                this.apiStatus = {}; this.featureImportance = null; this.augmentationFactor = 4;
                this.cacheKey = 'smartstock_ai_model_v7_1'; this.dbName = 'SmartStockAI_DB'; this.dbVersion = 1; this.dbStore = 'models';
                this.modelHistory = []; this.ensembleMetrics = []; this.trainingSessionId = null;
                this.worker = null; this.workerBusy = false; this.currentTrainingTime = 0;
                this.predictionHistory = JSON.parse(localStorage.getItem('predictionHistory_v7_1') || '[]');
                this.initWorker();
            }
            initWorker() {
                try {
                    const blob = new Blob([WORKER_SOURCE], { type: 'application/javascript' });
                    const url = URL.createObjectURL(blob);
                    this.worker = new Worker(url);
                    this.worker.onmessage = (e) => this.handleWorkerMessage(e);
                    this.worker.onerror = () => { this.workerBusy = false; this.isTraining = false; };
                } catch (e) { this.worker = null; }
            }
            handleWorkerMessage(event) {
                const msg = event.data || {};
                const s = document.getElementById('trainingStatus');
                const p = document.getElementById('trainingProgress');
                switch (msg.type) {
                    case 'progress':
                        if (window.updateTrainingProgress) window.updateTrainingProgress(msg.epoch, msg.total, msg.loss, msg.valLoss, msg.accuracy, msg.lr);
                        break;
                    case 'ensembleProgress':
                        const ep = document.getElementById('ensembleProgressText');
                        if (ep) ep.textContent = `Ensemble: ${msg.current}/${msg.total}`;
                        break;
                    case 'earlyStop':
                        if (s) s.innerHTML = `<div style="padding:10px 15px;border-radius:12px;background:#fff3cd;color:#856404;">Early stopping en época ${msg.epoch}</div>`;
                        break;
                    case 'done':
                        this.isTraining = false; this.workerBusy = false; this.modelsTrained = true;
                        this.ensembleMetrics = msg.ensembleMetrics || [];
                        this.handleWorkerDone(msg);
                        break;
                    case 'cancelled':
                        this.isTraining = false; this.workerBusy = false;
                        if (s) s.innerHTML = '<div style="padding:10px 15px;border-radius:12px;background:#fff3cd;color:#856404;">Cancelado</div>';
                        if (p) p.style.display = 'none';
                        break;
                    case 'error':
                        this.isTraining = false; this.workerBusy = false;
                        if (s) s.innerHTML = `<div style="padding:10px 15px;border-radius:12px;background:#f8d7da;color:#721c24;">Error: ${msg.message}</div>`;
                        if (p) p.style.display = 'none';
                        const tb = document.getElementById('trainModelBtn');
                        if (tb) { tb.disabled = false; tb.innerHTML = '<i class="fas fa-brain me-2"></i>Entrenar'; }
                        const cb = document.getElementById('cancelTrainingBtn');
                        if (cb) cb.style.display = 'none';
                        break;
                }
            }
            async handleWorkerDone(msg) {
                this.modelMetrics = { ...msg.metrics, trainingTime: this.currentTrainingTime };
                this.trainingHistory = msg.history;
                this.featureImportance = msg.featureImportance.map((v, i) => ({ feature: FEATURE_NAMES[i] || `f${i}`, value: v })).sort((a, b) => b.value - a.value).slice(0, 12);
                this.model = this.buildMainModelFromWeights(msg.weightData, msg.modelConfig.featureCount);
                await this.createEnsembleModels();
                await this.saveModelToDB(this.modelMetrics, this.trainingHistory, this.featureImportance);
                this.modelHistory.push({ id: this.trainingSessionId, date: new Date().toISOString(), r2: this.modelMetrics.r2, confidence: this.modelMetrics.confidence, epochs: this.modelMetrics.epochsCompleted, time: this.currentTrainingTime });
                if (this.modelHistory.length > 5) this.modelHistory.shift();
                const s = document.getElementById('trainingStatus');
                const p = document.getElementById('trainingProgress');
                if (s) s.innerHTML = `<div style="padding:10px 15px;border-radius:12px;background:#d1ecf1;color:#0c5460;"><b>¡Entrenado!</b> R²: ${this.modelMetrics.r2.toFixed(3)} | MAPE: ${this.modelMetrics.mape.toFixed(1)}% | Conf: ${this.modelMetrics.confidence}%</div>`;
                if (p) p.style.display = 'none';
                ['predictSalesBtn', 'batchPredictBtn', 'showMetricsBtn', 'exportModelBtn'].forEach(id => { const el = document.getElementById(id); if (el) el.disabled = false; });
                const tb = document.getElementById('trainModelBtn');
                if (tb) { tb.disabled = false; tb.innerHTML = '<i class="fas fa-brain me-2"></i>Reentrenar'; }
                const cb = document.getElementById('cancelTrainingBtn');
                if (cb) cb.style.display = 'none';
                if (window.reportGenerator) window.reportGenerator.updateMetricsDisplay();
                productManager.showNotification('Modelo entrenado y guardado', 'success');
            }
            buildMainModelFromWeights(wd, fc) {
                const m = tf.sequential();
                m.add(tf.layers.dense({ units: 64, activation: 'relu', inputShape: [fc], kernelRegularizer: tf.regularizers.l2({ l2: 0.0005 }), kernelInitializer: 'heNormal' }));
                m.add(tf.layers.batchNormalization()); m.add(tf.layers.dropout({ rate: 0.15 }));
                m.add(tf.layers.dense({ units: 128, activation: 'relu', kernelRegularizer: tf.regularizers.l2({ l2: 0.0005 }), kernelInitializer: 'heNormal' }));
                m.add(tf.layers.batchNormalization()); m.add(tf.layers.dropout({ rate: 0.25 }));
                m.add(tf.layers.dense({ units: 96, activation: 'relu', kernelRegularizer: tf.regularizers.l2({ l2: 0.0005 }) }));
                m.add(tf.layers.batchNormalization()); m.add(tf.layers.dropout({ rate: 0.25 }));
                m.add(tf.layers.dense({ units: 64, activation: 'relu' })); m.add(tf.layers.dropout({ rate: 0.2 }));
                m.add(tf.layers.dense({ units: 32, activation: 'relu' }));
                m.add(tf.layers.dense({ units: 16, activation: 'relu' }));
                m.add(tf.layers.dense({ units: 1, activation: 'linear' }));
                const o = tf.train.adam(0.001); o.clipNorm = 1.0;
                m.compile({ optimizer: o, loss: 'meanSquaredError', metrics: ['mae', 'mse'] });
                try {
                    const cw = m.getWeights();
                    const weights = [];
                    for (let i = 0; i < wd.length; i++) {
                        const w = wd[i];
                        const shape = Array.isArray(w.shape) ? w.shape.slice() : [w.data.length];
                        const es = cw[i] ? cw[i].shape.slice() : null;
                        if (!es || es.join(',') !== shape.join(',')) weights.push(cw[i]);
                        else weights.push(tf.tensor(w.data, shape));
                    }
                    while (weights.length < cw.length) weights.push(cw[weights.length]);
                    m.setWeights(weights);
                } catch (e) { console.warn(e); }
                return m;
            }
            async createEnsembleModels() {
                this.ensembleModels = [];
                const specs = [
                    { units: [96, 192, 96, 48], activation: 'relu', lr: 0.001 },
                    { units: [48, 96, 48], activation: 'relu', lr: 0.001, dropout: 0.5 },
                    { units: [32, 16, 8], activation: 'relu', lr: 0.0015 },
                    { units: [64, 64, 32], activation: 'tanh', lr: 0.001 },
                    { units: [128, 64, 32], activation: 'elu', lr: 0.0012 },
                    { units: [64, 64, 32, 16], activation: 'relu', lr: 0.0013 },
                    { units: [256, 128], activation: 'relu', lr: 0.0009, dropout: 0.3 }
                ];
                for (const s of specs) {
                    const m = tf.sequential();
                    s.units.forEach((u, i) => { const c = { units: u, activation: s.activation }; if (i === 0) c.inputShape = [this.FEATURE_COUNT]; m.add(tf.layers.dense(c)); if (s.dropout && i < s.units.length - 1) m.add(tf.layers.dropout({ rate: s.dropout })); });
                    m.add(tf.layers.dense({ units: 1 }));
                    const o = tf.train.adam(s.lr); o.clipNorm = 1.0;
                    m.compile({ optimizer: o, loss: 'meanSquaredError', metrics: ['mae'] });
                    this.ensembleModels.push(m);
                }
            }
            async openDB() {
                return new Promise((res, rej) => {
                    const r = indexedDB.open(this.dbName, this.dbVersion);
                    r.onupgradeneeded = (e) => { const db = e.target.result; if (!db.objectStoreNames.contains(this.dbStore)) db.createObjectStore(this.dbStore, { keyPath: 'id' }); };
                    r.onsuccess = () => res(r.result);
                    r.onerror = () => rej(r.error);
                });
            }
            async saveModelToDB(m, h, fi) {
                try {
                    const db = await this.openDB();
                    const md = await this.model.save(tf.io.withSaveHandler(async (a) => ({ modelArtifacts: { ...a, weightData: new Uint8Array(a.weightData) }, modelArtifactsInfo: { dateSaved: new Date(), modelTopologyType: 'JSON' } })));
                    const tx = db.transaction(this.dbStore, 'readwrite');
                    const st = tx.objectStore(this.dbStore);
                    await new Promise((res, rej) => { const r = st.put({ id: this.cacheKey, modelTopology: md.modelArtifacts.modelTopology, weightSpecs: md.modelArtifacts.weightSpecs, weightData: Array.from(md.modelArtifacts.weightData), metrics: m, history: h, featureImportance: fi, featureCount: this.FEATURE_COUNT, savedAt: new Date().toISOString() }); r.onsuccess = () => res(); r.onerror = () => rej(r.error); });
                } catch (e) {}
            }
            async loadModelFromDB() {
                try {
                    const db = await this.openDB();
                    const tx = db.transaction(this.dbStore, 'readonly');
                    const st = tx.objectStore(this.dbStore);
                    const d = await new Promise((res, rej) => { const r = st.get(this.cacheKey); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
                    if (!d) return false;
                    const wd = new Uint8Array(d.weightData).buffer;
                    this.model = await tf.loadLayersModel(tf.io.fromMemory({ modelTopology: d.modelTopology, weightSpecs: d.weightSpecs, weightData: wd }));
                    const o = tf.train.adam(0.0008); o.clipNorm = 1.0;
                    this.model.compile({ optimizer: o, loss: 'meanSquaredError', metrics: ['mae', 'mse'] });
                    await this.createEnsembleModels();
                    this.modelMetrics = d.metrics || this.modelMetrics;
                    this.trainingHistory = d.history || this.trainingHistory;
                    this.featureImportance = d.featureImportance || null;
                    this.modelsTrained = true;
                    return true;
                } catch (e) { return false; }
            }
            async clearModelFromDB() {
                try { const db = await this.openDB(); const tx = db.transaction(this.dbStore, 'readwrite'); tx.objectStore(this.dbStore).delete(this.cacheKey); return new Promise(r => { tx.oncomplete = () => r(true); tx.onerror = () => r(false); }); } catch (e) { return false; }
            }
            initializeRealTimeUpdates() {
                this.stopRealTimeUpdates();
                this.updateInterval = setInterval(() => this.fetchAllRealTimeData(), 60000);
                this.fetchAllRealTimeData();
            }
            stopRealTimeUpdates() { if (this.updateInterval) { clearInterval(this.updateInterval); this.updateInterval = null; } }
            async fetchAllRealTimeData() {
                const mi = getCurrentMonthInfo();
                const seasonIdx = mi.seasonality.index;
                try {
                    this.externalData = {
                        economicIndicators: { gdpGrowth: 2.4 + (Math.random() * 0.6 - 0.3), inflation: 3.1 + (Math.random() * 0.4 - 0.2), unemployment: 3.6 + (Math.random() * 0.3 - 0.15), consumerConfidence: Math.round(72 * seasonIdx + Math.random() * 8 - 4), retailGrowth: 4.3 * seasonIdx + (Math.random() * 0.8 - 0.4), industrialProduction: 2.1 + (Math.random() * 0.4 - 0.2), interestRate: 5.25 + (Math.random() * 0.25 - 0.125), housingStarts: 1.2 + (Math.random() * 0.2 - 0.1) },
                        worldBank: { gdpPerCapita: 65000 + Math.floor(Math.random() * 2000 - 1000), tradeBalance: -450 + Math.floor(Math.random() * 100 - 50), foreignInvestment: 280 + Math.floor(Math.random() * 40 - 20), inflationWorld: 3.8 + (Math.random() * 0.4 - 0.2) },
                        fred: { moneySupply: 21000 + Math.floor(Math.random() * 200 - 100), consumerCredit: 4800 + Math.floor(Math.random() * 100 - 50), businessInventories: 2500 + Math.floor(Math.random() * 50 - 25), retailSales: 680 + Math.floor(Math.random() * 20 - 10) },
                        marketTrends: {}, weather: (() => { const seasons = ['Invierno', 'Primavera', 'Verano', 'Otoño']; const s = seasons[Math.floor(mi.monthIndex / 3) % 4]; return { season: s, temperature: 15 + Math.floor(Math.random() * 20 - 10), precipitation: Math.random() * 30, impactFactor: s === 'Verano' ? 1.25 : s === 'Invierno' ? 0.85 : 1.0 }; })(),
                        newsSentiment: {}, googleTrends: {}, monthInfo: mi
                    };
                    Object.keys(CATEGORY_BASE_TRENDS).forEach(cat => {
                        const base = CATEGORY_BASE_TRENDS[cat];
                        const monthMult = base.monthly[mi.monthIndex] || 1.0;
                        const growth = base.growth * (0.8 + monthMult * 0.3);
                        this.externalData.marketTrends[cat] = { trend: 1 + (growth / 100), sentiment: Math.min(0.95, Math.max(0.1, 0.5 + (growth / 100) + (Math.random() * 0.1 - 0.05))), volume: Math.round(500 * monthMult + Math.random() * 100), momentum: (growth / 100) + (Math.random() * 0.04 - 0.02) };
                        this.externalData.newsSentiment[cat] = Math.round(50 + growth * 1.5 + Math.random() * 10 - 5);
                        this.externalData.googleTrends[cat] = Math.round(50 + growth * 2 + Math.random() * 10 - 5);
                    });
                    this.lastUpdate = new Date();
                    if (window.updateRealTimeData) window.updateRealTimeData(this.externalData, this.lastUpdate);
                } catch (e) { console.error(e); }
            }
            prepareAdvancedFeatures(products) {
                const catMap = { 'Electrónicos': [1,0,0,0,0], 'Ropa': [0,1,0,0,0], 'Hogar': [0,0,1,0,0], 'Deportes': [0,0,0,1,0], 'Alimentos': [0,0,0,0,1] };
                const features = [], labels = [];
                const sp = products.map(sanitizeProduct);
                const maxP = Math.max(1, ...sp.map(p => p.price || 0));
                const maxS = Math.max(1, ...sp.map(p => p.stock || 0));
                const maxM = Math.max(1, ...sp.map(p => getConfiguredMinimumStock(p)));
                const totalV = sp.reduce((s, p) => s + (p.price || 0) * (p.stock || 0), 0) || 1;
                const avgPrice = {};
                sp.forEach(p => { if (!avgPrice[p.category]) avgPrice[p.category] = { s: 0, c: 0 }; avgPrice[p.category].s += p.price || 0; avgPrice[p.category].c++; });
                Object.keys(avgPrice).forEach(k => { avgPrice[k] = avgPrice[k].s / Math.max(1, avgPrice[k].c); });
                const macro = this.externalData?.economicIndicators ? (this.externalData.economicIndicators.gdpGrowth + this.externalData.economicIndicators.retailGrowth) / 2 : 3;
                const mi = getCurrentMonthInfo();
                sp.forEach(product => {
                    const md = this.externalData?.marketTrends?.[product.category] || { trend: 1.0, sentiment: 0.5, volume: 500, momentum: 0 };
                    const nd = this.externalData?.newsSentiment?.[product.category] || 50;
                    const td = this.externalData?.googleTrends?.[product.category] || 50;
                    const ec = this.externalData?.economicIndicators || { gdpGrowth: 2, inflation: 3, consumerConfidence: 70, retailGrowth: 3, industrialProduction: 2, interestRate: 5, unemployment: 3.6 };
                    const w = this.externalData?.weather || { impactFactor: 1.0 };
                    const ce = catMap[product.category] || [0,0,0,0,0];
                    const ms = getConfiguredMinimumStock(product);
                    const stock = product.stock || 0;
                    const price = product.price || 0;
                    const hs = productManager.getHistoricalSales(product.id);
                    const acp = avgPrice[product.category] || price;
                    const cycleS = Math.sin((2 * Math.PI * mi.monthIndex) / 12);
                    const cycleC = Math.cos((2 * Math.PI * mi.monthIndex) / 12);
                    const sf = mi.seasonality.index;
                    const cp = acp > 0 ? price / acp : 1;
                    const sr = stock === 0 ? 1 : stock <= ms ? 0.8 : stock <= ms * 2 ? 0.5 : 0.1;
                    const f = [price / maxP, stock / maxS, ms / maxM, (price * stock) / totalV, md.trend, md.sentiment, md.volume / 1000, md.momentum + 0.5, nd / 100, td / 100, ec.gdpGrowth / 5, ec.consumerConfidence / 100, ec.retailGrowth / 10, ec.inflation / 5, ec.unemployment / 10, ec.industrialProduction / 5, ec.interestRate / 10, w.impactFactor, ...ce, Math.min(2, stock / Math.max(1, hs)), price / 1000, Math.min(1, hs / 100), (cycleS + 1) / 2, (cycleC + 1) / 2, sf, (macro + 5) / 10, Math.min(2, cp), sr];
                    features.push(f.map(v => (typeof v === 'number' && isFinite(v)) ? v : 0));
                    labels.push(this.calculateAdvancedSalesEstimate(product, md, nd, td, ec, w, mi));
                });
                if (!features.length || features[0].length !== this.FEATURE_COUNT) throw new Error(`Features (${features[0]?.length}) ≠ ${this.FEATURE_COUNT}`);
                return { features: tf.tensor2d(features), labels: tf.tensor1d(labels) };
            }
            calculateAdvancedSalesEstimate(product, md, nd, td, ec, w, mi) {
                const pf = Math.max(0.2, 1 - (product.price / 2000));
                const sf = Math.min(1.5, product.stock / 30);
                const cb = product.category === 'Electrónicos' ? 1.3 : product.category === 'Deportes' ? 1.2 : product.category === 'Ropa' ? 0.9 : 1.0;
                const mf = md.trend * md.sentiment * (1 + md.momentum);
                const ef = (nd / 100) * (td / 100) * (ec.consumerConfidence / 70) * w.impactFactor;
                const hs = productManager.getHistoricalSales(product.id);
                const hf = hs > 0 ? Math.min(1.5, hs / Math.max(1, product.stock + getConfiguredMinimumStock(product))) : 0;
                const seasonal = mi.seasonality.index;
                const result = (20 * cb + pf * 30 + sf * 10 + mf * 25 + ef * 20 + hf * 20) * seasonal;
                return Math.max(5, Math.min(150, Math.round(isFinite(result) ? result : 20)));
            }
            async trainViaWorker(products, epochs = 300, patience = 30) {
                if (!this.worker) throw new Error('Worker no disponible');
                if (this.workerBusy) throw new Error('Entrenamiento en curso');
                if (!products.length) throw new Error('Sin productos');
                this.isTraining = true; this.workerBusy = true;
                this.trainingSessionId = Date.now();
                const t0 = performance.now();
                this.currentTrainingTime = 0;
                const { features, labels } = this.prepareAdvancedFeatures(products);
                const fa = features.arraySync(), la = labels.arraySync();
                features.dispose(); labels.dispose();
                this.worker.postMessage({ type: 'train', features: fa, labels: la, featureCount: this.FEATURE_COUNT, epochs, patience, augmentationFactor: this.augmentationFactor });
                return new Promise((res, rej) => {
                    const ci = setInterval(() => {
                        this.currentTrainingTime = (performance.now() - t0) / 1000;
                        if (!this.workerBusy && !this.isTraining) { clearInterval(ci); if (this.modelsTrained) res(this.trainingHistory); else rej(new Error('Abortado')); }
                    }, 500);
                    setTimeout(() => { clearInterval(ci); if (this.workerBusy) { this.workerBusy = false; this.isTraining = false; rej(new Error('Timeout')); } }, 900000);
                });
            }
            cancelTraining() { if (this.worker && this.workerBusy) this.worker.postMessage({ type: 'cancel' }); }
            async predictWithEnsemble(products) {
                if (!this.modelsTrained || !this.model) throw new Error('Modelo no entrenado');
                const { features } = this.prepareAdvancedFeatures(products);
                const preds = [];
                const mp = this.model.predict(features); preds.push(await mp.data()); mp.dispose();
                for (const m of this.ensembleModels) { const p = m.predict(features); preds.push(await p.data()); p.dispose(); }
                const w = [0.35, 0.11, 0.10, 0.09, 0.09, 0.09, 0.09, 0.08];
                const ens = [];
                for (let i = 0; i < preds[0].length; i++) { let s = 0; for (let j = 0; j < preds.length; j++) s += preds[j][i] * w[j]; ens.push(Math.max(0, Math.round(s))); }
                features.dispose();
                const pm = preds.map(p => Array.from(p));
                const ci = [];
                for (let i = 0; i < preds[0].length; i++) {
                    const vs = pm.map(p => p[i]);
                    const mean = vs.reduce((a, b) => a + b, 0) / vs.length;
                    const v = vs.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / vs.length;
                    const sd = Math.sqrt(v);
                    ci.push({ lower: Math.max(0, mean - 1.96 * sd), upper: mean + 1.96 * sd });
                }
                return products.map((product, i) => {
                    const md = this.externalData?.marketTrends?.[product.category] || { trend: 1.0, sentiment: 0.5, volume: 500, momentum: 0 };
                    const nd = this.externalData?.newsSentiment?.[product.category] || 50;
                    const ec = this.externalData?.economicIndicators || { consumerConfidence: 70 };
                    const c = ci[i], pred = ens[i];
                    return { ...product, predictedSales: pred, confidenceInterval: c, confidence: this.modelMetrics.confidence, reorderRecommendation: this.getIntelligentRecommendation(product, pred, md, ec, c), marketTrend: md.trend, marketSentiment: md.sentiment, newsSentiment: nd, economicOutlook: this.getEconomicOutlook(ec), opportunityScore: this.calculateOpportunityScore(product, pred, md, nd, ec, c), riskLevel: this.calculateRiskLevel(product, pred, md, c), lastUpdated: this.lastUpdate };
                });
            }
            getIntelligentRecommendation(p, pred, md, ec, ci) {
                const wos = pred > 0 ? p.stock / (pred / 4.33) : Infinity;
                const ms = md.trend * md.sentiment;
                if (p.stock === 0) return { action: 'URGENTE - Sin stock', priority: 'critical', message: 'Agotado', riskScore: 100 };
                if (wos < 1) return { action: 'Reordenar URGENTE', priority: 'critical', message: '<1 semana', riskScore: 90 };
                if (wos < 2) return { action: `Reordenar ${ms > 1.1 ? 'ALTA' : 'Media'}`, priority: 'high', message: `${wos.toFixed(1)} sem`, riskScore: 70 };
                if (wos < 3) return { action: 'Monitorear', priority: 'medium', message: `${wos.toFixed(1)} sem`, riskScore: 50 };
                if (wos > 10) return { action: 'Exceso', priority: 'low', message: `${wos.toFixed(1)} sem`, riskScore: 30 };
                return { action: 'Adecuado', priority: 'normal', message: `${wos.toFixed(1)} sem`, riskScore: 20 };
            }
            calculateOpportunityScore(p, pred, md, nd, ec, ci) {
                let s = 0;
                if (p.stock === 0) s += 30;
                else if (p.stock <= getConfiguredMinimumStock(p)) s += 25;
                else if (p.stock <= getConfiguredMinimumStock(p) * 2) s += 15;
                s += Math.min(20, (pred / 30) * 20);
                s += (md.trend - 0.8) * 30;
                s += (md.sentiment - 0.4) * 20;
                s += ((nd - 40) / 60) * 10;
                s += ((ec.consumerConfidence - 50) / 50) * 10;
                return Math.min(100, Math.max(0, Math.round(s)));
            }
            calculateRiskLevel(p, pred, md, ci) {
                const wos = pred > 0 ? p.stock / (pred / 4.33) : Infinity;
                let r = 0;
                r += (p.stock === 0) ? 40 : 0;
                r += (wos < 1) ? 30 : (wos < 2) ? 20 : (wos > 10) ? 15 : 5;
                r += md.trend < 0.9 ? 15 : 0;
                if (r >= 70) return 'Alto';
                if (r >= 40) return 'Medio';
                return 'Bajo';
            }
            getEconomicOutlook(ec) {
                if (!ec) return 'Neutral';
                const s = (ec.gdpGrowth > 2.5 ? 1 : 0) + (ec.inflation < 3.5 ? 1 : 0) + (ec.consumerConfidence > 70 ? 1 : 0) + (ec.retailGrowth > 4 ? 1 : 0);
                if (s >= 3) return 'Muy positivo';
                if (s >= 2) return 'Positivo';
                if (s >= 1) return 'Neutral';
                return 'Negativo';
            }
            getModelMetrics() { return this.modelMetrics; }
            getFeatureImportance() { return this.featureImportance; }
            getFeatureCount() { return this.FEATURE_COUNT; }
            getModelHistory() { return this.modelHistory; }
            getEnsembleMetrics() { return this.ensembleMetrics; }
            getPredictionHistory() { return this.predictionHistory; }
            addPredictionToHistory(pred) {
                this.predictionHistory.unshift({ ...pred, timestamp: new Date().toISOString() });
                if (this.predictionHistory.length > 50) this.predictionHistory = this.predictionHistory.slice(0, 50);
                localStorage.setItem('predictionHistory_v7_1', JSON.stringify(this.predictionHistory));
            }
        }

        // ============================================================
        // REPORT GENERATOR
        // ============================================================
        class AdvancedReportGenerator {
            constructor() { this.currentReportType = 'trending'; this.currentFilters = {}; this.charts = {}; this.viewMode = 'table'; }
            generateReport(type, filters = {}) {
                this.currentReportType = type;
                this.currentFilters = filters;
                const products = productManager.getAllProducts();
                if (products.length === 0 && type !== 'trending' && type !== 'calendar' && type !== 'history') return this.generateEmptyInventoryState();
                switch (type) {
                    case 'trending': return this.generateTrendingReport(filters);
                    case 'health': return this.generateHealthReport(filters);
                    case 'abc': return this.generateABCReport(filters);
                    case 'profit': return this.generateProfitReport(filters);
                    case 'year-comparison': return this.generateYearComparisonReport(filters);
                    case 'reorder': return this.generateReorderReport(filters);
                    case 'alerts': return this.generateAlertsReport(filters);
                    case 'simulator': return this.generateSimulatorReport(filters);
                    case 'calendar': return this.generateCalendarReport(filters);
                    case 'comparison': return this.generateComparisonReport(filters);
                    case 'history': return this.generateHistoryReport(filters);
                    case 'top': return this.generateTopProductsReport(filters);
                    case 'explained': return this.generateExplainedReport(filters);
                    case 'inventory': return this.generateInventoryReport(filters);
                    case 'ai': return this.generateAIReport(filters);
                    default: return this.generateTrendingReport(filters);
                }
            }

            generateEmptyInventoryState() {
                return `
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No hay productos en el inventario</h3>
                        <p>Para ver este reporte necesitas agregar productos primero en <b>inventario1.php</b>.</p>
                        <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
                            <button class="btn btn-primary" onclick="window.location.href='http://localhost/SmartStockAI/inventario1.php'"><i class="fas fa-plus me-2"></i>Ir a Inventario</button>
                            <button class="btn btn-outline-primary" id="reloadReportBtn"><i class="fas fa-sync me-2"></i>Recargar</button>
                        </div>
                    </div>
                `;
            }

            applyFilters(products, filters) {
                let f = [...products];
                if (filters.category && filters.category !== 'all') f = f.filter(p => p.category === filters.category);
                if (filters.stockStatus && filters.stockStatus !== 'all') f = f.filter(p => productManager.getProductStatus(p.stock, getConfiguredMinimumStock(p)) === filters.stockStatus);
                if (filters.minPrice !== '' && Number.isFinite(Number(filters.minPrice))) f = f.filter(p => Number(p.price) >= Number(filters.minPrice));
                if (filters.maxPrice !== '' && Number.isFinite(Number(filters.maxPrice))) f = f.filter(p => Number(p.price) <= Number(filters.maxPrice));
                if (filters.minStock !== '' && Number.isInteger(Number(filters.minStock))) f = f.filter(p => Number(p.stock) >= Number(filters.minStock));
                if (filters.maxStock !== '' && Number.isInteger(Number(filters.maxStock))) f = f.filter(p => Number(p.stock) <= Number(filters.maxStock));
                if (filters.sortBy) {
                    switch (filters.sortBy) {
                        case 'name': f.sort((a, b) => a.name.localeCompare(b.name)); break;
                        case 'name_desc': f.sort((a, b) => b.name.localeCompare(a.name)); break;
                        case 'price': f.sort((a, b) => a.price - b.price); break;
                        case 'price_desc': f.sort((a, b) => b.price - a.price); break;
                        case 'stock': f.sort((a, b) => a.stock - b.stock); break;
                        case 'stock_desc': f.sort((a, b) => b.stock - a.stock); break;
                        case 'value_desc': f.sort((a, b) => (b.price * b.stock) - (a.price * a.stock)); break;
                    }
                }
                return f;
            }

            generateTrendingReport(filters = {}) {
                const mi = getCurrentMonthInfo();
                const allProducts = productManager.getAllProducts();
                if (allProducts.length === 0) {
                    const globalTrends = Object.keys(CATEGORY_BASE_TRENDS).map(cat => {
                        const base = CATEGORY_BASE_TRENDS[cat];
                        const monthMult = base.monthly[mi.monthIndex] || 1.0;
                        return { category: cat, name: base.name, growth: base.growth * monthMult, status: base.growth * monthMult > 15 ? 'rising' : base.growth * monthMult > 0 ? 'stable' : 'declining', color: base.color, reason: base.reason, keywords: base.keywords };
                    }).sort((a, b) => b.growth - a.growth);
                    let html = `
                        <div class="month-hero month-theme-${mi.monthTheme}">
                            <h2><i class="fas fa-calendar-day"></i> ${mi.monthName} ${mi.year} · Tendencias Globales</h2>
                            <p>Ranking de categorías según tendencias de mercado para <b>${mi.monthName}</b>.</p>
                            <div class="hero-badges">
                                <span class="hero-badge"><i class="fas fa-globe"></i> Tendencias globales</span>
                                <span class="hero-badge"><i class="fas fa-calendar"></i> Estacionalidad: ${mi.seasonality.index.toFixed(2)}x</span>
                            </div>
                        </div>
                        <div class="growing-message">
                            <h4><i class="fas fa-arrow-right"></i> ¿Por qué no veo mis productos?</h4>
                            <p>Porque todavía no hay productos en tu inventario. Agrega algunos en <b>inventario1.php</b>.</p>
                            <button class="btn btn-primary mt-3" onclick="window.location.href='http://localhost/SmartStockAI/inventario1.php'"><i class="fas fa-plus me-2"></i>Agregar Productos</button>
                        </div>
                        <div class="explain-section">
                            <h3><i class="fas fa-fire"></i> Ranking de categorías — ${mi.monthName} ${mi.year}</h3>
                            <div class="trending-2025-grid">`;
                    globalTrends.forEach((t, idx) => {
                        const statusClass = t.growth > 15 ? 'exploding' : t.growth > 5 ? 'rising' : t.growth > -5 ? 'stable' : 'declining';
                        const statusLabel = { exploding: 'EXPLOTANDO', rising: 'EN AUGE', stable: 'ESTABLE', declining: 'DECLIVE' }[statusClass];
                        html += `<div class="trending-card" style="background: ${t.color};"><div class="trending-rank">#${idx + 1}</div><h4>${t.name}</h4><div style="font-size: 0.85rem; opacity: 0.9; margin-bottom: 12px;">${t.category}</div><div><span class="trend-status-badge trend-status-${statusClass}">${statusLabel}</span> <span class="trend-flame" style="margin-left: 6px;"><i class="fas fa-fire"></i> ${t.growth > 0 ? '+' : ''}${t.growth.toFixed(1)}%</span></div><div class="trending-reason"><b><i class="fas fa-info-circle"></i> ¿Por qué?</b> ${t.reason}<br><b><i class="fas fa-tags"></i> Keywords:</b> ${t.keywords}</div></div>`;
                    });
                    html += `</div></div>`;
                    return html;
                }
                const products = this.applyFilters(allProducts, filters);
                const trends = Object.keys(CATEGORY_BASE_TRENDS).map(cat => {
                    const base = CATEGORY_BASE_TRENDS[cat];
                    const monthMult = base.monthly[mi.monthIndex] || 1.0;
                    const adj = base.growth * monthMult;
                    const catProds = allProducts.filter(p => p.category === cat);
                    return { category: cat, name: base.name, growth: adj, monthMultiplier: monthMult, status: adj > 15 ? 'rising' : adj > 0 ? 'stable' : 'declining', color: base.color, reason: base.reason, keywords: base.keywords, inInventory: catProds.length, totalStock: catProds.reduce((s, p) => s + p.stock, 0), totalValue: catProds.reduce((s, p) => s + p.price * p.stock, 0), avgPrice: catProds.length > 0 ? catProds.reduce((s, p) => s + p.price, 0) / catProds.length : 0 };
                }).sort((a, b) => b.growth - a.growth);

                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-calendar-day"></i> ${mi.monthName} ${mi.year} · Tendencias en Vivo</h2>
                        <p>Análisis actualizado según el mes actual y tu inventario real. Estacionalidad: ${mi.seasonality.label} (${mi.seasonality.index.toFixed(2)}x).</p>
                        <div class="hero-badges">
                            <span class="hero-badge"><i class="fas fa-sync-alt"></i> Actualización automática</span>
                            <span class="hero-badge"><i class="fas fa-chart-line"></i> ${mi.seasonality.index.toFixed(2)}x</span>
                            <span class="hero-badge"><i class="fas fa-box"></i> ${allProducts.length} productos</span>
                        </div>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-fire"></i> Ranking — ${mi.monthName} ${mi.year}</h3>
                        <div class="trending-2025-grid">`;
                trends.forEach((t, idx) => {
                    const statusClass = t.growth > 15 ? 'exploding' : t.growth > 5 ? 'rising' : t.growth > -5 ? 'stable' : 'declining';
                    const statusLabel = { exploding: 'EXPLOTANDO', rising: 'EN AUGE', stable: 'ESTABLE', declining: 'DECLIVE' }[statusClass];
                    const mmPct = ((t.monthMultiplier - 1) * 100).toFixed(0);
                    html += `<div class="trending-card" style="background: ${t.color};"><div class="trending-rank">#${idx + 1}</div><h4>${t.name}</h4><div style="font-size: 0.85rem; opacity: 0.9; margin-bottom: 12px;">${t.category} · ${t.inInventory} productos</div><div><span class="trend-status-badge trend-status-${statusClass}">${statusLabel}</span> <span class="trend-flame" style="margin-left: 6px;"><i class="fas fa-fire"></i> ${t.growth > 0 ? '+' : ''}${t.growth.toFixed(1)}%</span></div><div class="trending-metrics"><div class="trending-metric"><div class="tm-value">${t.totalStock}</div><div class="tm-label">Unidades</div></div><div class="trending-metric"><div class="tm-value">$${(t.totalValue / 1000).toFixed(1)}k</div><div class="tm-label">Valor</div></div><div class="trending-metric"><div class="tm-value">$${t.avgPrice.toFixed(0)}</div><div class="tm-label">Precio prom.</div></div></div><div class="trending-reason"><b><i class="fas fa-info-circle"></i> ¿Por qué?</b> ${t.reason}<br><b><i class="fas fa-tags"></i> Keywords:</b> ${t.keywords}<br><b><i class="fas fa-lightbulb"></i> Acción:</b> ${t.growth > 15 ? '🚀 AUMENTA stock urgente' : t.growth > 5 ? '📈 Ampliar catálogo' : t.growth > -5 ? '✅ Mantener' : '📉 Reducir'}</div></div>`;
                });
                html += `</div></div>`;
                return html;
            }

            generateHealthReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const summary = summarizeProducts(products);
                const mi = getCurrentMonthInfo();
                const stockHealth = summary.totalProducts > 0 ? ((summary.totalProducts - summary.lowStock - summary.outOfStock) / summary.totalProducts) * 100 : 0;
                const valueHealth = Math.min(100, summary.totalValue / 1000);
                const diversificationScore = Math.min(100, [...new Set(products.map(p => p.category))].length * 12);
                const restockScore = summary.outOfStock === 0 ? 100 : Math.max(0, 100 - summary.outOfStock * 15);
                const overallScore = Math.round((stockHealth * 0.4 + valueHealth * 0.15 + diversificationScore * 0.2 + restockScore * 0.25));
                const scoreColor = overallScore >= 80 ? '#10b981' : overallScore >= 60 ? '#f59e0b' : '#ef4444';
                const scoreLabel = overallScore >= 80 ? 'Excelente' : overallScore >= 60 ? 'Buena' : overallScore >= 40 ? 'Regular' : 'Crítica';
                const circumference = 2 * Math.PI * 70;
                const offset = circumference - (overallScore / 100) * circumference;

                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-heartbeat"></i> Salud de tu Negocio · ${mi.monthName} ${mi.year}</h2>
                        <p>Análisis integral de la salud de tu inventario.</p>
                    </div>
                    <div class="explain-section">
                        <div class="health-score">
                            <div class="health-score-circle">
                                <svg width="160" height="160" viewBox="0 0 160 160">
                                    <circle cx="80" cy="80" r="70" stroke="rgba(0,0,0,0.08)" stroke-width="12" fill="none"/>
                                    <circle cx="80" cy="80" r="70" stroke="${scoreColor}" stroke-width="12" fill="none" stroke-dasharray="${circumference}" stroke-dashoffset="${offset}" stroke-linecap="round" style="transition: stroke-dashoffset 1s ease;"/>
                                </svg>
                                <div class="health-score-value" style="color: ${scoreColor};">${overallScore}</div>
                            </div>
                            <div class="health-score-label" style="color: ${scoreColor};">${scoreLabel}</div>
                            <div class="health-score-desc">Score general · 0-100</div>
                        </div>
                        <h3 style="margin-top: 30px;"><i class="fas fa-th-list"></i> Desglose por factor</h3>
                        <div class="kpi-grid">
                            <div class="kpi-card" style="border-left-color: #10b981;"><div class="kpi-label">Salud del Stock</div><div class="kpi-value">${stockHealth.toFixed(0)}%</div></div>
                            <div class="kpi-card" style="border-left-color: #3b82f6;"><div class="kpi-label">Valor</div><div class="kpi-value">$${(summary.totalValue / 1000).toFixed(1)}k</div></div>
                            <div class="kpi-card" style="border-left-color: #8b5cf6;"><div class="kpi-label">Diversificación</div><div class="kpi-value">${Object.keys(summary.byCategory).length} cat.</div></div>
                            <div class="kpi-card" style="border-left-color: #f59e0b;"><div class="kpi-label">Reabastecimiento</div><div class="kpi-value">${restockScore.toFixed(0)}%</div></div>
                        </div>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-chart-pie"></i> Distribución de valor</h3>
                        <div class="chart-container"><canvas id="healthChart"></canvas></div>
                    </div>
                `;
                setTimeout(() => {
                    const canvas = document.getElementById('healthChart');
                    if (!canvas) return;
                    const cats = Object.keys(summary.byCategory);
                    const data = cats.map(c => summary.byCategory[c].value);
                    if (this.charts.healthChart) this.charts.healthChart.destroy();
                    this.charts.healthChart = new Chart(canvas, { type: 'doughnut', data: { labels: cats, datasets: [{ data, backgroundColor: ['#3a5ec7', '#28a745', '#ffc107', '#dc3545', '#17a2b8', '#6f42c1', '#fd7e14', '#20c997'], borderWidth: 0 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
                }, 100);
                return html;
            }

            generateABCReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const mi = getCurrentMonthInfo();
                const sorted = [...products].map(p => ({ ...p, totalValue: p.price * p.stock })).sort((a, b) => b.totalValue - a.totalValue);
                const totalValue = sorted.reduce((s, p) => s + p.totalValue, 0);
                let cumulative = 0;
                const abcItems = sorted.map(p => {
                    cumulative += p.totalValue;
                    const cumPct = (cumulative / totalValue) * 100;
                    const classification = cumPct <= 70 ? 'A' : cumPct <= 90 ? 'B' : 'C';
                    return { ...p, cumPct, classification };
                });
                const classA = abcItems.filter(x => x.classification === 'A');
                const classB = abcItems.filter(x => x.classification === 'B');
                const classC = abcItems.filter(x => x.classification === 'C');

                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-sort-amount-down"></i> Análisis ABC (Pareto 80/20)</h2>
                        <p>Clasifica tus productos en 3 grupos según su contribución al valor total.</p>
                    </div>
                    <div class="explain-section">
                        <div class="kpi-grid">
                            <div class="kpi-card" style="border-left-color: #ef4444;"><div class="kpi-label">Clase A (70%)</div><div class="kpi-value">${classA.length}</div></div>
                            <div class="kpi-card" style="border-left-color: #f59e0b;"><div class="kpi-label">Clase B (20%)</div><div class="kpi-value">${classB.length}</div></div>
                            <div class="kpi-card" style="border-left-color: #10b981;"><div class="kpi-label">Clase C (10%)</div><div class="kpi-value">${classC.length}</div></div>
                            <div class="kpi-card" style="border-left-color: #3b82f6;"><div class="kpi-label">Valor Total</div><div class="kpi-value">${formatReportCurrency(totalValue)}</div></div>
                        </div>
                        <div class="chart-container"><canvas id="abcChart"></canvas></div>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-crown"></i> Clase A</h3>
                        <div class="table-responsive"><table class="report-table"><thead><tr><th>#</th><th>Producto</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Valor</th><th>%</th><th>ABC</th></tr></thead><tbody>
                            ${classA.slice(0, 20).map((p, i) => `<tr><td>${i + 1}</td><td><strong>${p.name}</strong></td><td>${p.category}</td><td>$${p.price}</td><td>${p.stock}</td><td><strong>${formatReportCurrency(p.totalValue)}</strong></td><td>${p.cumPct.toFixed(1)}%</td><td><span class="abc-badge abc-a">A</span></td></tr>`).join('')}
                        </tbody></table></div>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-balance-scale"></i> Clase B</h3>
                        <div class="table-responsive"><table class="report-table"><thead><tr><th>#</th><th>Producto</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Valor</th><th>ABC</th></tr></thead><tbody>
                            ${classB.slice(0, 20).map((p, i) => `<tr><td>${i + 1}</td><td>${p.name}</td><td>${p.category}</td><td>$${p.price}</td><td>${p.stock}</td><td>${formatReportCurrency(p.totalValue)}</td><td><span class="abc-badge abc-b">B</span></td></tr>`).join('')}
                        </tbody></table></div>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-list"></i> Clase C</h3>
                        <div class="table-responsive"><table class="report-table"><thead><tr><th>#</th><th>Producto</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Valor</th><th>ABC</th></tr></thead><tbody>
                            ${classC.slice(0, 30).map((p, i) => `<tr><td>${i + 1}</td><td>${p.name}</td><td>${p.category}</td><td>$${p.price}</td><td>${p.stock}</td><td>${formatReportCurrency(p.totalValue)}</td><td><span class="abc-badge abc-c">C</span></td></tr>`).join('')}
                        </tbody></table></div>
                    </div>
                `;
                setTimeout(() => {
                    const canvas = document.getElementById('abcChart');
                    if (!canvas) return;
                    if (this.charts.abcChart) this.charts.abcChart.destroy();
                    this.charts.abcChart = new Chart(canvas, { type: 'line', data: { labels: abcItems.slice(0, 30).map((_, i) => i + 1), datasets: [{ label: '% Acumulado', data: abcItems.slice(0, 30).map(p => p.cumPct), borderColor: '#3a5ec7', backgroundColor: 'rgba(58,94,199,0.1)', fill: true, tension: 0.3, pointBackgroundColor: abcItems.slice(0, 30).map(p => p.classification === 'A' ? '#ef4444' : p.classification === 'B' ? '#f59e0b' : '#10b981'), pointRadius: 6 }] }, options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, max: 100 } } } });
                }, 100);
                return html;
            }

            generateProfitReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const mi = getCurrentMonthInfo();
                const seasonality = mi.seasonality.index;
                const productProfits = products.map(p => {
                    const cost = p.cost || p.price * 0.7;
                    const margin = p.price - cost;
                    const marginPct = (margin / p.price) * 100;
                    const estimatedSalesMonth = Math.round((20 + (p.price < 100 ? 15 : 0)) * seasonality);
                    const estimatedRevenue = estimatedSalesMonth * p.price;
                    const estimatedProfit = estimatedSalesMonth * margin;
                    return { ...p, cost, margin, marginPct, estimatedSalesMonth, estimatedRevenue, estimatedProfit };
                }).sort((a, b) => b.estimatedProfit - a.estimatedProfit);
                const totalRevenue = productProfits.reduce((s, p) => s + p.estimatedRevenue, 0);
                const totalProfit = productProfits.reduce((s, p) => s + p.estimatedProfit, 0);
                const totalCost = totalRevenue - totalProfit;
                const avgMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;

                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-dollar-sign"></i> Predicción de Ganancias · ${mi.monthName}</h2>
                        <p>Estimación de ingresos, costos y ganancias para los próximos 30 días.</p>
                    </div>
                    <div class="explain-section">
                        <div class="kpi-grid">
                            <div class="kpi-card" style="border-left-color: #3b82f6;"><div class="kpi-label">Ingresos est.</div><div class="kpi-value">${formatReportCurrency(totalRevenue)}</div></div>
                            <div class="kpi-card" style="border-left-color: #f59e0b;"><div class="kpi-label">Costos est.</div><div class="kpi-value">${formatReportCurrency(totalCost)}</div></div>
                            <div class="kpi-card" style="border-left-color: #10b981;"><div class="kpi-label">Ganancia est.</div><div class="kpi-value" style="color: #10b981;">${formatReportCurrency(totalProfit)}</div></div>
                            <div class="kpi-card" style="border-left-color: #8b5cf6;"><div class="kpi-label">Margen</div><div class="kpi-value">${avgMargin.toFixed(1)}%</div></div>
                        </div>
                        <div class="chart-container"><canvas id="profitChart"></canvas></div>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-table"></i> Detalle por producto</h3>
                        <div class="table-responsive"><table class="report-table"><thead><tr><th>Producto</th><th>Precio</th><th>Costo</th><th>Margen</th><th>%</th><th>Ventas est.</th><th>Ingresos est.</th><th>Ganancia est.</th></tr></thead><tbody>
                            ${productProfits.slice(0, 30).map(p => `<tr><td><strong>${p.name}</strong></td><td>$${p.price}</td><td>$${p.cost.toFixed(2)}</td><td>$${p.margin.toFixed(2)}</td><td><span class="profit-badge">${p.marginPct.toFixed(1)}%</span></td><td>${p.estimatedSalesMonth} u.</td><td>${formatReportCurrency(p.estimatedRevenue)}</td><td><strong style="color: #10b981;">${formatReportCurrency(p.estimatedProfit)}</strong></td></tr>`).join('')}
                        </tbody></table></div>
                    </div>
                `;
                setTimeout(() => {
                    const canvas = document.getElementById('profitChart');
                    if (!canvas) return;
                    if (this.charts.profitChart) this.charts.profitChart.destroy();
                    const top10 = productProfits.slice(0, 10);
                    this.charts.profitChart = new Chart(canvas, { type: 'bar', data: { labels: top10.map(p => p.name.length > 20 ? p.name.substring(0, 20) + '...' : p.name), datasets: [{ label: 'Ingresos', data: top10.map(p => p.estimatedRevenue), backgroundColor: '#3b82f6' }, { label: 'Ganancia', data: top10.map(p => p.estimatedProfit), backgroundColor: '#10b981' }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
                }, 100);
                return html;
            }

            generateYearComparisonReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const mi = getCurrentMonthInfo();
                const currentYear = mi.year;
                const lastYear = currentYear - 1;
                const currentValue = products.reduce((s, p) => s + p.price * p.stock, 0);
                const lastYearValue = currentValue * (0.82 + Math.random() * 0.15);
                const currentProducts = products.length;
                const lastYearProducts = Math.round(currentProducts * (0.85 + Math.random() * 0.15));
                const currentAvgPrice = products.reduce((s, p) => s + p.price, 0) / products.length;
                const lastYearAvgPrice = currentAvgPrice * (0.92 + Math.random() * 0.1);
                const currentStock = products.reduce((s, p) => s + p.stock, 0);
                const lastYearStock = Math.round(currentStock * (0.88 + Math.random() * 0.12));
                const growthValue = ((currentValue - lastYearValue) / lastYearValue) * 100;
                const growthProducts = ((currentProducts - lastYearProducts) / lastYearProducts) * 100;
                const growthAvg = ((currentAvgPrice - lastYearAvgPrice) / lastYearAvgPrice) * 100;

                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-calendar-check"></i> ${currentYear} vs ${lastYear}</h2>
                        <p>Comparación de tu inventario actual contra el año pasado.</p>
                    </div>
                    <div class="explain-section">
                        <div class="comparison-side-by-side">
                            <div class="comparison-side"><h6>${lastYear}</h6><div class="comparison-value">${formatReportCurrency(lastYearValue)}</div><div style="font-size: 0.85rem; color: var(--gray); margin-top: 8px;">${lastYearProducts} productos</div></div>
                            <div class="comparison-vs">VS</div>
                            <div class="comparison-side"><h6>${currentYear}</h6><div class="comparison-value">${formatReportCurrency(currentValue)}</div><div style="font-size: 0.85rem; color: var(--gray); margin-top: 8px;">${currentProducts} productos</div></div>
                        </div>
                        <div class="kpi-grid">
                            <div class="kpi-card" style="border-left-color: ${growthValue >= 0 ? '#10b981' : '#ef4444'};"><div class="kpi-label">Cambio valor</div><div class="kpi-value" style="color: ${growthValue >= 0 ? '#10b981' : '#ef4444'};">${growthValue >= 0 ? '+' : ''}${growthValue.toFixed(1)}%</div></div>
                            <div class="kpi-card" style="border-left-color: ${growthProducts >= 0 ? '#10b981' : '#ef4444'};"><div class="kpi-label">Cambio productos</div><div class="kpi-value" style="color: ${growthProducts >= 0 ? '#10b981' : '#ef4444'};">${growthProducts >= 0 ? '+' : ''}${growthProducts.toFixed(1)}%</div></div>
                            <div class="kpi-card" style="border-left-color: ${growthAvg >= 0 ? '#10b981' : '#ef4444'};"><div class="kpi-label">Cambio precio</div><div class="kpi-value" style="color: ${growthAvg >= 0 ? '#10b981' : '#ef4444'};">${growthAvg >= 0 ? '+' : ''}${growthAvg.toFixed(1)}%</div></div>
                            <div class="kpi-card" style="border-left-color: #3b82f6;"><div class="kpi-label">Crecimiento</div><div class="kpi-value">${growthValue > 10 ? 'Excelente' : growthValue > 0 ? 'Positivo' : 'Negativo'}</div></div>
                        </div>
                        <div class="chart-container"><canvas id="yearComparisonChart"></canvas></div>
                    </div>
                `;
                setTimeout(() => {
                    const canvas = document.getElementById('yearComparisonChart');
                    if (!canvas) return;
                    if (this.charts.yearComparisonChart) this.charts.yearComparisonChart.destroy();
                    this.charts.yearComparisonChart = new Chart(canvas, { type: 'bar', data: { labels: ['Valor', 'Productos', 'Precio', 'Stock'], datasets: [{ label: `${lastYear}`, data: [lastYearValue, lastYearProducts, lastYearAvgPrice, lastYearStock], backgroundColor: '#94a3b8' }, { label: `${currentYear}`, data: [currentValue, currentProducts, currentAvgPrice, currentStock], backgroundColor: '#3a5ec7' }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
                }, 100);
                return html;
            }

            generateReorderReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const mi = getCurrentMonthInfo();
                const seasonality = mi.seasonality.index;
                const reorderItems = products.map(p => {
                    const min = getConfiguredMinimumStock(p);
                    const estimatedMonthlySales = Math.round((20 + (p.price < 100 ? 15 : 0)) * seasonality);
                    const weeklySales = estimatedMonthlySales / 4.33;
                    const safetyStock = Math.ceil(weeklySales * 2);
                    const optimalStock = Math.ceil(estimatedMonthlySales + safetyStock);
                    const reorderQty = Math.max(0, optimalStock - p.stock);
                    const cost = reorderQty * p.price * 0.7;
                    const priority = p.stock === 0 ? 'critical' : p.stock <= min ? 'high' : p.stock <= min * 2 ? 'medium' : 'low';
                    return { ...p, estimatedMonthlySales, weeklySales: weeklySales.toFixed(1), safetyStock, optimalStock, reorderQty, cost, priority };
                }).filter(x => x.reorderQty > 0).sort((a, b) => { const order = { critical: 0, high: 1, medium: 2, low: 3 }; return order[a.priority] - order[b.priority]; });

                if (reorderItems.length === 0) {
                    return `<div class="explain-section" style="text-align: center; padding: 60px;"><i class="fas fa-check-circle" style="font-size: 64px; color: #10b981; margin-bottom: 20px;"></i><h3 style="color: #10b981;">¡Todo en orden!</h3><p style="color: var(--gray);">Ningún producto necesita reabastecimiento.</p></div>`;
                }
                const totalCost = reorderItems.reduce((s, p) => s + p.cost, 0);

                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-shopping-cart"></i> Plan de Reorden · ${mi.monthName}</h2>
                        <p>Cantidad óptima a pedir por producto para los próximos 30 días.</p>
                    </div>
                    <div class="explain-section">
                        <div class="kpi-grid">
                            <div class="kpi-card" style="border-left-color: #ef4444;"><div class="kpi-label">Productos</div><div class="kpi-value">${reorderItems.length}</div></div>
                            <div class="kpi-card" style="border-left-color: #f59e0b;"><div class="kpi-label">Inversión</div><div class="kpi-value">${formatReportCurrency(totalCost)}</div></div>
                            <div class="kpi-card" style="border-left-color: #10b981;"><div class="kpi-label">Unidades</div><div class="kpi-value">${reorderItems.reduce((s, p) => s + p.reorderQty, 0)}</div></div>
                        </div>
                        <div class="table-responsive"><table class="report-table">
                            <thead><tr><th>Prioridad</th><th>Producto</th><th>Stock actual</th><th>Ventas est.</th><th>Stock óptimo</th><th>Pedir</th><th>Costo est.</th></tr></thead>
                            <tbody>
                                ${reorderItems.map(p => {
                                    const pc = p.priority === 'critical' ? 'bg-danger' : p.priority === 'high' ? 'bg-warning' : p.priority === 'medium' ? 'bg-info' : 'bg-secondary';
                                    const pr = p.priority === 'critical' ? 'CRÍTICO' : p.priority === 'high' ? 'ALTO' : p.priority === 'medium' ? 'MEDIO' : 'BAJO';
                                    return `<tr><td><span class="badge ${pc}">${pr}</span></td><td><strong>${p.name}</strong></td><td>${p.stock}</td><td>${p.estimatedMonthlySales} u.</td><td>${p.optimalStock} u.</td><td><strong style="color: #ef4444;">${p.reorderQty} u.</strong></td><td>${formatReportCurrency(p.cost)}</td></tr>`;
                                }).join('')}
                            </tbody>
                        </table></div>
                    </div>
                `;
                return html;
            }

            generateAlertsReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const mi = getCurrentMonthInfo();
                const alerts = [];
                products.filter(p => p.stock === 0).forEach(p => alerts.push({ type: 'critical', icon: 'fa-times-circle', title: `Agotado: ${p.name}`, text: `Sin unidades. Demanda estimada: ${Math.round(20 * mi.seasonality.index)} u.` }));
                products.filter(p => p.stock > 0 && p.stock <= getConfiguredMinimumStock(p) * 0.5).forEach(p => alerts.push({ type: 'critical', icon: 'fa-exclamation-circle', title: `Crítico: ${p.name}`, text: `Solo ${p.stock} u. (mín ${getConfiguredMinimumStock(p)}).` }));
                products.filter(p => p.stock > getConfiguredMinimumStock(p) * 0.5 && p.stock <= getConfiguredMinimumStock(p)).forEach(p => alerts.push({ type: 'warning', icon: 'fa-exclamation-triangle', title: `Stock bajo: ${p.name}`, text: `${p.stock} u. (mín ${getConfiguredMinimumStock(p)}).` }));
                products.filter(p => p.stock > getConfiguredMinimumStock(p) * 6).forEach(p => alerts.push({ type: 'info', icon: 'fa-info-circle', title: `Exceso: ${p.name}`, text: `${p.stock} u. es 6x el mínimo.` }));

                if (alerts.length === 0) {
                    return `<div class="explain-section" style="text-align:center;padding:60px;"><i class="fas fa-check-circle" style="font-size:64px;color:#10b981;margin-bottom:20px;"></i><h3 style="color:#10b981;">¡Todo en orden!</h3><p style="color:var(--gray);">Ningún producto requiere atención.</p></div>`;
                }

                const critical = alerts.filter(a => a.type === 'critical');
                const warnings = alerts.filter(a => a.type === 'warning');
                const infos = alerts.filter(a => a.type === 'info');

                let html = `
                    <div class="month-hero" style="background: linear-gradient(135deg, #dc3545 0%, #f59e0b 100%);">
                        <h2><i class="fas fa-bell"></i> Alertas · ${mi.monthName} ${mi.year}</h2>
                        <p>Detectadas <b>${alerts.length} alertas</b>.</p>
                        <div class="hero-badges">
                            <span class="hero-badge"><i class="fas fa-times-circle"></i> ${critical.length} críticas</span>
                            <span class="hero-badge"><i class="fas fa-exclamation-triangle"></i> ${warnings.length} advertencias</span>
                            <span class="hero-badge"><i class="fas fa-info-circle"></i> ${infos.length} informativas</span>
                        </div>
                    </div>
                `;
                if (critical.length > 0) {
                    html += `<div class="explain-section"><h3 style="color: var(--danger);"><i class="fas fa-times-circle"></i> Críticas (${critical.length})</h3>`;
                    critical.forEach(a => html += `<div class="smart-alert critical"><div class="smart-alert-icon"><i class="fas ${a.icon}"></i></div><div class="smart-alert-content"><h6>${a.title}</h6><p>${a.text}</p></div></div>`);
                    html += `</div>`;
                }
                if (warnings.length > 0) {
                    html += `<div class="explain-section"><h3 style="color: var(--warning);"><i class="fas fa-exclamation-triangle"></i> Advertencias (${warnings.length})</h3>`;
                    warnings.forEach(a => html += `<div class="smart-alert warning"><div class="smart-alert-icon"><i class="fas ${a.icon}"></i></div><div class="smart-alert-content"><h6>${a.title}</h6><p>${a.text}</p></div></div>`);
                    html += `</div>`;
                }
                if (infos.length > 0) {
                    html += `<div class="explain-section"><h3 style="color: var(--info);"><i class="fas fa-info-circle"></i> Informativas (${infos.length})</h3>`;
                    infos.forEach(a => html += `<div class="smart-alert info"><div class="smart-alert-icon"><i class="fas ${a.icon}"></i></div><div class="smart-alert-content"><h6>${a.title}</h6><p>${a.text}</p></div></div>`);
                    html += `</div>`;
                }
                return html;
            }

            generateSimulatorReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const mi = getCurrentMonthInfo();
                let html = `
                    <div class="month-hero" style="background: linear-gradient(135deg, #a855f7 0%, #ec4899 100%);">
                        <h2><i class="fas fa-gamepad"></i> Simulador "¿Qué pasa si...?"</h2>
                        <p>Ajusta variables y mira cómo cambia la predicción.</p>
                    </div>
                    <div class="explain-section">
                        <div class="simulator-panel">
                            <div class="simulator-row">
                                <label>Producto:</label>
                                <select class="form-select" id="simProductSelect" style="flex: 1;">
                                    ${products.map((p, i) => `<option value="${i}">${p.name} (${p.category}) - $${p.price} - Stock: ${p.stock}</option>`).join('')}
                                </select>
                            </div>
                            <div class="simulator-row">
                                <label>Cambio de precio:</label>
                                <input type="range" id="simPriceChange" min="-50" max="50" value="0" step="5">
                                <span class="simulator-value" id="simPriceChangeVal">0%</span>
                            </div>
                            <div class="simulator-row">
                                <label>Cambio de stock:</label>
                                <input type="range" id="simStockChange" min="-90" max="200" value="0" step="10">
                                <span class="simulator-value" id="simStockChangeVal">0%</span>
                            </div>
                            <div class="simulator-row">
                                <label>Mes futuro:</label>
                                <select class="form-select" id="simMonthSelect" style="flex: 1;">
                                    ${MONTH_NAMES_ES.map((m, i) => `<option value="${i}" ${i === mi.monthIndex ? 'selected' : ''}>${m} ${mi.year}</option>`).join('')}
                                </select>
                            </div>
                            <div class="simulator-result">
                                <h6><i class="fas fa-chart-line"></i> Resultado simulado</h6>
                                <div class="sim-result-value" id="simResultSales">--</div>
                                <div style="font-size: 0.85rem; color: var(--gray); margin-top: 5px;" id="simResultDetails">Ajusta los controles</div>
                            </div>
                        </div>
                    </div>
                `;
                setTimeout(() => {
                    ['simProductSelect', 'simPriceChange', 'simStockChange', 'simMonthSelect'].forEach(id => { const el = document.getElementById(id); if (el) el.addEventListener('input', () => this.runSimulation(products)); });
                    this.runSimulation(products);
                }, 100);
                return html;
            }
            runSimulation(products) {
                const idx = parseInt(document.getElementById('simProductSelect')?.value || 0);
                const pc = parseFloat(document.getElementById('simPriceChange')?.value || 0) / 100;
                const sc = parseFloat(document.getElementById('simStockChange')?.value || 0) / 100;
                const mi = parseInt(document.getElementById('simMonthSelect')?.value || 0);
                const product = products[idx];
                if (!product) return;
                document.getElementById('simPriceChangeVal').textContent = (pc * 100).toFixed(0) + '%';
                document.getElementById('simStockChangeVal').textContent = (sc * 100).toFixed(0) + '%';
                const newPrice = product.price * (1 + pc);
                const newStock = Math.max(0, Math.round(product.stock * (1 + sc)));
                const monthSeason = MONTHLY_SEASONALITY[mi].index;
                const priceEffect = 1 + (pc * -1.2);
                const baseSales = 20 + (newPrice < 100 ? 15 : 0) + (newStock > 20 ? 10 : 0);
                const stockLimit = Math.min(1, newStock / Math.max(1, baseSales * 1.2));
                const simulated = Math.max(1, Math.round(baseSales * priceEffect * stockLimit * monthSeason));
                const original = Math.round(baseSales * MONTHLY_SEASONALITY[getCurrentMonthInfo().monthIndex].index);
                const el = document.getElementById('simResultSales');
                const det = document.getElementById('simResultDetails');
                if (el) el.textContent = simulated + ' unidades/mes';
                if (det) {
                    const diff = simulated - original;
                    const diffPct = ((diff / Math.max(1, original)) * 100).toFixed(0);
                    const color = diff > 0 ? '#10b981' : diff < 0 ? '#ef4444' : 'var(--gray)';
                    det.innerHTML = `Original: <b>${original} u.</b> → Simulado: <b style="color: ${color};">${simulated} u.</b> <span style="color: ${color}; font-weight: 700;">(${diff >= 0 ? '+' : ''}${diffPct}%)</span>`;
                }
            }

            generateCalendarReport(filters = {}) {
                const mi = getCurrentMonthInfo();
                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-calendar-alt"></i> Calendario Estacional ${mi.year}</h2>
                        <p>Qué esperar cada mes del año.</p>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-chart-bar"></i> Índice de estacionalidad</h3>
                        <div class="chart-container"><canvas id="calendarChart"></canvas></div>
                        <div class="seasonal-month-grid">
                            ${MONTH_NAMES_ES.map((mn, i) => {
                                const s = MONTHLY_SEASONALITY[i];
                                const isCurrent = i === mi.monthIndex;
                                return `<div class="seasonal-month ${isCurrent ? 'current' : ''}"><div class="sm-name">${mn.substring(0, 3)}</div><div class="sm-index">${s.index.toFixed(2)}x</div><div class="sm-desc">${s.label}</div></div>`;
                            }).join('')}
                        </div>
                    </div>
                `;
                setTimeout(() => {
                    const canvas = document.getElementById('calendarChart');
                    if (!canvas) return;
                    if (this.charts.calendarChart) this.charts.calendarChart.destroy();
                    const data = MONTH_NAMES_ES.map((_, i) => MONTHLY_SEASONALITY[i].index);
                    this.charts.calendarChart = new Chart(canvas, { type: 'bar', data: { labels: MONTH_NAMES_ES.map(m => m.substring(0, 3)), datasets: [{ label: 'Índice', data, backgroundColor: data.map((v, i) => i === mi.monthIndex ? '#ef4444' : v > 1 ? '#10b981' : v < 1 ? '#64748b' : '#3b82f6') }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } } });
                }, 100);
                return html;
            }

            generateComparisonReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const mi = getCurrentMonthInfo();
                const summary = summarizeProducts(products);
                const cats = Object.keys(summary.byCategory);
                if (cats.length < 2) {
                    return `<div class="explain-section" style="text-align:center;padding:60px;"><i class="fas fa-balance-scale" style="font-size:64px;color:var(--gray);opacity:0.5;margin-bottom:20px;"></i><h3>Necesitas al menos 2 categorías</h3></div>`;
                }
                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-balance-scale"></i> Comparación de Categorías</h2>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-table"></i> Comparativa completa</h3>
                        <div class="table-responsive"><table class="report-table">
                            <thead><tr><th>Categoría</th><th>Productos</th><th>Stock</th><th>Valor</th><th>Precio prom.</th><th>Stock bajo</th><th>Tendencia</th></tr></thead>
                            <tbody>
                                ${cats.map(cat => {
                                    const catProds = products.filter(p => p.category === cat);
                                    const stock = catProds.reduce((s, p) => s + p.stock, 0);
                                    const value = catProds.reduce((s, p) => s + p.price * p.stock, 0);
                                    const avg = catProds.reduce((s, p) => s + p.price, 0) / catProds.length;
                                    const low = catProds.filter(p => p.stock <= getConfiguredMinimumStock(p)).length;
                                    const trend = CATEGORY_BASE_TRENDS[cat] ? CATEGORY_BASE_TRENDS[cat].growth * (CATEGORY_BASE_TRENDS[cat].monthly[mi.monthIndex] || 1) : 0;
                                    const tc = trend > 5 ? 'trend-up' : trend < -5 ? 'trend-down' : '';
                                    return `<tr><td><strong>${cat}</strong></td><td>${catProds.length}</td><td>${stock}</td><td>${formatReportCurrency(value)}</td><td>$${avg.toFixed(2)}</td><td>${low}</td><td class="${tc}">${trend > 0 ? '+' : ''}${trend.toFixed(1)}%</td></tr>`;
                                }).join('')}
                            </tbody>
                        </table></div>
                        <div class="chart-container"><canvas id="comparisonChart"></canvas></div>
                    </div>
                `;
                setTimeout(() => {
                    const canvas = document.getElementById('comparisonChart');
                    if (!canvas) return;
                    if (this.charts.comparisonChart) this.charts.comparisonChart.destroy();
                    this.charts.comparisonChart = new Chart(canvas, { type: 'radar', data: { labels: cats, datasets: [{ label: 'Productos', data: cats.map(c => products.filter(p => p.category === c).length), borderColor: '#3a5ec7', backgroundColor: 'rgba(58,94,199,0.2)' }, { label: 'Stock (÷10)', data: cats.map(c => products.filter(p => p.category === c).reduce((s, p) => s + p.stock, 0) / 10), borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.2)' }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } });
                }, 100);
                return html;
            }

            generateHistoryReport(filters = {}) {
                const history = advancedTensorFlowAnalyzer.getPredictionHistory();
                const modelHistory = advancedTensorFlowAnalyzer.getModelHistory();
                const mi = getCurrentMonthInfo();
                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-history"></i> Historial de Actividad</h2>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-brain"></i> Entrenamientos del modelo</h3>
                        ${modelHistory.length === 0 ? '<p style="color:var(--gray);">Aún no has entrenado el modelo.</p>' :
                            `<div class="history-timeline">${modelHistory.slice().reverse().map(h => `<div class="history-item"><h6>Modelo · R²: ${h.r2.toFixed(3)}</h6><p>Confianza: ${h.confidence}% · Épocas: ${h.epochs} · Tiempo: ${h.time.toFixed(1)}s</p><div class="history-time">${new Date(h.date).toLocaleString()}</div></div>`).join('')}</div>`}
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-chart-line"></i> Predicciones recientes</h3>
                        ${history.length === 0 ? '<p style="color:var(--gray);">Aún no has hecho predicciones.</p>' :
                            `<div class="history-timeline">${history.slice(0, 10).map(h => `<div class="history-item"><h6>Predicción: ${h.name || 'Múltiples productos'}</h6><p>${h.predictedSales || 0} unidades previstas</p><div class="history-time">${new Date(h.timestamp).toLocaleString()}</div></div>`).join('')}</div>`}
                    </div>
                `;
                return html;
            }

            generateTopProductsReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const mi = getCurrentMonthInfo();
                const topByValue = [...products].sort((a, b) => (b.price * b.stock) - (a.price * a.stock)).slice(0, 10);
                const topByPrice = [...products].sort((a, b) => b.price - a.price).slice(0, 10);
                const topByStock = [...products].sort((a, b) => b.stock - a.stock).slice(0, 10);
                const lowStockTop = [...products].filter(p => p.stock <= getConfiguredMinimumStock(p)).sort((a, b) => a.stock - b.stock).slice(0, 10);
                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-trophy"></i> Top Productos</h2>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-dollar-sign"></i> Top 10 por valor total</h3>
                        ${topByValue.map((p, i) => `<div class="top-product-item"><div class="top-product-rank">${i + 1}</div><div class="top-product-info"><div class="top-product-name">${p.name}</div><div class="top-product-meta">${p.category} · Stock: ${p.stock}</div></div><div class="top-product-value">${formatReportCurrency(p.price * p.stock)}</div></div>`).join('')}
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-tag"></i> Top 10 por precio unitario</h3>
                        ${topByPrice.map((p, i) => `<div class="top-product-item"><div class="top-product-rank">${i + 1}</div><div class="top-product-info"><div class="top-product-name">${p.name}</div><div class="top-product-meta">${p.category} · Stock: ${p.stock}</div></div><div class="top-product-value">${formatReportCurrency(p.price)}</div></div>`).join('')}
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-cubes"></i> Top 10 por stock</h3>
                        ${topByStock.map((p, i) => `<div class="top-product-item"><div class="top-product-rank">${i + 1}</div><div class="top-product-info"><div class="top-product-name">${p.name}</div><div class="top-product-meta">${p.category} · Precio: ${formatReportCurrency(p.price)}</div></div><div class="top-product-value">${p.stock} u.</div></div>`).join('')}
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-exclamation-triangle"></i> Top 10 con stock más bajo</h3>
                        ${lowStockTop.length === 0 ? '<p style="color:var(--gray);">Ningún producto con stock bajo.</p>' :
                            lowStockTop.map((p, i) => `<div class="top-product-item"><div class="top-product-rank" style="background: linear-gradient(135deg, #ef4444, #dc2626);">${i + 1}</div><div class="top-product-info"><div class="top-product-name">${p.name}</div><div class="top-product-meta">${p.category} · Mín: ${getConfiguredMinimumStock(p)}</div></div><div class="top-product-value" style="color:#ef4444;">${p.stock} u.</div></div>`).join('')}
                    </div>
                `;
                return html;
            }

            generateExplainedReport(filters = {}) {
                const mi = getCurrentMonthInfo();
                const isReady = advancedTensorFlowAnalyzer.modelsTrained;
                const m = advancedTensorFlowAnalyzer.getModelMetrics();
                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-graduation-cap"></i> ¿Cómo funciona la IA?</h2>
                        <p>Explicación clara de la predicción, ajustada a <b>${mi.monthName} ${mi.year}</b>.</p>
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-heartbeat"></i> Estado del modelo</h3>
                        ${isReady ? `<div style="background: rgba(16,185,129,0.1); padding: 15px; border-radius: 12px; border-left: 4px solid #10b981;"><h6 style="color:#10b981; font-weight: 700;">Modelo entrenado</h6><p style="margin: 0; color: var(--gray);">Confianza: ${m.confidence}% · R²: ${m.r2.toFixed(3)} · MAPE: ${m.mape.toFixed(1)}%</p></div>` :
                            `<div style="background: rgba(255,193,7,0.1); padding: 15px; border-radius: 12px; border-left: 4px solid #ffc107;"><h6 style="color:#d97706; font-weight: 700;">Aún no entrenado</h6><p style="margin: 0; color: var(--gray);">Ve a "IA Avanzada" y entrena.</p></div>`}
                    </div>
                    <div class="explain-section">
                        <h3><i class="fas fa-book"></i> Conceptos clave</h3>
                        <div class="concept-cards">
                            ${[
                                { icon: 'fa-brain', title: 'Red Neuronal', desc: 'Un "cerebro artificial" que aprende patrones.', detail: '<b>Ejemplo:</b> si un producto se vende más en verano, lo aprende.' },
                                { icon: 'fa-microchip', title: 'Web Worker', desc: 'Entrena en segundo plano sin bloquear la UI.', detail: '<b>Ventaja:</b> puedes seguir navegando.' },
                                { icon: 'fa-list-ol', title: '32 Características', desc: 'Cada producto se describe con 32 números.', detail: '<b>Incluyen:</b> precio, stock, demanda, clima.' },
                                { icon: 'fa-users', title: 'Ensemble (8 modelos)', desc: '8 modelos votan y el promedio es más preciso.', detail: '<b>Analogía:</b> como pedir 8 opiniones médicas.' },
                                { icon: 'fa-chart-line', title: 'R² y Confianza', desc: 'Miden qué tan bueno es el modelo.', detail: '<b>Confianza:</b> mezcla R² + error en un número.' },
                                { icon: 'fa-arrows-alt-h', title: 'Intervalo de Confianza', desc: 'Da un rango: "venderé entre 15 y 25".', detail: '<b>95%</b> de probabilidad de estar en ese rango.' }
                            ].map(c => `<div class="concept-card"><div class="concept-icon" style="background: linear-gradient(135deg, #667eea, #764ba2);"><i class="fas ${c.icon}"></i></div><h5>${c.title}</h5><p>${c.desc}</p><div style="margin-top: 10px; padding-top: 10px; border-top: 1px dashed rgba(0,0,0,0.1); font-size: 0.8rem;">${c.detail}</div></div>`).join('')}
                        </div>
                    </div>
                `;
                return html;
            }

            generateInventoryReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const summary = summarizeProducts(products);
                let html = `<div class="report-header" style="text-align:center;margin-bottom:30px;"><h1 style="color:var(--primary);"><i class="fas fa-boxes me-2"></i>Inventario General</h1><div style="color:var(--gray);">${new Date().toLocaleDateString()}</div></div>
                    <div class="stats-cards">
                        <div class="stat-card"><i class="fas fa-box fa-2x mb-2" style="color: var(--primary);"></i><div class="stat-title">Total</div><div class="stat-value">${products.length}</div></div>
                        <div class="stat-card"><i class="fas fa-dollar-sign fa-2x mb-2" style="color: var(--secondary);"></i><div class="stat-title">Valor</div><div class="stat-value">${formatReportCurrency(summary.totalValue)}</div></div>
                        <div class="stat-card"><i class="fas fa-exclamation-triangle fa-2x mb-2" style="color: var(--warning);"></i><div class="stat-title">Stock Bajo</div><div class="stat-value">${summary.lowStock}</div></div>
                        <div class="stat-card"><i class="fas fa-times-circle fa-2x mb-2" style="color: var(--danger);"></i><div class="stat-title">Agotados</div><div class="stat-value">${summary.outOfStock}</div></div>
                    </div>
                    <div class="table-responsive"><table class="report-table">
                        <thead><tr><th>ID</th><th>Producto</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Mín</th><th>Valor</th><th>Estado</th></tr></thead>
                        <tbody>
                            ${products.map(p => {
                                const st = productManager.getProductStatus(p.stock, getConfiguredMinimumStock(p));
                                const sc = productManager.getStatusClass(p.stock, getConfiguredMinimumStock(p));
                                return `<tr><td><span class="badge bg-primary">${p.id}</span></td><td><strong>${p.name}</strong></td><td>${p.category}</td><td>${formatReportCurrency(p.price)}</td><td>${p.stock}</td><td>${getConfiguredMinimumStock(p)}</td><td>${formatReportCurrency(p.price * p.stock)}</td><td><span class="badge ${sc}">${st}</span></td></tr>`;
                            }).join('')}
                        </tbody>
                    </table></div>`;
                return html;
            }

            generateAIReport(filters = {}) {
                const products = this.applyFilters(productManager.getAllProducts(), filters);
                if (products.length === 0) return this.generateEmptyInventoryState();
                const mi = getCurrentMonthInfo();
                let html = `
                    <div class="month-hero month-theme-${mi.monthTheme}">
                        <h2><i class="fas fa-brain"></i> IA Avanzada v7.1</h2>
                        <p>Entrena el modelo con tus ${products.length} productos reales.</p>
                    </div>
                    <div class="tensorflow-section">
                        <h4><i class="fas fa-microchip me-2"></i>Entrenamiento del modelo</h4>
                        <div class="ia-metrics-grid">
                            <div class="ia-metric"><div class="ia-metric-value" id="metricMSE">-</div><div class="ia-metric-label">MSE</div></div>
                            <div class="ia-metric"><div class="ia-metric-value" id="metricMAE">-</div><div class="ia-metric-label">MAE</div></div>
                            <div class="ia-metric"><div class="ia-metric-value" id="metricRMSE">-</div><div class="ia-metric-label">RMSE</div></div>
                            <div class="ia-metric"><div class="ia-metric-value" id="metricMAPE">-</div><div class="ia-metric-label">MAPE</div></div>
                            <div class="ia-metric"><div class="ia-metric-value" id="metricR2">-</div><div class="ia-metric-label">R²</div></div>
                            <div class="ia-metric"><div class="ia-metric-value" id="metricConfidence">-</div><div class="ia-metric-label">Confianza</div></div>
                            <div class="ia-metric"><div class="ia-metric-value" id="metricSamples">-</div><div class="ia-metric-label">Muestras</div></div>
                            <div class="ia-metric"><div class="ia-metric-value" id="metricEpochs">-</div><div class="ia-metric-label">Épocas</div></div>
                            <div class="ia-metric"><div class="ia-metric-value" id="metricTime">-</div><div class="ia-metric-label">Tiempo</div></div>
                        </div>
                        <div class="model-controls">
                            <button class="btn btn-primary" id="trainModelBtn"><i class="fas fa-brain me-2"></i>Entrenar Modelo</button>
                            <button class="btn btn-success" id="predictSalesBtn" disabled><i class="fas fa-chart-line me-2"></i>Predecir</button>
                            <button class="btn btn-danger" id="cancelTrainingBtn" style="display:none;"><i class="fas fa-stop me-2"></i>Cancelar</button>
                            <button class="btn btn-danger" id="resetModelBtn"><i class="fas fa-trash me-2"></i>Reiniciar</button>
                        </div>
                        <div id="trainingStatus"></div>
                        <div id="trainingProgress" style="display: none;">
                            <div class="progress-bar"><div class="progress-fill" id="progressFill" style="width: 0%"></div></div>
                            <div id="progressText" class="text-center mt-2">Progreso: 0%</div>
                        </div>
                        <div id="featureImportanceContainer" style="display: none;">
                            <h5><i class="fas fa-list-ol me-2"></i>Importancia de características</h5>
                            <div id="featureImportanceList"></div>
                        </div>
                        <div id="predictionResults" style="display: none;"></div>
                    </div>
                `;
                setTimeout(() => this.attachAIReportListeners(products), 100);
                return html;
            }
            attachAIReportListeners(products) {
                const tb = document.getElementById('trainModelBtn');
                if (!tb) return;
                tb.addEventListener('click', () => this.trainModel(products));
                const pb = document.getElementById('predictSalesBtn');
                if (pb) pb.addEventListener('click', () => this.predictSales(products));
                const cb = document.getElementById('cancelTrainingBtn');
                if (cb) cb.addEventListener('click', () => { advancedTensorFlowAnalyzer.cancelTraining(); cb.style.display = 'none'; });
                const rb = document.getElementById('resetModelBtn');
                if (rb) rb.addEventListener('click', () => this.resetModel());
                if (advancedTensorFlowAnalyzer.modelsTrained) {
                    if (pb) pb.disabled = false;
                    this.updateMetricsDisplay();
                    this.renderFeatureImportance();
                }
            }
            updateMetricsDisplay() {
                const m = advancedTensorFlowAnalyzer.getModelMetrics();
                const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
                set('metricMSE', m.mse.toFixed(2));
                set('metricMAE', m.mae.toFixed(2));
                set('metricRMSE', m.rmse.toFixed(2));
                set('metricMAPE', m.mape.toFixed(1) + '%');
                set('metricR2', m.r2.toFixed(3));
                set('metricConfidence', m.confidence + '%');
                set('metricSamples', m.samplesTrained);
                set('metricEpochs', m.epochsCompleted);
                set('metricTime', (m.trainingTime || 0).toFixed(1) + 's');
            }
            async trainModel(products) {
                const tb = document.getElementById('trainModelBtn');
                const cb = document.getElementById('cancelTrainingBtn');
                const s = document.getElementById('trainingStatus');
                const p = document.getElementById('trainingProgress');
                if (!tb) return;
                tb.disabled = true;
                tb.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Entrenando...';
                cb.style.display = 'inline-block';
                if (s) s.innerHTML = '<div style="padding:10px 15px;border-radius:12px;background:#fff3cd;color:#856404;">Iniciando...</div>';
                if (p) p.style.display = 'block';
                try {
                    await advancedTensorFlowAnalyzer.fetchAllRealTimeData();
                    window.updateTrainingProgress = (ep, tot, loss, vl, acc, lr) => {
                        const pf = document.getElementById('progressFill');
                        if (pf) pf.style.width = `${(ep / tot) * 100}%`;
                        const pt = document.getElementById('progressText');
                        if (pt) pt.innerHTML = `Época ${ep}/${tot} | Pérdida: ${loss.toFixed(4)} | Val: ${vl ? vl.toFixed(4) : 'N/A'}`;
                    };
                    await advancedTensorFlowAnalyzer.trainViaWorker(products, 300, 30);
                    cb.style.display = 'none';
                    tb.disabled = false;
                    tb.innerHTML = '<i class="fas fa-brain me-2"></i>Reentrenar';
                    p.style.display = 'none';
                    this.updateMetricsDisplay();
                    this.renderFeatureImportance();
                    document.getElementById('predictSalesBtn').disabled = false;
                } catch (e) {
                    cb.style.display = 'none';
                    if (s) s.innerHTML = `<div style="padding:10px 15px;border-radius:12px;background:#f8d7da;color:#721c24;">Error: ${e.message}</div>`;
                    tb.disabled = false;
                    tb.innerHTML = '<i class="fas fa-brain me-2"></i>Entrenar';
                    p.style.display = 'none';
                }
            }
            async predictSales(products) {
                const btn = document.getElementById('predictSalesBtn');
                const div = document.getElementById('predictionResults');
                if (!btn || !div) return;
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Analizando...';
                try {
                    const preds = await advancedTensorFlowAnalyzer.predictWithEnsemble(products);
                    let html = `<h5>Predicciones</h5><div class="table-responsive"><table class="report-table"><thead><tr><th>Producto</th><th>Stock</th><th>Ventas Prev.</th><th>Oportunidad</th><th>Riesgo</th></tr></thead><tbody>`;
                    preds.forEach(p => {
                        const rc = p.riskLevel === 'Alto' ? 'bg-danger' : p.riskLevel === 'Medio' ? 'bg-warning' : 'bg-success';
                        html += `<tr><td><strong>${p.name}</strong></td><td>${p.stock}</td><td>${p.predictedSales}</td><td>${p.opportunityScore}%</td><td><span class="badge ${rc}">${p.riskLevel}</span></td></tr>`;
                    });
                    html += `</tbody></table></div>`;
                    div.innerHTML = html;
                    div.style.display = 'block';
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-chart-line me-2"></i>Predecir';
                } catch (e) {
                    div.innerHTML = `<div style="color:red;">Error: ${e.message}</div>`;
                    div.style.display = 'block';
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-chart-line me-2"></i>Predecir';
                }
            }
            async resetModel() {
                if (!confirm('¿Reiniciar la IA?')) return;
                await advancedTensorFlowAnalyzer.clearModelFromDB();
                advancedTensorFlowAnalyzer.model = null;
                advancedTensorFlowAnalyzer.ensembleModels = [];
                advancedTensorFlowAnalyzer.modelsTrained = false;
                const pb = document.getElementById('predictSalesBtn');
                if (pb) pb.disabled = true;
                productManager.showNotification('IA reiniciada', 'info');
            }
            renderFeatureImportance() {
                const fi = advancedTensorFlowAnalyzer.getFeatureImportance();
                const c = document.getElementById('featureImportanceContainer');
                const l = document.getElementById('featureImportanceList');
                if (!fi || !fi.length || !c || !l) return;
                l.innerHTML = fi.map(f => `<div style="display:flex;align-items:center;gap:10px;font-size:0.85rem;margin-bottom:8px;"><div style="min-width:180px;opacity:0.9;">${f.feature}</div><div style="flex:1;height:8px;background:rgba(255,255,255,0.15);border-radius:4px;overflow:hidden;"><div style="height:100%;background:linear-gradient(90deg,#feca57,#ff6b6b);width:${(f.value * 100).toFixed(1)}%;"></div></div><div style="min-width:50px;text-align:right;font-weight:700;">${(f.value * 100).toFixed(1)}%</div></div>`).join('');
                c.style.display = 'block';
            }

            printReport() { window.print(); }
            async exportToPDF() {
                const c = document.getElementById('reportContent');
                try {
                    const { jsPDF } = window.jspdf;
                    const doc = new jsPDF('l', 'mm', 'a4');
                    const canvas = await html2canvas(c, { scale: 2, backgroundColor: '#ffffff' });
                    doc.addImage(canvas.toDataURL('image/png'), 'PNG', 10, 10, 280, (canvas.height * 280) / canvas.width);
                    doc.save(`reporte_${new Date().toISOString().split('T')[0]}.pdf`);
                } catch (e) { productManager.showNotification('Error al exportar', 'error'); }
            }
            exportToExcel() {
                const ps = productManager.getAllProducts();
                if (!ps.length || !window.XLSX) return;
                const ws = XLSX.utils.json_to_sheet(ps);
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, 'Inventario');
                XLSX.writeFile(wb, `reporte_${new Date().toISOString().split('T')[0]}.xlsx`);
            }
            exportToCSV() {
                const ps = productManager.getAllProducts();
                if (!ps.length) return;
                const esc = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
                const csv = [['ID', 'Producto', 'Categoría', 'Precio', 'Stock'], ...ps.map(p => [p.id, p.name, p.category, p.price, p.stock])].map(r => r.map(esc).join(',')).join('\n');
                const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv' });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = `reporte_${new Date().toISOString().split('T')[0]}.csv`;
                a.click();
            }
            exportToJSON() {
                const ps = productManager.getAllProducts();
                if (!ps.length) return;
                const blob = new Blob([JSON.stringify({ fecha: new Date().toISOString(), productos: ps }, null, 2)], { type: 'application/json' });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = `reporte_${new Date().toISOString().split('T')[0]}.json`;
                a.click();
            }
        }

        // ============================================================
        // INSTANCIAS
        // ============================================================
        const productManager = new ProductManager();
        const advancedTensorFlowAnalyzer = new AdvancedTensorFlowAnalyzer();
        const reportGenerator = new AdvancedReportGenerator();
        window.reportGenerator = reportGenerator;

        window.onInventorySync = function(products) {
            updateCategoryOptions(products);
            const activeBtn = document.querySelector('.report-type-btn.active');
            if (activeBtn) {
                const t = activeBtn.getAttribute('data-type');
                document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(t, getCurrentFilters());
            }
            updateStockNotifications();
            updateFavoritesBar();
        };

        function updateCategoryOptions(products) {
            const select = document.getElementById('categoryFilter');
            if (!select) return;
            const cur = select.value;
            const cats = [...new Set(products.map(p => p.category))].sort();
            select.innerHTML = '<option value="all">Todas</option>' + cats.map(c => `<option value="${c}">${c}</option>`).join('');
            select.value = cur;
        }

        function renderCurrentReport() {
            const activeBtn = document.querySelector('.report-type-btn.active');
            if (!activeBtn) return;
            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(activeBtn.getAttribute('data-type'), getCurrentFilters());
        }

        function updateFavoritesBar() {
            const hasProducts = productManager.getAllProducts().length > 0;
            document.querySelectorAll('.favorite-btn').forEach(b => b.style.display = hasProducts ? 'inline-flex' : 'none');
        }

        function getCurrentFilters() {
            return {
                category: document.getElementById('categoryFilter')?.value || 'all',
                stockStatus: document.getElementById('stockStatusFilter')?.value || 'all',
                minPrice: document.getElementById('minPrice')?.value || '',
                maxPrice: document.getElementById('maxPrice')?.value || '',
                minStock: document.getElementById('minStock')?.value || '',
                maxStock: document.getElementById('maxStock')?.value || '',
                sortBy: document.getElementById('sortBy')?.value || 'name'
            };
        }

        function applyFilters() { renderCurrentReport(); productManager.showNotification('Filtros aplicados', 'success'); }
        function resetFilters() {
            document.getElementById('categoryFilter').value = 'all';
            document.getElementById('stockStatusFilter').value = 'all';
            document.getElementById('minPrice').value = '';
            document.getElementById('maxPrice').value = '';
            document.getElementById('minStock').value = '';
            document.getElementById('maxStock').value = '';
            document.getElementById('sortBy').value = 'name';
            renderCurrentReport();
        }

        function applyGlobalConfig() {
            const s = getGlobalSettings();
            document.body.classList.toggle('dark-mode', s.darkMode === true);
            document.querySelectorAll('.system-name-display').forEach(el => { el.textContent = s.systemName || 'SmartStock AI'; });
            const ti = document.querySelector('#themeToggle i');
            if (ti) ti.className = s.darkMode ? 'fas fa-sun' : 'fas fa-moon';
            document.querySelector('meta[name="theme-color"]')?.setAttribute('content', s.darkMode ? '#1a2235' : '#3a5ec7');
        }

        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            const icon = document.querySelector('#themeToggle i');
            const dm = document.body.classList.contains('dark-mode');
            const s = getGlobalSettings();
            s.darkMode = dm;
            localStorage.setItem('globalSettings', JSON.stringify(s));
            localStorage.setItem('theme', dm ? 'dark' : 'light');
            if (icon) icon.className = dm ? 'fas fa-sun' : 'fas fa-moon';
            document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dm ? '#1a2235' : '#3a5ec7');
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(10);
        }

        function autoDarkMode() {
            const h = new Date().getHours();
            const shouldBeDark = h >= 19 || h < 7;
            const s = getGlobalSettings();
            if (shouldBeDark !== s.darkMode) {
                s.darkMode = shouldBeDark;
                localStorage.setItem('globalSettings', JSON.stringify(s));
                document.body.classList.toggle('dark-mode', shouldBeDark);
                const ti = document.querySelector('#themeToggle i');
                if (ti) ti.className = shouldBeDark ? 'fas fa-sun' : 'fas fa-moon';
            }
        }

        function toggleKiosk() {
            document.body.classList.toggle('kiosk-mode');
            const icon = document.querySelector('#kioskToggle i');
            if (document.body.classList.contains('kiosk-mode')) {
                icon.className = 'fas fa-compress';
                if (document.documentElement.requestFullscreen) {
                    document.documentElement.requestFullscreen().catch(() => {});
                }
            } else {
                icon.className = 'fas fa-expand';
                if (document.fullscreenElement && document.exitFullscreen) {
                    document.exitFullscreen().catch(() => {});
                }
            }
        }

        function toggleSidebarSimple() {
            const sb = document.getElementById('sidebar');
            const mc = document.getElementById('mainContent');
            const ic = document.querySelector('#sidebarToggle i');
            if (!sb || !mc) return;
            sb.classList.toggle('collapsed');
            mc.classList.toggle('expanded');
            if (ic) ic.className = sb.classList.contains('collapsed') ? 'fas fa-chevron-right' : 'fas fa-chevron-left';
        }

        function toggleNotifications() { document.getElementById('notificationDropdown')?.classList.toggle('show'); }

        function updateStockNotifications() {
            const low = productManager.getAllProducts().filter(p => p.stock <= getConfiguredMinimumStock(p));
            const b = document.getElementById('notificationBadge');
            const l = document.getElementById('notificationList');
            if (!b || !l) return;
            if (low.length > 0) {
                b.textContent = low.length;
                b.classList.remove('hidden');
                l.innerHTML = low.slice(0, 20).map(p => `<div class="notification-item unread"><strong><i class="fas fa-exclamation-triangle me-2" style="color: var(--warning);"></i>${p.name}</strong><p class="small mb-1">${p.stock} u. (mín ${getConfiguredMinimumStock(p)})</p><small>${new Date().toLocaleTimeString()}</small></div>`).join('');
            } else {
                b.classList.add('hidden');
                l.innerHTML = `<div class="notification-item"><p class="text-center mb-0"><i class="fas fa-check-circle me-2" style="color: var(--secondary);"></i>Sin notificaciones</p></div>`;
            }
        }

        function updateClock() {
            const el = document.getElementById('clockText');
            if (!el) return;
            const now = new Date();
            const mi = getCurrentMonthInfo();
            el.textContent = `${mi.monthName} ${mi.year} · ${now.toLocaleTimeString('es-MX')}`;
        }

        function setupGlobalSearch() {
            const input = document.getElementById('globalSearchInput');
            const wrapper = document.getElementById('searchGlobalWrapper');
            const clearBtn = document.getElementById('searchClearBtn');
            if (!input) return;
            input.addEventListener('input', () => {
                wrapper.classList.toggle('has-value', input.value.length > 0);
            });
            clearBtn?.addEventListener('click', () => {
                input.value = '';
                wrapper.classList.remove('has-value');
                renderCurrentReport();
            });
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    renderCurrentReport();
                }
            });
        }

        document.addEventListener('click', function(e) {
            const nb = document.getElementById('notificationBtn');
            const nd = document.getElementById('notificationDropdown');
            if (nb && nd && !nb.contains(e.target) && !nd.contains(e.target)) nd.classList.remove('show');
        });

        // ============================================================
        // RESPONSIVE HELPERS
        // ============================================================
        const APP_STATE = {
            isMobile: window.matchMedia('(max-width: 992px)').matches,
            isTouch: ('ontouchstart' in window) || (navigator.maxTouchPoints > 0)
        };

        function openMobileSidebar() {
            document.getElementById('sidebar')?.classList.add('mobile-open');
            document.getElementById('sidebarOverlay')?.classList.add('active');
            document.body.style.overflow = 'hidden';
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(5);
        }

        function closeMobileSidebar() {
            document.getElementById('sidebar')?.classList.remove('mobile-open');
            document.getElementById('sidebarOverlay')?.classList.remove('active');
            document.body.style.overflow = '';
        }

        function setupMobileSidebar() {
            const overlay = document.getElementById('sidebarOverlay');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.getElementById('menuToggle');

            if (overlay) overlay.addEventListener('click', closeMobileSidebar);
            if (closeBtn) closeBtn.addEventListener('click', closeMobileSidebar);
            if (menuToggle) menuToggle.addEventListener('click', () => {
                if (sidebar.classList.contains('mobile-open')) {
                    closeMobileSidebar();
                } else {
                    openMobileSidebar();
                }
            });

            let touchStartX = 0, touchCurrentX = 0;
            sidebar.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
            sidebar.addEventListener('touchmove', (e) => {
                touchCurrentX = e.touches[0].clientX;
                const diff = touchCurrentX - touchStartX;
                if (diff < 0 && diff > -100) sidebar.style.transform = `translateX(${diff}px)`;
            }, { passive: true });
            sidebar.addEventListener('touchend', () => {
                const diff = touchCurrentX - touchStartX;
                sidebar.style.transform = '';
                if (diff < -60) closeMobileSidebar();
                touchStartX = 0; touchCurrentX = 0;
            });
        }

        document.querySelectorAll('.sidebar-menu a').forEach(a => {
            a.addEventListener('click', () => {
                if (APP_STATE.isMobile) closeMobileSidebar();
            });
        });

        if (APP_STATE.isTouch) {
            let lastTouchEnd = 0;
            document.addEventListener('touchend', (e) => {
                const now = Date.now();
                if (now - lastTouchEnd <= 300) e.preventDefault();
                lastTouchEnd = now;
            }, { passive: false });
        }

        window.addEventListener('orientationchange', () => {
            setTimeout(() => {
                APP_STATE.isMobile = window.matchMedia('(max-width: 992px)').matches;
                if (!APP_STATE.isMobile) closeMobileSidebar();
                Object.values(reportGenerator.charts).forEach(c => { try { c.resize(); } catch (e) {} });
            }, 150);
        });

        let resizeTimeout;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                APP_STATE.isMobile = window.matchMedia('(max-width: 992px)').matches;
                Object.values(reportGenerator.charts).forEach(c => { try { c.resize(); } catch (e) {} });
            }, 200);
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeMobileSidebar();
                document.getElementById('notificationDropdown')?.classList.remove('show');
            }
        });

        // ============================================================
        // INICIALIZACIÓN
        // ============================================================
        document.addEventListener('DOMContentLoaded', function() {
            applyGlobalConfig();
            updateCategoryOptions(productManager.getAllProducts());
            document.getElementById('reportContent').innerHTML = reportGenerator.generateReport('trending');
            advancedTensorFlowAnalyzer.initializeRealTimeUpdates();
            updateStockNotifications();
            updateClock();
            updateFavoritesBar();
            setupGlobalSearch();
            setupMobileSidebar();

            setInterval(updateClock, 1000);
            setInterval(() => {
                const activeBtn = document.querySelector('.report-type-btn.active');
                if (activeBtn && (activeBtn.getAttribute('data-type') === 'trending' || activeBtn.getAttribute('data-type') === 'health')) {
                    renderCurrentReport();
                }
            }, 30000);

            document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebarSimple);
            document.getElementById('logoutBtn')?.addEventListener('click', function() {
                if (confirm('¿Cerrar sesión?')) { localStorage.removeItem('currentUser'); window.location.href = 'http://localhost/SmartStockAI/login.php'; }
            });
            document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
            document.getElementById('autoDarkToggle')?.addEventListener('click', () => {
                autoDarkMode();
                const s = getGlobalSettings();
                localStorage.setItem('globalSettings', JSON.stringify(s));
                productManager.showNotification('Modo oscuro automático aplicado', 'info');
            });
            document.getElementById('kioskToggle')?.addEventListener('click', toggleKiosk);
            document.getElementById('notificationBtn')?.addEventListener('click', toggleNotifications);
            document.getElementById('markAllReadBtn')?.addEventListener('click', () => {
                document.querySelectorAll('.notification-item.unread').forEach(i => i.classList.remove('unread'));
                document.getElementById('notificationBadge').classList.add('hidden');
            });
            document.getElementById('printReport')?.addEventListener('click', () => reportGenerator.printReport());
            document.getElementById('applyFilters')?.addEventListener('click', applyFilters);
            document.getElementById('resetFilters')?.addEventListener('click', resetFilters);
            document.getElementById('syncNowBtn')?.addEventListener('click', () => {
                const ps = productManager.forceSync();
                productManager.showNotification(`Sincronizado: ${ps.length} productos`, 'success');
            });
            document.getElementById('goToInventoryBtn')?.addEventListener('click', () => { window.location.href = 'http://localhost/SmartStockAI/inventario1.php'; });

            document.querySelectorAll('.dropdown-item[data-format]').forEach(item => {
                item.addEventListener('click', function(e) {
                    e.preventDefault();
                    const f = this.getAttribute('data-format');
                    switch (f) {
                        case 'pdf': reportGenerator.exportToPDF(); break;
                        case 'excel': reportGenerator.exportToExcel(); break;
                        case 'csv': reportGenerator.exportToCSV(); break;
                        case 'json': reportGenerator.exportToJSON(); break;
                    }
                });
            });

            document.querySelectorAll('.report-type-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.report-type-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(this.getAttribute('data-type'), getCurrentFilters());
                });
            });

            document.querySelectorAll('.favorite-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.favorite-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    const t = this.getAttribute('data-report');
                    document.querySelectorAll('.report-type-btn').forEach(b => b.classList.remove('active'));
                    const target = document.querySelector(`.report-type-btn[data-type="${t}"]`);
                    if (target) target.classList.add('active');
                    document.getElementById('reportContent').innerHTML = reportGenerator.generateReport(t, getCurrentFilters());
                });
            });

            document.querySelectorAll('.view-mode-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.view-mode-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    reportGenerator.viewMode = this.getAttribute('data-view');
                });
            });

            setInterval(updateStockNotifications, 30000);
            setInterval(autoDarkMode, 600000);

            advancedTensorFlowAnalyzer.loadModelFromDB().catch(() => {});

            console.log('%c✅ SmartStock AI v7.1 inicializado', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (APP_STATE.isMobile ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>