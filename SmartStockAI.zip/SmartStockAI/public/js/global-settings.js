(function () {
    'use strict';

    const colors = {
        blue: '#3a5ec7',
        green: '#28a745',
        red: '#dc3545',
        purple: '#6f42c1',
        orange: '#fd7e14',
        teal: '#20c997'
    };

    const routes = {
        dashboard: 'principal.php',
        admin: 'principal.php',
        inventario: 'inventario1.php',
        reportes: 'Reportes.php',
        transacciones: 'Trassanciones.php',
        ventas: 'Trassanciones.php',
        clientes: 'clientes.php',
        proveedores: 'proveedores.php',
        usuarios: 'usuarios.php',
        perfil: 'perfil.php',
        seguridad: 'seguridad.php',
        configuracion: 'configuracion.php'
    };

    function readSettings() {
        try {
            return JSON.parse(localStorage.getItem('globalSettings')) || {};
        } catch (error) {
            return {};
        }
    }

    function applySettings() {
        const settings = readSettings();
        const root = document.documentElement;
        const primary = colors[settings.themeColor] || colors.blue;
        const darkMode = settings.darkMode === true || localStorage.getItem('theme') === 'dark';
        const fontFamily = settings.fontFamily || "'Plus Jakarta Sans', 'Segoe UI', sans-serif";
        const transition = settings.enableAnimations === false ? 'none' : 'all 0.3s ease';

        root.style.setProperty('--primary', primary);
        root.style.setProperty('--primary-dark', primary);
        root.style.setProperty('--font-family', fontFamily);
        root.style.setProperty('--font-main', fontFamily);
        root.style.setProperty('--transition', transition);
        root.style.setProperty('--border-radius', settings.borderRadius || '12px');
        root.style.setProperty('--sidebar-opacity', String(parseInt(settings.sidebarOpacity || 100, 10) / 100));
        root.style.setProperty('--sidebar-bg', settings.sidebarTheme === 'dark'
            ? '#111827'
            : settings.sidebarTheme === 'light'
                ? '#ffffff'
                : primary);

        document.body.classList.toggle('dark-mode', darkMode);
        document.body.style.fontFamily = fontFamily;
        document.body.style.transition = transition;

        document.querySelectorAll('.system-name-display').forEach(element => {
            element.textContent = settings.systemName || 'SmartStock AI';
        });

        document.querySelectorAll('.sidebar').forEach(sidebar => {
            sidebar.style.opacity = String(parseInt(settings.sidebarOpacity || 100, 10) / 100);
        });

        if (settings.modules) {
            Object.keys(settings.modules).forEach(module => {
                document.querySelectorAll(`[data-module="${module}"]`).forEach(element => {
                    element.style.display = settings.modules[module] ? '' : 'none';
                });
            });
        }

        document.querySelectorAll('#themeToggle i, #themeToggleBtn i').forEach(icon => {
            icon.className = darkMode ? 'fas fa-sun' : 'fas fa-moon';
        });
    }

    function syncThemeToggle() {
        document.querySelectorAll('#themeToggle, #themeToggleBtn').forEach(button => {
            button.addEventListener('click', function () {
                window.setTimeout(function () {
                    const settings = readSettings();
                    settings.darkMode = document.body.classList.contains('dark-mode');
                    settings.autoDarkMode = 'disabled';
                    localStorage.setItem('globalSettings', JSON.stringify(settings));
                    localStorage.setItem('theme', settings.darkMode ? 'dark' : 'light');
                    applySettings();
                }, 0);
            }, true);
        });
    }

    function normalizePage(value) {
        return String(value || '')
            .trim()
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, '');
    }

    function syncNavigation() {
        document.querySelectorAll('a[href*="/admin.php"]').forEach(link => {
            link.href = routes.dashboard;
        });

        document.addEventListener('click', function (event) {
            const link = event.target.closest('a');
            if (!link) return;

            const page = normalizePage(link.dataset.page);
            const internalControl = link.id && [
                'dashboardLink', 'inventoryLink', 'suppliersLink', 'reportsLink',
                'viewAllNotifications', 'resendCode', 'backToStep1', 'backToStep2'
            ].includes(link.id);

            if (internalControl || !routes[page]) return;
            event.preventDefault();
            window.location.href = routes[page];
        });

        document.querySelectorAll('.sidebar a[href="#"]').forEach(link => {
            if (link.dataset.page || (link.id && link.id.endsWith('Link'))) return;
            const text = normalizePage(link.textContent);
            const page = Object.keys(routes).find(route => text.includes(route));
            if (page) link.dataset.page = page;
        });
    }

    window.SmartStockGlobalSettings = {
        read: readSettings,
        apply: applySettings
    };

    document.addEventListener('DOMContentLoaded', function () {
        applySettings();
        syncThemeToggle();
        syncNavigation();
    });

    window.addEventListener('storage', function (event) {
        if (event.key === 'globalSettings' || event.key === 'theme') {
            applySettings();
        }
    });
}());
