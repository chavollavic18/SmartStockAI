<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>Mi Perfil - SmartStock AI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>

    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --primary-light: rgba(58, 94, 199, 0.12);
            --secondary: #10b981;
            --secondary-light: rgba(16, 185, 129, 0.12);
            --dark: #0f172a;
            --light: #f8fafc;
            --gray: #64748b;
            --gray-light: #f1f5f9;
            --danger: #ef4444;
            --danger-light: rgba(239, 68, 68, 0.12);
            --warning: #f59e0b;
            --warning-light: rgba(245, 158, 11, 0.12);
            --info: #06b6d4;
            --info-light: rgba(6, 182, 212, 0.12);

            --bg: #f3f4f6;
            --card-bg: #ffffff;
            --card-border: #e2e8f0;
            --text-main: #1e293b;
            --text-muted: #64748b;

            --border-radius-sm: 8px;
            --border-radius: 16px;
            --border-radius-lg: 24px;
            --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            --sidebar-width: 270px;
            --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.02);
            --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
            --shadow-lg: 0 20px 35px -10px rgba(0, 0, 0, 0.12);
            --font-main: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;

            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }

        .dark-mode {
            --bg: #0b0f19;
            --card-bg: #151c2c;
            --card-border: #232d42;
            --text-main: #f1f5f9;
            --text-muted: #94a3b8;
            --gray-light: #1e293b;
            --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: var(--font-main); }

        html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }

        body {
            background-color: var(--bg);
            color: var(--text-main);
            transition: var(--transition);
            min-height: 100vh;
            min-height: 100dvh;
            overflow-x: hidden;
            -webkit-tap-highlight-color: transparent;
            -webkit-font-smoothing: antialiased;
        }

        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--gray); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary); }

        .app-container { display: flex; min-height: 100vh; min-height: 100dvh; }

        .sidebar-overlay {
            display: none; position: fixed; inset: 0;
            background: rgba(15, 23, 42, 0.55);
            backdrop-filter: blur(3px); -webkit-backdrop-filter: blur(3px);
            z-index: 1040; opacity: 0; transition: opacity 0.3s ease;
        }
        .sidebar-overlay.active { display: block; opacity: 1; }

        .sidebar {
            width: var(--sidebar-width);
            background: var(--sidebar-bg, linear-gradient(180deg, #1e293b 0%, #0f172a 100%));
            color: #ffffff;
            height: 100vh;
            height: 100dvh;
            position: fixed;
            left: 0; top: 0;
            padding: 24px 16px;
            padding-top: calc(24px + var(--safe-top));
            padding-bottom: calc(24px + var(--safe-bottom));
            transition: var(--transition);
            z-index: 1050;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 25px rgba(0,0,0,0.15);
            will-change: transform;
        }

        .sidebar-header {
            padding: 0 12px 24px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .logo {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -0.5px;
            background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }
        .logo span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: var(--transition);
            -webkit-text-fill-color: white;
            flex-shrink: 0;
        }

        .sidebar-close-btn {
            display: none;
            background: rgba(255,255,255,0.08);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            transition: var(--transition);
            flex-shrink: 0;
        }
        .sidebar-close-btn:hover { background: var(--danger); }

        .sidebar-nav-container { flex: 1; overflow-y: auto; padding-right: 4px; -webkit-overflow-scrolling: touch; }
        .menu-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #64748b;
            font-weight: 700;
            margin: 16px 12px 8px 12px;
        }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li { margin-bottom: 4px; }
        .sidebar-menu a {
            color: #94a3b8; text-decoration: none; padding: 12px 16px;
            display: flex; align-items: center; border-radius: var(--border-radius-sm);
            transition: var(--transition); font-weight: 500; font-size: 14px; cursor: pointer; gap: 12px;
            min-height: 44px;
            touch-action: manipulation;
        }
        .sidebar-menu a:hover { color: #ffffff; background: rgba(255, 255, 255, 0.06); transform: translateX(3px); }
        .sidebar-menu a.active { color: #ffffff; background: var(--primary); font-weight: 600; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); }
        .sidebar-menu i { font-size: 18px; width: 22px; text-align: center; flex-shrink: 0; }

        .sidebar-footer { padding-top: 16px; border-top: 1px solid rgba(255, 255, 255, 0.08); }
        .logout-btn {
            background: rgba(239, 68, 68, 0.1); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.2);
            width: 100%; padding: 12px 16px; border-radius: var(--border-radius-sm);
            display: flex; align-items: center; justify-content: center; gap: 10px;
            transition: var(--transition); cursor: pointer; font-weight: 600; font-size: 14px;
            min-height: 44px;
            touch-action: manipulation;
        }
        .logout-btn:hover { background: var(--danger); color: white; border-color: var(--danger); box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3); }

        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 30px;
            padding-top: calc(30px + var(--safe-top));
            padding-bottom: calc(30px + var(--safe-bottom));
            transition: var(--transition);
            min-width: 0;
            overflow-x: hidden;
        }

        .top-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px; background: var(--card-bg); padding: 16px 28px;
            border-radius: var(--border-radius); box-shadow: var(--shadow); border: 1px solid var(--card-border);
            gap: 16px;
            flex-wrap: wrap;
        }

        .user-profile-summary { display: flex; align-items: center; gap: 16px; min-width: 0; }
        .avatar-wrapper { position: relative; flex-shrink: 0; }
        .user-avatar {
            width: 50px; height: 50px; border-radius: 50%; background: var(--primary);
            color: white; display: flex; align-items: center; justify-content: center;
            font-size: 18px; font-weight: 700; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15); transition: var(--transition);
        }
        .status-indicator {
            width: 14px; height: 14px; background-color: var(--secondary);
            border: 2.5px solid var(--card-bg); border-radius: 50%; position: absolute; bottom: 0; right: 0;
        }
        .user-details { min-width: 0; }
        .user-details h5 { margin: 0; font-weight: 700; font-size: 16px; color: var(--text-main); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .user-details p { margin: 0; color: var(--text-muted); font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .user-badge {
            display: inline-block; padding: 2px 10px; border-radius: 20px;
            font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 4px;
        }
        .badge-admin { background: var(--warning-light); color: #d97706; }
        .badge-employee { background: var(--secondary-light); color: var(--secondary); }

        .header-controls { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
        .global-search { position: relative; width: 240px; }
        .global-search input {
            width: 100%; padding: 11px 40px 11px 16px; border: 1px solid var(--card-border);
            border-radius: 30px; background: var(--bg); color: var(--text-main); font-size: 16px; transition: var(--transition);
            min-height: 44px;
        }
        .global-search input:focus { outline: none; border-color: var(--primary); background: var(--card-bg); box-shadow: 0 0 0 4px var(--primary-light); }
        .global-search i { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-size: 14px; }

        .control-btn {
            width: 44px; height: 44px; border-radius: 50%; background: var(--bg);
            border: 1px solid var(--card-border); color: var(--text-main); display: flex;
            align-items: center; justify-content: center; cursor: pointer; transition: var(--transition); position: relative;
            flex-shrink: 0;
            touch-action: manipulation;
        }
        .control-btn:hover { background: var(--primary); color: white; border-color: var(--primary); transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .control-btn:active { transform: scale(0.95); }
        .btn-badge {
            position: absolute; top: -2px; right: -2px; background: var(--danger);
            color: white; font-size: 10px; font-weight: 700; width: 18px; height: 18px;
            border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid var(--card-bg);
        }

        .page-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 28px; padding-bottom: 16px; border-bottom: 1px solid var(--card-border);
            flex-wrap: wrap; gap: 15px;
        }
        .page-header h1 { font-size: 26px; font-weight: 700; display: flex; align-items: center; gap: 12px; }
        .page-header h1 i { color: var(--primary); font-size: 28px; }

        .header-actions { display: flex; gap: 12px; flex-wrap: wrap; }
        .btn {
            padding: 11px 20px; border: none; border-radius: 10px; cursor: pointer;
            font-weight: 600; font-size: 13px; display: inline-flex; align-items: center;
            gap: 8px; transition: all 0.2s;
            min-height: 44px;
            touch-action: manipulation;
            justify-content: center;
        }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(58,94,199,0.3); }
        .btn-outline { background: transparent; border: 1px solid var(--primary); color: var(--primary); }
        .btn-outline:hover { background: var(--primary); color: white; }
        .btn-secondary { background: var(--gray-light); color: var(--text-main); }
        .btn-secondary:hover { background: var(--gray); color: white; }
        .btn-success { background: var(--secondary); color: white; }
        .btn-success:hover { background: #05b587; transform: translateY(-2px); }
        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: #d13a5c; transform: translateY(-2px); }
        .btn-warning { background: var(--warning); color: #000; }
        .btn-sm { padding: 7px 12px; font-size: 12px; min-height: 36px; }
        .icon-btn {
            width: 44px; height: 44px; border-radius: 50%; border: none; cursor: pointer;
            background: var(--card-bg); color: var(--text-main); display: flex; align-items: center;
            justify-content: center; transition: var(--transition); box-shadow: var(--shadow-sm);
            flex-shrink: 0;
            touch-action: manipulation;
        }
        .icon-btn:hover { transform: translateY(-3px); box-shadow: var(--shadow); }

        .modal-overlay {
            position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5); display: none; justify-content: center;
            align-items: center; z-index: 2000; backdrop-filter: blur(5px);
            -webkit-backdrop-filter: blur(5px);
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
        }
        .modal-overlay.show { display: flex !important; }
        .modal {
            background: var(--card-bg); border-radius: 20px; padding: 32px;
            max-width: 600px; width: 90%; max-height: calc(100vh - 40px); max-height: calc(100dvh - 40px); overflow-y: auto;
            box-shadow: var(--shadow-lg); animation: modalSlideIn 0.3s ease;
            color: var(--text-main);
            -webkit-overflow-scrolling: touch;
        }
        @keyframes modalSlideIn {
            from { transform: translateY(-30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        .modal-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px;
        }
        .modal-header h2 { font-size: 22px; font-weight: 700; display: flex; align-items: center; gap: 10px; }
        .modal-close {
            background: none; border: none; font-size: 28px; cursor: pointer;
            color: var(--text-muted); transition: color 0.2s; width: 36px; height: 36px;
            display: flex; align-items: center; justify-content: center; border-radius: 8px;
            flex-shrink: 0;
            touch-action: manipulation;
        }
        .modal-close:hover { color: var(--danger); background: rgba(239,68,68,0.1); }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main); font-size: 13px; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 12px 16px; border: 1px solid var(--card-border);
            border-radius: 10px; font-size: 16px; transition: border-color 0.2s;
            font-family: inherit; background: var(--bg); color: var(--text-main);
            min-height: 44px;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            outline: none; border-color: var(--primary);
            box-shadow: 0 0 0 3px var(--primary-light);
        }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .modal-footer {
            display: flex; justify-content: flex-end; gap: 12px;
            margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--card-border);
            flex-wrap: wrap;
        }

        .profile-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            border-radius: 20px; padding: 32px; margin-bottom: 28px;
            color: white; position: relative; overflow: hidden;
        }
        .profile-header::before {
            content: ''; position: absolute; top: -50%; right: -10%;
            width: 400px; height: 400px;
            background: rgba(255,255,255,0.05); border-radius: 50%;
        }

        .profile-info { display: flex; align-items: center; gap: 28px; position: relative; z-index: 1; flex-wrap: wrap; }
        .profile-photo-container { position: relative; }
        .profile-photo {
            width: 130px; height: 130px; border-radius: 50%; border: 4px solid white;
            object-fit: cover; box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            background: rgba(255,255,255,0.2);
        }
        .photo-edit-btn {
            position: absolute; bottom: 5px; right: 5px; background: white;
            color: var(--primary); width: 40px; height: 40px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center; cursor: pointer;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2); border: 2px solid var(--primary);
            transition: all 0.2s;
            touch-action: manipulation;
        }
        .photo-edit-btn:hover { transform: scale(1.1); background: var(--primary); color: white; }

        .profile-details { min-width: 0; }
        .profile-details h2 { font-size: 28px; font-weight: 700; margin-bottom: 6px; }
        .profile-details .badge-role {
            display: inline-block; background: rgba(255,255,255,0.2);
            padding: 6px 16px; border-radius: 30px; font-size: 13px; font-weight: 600;
            margin-bottom: 12px; backdrop-filter: blur(10px);
        }
        .profile-details p { margin-bottom: 6px; font-size: 14px; opacity: 0.9; }
        .profile-details p i { width: 20px; margin-right: 8px; }

        .profile-stats {
            display: flex; gap: 30px; margin-left: auto;
            text-align: center; position: relative; z-index: 1;
        }
        .stat-item { text-align: center; }
        .stat-value { font-size: 32px; font-weight: 700; }
        .stat-label { font-size: 13px; opacity: 0.8; margin-top: 4px; }

        .completeness-bar { margin-top: 20px; position: relative; z-index: 1; }
        .completeness-bar-label { display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 6px; }
        .completeness-bar-track { height: 8px; background: rgba(255,255,255,0.2); border-radius: 4px; overflow: hidden; }
        .completeness-bar-fill { height: 100%; background: white; transition: width 0.5s ease; border-radius: 4px; }

        .profile-grid { display: grid; grid-template-columns: 1fr 1.5fr; gap: 24px; margin-bottom: 24px; }

        .card {
            background: var(--card-bg); border-radius: 20px; padding: 24px;
            box-shadow: var(--shadow-sm); border: 1px solid var(--card-border);
            margin-bottom: 24px; transition: var(--transition);
        }
        .card-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 20px; padding-bottom: 12px;
            border-bottom: 1px solid var(--card-border);
            flex-wrap: wrap; gap: 10px;
        }
        .card-header h3 { font-size: 18px; font-weight: 600; display: flex; align-items: center; gap: 10px; }
        .card-header h3 i { color: var(--primary); font-size: 20px; }

        .permission-category { margin-bottom: 20px; }
        .permission-category h4 {
            font-size: 15px; font-weight: 600; color: var(--text-muted);
            margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px;
        }
        .permission-list { list-style: none; padding: 0; }
        .permission-item {
            display: flex; align-items: center; padding: 10px 0;
            border-bottom: 1px solid var(--card-border);
            gap: 12px;
        }
        .permission-item:last-child { border-bottom: none; }
        .permission-icon {
            width: 32px; height: 32px; border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 14px;
            flex-shrink: 0;
        }
        .permission-icon.allowed { background: var(--secondary-light); color: var(--secondary); }
        .permission-icon.denied { background: var(--danger-light); color: var(--danger); }
        .permission-icon.limited { background: var(--warning-light); color: var(--warning); }
        .permission-content { flex: 1; min-width: 0; }
        .permission-name { font-weight: 600; font-size: 14px; margin-bottom: 2px; }
        .permission-desc { font-size: 12px; color: var(--text-muted); }
        .permission-status {
            font-size: 11px; font-weight: 600; padding: 4px 10px;
            border-radius: 20px; background: var(--gray-light); color: var(--text-main);
            white-space: nowrap;
        }
        .permission-status.allowed { background: var(--secondary); color: white; }
        .permission-status.denied { background: var(--danger); color: white; }
        .permission-status.limited { background: var(--warning); color: #000; }

        .performance-overview { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px; }
        .performance-card { background: var(--bg); border-radius: 16px; padding: 18px; text-align: center; }
        .performance-score { font-size: 42px; font-weight: 700; color: var(--primary); margin-bottom: 4px; }
        .performance-label { font-size: 13px; color: var(--text-muted); font-weight: 600; }
        .rating-stars { color: var(--warning); font-size: 16px; margin-top: 8px; }

        .metrics-list { margin-top: 16px; }
        .metric-item {
            display: flex; align-items: center; padding: 12px 0;
            border-bottom: 1px solid var(--card-border);
        }
        .metric-item:last-child { border-bottom: none; }
        .metric-info { flex: 1; min-width: 0; }
        .metric-name { font-weight: 600; font-size: 14px; margin-bottom: 2px; }
        .metric-progress { display: flex; align-items: center; gap: 12px; margin-top: 6px; }
        .progress-bar-container { flex: 1; height: 6px; background: var(--gray-light); border-radius: 3px; overflow: hidden; }
        .progress-bar-fill { height: 100%; border-radius: 3px; background: var(--primary); transition: width 0.5s; }
        .metric-value { font-weight: 600; font-size: 14px; min-width: 45px; }

        .announcement-form { background: var(--primary-light); border-radius: 16px; padding: 20px; margin-bottom: 24px; }
        .dark-mode .announcement-form { background: rgba(58,94,199,0.1); }
        .announcement-form textarea {
            width: 100%; border: 1px solid var(--card-border); border-radius: 12px;
            padding: 14px; font-size: 16px; resize: vertical; min-height: 100px;
            background: var(--card-bg); margin-bottom: 12px; color: var(--text-main);
        }
        .announcement-form textarea:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-light); }
        .form-actions { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        .visibility-selector { display: flex; gap: 8px; flex-wrap: wrap; }
        .visibility-btn {
            padding: 8px 14px; border: 1px solid var(--card-border);
            border-radius: 20px; background: var(--card-bg); cursor: pointer;
            font-size: 12px; font-weight: 600; transition: all 0.2s; color: var(--text-main);
            min-height: 36px;
            touch-action: manipulation;
        }
        .visibility-btn.active { background: var(--primary); color: white; border-color: var(--primary); }

        .announcements-list { max-height: 500px; overflow-y: auto; -webkit-overflow-scrolling: touch; }
        .announcement-item { padding: 20px; border-bottom: 1px solid var(--card-border); transition: background 0.2s; }
        .announcement-item:hover { background: var(--bg); }
        .announcement-header { display: flex; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 10px; }
        .announcer-avatar { width: 48px; height: 48px; border-radius: 50%; margin-right: 14px; object-fit: cover; flex-shrink: 0; }
        .announcer-info { flex: 1; min-width: 0; }
        .announcer-name { font-weight: 700; font-size: 15px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .badge-manager { background: var(--warning); color: #000; font-size: 10px; padding: 3px 8px; border-radius: 20px; font-weight: 600; }
        .badge-hr { background: var(--info); color: white; font-size: 10px; padding: 3px 8px; border-radius: 20px; font-weight: 600; }
        .announcement-time { font-size: 11px; color: var(--text-muted); margin-top: 2px; }
        .announcement-visibility {
            font-size: 11px; padding: 3px 10px;
            border-radius: 20px; background: var(--gray-light); color: var(--text-main);
            white-space: nowrap;
        }
        .announcement-content {
            margin-left: 62px; padding: 12px 16px;
            background: var(--bg); border-radius: 16px;
            font-size: 14px; line-height: 1.7;
            word-wrap: break-word;
        }
        .announcement-content i { color: var(--primary); margin-right: 8px; }
        .announcement-actions { margin-left: 62px; margin-top: 8px; display: flex; gap: 6px; flex-wrap: wrap; }
        .rating-badge {
            display: inline-flex; align-items: center; gap: 4px;
            background: var(--warning); color: #000; padding: 4px 10px;
            border-radius: 20px; font-size: 12px; font-weight: 600; margin-left: 10px;
        }

        .tab-container { margin-bottom: 24px; }
        .tab-buttons {
            display: flex; gap: 8px; background: var(--gray-light);
            padding: 5px; border-radius: 40px; overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
            scroll-snap-type: x proximity;
        }
        .tab-buttons::-webkit-scrollbar { display: none; }
        .tab-btn {
            padding: 11px 20px; border: none; background: transparent;
            border-radius: 30px; cursor: pointer; font-weight: 600;
            font-size: 13px; color: var(--text-muted); transition: all 0.2s;
            white-space: nowrap;
            flex-shrink: 0;
            scroll-snap-align: start;
            min-height: 44px;
            touch-action: manipulation;
        }
        .tab-btn.active { background: var(--primary); color: white; }
        .tab-btn:hover:not(.active) { background: var(--primary-light); color: var(--primary); }

        .password-strength { margin-top: 8px; height: 6px; background: var(--gray-light); border-radius: 3px; overflow: hidden; }
        .password-strength-fill { height: 100%; transition: all 0.3s; border-radius: 3px; }
        .strength-weak { background: var(--danger); width: 33%; }
        .strength-medium { background: var(--warning); width: 66%; }
        .strength-strong { background: var(--secondary); width: 100%; }

        .session-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 15px; background: var(--bg); border-radius: 12px;
            margin-bottom: 10px; flex-wrap: wrap; gap: 10px;
        }
        .session-info { flex: 1; min-width: 0; }
        .session-device { font-weight: 600; margin-bottom: 4px; }
        .session-meta { font-size: 12px; color: var(--text-muted); }
        .session-current { background: var(--secondary-light); color: var(--secondary); padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }

        .preference-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 15px 0; border-bottom: 1px solid var(--card-border);
            flex-wrap: wrap; gap: 10px;
        }
        .preference-item:last-child { border-bottom: none; }
        .preference-info { flex: 1; min-width: 200px; }
        .preference-title { font-weight: 600; margin-bottom: 3px; }
        .preference-desc { font-size: 13px; color: var(--text-muted); }

        .switch { position: relative; display: inline-block; width: 52px; height: 26px; flex-shrink: 0; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 26px; }
        .slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: var(--primary); }
        input:checked + .slider:before { transform: translateX(26px); }

        .documents-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 15px; }
        .document-card {
            background: var(--bg); border-radius: 12px; padding: 20px;
            text-align: center; transition: var(--transition);
            position: relative; cursor: pointer;
        }
        .document-card:hover { transform: translateY(-5px); box-shadow: var(--shadow); }
        .document-icon { font-size: 40px; margin-bottom: 12px; }
        .document-icon.pdf { color: var(--danger); }
        .document-icon.img { color: var(--info); }
        .document-icon.doc { color: var(--primary); }
        .document-name { font-weight: 600; margin-bottom: 6px; word-break: break-word; }
        .document-meta { font-size: 12px; color: var(--text-muted); }
        .document-delete {
            position: absolute; top: 8px; right: 8px; background: var(--danger); color: white;
            border: none; width: 32px; height: 32px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; font-size: 12px; opacity: 0; transition: var(--transition);
            touch-action: manipulation;
        }
        .document-card:hover .document-delete { opacity: 1; }

        .achievement-badge {
            display: flex; align-items: center; gap: 12px;
            padding: 14px; background: var(--bg); border-radius: 12px;
            margin-bottom: 10px; transition: var(--transition);
        }
        .achievement-badge:hover { transform: translateX(5px); }
        .achievement-badge.locked { opacity: 0.5; filter: grayscale(1); }
        .achievement-icon {
            width: 44px; height: 44px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px; flex-shrink: 0;
        }

        .timeline { position: relative; padding: 10px 0; }
        .timeline::before {
            content: ''; position: absolute; left: 20px; top: 0; bottom: 0;
            width: 2px; background: var(--primary); opacity: 0.3;
        }
        .timeline-item { position: relative; padding-left: 55px; margin-bottom: 20px; }
        .timeline-marker {
            position: absolute; left: 12px; width: 18px; height: 18px;
            border-radius: 50%; background: var(--primary);
            border: 3px solid var(--card-bg); z-index: 1;
        }
        .timeline-content { background: var(--bg); padding: 12px 16px; border-radius: 12px; }
        .timeline-title { font-weight: 600; margin-bottom: 3px; font-size: 14px; }
        .timeline-date { font-size: 12px; color: var(--text-muted); }

        .toast-container {
            position: fixed; bottom: calc(20px + var(--safe-bottom)); right: calc(20px + var(--safe-right));
            left: 20px;
            z-index: 3000;
            display: flex; flex-direction: column; gap: 10px;
            pointer-events: none;
            align-items: flex-end;
        }
        .toast {
            min-width: 280px; max-width: 400px; background: var(--card-bg); border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.15); overflow: hidden;
            display: flex; align-items: center; padding: 14px 16px;
            gap: 12px; animation: slideIn 0.3s ease; color: var(--text-main);
            pointer-events: auto;
        }
        .toast.success { border-left: 4px solid var(--secondary); }
        .toast.error { border-left: 4px solid var(--danger); }
        .toast.warning { border-left: 4px solid var(--warning); }
        .toast.info { border-left: 4px solid var(--info); }
        .toast i { font-size: 20px; flex-shrink: 0; }
        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        .toast.info i { color: var(--info); }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        .empty-state { text-align: center; padding: 40px; color: var(--text-muted); }
        .empty-state i { font-size: 48px; margin-bottom: 15px; opacity: 0.5; }

        .text-success { color: var(--secondary) !important; }
        .text-warning { color: var(--warning) !important; }
        .text-danger { color: var(--danger) !important; }
        .text-primary { color: var(--primary) !important; }
        .text-muted { color: var(--text-muted) !important; }
        .mt-3 { margin-top: 16px; }
        .mb-3 { margin-bottom: 16px; }
        .w-100 { width: 100%; }

        .badge-info { background: var(--info); color: white; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .badge-success { background: var(--secondary); color: white; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .badge-warning { background: var(--warning); color: #000; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }

        /* ✅ CORREGIDO: Botón móvil con pointer-events explícito */
        .mobile-nav-toggle {
            display: none; 
            position: fixed;
            bottom: calc(20px + var(--safe-bottom));
            right: calc(20px + var(--safe-right));
            width: 56px; 
            height: 56px; 
            border-radius: 50%; 
            background: var(--primary);
            color: white; 
            border: none; 
            box-shadow: var(--shadow-lg);
            z-index: 1100; 
            align-items: center; 
            justify-content: center;
            font-size: 22px; 
            cursor: pointer;
            touch-action: manipulation;
            transition: var(--transition);
            pointer-events: auto;
        }
        .mobile-nav-toggle:active { transform: scale(0.92); }

        @media (max-width: 1200px) {
            .profile-grid { grid-template-columns: 1fr; }
            .profile-stats { display: none; }
        }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); width: var(--sidebar-width); }
            .sidebar.mobile-open { transform: translateX(0); }
            .sidebar-close-btn { display: flex; }

            .main-content {
                margin-left: 0;
                padding: 20px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .mobile-nav-toggle { display: flex; }

            .top-header { flex-direction: column; align-items: stretch; gap: 16px; padding: 16px 20px; }
            .header-controls { justify-content: space-between; flex-wrap: wrap; }
            .global-search { order: -1; width: 100%; }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 16px;
                padding-top: calc(16px + var(--safe-top));
                padding-bottom: calc(90px + var(--safe-bottom));
            }

            .sidebar { width: 88vw; max-width: 320px; padding: 20px 12px; padding-top: calc(20px + var(--safe-top)); padding-bottom: calc(20px + var(--safe-bottom)); }

            .top-header { padding: 14px 16px; border-radius: var(--border-radius-sm); gap: 12px; }
            .user-avatar { width: 44px; height: 44px; font-size: 16px; }
            .user-details h5 { font-size: 14px; }
            .user-details p { font-size: 12px; }
            .control-btn { width: 40px; height: 40px; font-size: 14px; }
            .global-search input { font-size: 16px; min-height: 42px; padding: 10px 38px 10px 14px; }

            .page-header { flex-direction: column; align-items: stretch; gap: 12px; padding-bottom: 12px; margin-bottom: 18px; }
            .page-header h1 { font-size: 20px; gap: 8px; }
            .page-header h1 i { font-size: 22px; }
            .header-actions { width: 100%; justify-content: space-between; }
            .header-actions .btn { flex: 1; min-width: 0; padding: 10px 12px; font-size: 12px; }
            .header-actions .icon-btn { flex-shrink: 0; }

            .profile-header { padding: 24px 18px; border-radius: var(--border-radius-sm); margin-bottom: 18px; }
            .profile-info { flex-direction: column; text-align: center; gap: 16px; }
            .profile-photo { width: 100px; height: 100px; }
            .photo-edit-btn { width: 36px; height: 36px; }
            .profile-details h2 { font-size: 22px; }
            .profile-details .badge-role { font-size: 12px; padding: 5px 14px; }
            .profile-details p { font-size: 13px; }
            .completeness-bar-label { font-size: 12px; }

            .tab-container { margin-bottom: 18px; }
            .tab-buttons { padding: 4px; gap: 6px; }
            .tab-btn { padding: 9px 16px; font-size: 12px; }
            .tab-btn i { font-size: 12px; margin-right: 4px; }

            .card { padding: 18px; border-radius: var(--border-radius-sm); margin-bottom: 18px; }
            .card-header { margin-bottom: 16px; padding-bottom: 10px; }
            .card-header h3 { font-size: 15px; }
            .card-header h3 i { font-size: 17px; }

            .profile-grid { grid-template-columns: 1fr; gap: 16px; margin-bottom: 18px; }

            .performance-overview { grid-template-columns: repeat(3, 1fr); gap: 8px; }
            .performance-card { padding: 12px 8px; border-radius: 10px; }
            .performance-score { font-size: 24px; }
            .performance-label { font-size: 10px; }

            .permission-item { flex-wrap: wrap; gap: 8px; }
            .permission-status { margin-left: auto; }

            .form-row { grid-template-columns: 1fr; gap: 12px; }

            .announcement-item { padding: 16px; }
            .announcer-avatar { width: 40px; height: 40px; margin-right: 10px; }
            .announcer-name { font-size: 13px; }
            .announcement-content { margin-left: 0; padding: 12px 14px; font-size: 13px; }
            .announcement-actions { margin-left: 0; }
            .announcement-header { gap: 8px; }
            .announcement-visibility { font-size: 10px; }

            .session-item { flex-direction: column; align-items: flex-start; padding: 12px; }
            .session-item .btn { width: 100%; }

            .preference-item { flex-direction: column; align-items: flex-start; padding: 12px 0; }
            .switch { align-self: flex-end; }

            .documents-grid { grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; }
            .document-card { padding: 16px; }
            .document-icon { font-size: 32px; }
            .document-name { font-size: 13px; }
            .document-delete { opacity: 1; width: 28px; height: 28px; }

            .achievement-badge { padding: 12px; }
            .achievement-icon { width: 38px; height: 38px; font-size: 17px; }

            .timeline-item { padding-left: 42px; margin-bottom: 16px; }
            .timeline-marker { left: 5px; width: 16px; height: 16px; }
            .timeline-title { font-size: 13px; }

            .modal-overlay { padding: 0; padding-top: calc(40px + var(--safe-top)); align-items: flex-end; }
            .modal { max-width: 100%; width: 100%; padding: 22px 20px; border-radius: 20px 20px 0 0; max-height: calc(100dvh - 40px); }
            .modal-header { margin-bottom: 18px; }
            .modal-header h2 { font-size: 18px; }
            .modal-footer { flex-direction: column-reverse; gap: 8px; }
            .modal-footer .btn { width: 100%; }

            .toast-container { top: calc(12px + var(--safe-top)); bottom: auto; right: 12px; left: 12px; align-items: stretch; }
            .toast { min-width: 0; max-width: 100%; width: 100%; padding: 12px 14px; font-size: 13px; }

            .empty-state { padding: 30px 16px; }
            .empty-state i { font-size: 40px; }
        }

        @media (max-width: 380px) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); padding-bottom: calc(80px + var(--safe-bottom)); }
            .page-header h1 { font-size: 17px; }
            .profile-details h2 { font-size: 18px; }
            .performance-score { font-size: 20px; }
            .tab-btn { padding: 8px 12px; font-size: 11px; }
            .card-header h3 { font-size: 14px; }
            .btn { padding: 10px 14px; font-size: 12px; }
            .documents-grid { grid-template-columns: 1fr; }
        }

        @media (max-height: 500px) and (orientation: landscape) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); }
            .top-header { padding: 10px 16px; margin-bottom: 12px; }
            .profile-header { padding: 16px; }
            .profile-info { flex-direction: row; }
            .profile-photo { width: 70px; height: 70px; }
            .performance-overview { grid-template-columns: repeat(3, 1fr); }
            .sidebar { padding: 16px 12px; padding-top: calc(16px + var(--safe-top)); }
            .modal { max-height: 95dvh; }
        }

        @media (min-width: 1440px) {
            .main-content { padding: 40px; }
            .profile-grid { grid-template-columns: 1fr 1.5fr; }
        }
        @media (min-width: 1920px) {
            .main-content { padding: 48px 60px; max-width: 1800px; margin-left: auto; margin-right: auto; }
        }

        @media (hover: none) {
            .control-btn:hover { transform: none; background: var(--bg); color: var(--text-main); border-color: var(--card-border); box-shadow: none; }
            .btn:hover { transform: none; box-shadow: none; }
            .btn-primary:hover { background: var(--primary); }
            .btn-outline:hover { background: transparent; color: var(--primary); }
            .btn-success:hover { background: var(--secondary); }
            .btn-danger:hover { background: var(--danger); }
            .icon-btn:hover { transform: none; box-shadow: var(--shadow-sm); }
            .photo-edit-btn:hover { transform: none; background: white; color: var(--primary); }
            .card:hover { box-shadow: var(--shadow-sm); }
            .document-card:hover { transform: none; box-shadow: none; }
            .achievement-badge:hover { transform: none; }
            .sidebar-menu a:hover { transform: none; background: transparent; }
            .sidebar-menu a.active:hover { background: var(--primary); }
            .modal-close:hover { background: none; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        @media print {
            .sidebar, .top-header, .mobile-nav-toggle, .header-actions,
            .tab-container, .modal-overlay, .toast-container,
            .photo-edit-btn, .document-delete, .btn, .icon-btn { display: none !important; }
            .main-content { margin-left: 0 !important; padding: 0 !important; }
            .profile-header { color: #000; background: #f0f0f0 !important; }
            .profile-header::before { display: none; }
            .profile-details h2, .profile-details p, .profile-details .badge-role, .stat-value, .stat-label { color: #000 !important; }
            .card { box-shadow: none; border: 1px solid #ddd; page-break-inside: avoid; }
            .tab-content { display: block !important; }
            .tab-content[style*="display: none"] { display: block !important; }
        }
    </style>
</head>
<body>

    <div class="app-container">

        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-brain"></i></div>
                    <span class="system-name-display">SmartStock AI</span>
                </div>
                <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a data-page="admin"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                    <li><a data-page="inventario"><i class="fas fa-boxes-stacked"></i> Inventario</a></li>
                    <li><a data-page="Transacciones"><i class="fas fa-right-left"></i> Transacciones</a></li>
                    <li><a data-page="Reportes"><i class="fas fa-chart-column"></i> Reportes</a></li>
                </ul>

                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a data-page="clientes"><i class="fas fa-address-book"></i> Clientes</a></li>
                    <li><a data-page="proveedores"><i class="fas fa-truck-field"></i> Proveedores</a></li>
                </ul>

                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a data-page="usuarios"><i class="fas fa-users-gear"></i> Usuarios</a></li>
                    <li><a data-page="seguridad"><i class="fas fa-shield-halved"></i> Seguridad</a></li>
                    <li><a data-page="perfil" class="active"><i class="fas fa-circle-user"></i> Mi Perfil</a></li>
                    <li><a data-page="configuracion"><i class="fas fa-sliders"></i> Configuración</a></li>
                </ul>
            </div>

            <div class="sidebar-footer">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    <span>Cerrar Sesión</span>
                </button>
            </div>
        </aside>

        <main class="main-content">

            <header class="top-header">
                <div class="user-profile-summary">
                    <div class="avatar-wrapper">
                        <div class="user-avatar" id="userAvatar"></div>
                        <div class="status-indicator"></div>
                    </div>
                    <div class="user-details">
                        <h5 id="userName"></h5>
                        <p id="userEmail"></p>
                        <span class="user-badge" id="userRoleBadge"></span>
                    </div>
                </div>

                <div class="header-controls">
                    <div class="global-search">
                        <input type="text" id="globalSearchInput" placeholder="Buscar en el sistema...">
                        <i class="fas fa-magnifying-glass"></i>
                    </div>

                    <button class="control-btn" id="themeToggleBtn" title="Cambiar Tema Visual">
                        <i class="fas fa-moon"></i>
                    </button>

                    <button class="control-btn" id="notificationsBtn" title="Notificaciones">
                        <i class="fas fa-bell"></i>
                        <span class="btn-badge" id="notifBadge">3</span>
                    </button>
                </div>
            </header>

            <div class="page-header">
                <h1><i class="fas fa-user-circle"></i> Mi Perfil</h1>
                <div class="header-actions">
                    <button class="icon-btn" id="shortcutsBtn" title="Atajos de teclado"><i class="fas fa-keyboard"></i></button>
                    <button class="btn btn-outline" id="importProfileBtn"><i class="fas fa-upload"></i><span>Importar</span></button>
                    <button class="btn btn-outline" id="exportProfileBtn"><i class="fas fa-download"></i><span>Exportar</span></button>
                    <button class="btn btn-primary" id="editProfileBtn"><i class="fas fa-edit"></i><span>Editar</span></button>
                </div>
            </div>

            <div class="profile-header">
                <div class="profile-info">
                    <div class="profile-photo-container">
                        <img src="https://ui-avatars.com/api/?name=User&size=130&background=3a5ec7&color=fff&bold=true" alt="Foto de perfil" class="profile-photo" id="profilePhoto">
                        <div class="photo-edit-btn" id="changePhotoBtn" title="Cambiar foto">
                            <i class="fas fa-camera"></i>
                        </div>
                    </div>
                    <div class="profile-details">
                        <h2 id="profileName">— Sin nombre —</h2>
                        <span class="badge-role" id="profileRole"><i class="fas fa-briefcase"></i> Sin cargo</span>
                        <p><i class="fas fa-envelope"></i> <span id="profileEmail">—</span></p>
                        <p><i class="fas fa-phone"></i> <span id="profilePhone">—</span></p>
                        <p><i class="fas fa-building"></i> Departamento: <span id="profileDepartment">—</span></p>
                        <p><i class="fas fa-calendar-alt"></i> Ingreso: <span id="profileJoinDate">—</span></p>
                        <p><i class="fas fa-user-tie"></i> Reporta a: <span id="profileManager">—</span></p>
                    </div>
                    <div class="profile-stats">
                        <div class="stat-item">
                            <div class="stat-value" id="statRating">0.0</div>
                            <div class="stat-label">Calificación</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value" id="statSales">0</div>
                            <div class="stat-label">Ventas</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value" id="statAttendance">0%</div>
                            <div class="stat-label">Asistencia</div>
                        </div>
                    </div>
                </div>
                <div class="completeness-bar">
                    <div class="completeness-bar-label">
                        <span><i class="fas fa-check-circle"></i> Completitud del perfil</span>
                        <span id="completenessText">0%</span>
                    </div>
                    <div class="completeness-bar-track">
                        <div class="completeness-bar-fill" id="completenessFill" style="width: 0%"></div>
                    </div>
                </div>
            </div>

            <div class="tab-container">
                <div class="tab-buttons">
                    <button class="tab-btn active" data-tab="overview"><i class="fas fa-user"></i> Resumen</button>
                    <button class="tab-btn" data-tab="permissions"><i class="fas fa-shield-alt"></i> Permisos</button>
                    <button class="tab-btn" data-tab="performance"><i class="fas fa-chart-line"></i> Desempeño</button>
                    <button class="tab-btn" data-tab="documents"><i class="fas fa-file"></i> Documentos</button>
                    <button class="tab-btn" data-tab="security"><i class="fas fa-lock"></i> Seguridad</button>
                    <button class="tab-btn" data-tab="preferences"><i class="fas fa-sliders-h"></i> Preferencias</button>
                    <button class="tab-btn" data-tab="announcements"><i class="fas fa-bullhorn"></i> Anuncios</button>
                    <button class="tab-btn" data-tab="activity"><i class="fas fa-history"></i> Actividad</button>
                </div>
            </div>

            <div class="tab-content active" id="tab-overview">
                <div class="profile-grid">
                    <div>
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-info-circle"></i> Información Personal</h3>
                                <button class="btn btn-sm btn-outline" id="editPersonalInfoBtn"><i class="fas fa-pencil-alt"></i> Editar</button>
                            </div>
                            <div style="display: grid; gap: 16px;" id="personalInfoContainer">
                                <div><strong>Nombre Completo:</strong> <span id="fullName">— Sin información —</span></div>
                                <div><strong>Email Corporativo:</strong> <span id="corpEmail">—</span></div>
                                <div><strong>Teléfono:</strong> <span id="personalPhone">—</span></div>
                                <div><strong>Fecha de Nacimiento:</strong> <span id="birthDate">—</span></div>
                                <div><strong>Dirección:</strong> <span id="address">—</span></div>
                                <div><strong>NSS:</strong> <span id="nss">—</span></div>
                                <div><strong>RFC:</strong> <span id="rfc">—</span></div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-shield-alt"></i> Resumen de Permisos</h3>
                            </div>
                            <div style="display: grid; gap: 8px;">
                                <div style="display: flex; align-items: center; gap: 10px; padding: 8px 0;">
                                    <i class="fas fa-check-circle text-success" style="font-size: 18px;"></i>
                                    <span><strong id="allowedCount">0 permisos concedidos</strong></span>
                                </div>
                                <div style="display: flex; align-items: center; gap: 10px; padding: 8px 0;">
                                    <i class="fas fa-clock text-warning" style="font-size: 18px;"></i>
                                    <span><strong id="limitedCount">0 permisos limitados</strong></span>
                                </div>
                                <div style="display: flex; align-items: center; gap: 10px; padding: 8px 0;">
                                    <i class="fas fa-times-circle text-danger" style="font-size: 18px;"></i>
                                    <span><strong id="deniedCount">0 permisos denegados</strong></span>
                                </div>
                            </div>
                            <button class="btn btn-outline w-100 mt-3" onclick="switchTab('permissions')">
                                <i class="fas fa-arrow-right"></i> Ver todos los permisos
                            </button>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-medal"></i> Logros Desbloqueados</h3>
                            </div>
                            <div id="achievementsList"></div>
                        </div>
                    </div>

                    <div>
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-chart-bar"></i> Desempeño Reciente</h3>
                            </div>
                            <div class="performance-overview" style="margin-top: 20px;">
                                <div class="performance-card">
                                    <div class="performance-score" id="complianceScore">0%</div>
                                    <div class="performance-label">Cumplimiento</div>
                                </div>
                                <div class="performance-card">
                                    <div class="performance-score" id="ratingScore">0.0</div>
                                    <div class="performance-label">Calificación</div>
                                </div>
                                <div class="performance-card">
                                    <div class="performance-score" id="vsTargetScore">+0%</div>
                                    <div class="performance-label">vs Meta</div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-bullhorn"></i> Últimos Anuncios</h3>
                            </div>
                            <div id="recentAnnouncements">
                                <div class="empty-state">
                                    <i class="fas fa-bullhorn"></i>
                                    <p>No hay anuncios disponibles</p>
                                </div>
                            </div>
                            <button class="btn btn-outline w-100 mt-3" onclick="switchTab('announcements')">
                                <i class="fas fa-arrow-right"></i> Ver todos los anuncios
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-content" id="tab-permissions" style="display: none;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-lock"></i> Permisos del Sistema</h3>
                    </div>
                    <div id="permissionsList"></div>
                </div>
            </div>

            <div class="tab-content" id="tab-performance" style="display: none;">
                <div class="profile-grid">
                    <div>
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-trophy"></i> Evaluación General</h3>
                            </div>
                            <div style="text-align: center; padding: 20px;">
                                <div style="font-size: 72px; font-weight: 700; color: var(--primary);" id="overallRating">0.0</div>
                                <div class="rating-stars" style="font-size: 24px; margin-bottom: 16px;" id="overallStars">☆☆☆☆☆</div>
                                <p style="color: var(--text-muted);" id="overallComment">Sin evaluaciones registradas</p>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-clipboard-check"></i> Evaluaciones Recientes</h3>
                            </div>
                            <div id="recentEvaluations">
                                <div class="empty-state"><i class="fas fa-clipboard"></i><p>Sin evaluaciones</p></div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-chart-line"></i> Métricas de Desempeño</h3>
                            </div>
                            <div id="performanceMetrics"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-content" id="tab-documents" style="display: none;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-file"></i> Mis Documentos</h3>
                        <button class="btn btn-primary btn-sm" id="uploadDocBtn"><i class="fas fa-upload"></i> Subir Documento</button>
                    </div>
                    <div class="documents-grid" id="documentsGrid">
                        <div class="empty-state" style="grid-column: 1 / -1;">
                            <i class="fas fa-folder-open"></i>
                            <p>No hay documentos subidos</p>
                            <button class="btn btn-primary btn-sm mt-3" onclick="document.getElementById('uploadDocBtn').click()">
                                <i class="fas fa-upload"></i> Subir primer documento
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-content" id="tab-security" style="display: none;">
                <div class="profile-grid">
                    <div>
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-key"></i> Cambiar Contraseña</h3>
                            </div>
                            <form id="changePasswordForm">
                                <div class="form-group">
                                    <label for="currentPassword">Contraseña Actual</label>
                                    <input type="password" id="currentPassword" required>
                                </div>
                                <div class="form-group">
                                    <label for="newPassword">Nueva Contraseña</label>
                                    <input type="password" id="newPassword" required minlength="6">
                                    <div class="password-strength">
                                        <div class="password-strength-fill" id="passwordStrengthFill" style="width: 0%"></div>
                                    </div>
                                    <small id="passwordStrengthText" style="color: var(--text-muted); font-size: 12px; margin-top: 5px; display: block;">Ingresa una contraseña</small>
                                </div>
                                <div class="form-group">
                                    <label for="confirmPassword">Confirmar Nueva Contraseña</label>
                                    <input type="password" id="confirmPassword" required minlength="6">
                                </div>
                                <button type="submit" class="btn btn-primary w-100"><i class="fas fa-save"></i> Actualizar Contraseña</button>
                            </form>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-shield-alt"></i> Autenticación en 2 Pasos</h3>
                            </div>
                            <div class="preference-item">
                                <div class="preference-info">
                                    <div class="preference-title">Activar 2FA</div>
                                    <div class="preference-desc">Añade una capa extra de seguridad a tu cuenta</div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="twoFactorToggle">
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <div id="twoFactorSetup" style="display: none; margin-top: 15px; padding: 15px; background: var(--bg); border-radius: 12px;">
                                <p style="margin-bottom: 12px;"><strong>Código QR:</strong> Escanea con tu app autenticadora</p>
                                <div style="background: white; padding: 15px; border-radius: 10px; text-align: center; margin-bottom: 12px;">
                                    <i class="fas fa-qrcode" style="font-size: 80px; color: #333;"></i>
                                </div>
                                <p style="font-size: 12px; color: var(--text-muted);">Clave secreta: <code style="background: var(--gray-light); padding: 2px 6px; border-radius: 4px;">JBSWY3DPEHPK3PXP</code></p>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-desktop"></i> Sesiones Activas</h3>
                                <button class="btn btn-sm btn-danger" id="closeAllSessionsBtn"><i class="fas fa-sign-out-alt"></i> Cerrar todas</button>
                            </div>
                            <div id="sessionsList"></div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-history"></i> Historial de Accesos</h3>
                            </div>
                            <div id="loginHistory"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-content" id="tab-preferences" style="display: none;">
                <div class="profile-grid">
                    <div>
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-bell"></i> Notificaciones</h3>
                            </div>
                            <div class="preference-item">
                                <div class="preference-info">
                                    <div class="preference-title">Notificaciones por Email</div>
                                    <div class="preference-desc">Recibe actualizaciones por correo</div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="prefEmailNotifications" checked>
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <div class="preference-item">
                                <div class="preference-info">
                                    <div class="preference-title">Notificaciones Push</div>
                                    <div class="preference-desc">Recibe alertas en el navegador</div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="prefPushNotifications">
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <div class="preference-item">
                                <div class="preference-info">
                                    <div class="preference-title">Resumen Semanal</div>
                                    <div class="preference-desc">Recibe un resumen de tu desempeño cada semana</div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="prefWeeklySummary" checked>
                                    <span class="slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-globe"></i> Idioma y Región</h3>
                            </div>
                            <div class="form-group">
                                <label for="prefLanguage">Idioma</label>
                                <select id="prefLanguage">
                                    <option value="es" selected>Español</option>
                                    <option value="en">English</option>
                                    <option value="pt">Português</option>
                                    <option value="fr">Français</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="prefTimezone">Zona Horaria</label>
                                <select id="prefTimezone">
                                    <option value="America/Mexico_City" selected>Ciudad de México (GMT-6)</option>
                                    <option value="America/New_York">Nueva York (GMT-5)</option>
                                    <option value="America/Los_Angeles">Los Ángeles (GMT-8)</option>
                                    <option value="Europe/Madrid">Madrid (GMT+1)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="prefDateFormat">Formato de Fecha</label>
                                <select id="prefDateFormat">
                                    <option value="DD/MM/YYYY" selected>DD/MM/YYYY</option>
                                    <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                                    <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                                </select>
                            </div>
                            <button class="btn btn-primary w-100" id="savePreferencesBtn"><i class="fas fa-save"></i> Guardar Preferencias</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-content" id="tab-announcements" style="display: none;">
                <div class="announcement-form" id="announcementForm">
                    <h4 style="margin-bottom: 16px; font-size: 16px;"><i class="fas fa-pen"></i> Dejar un anuncio o comentario</h4>
                    <textarea id="announcementText" placeholder="Escribe un anuncio, comentario o retroalimentación..."></textarea>
                    <div class="form-actions">
                        <div class="visibility-selector">
                            <button class="visibility-btn active" data-visibility="public"><i class="fas fa-globe"></i> Público</button>
                            <button class="visibility-btn" data-visibility="manager"><i class="fas fa-user-tie"></i> Solo Jefes</button>
                            <button class="visibility-btn" data-visibility="private"><i class="fas fa-lock"></i> Privado</button>
                        </div>
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <select id="ratingSelect" style="padding: 8px 12px; border-radius: 20px; border: 1px solid var(--card-border); background: var(--card-bg); color: var(--text-main); min-height: 44px; font-size: 14px;">
                                <option value="">Sin calificación</option>
                                <option value="5">⭐⭐⭐⭐⭐ Excelente</option>
                                <option value="4">⭐⭐⭐⭐ Muy Bueno</option>
                                <option value="3">⭐⭐⭐ Bueno</option>
                                <option value="2">⭐⭐ Regular</option>
                                <option value="1">⭐ Necesita Mejorar</option>
                            </select>
                            <button class="btn btn-primary" id="postAnnouncementBtn"><i class="fas fa-paper-plane"></i> Publicar</button>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-comments"></i> Anuncios y Comentarios</h3>
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <input type="text" id="searchAnnouncements" placeholder="Buscar..." style="padding: 10px 12px; border-radius: 8px; border: 1px solid var(--card-border); background: var(--card-bg); color: var(--text-main); min-height: 44px; font-size: 16px;">
                            <select id="filterAnnouncements" style="padding: 10px 12px; border-radius: 8px; border: 1px solid var(--card-border); background: var(--card-bg); color: var(--text-main); min-height: 44px; font-size: 14px;">
                                <option value="all">Todos</option>
                                <option value="public">Públicos</option>
                                <option value="manager">De Jefes</option>
                                <option value="private">Privados</option>
                                <option value="with-rating">Con Calificación</option>
                            </select>
                        </div>
                    </div>
                    <div class="announcements-list" id="announcementsList">
                        <div class="empty-state">
                            <i class="fas fa-comments"></i>
                            <p>No hay anuncios publicados</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-content" id="tab-activity" style="display: none;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-history"></i> Historial de Actividad</h3>
                        <button class="btn btn-sm btn-outline" id="clearActivityBtn"><i class="fas fa-trash"></i> Limpiar</button>
                    </div>
                    <div class="timeline" id="activityTimeline">
                        <div class="empty-state">
                            <i class="fas fa-history"></i>
                            <p>Sin actividad registrada</p>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <button class="mobile-nav-toggle" id="mobileNavToggle" aria-label="Abrir menú">
        <i class="fas fa-bars"></i>
    </button>

    <div class="modal-overlay" id="editProfileModal">
        <div class="modal">
            <div class="modal-header">
                <h2><i class="fas fa-user-edit"></i> Editar Perfil</h2>
                <button class="modal-close" id="closeModalBtn" aria-label="Cerrar">&times;</button>
            </div>
            <form id="editProfileForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="editFirstName">Nombre</label>
                        <input type="text" id="editFirstName" placeholder="Ingresa tu nombre">
                    </div>
                    <div class="form-group">
                        <label for="editLastName">Apellidos</label>
                        <input type="text" id="editLastName" placeholder="Ingresa tus apellidos">
                    </div>
                </div>
                <div class="form-group">
                    <label for="editEmail">Email Corporativo</label>
                    <input type="email" id="editEmail" placeholder="correo@empresa.com">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="editPhone">Teléfono</label>
                        <input type="tel" id="editPhone" placeholder="+52 (55) 0000-0000">
                    </div>
                    <div class="form-group">
                        <label for="editBirthDate">Fecha de Nacimiento</label>
                        <input type="date" id="editBirthDate">
                    </div>
                </div>
                <div class="form-group">
                    <label for="editAddress">Dirección</label>
                    <textarea id="editAddress" rows="2" placeholder="Ingresa tu dirección"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="editDepartment">Departamento</label>
                        <select id="editDepartment">
                            <option value="">Seleccionar...</option>
                            <option value="Ventas">Ventas</option>
                            <option value="Marketing">Marketing</option>
                            <option value="TI">TI</option>
                            <option value="RRHH">RRHH</option>
                            <option value="Finanzas">Finanzas</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="editRole">Cargo</label>
                        <select id="editRole">
                            <option value="">Seleccionar...</option>
                            <option value="Supervisor de Ventas">Supervisor de Ventas</option>
                            <option value="Gerente de Ventas">Gerente de Ventas</option>
                            <option value="Ejecutivo de Ventas">Ejecutivo de Ventas</option>
                            <option value="Director Comercial">Director Comercial</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="editManager">Reporta a</label>
                    <input type="text" id="editManager" placeholder="Nombre del jefe directo">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="editJoinDate">Fecha de Ingreso</label>
                        <input type="date" id="editJoinDate">
                    </div>
                    <div class="form-group">
                        <label for="editNSS">NSS</label>
                        <input type="text" id="editNSS" placeholder="0000-00-0000">
                    </div>
                </div>
                <div class="form-group">
                    <label for="editRFC">RFC</label>
                    <input type="text" id="editRFC" placeholder="RFC">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="cancelModalBtn">Cancelar</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>

    <div class="modal-overlay" id="shortcutsModal">
        <div class="modal">
            <div class="modal-header">
                <h2><i class="fas fa-keyboard"></i> Atajos de Teclado</h2>
                <button class="modal-close" id="shortcutsCloseBtn" aria-label="Cerrar">&times;</button>
            </div>
            <div style="display: grid; gap: 12px;">
                <div style="display: flex; justify-content: space-between; padding: 10px; background: var(--bg); border-radius: 8px;">
                    <span><strong>Ctrl + E</strong></span><span>Editar perfil</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 10px; background: var(--bg); border-radius: 8px;">
                    <span><strong>Ctrl + S</strong></span><span>Exportar perfil</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 10px; background: var(--bg); border-radius: 8px;">
                    <span><strong>Ctrl + D</strong></span><span>Cambiar tema</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 10px; background: var(--bg); border-radius: 8px;">
                    <span><strong>Ctrl + P</strong></span><span>Imprimir</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 10px; background: var(--bg); border-radius: 8px;">
                    <span><strong>Esc</strong></span><span>Cerrar modales</span>
                </div>
            </div>
        </div>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <script>
        // ============================================================
        // ✅ CORREGIDO: Usar funciones dinámicas en vez de constantes
        // ============================================================
        function isMobileView() {
            return window.matchMedia('(max-width: 992px)').matches;
        }

        function isTouchDevice() {
            return ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
        }

        // Mantener compatibilidad con código existente
        const APP_STATE = {
            get isMobile() { return isMobileView(); },
            get isTouch() { return isTouchDevice(); }
        };

        // ✅ CORREGIDO: Funciones del sidebar con guardas para evitar conflictos
        function openMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.add('mobile-open');
            if (ov) ov.classList.add('active');
            document.body.style.overflow = 'hidden';
            if (isTouchDevice() && navigator.vibrate) navigator.vibrate(5);
        }

        function closeMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) {
                sb.classList.remove('mobile-open');
                sb.style.transform = ''; // Limpiar transform del swipe
            }
            if (ov) ov.classList.remove('active');
            document.body.style.overflow = '';
        }

        // ✅ CORREGIDO: setupMobileSidebar con protección contra duplicados
        let sidebarInitialized = false;
        function setupMobileSidebar() {
            if (sidebarInitialized) return;
            sidebarInitialized = true;

            const overlay = document.getElementById('sidebarOverlay');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.getElementById('mobileNavToggle');

            if (overlay) {
                overlay.addEventListener('click', closeMobileSidebar);
            }
            
            if (closeBtn) {
                closeBtn.addEventListener('click', closeMobileSidebar);
            }
            
            if (menuToggle) {
                // ✅ CORREGIDO: Usar addEventListener sin clonar (evitar duplicados)
                menuToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const sb = document.getElementById('sidebar');
                    if (!sb) return;
                    if (sb.classList.contains('mobile-open')) {
                        closeMobileSidebar();
                    } else {
                        openMobileSidebar();
                    }
                });
            }

            // Swipe para cerrar
            if (sidebar) {
                let touchStartX = 0, touchCurrentX = 0;
                sidebar.addEventListener('touchstart', (e) => { 
                    touchStartX = e.touches[0].clientX; 
                }, { passive: true });
                
                sidebar.addEventListener('touchmove', (e) => {
                    touchCurrentX = e.touches[0].clientX;
                    const diff = touchCurrentX - touchStartX;
                    if (diff < 0 && diff > -100) sidebar.style.transform = `translateX(${diff}px)`;
                }, { passive: true });
                
                sidebar.addEventListener('touchend', () => {
                    const diff = touchCurrentX - touchStartX;
                    sidebar.style.transform = '';
                    if (diff < -60) closeMobileSidebar();
                    touchStartX = 0; 
                    touchCurrentX = 0;
                });
            }
        }

        const SYSTEM_ROUTES = {
            'admin': 'http://localhost/SmartStockAI/admin.php',
            'inventario': 'http://localhost/SmartStockAI/inventario1.php',
            'Reportes': 'http://localhost/SmartStockAI/Reportes.php',
            'Transacciones': 'http://localhost/SmartStockAI/Trassanciones.php',
            'clientes': 'http://localhost/SmartStockAI/clientes.php',
            'proveedores': 'http://localhost/SmartStockAI/proveedores.php',
            'usuarios': 'http://localhost/SmartStockAI/usuarios.php',
            'seguridad': 'http://localhost/SmartStockAI/seguridad.php',
            'perfil': 'http://localhost/SmartStockAI/perfil.php',
            'configuracion': 'http://localhost/SmartStockAI/configuracion.php'
        };

        function navigateTo(pageKey) {
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            const restrictedAdminPages = ['usuarios', 'seguridad', 'configuracion'];

            if (restrictedAdminPages.includes(pageKey) && currentUser.role !== 'admin') {
                alert('Acceso Denegado: Esta sección requiere privilegios de Administrador.');
                return;
            }

            const targetUrl = SYSTEM_ROUTES[pageKey];
            if (targetUrl) window.location.href = targetUrl;
        }

        function setupNavigationListeners() {
            document.querySelectorAll('[data-page]').forEach(element => {
                element.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (isMobileView()) closeMobileSidebar();
                    navigateTo(this.getAttribute('data-page'));
                });
            });
        }

        function hexToRgba(hex, alpha = 0.12) {
            if (!hex) return `rgba(58, 94, 199, ${alpha})`;
            let c = hex.replace('#', '');
            if (c.length === 3) c = c.split('').map(char => char + char).join('');
            const num = parseInt(c, 16);
            return `rgba(${(num >> 16) & 255}, ${(num >> 8) & 255}, ${num & 255}, ${alpha})`;
        }

        function applyGlobalConfig() {
            const settings = JSON.parse(localStorage.getItem('globalSettings')) || {};
            const legacySettings = JSON.parse(localStorage.getItem('appSettings')) || {};
            const savedTheme = settings.darkMode ? 'dark' : (localStorage.getItem('theme') || legacySettings.theme || 'light');
            const colors = {
                blue: '#3a5ec7',
                green: '#28a745',
                red: '#dc3545',
                purple: '#6f42c1',
                orange: '#fd7e14',
                teal: '#20c997'
            };
            const primaryColor = colors[settings.themeColor] || legacySettings.primaryColor || localStorage.getItem('primaryColor') || '#3a5ec7';

            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
                const themeBtn = document.querySelector('#themeToggleBtn i');
                if (themeBtn) themeBtn.className = 'fas fa-sun';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#0b0f19');
            } else {
                document.body.classList.remove('dark-mode');
                const themeBtn = document.querySelector('#themeToggleBtn i');
                if (themeBtn) themeBtn.className = 'fas fa-moon';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#3a5ec7');
            }

            const primaryLight = hexToRgba(primaryColor, 0.12);
            document.documentElement.style.setProperty('--primary', primaryColor);
            document.documentElement.style.setProperty('--primary-dark', primaryColor);
            document.documentElement.style.setProperty('--primary-light', primaryLight);

            document.querySelectorAll('.system-name-display').forEach(element => {
                element.textContent = settings.systemName || 'SmartStock AI';
            });

            if (settings.sidebarTheme === 'dark') {
                document.documentElement.style.setProperty('--sidebar-bg', 'linear-gradient(180deg, #111827 0%, #030712 100%)');
            } else if (settings.sidebarTheme === 'light') {
                document.documentElement.style.setProperty('--sidebar-bg', '#ffffff');
            } else {
                document.documentElement.style.setProperty('--sidebar-bg', `linear-gradient(180deg, ${primaryColor} 0%, ${primaryColor} 100%)`);
            }
        }

        function setupUserSession() {
            const user = JSON.parse(localStorage.getItem('currentUser') || '{"name":"","email":"","role":"","avatar":""}');
            document.getElementById('userName').textContent = user.name || 'Invitado';
            document.getElementById('userEmail').textContent = user.email || '';
            document.getElementById('userAvatar').textContent = user.avatar || (user.name ? user.name.charAt(0).toUpperCase() : '?');

            const roleBadge = document.getElementById('userRoleBadge');
            if (user.role === 'admin') {
                roleBadge.textContent = 'Administrador';
                roleBadge.className = 'user-badge badge-admin';
            } else if (user.role === 'employee') {
                roleBadge.textContent = 'Empleado';
                roleBadge.className = 'user-badge badge-employee';
            } else {
                roleBadge.textContent = '';
                roleBadge.className = 'user-badge';
            }
        }

        // ✅ CORREGIDO: Todo en un solo DOMContentLoaded
        document.addEventListener('DOMContentLoaded', function() {
            applyGlobalConfig();
            setupUserSession();
            setupNavigationListeners();
            setupMobileSidebar();

            // Cerrar sidebar al navegar
            document.querySelectorAll('.sidebar-menu a').forEach(a => {
                a.addEventListener('click', () => {
                    if (isMobileView()) closeMobileSidebar();
                });
            });

            // Prevenir zoom doble-tap iOS
            if (isTouchDevice()) {
                let lastTouchEnd = 0;
                document.addEventListener('touchend', (e) => {
                    const now = Date.now();
                    if (now - lastTouchEnd <= 300) e.preventDefault();
                    lastTouchEnd = now;
                }, { passive: false });
            }

            // Detectar orientación
            window.addEventListener('orientationchange', () => {
                setTimeout(() => {
                    if (!isMobileView()) closeMobileSidebar();
                }, 150);
            });

            // Logout
            document.getElementById('logoutBtn').addEventListener('click', function() {
                if (confirm('¿Desea cerrar la sesión actual?')) {
                    localStorage.removeItem('currentUser');
                    window.location.href = 'http://localhost/SmartStockAI/login.php';
                }
            });

            // ✅ CORREGIDO: Theme toggle solo se registra UNA VEZ aquí
            document.getElementById('themeToggleBtn').addEventListener('click', function() {
                const isDark = document.body.classList.toggle('dark-mode');
                const settings = JSON.parse(localStorage.getItem('globalSettings')) || {};
                settings.darkMode = isDark;
                localStorage.setItem('globalSettings', JSON.stringify(settings));
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
                this.querySelector('i').className = isDark ? 'fas fa-sun' : 'fas fa-moon';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', isDark ? '#0b0f19' : '#3a5ec7');
                if (isTouchDevice() && navigator.vibrate) navigator.vibrate(10);
            });

            window.addEventListener('storage', function(e) {
                if (e.key === 'globalSettings' || e.key === 'appSettings' || e.key === 'theme' || e.key === 'primaryColor') {
                    applyGlobalConfig();
                }
            });
            window.addEventListener('focus', function() { applyGlobalConfig(); });

            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    closeMobileSidebar();
                }
            });

            console.log('%c✅ SmartStock AI - Perfil cargado', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (isMobileView() ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });

        // ============================================================
        // LÓGICA DEL PERFIL
        // ============================================================
        (function(){
            "use strict";

            const defaultState = {
                currentUser: {
                    firstName: "", lastName: "", name: "", email: "", phone: "",
                    birthDate: "", address: "", role: "", department: "", manager: "",
                    joinDate: "", nss: "", rfc: "", photo: "", isManager: true
                },
                permissions: [
                    { category: "Dashboard", items: [
                        { name: "Ver Dashboard", desc: "Acceso al panel principal", status: "allowed" },
                        { name: "Ver Estadísticas", desc: "Visualizar métricas y gráficos", status: "allowed" }
                    ]},
                    { category: "Inventario", items: [
                        { name: "Ver Productos", desc: "Consultar catálogo de productos", status: "allowed" },
                        { name: "Editar Productos", desc: "Modificar información de productos", status: "limited" },
                        { name: "Eliminar Productos", desc: "Eliminar productos del sistema", status: "denied" },
                        { name: "Ajustar Stock", desc: "Modificar cantidades de inventario", status: "allowed" }
                    ]},
                    { category: "Ventas", items: [
                        { name: "Realizar Ventas", desc: "Procesar transacciones de venta", status: "allowed" },
                        { name: "Ver Historial", desc: "Consultar ventas realizadas", status: "allowed" },
                        { name: "Anular Ventas", desc: "Cancelar transacciones", status: "limited" },
                        { name: "Aplicar Descuentos", desc: "Aplicar descuentos especiales", status: "allowed" }
                    ]},
                    { category: "Reportes", items: [
                        { name: "Generar Reportes", desc: "Crear reportes del sistema", status: "allowed" },
                        { name: "Exportar Datos", desc: "Exportar información a Excel/PDF", status: "allowed" }
                    ]},
                    { category: "Administración", items: [
                        { name: "Gestionar Usuarios", desc: "Crear/editar usuarios", status: "denied" },
                        { name: "Configurar Sistema", desc: "Ajustes generales", status: "denied" },
                        { name: "Ver Auditoría", desc: "Registro de actividades", status: "denied" }
                    ]}
                ],
                announcements: [],
                evaluations: [],
                metrics: [
                    { name: "Cumplimiento de Objetivos", value: 0, target: 100 },
                    { name: "Satisfacción del Cliente", value: 0, target: 5, isRating: true },
                    { name: "Productividad", value: 0, target: 100 },
                    { name: "Trabajo en Equipo", value: 0, target: 100 },
                    { name: "Puntualidad", value: 0, target: 100 }
                ],
                achievements: [
                    { icon: "trophy", title: "Empleado del Trimestre", date: "—", color: "warning", unlocked: false },
                    { icon: "chart-line", title: "Mayor Crecimiento en Ventas", date: "—", color: "success", unlocked: false },
                    { icon: "star", title: "Excelencia en Servicio", date: "—", color: "primary", unlocked: false },
                    { icon: "rocket", title: "Primeros 100 días", date: "—", color: "info", unlocked: false },
                    { icon: "award", title: "Año Completo", date: "—", color: "primary", unlocked: false }
                ],
                documents: [],
                preferences: {
                    emailNotifications: true,
                    pushNotifications: false,
                    weeklySummary: true,
                    language: "es",
                    timezone: "America/Mexico_City",
                    dateFormat: "DD/MM/YYYY"
                },
                twoFactor: false,
                sessions: [
                    { id: 1, device: "Chrome en Windows", location: "Ciudad de México, MX", ip: "192.168.1.1", lastActive: "Ahora", current: true },
                    { id: 2, device: "Safari en iPhone", location: "Ciudad de México, MX", ip: "192.168.1.2", lastActive: "Hace 2 horas", current: false }
                ],
                loginHistory: [
                    { date: "Hoy, 09:30", device: "Chrome en Windows", ip: "192.168.1.1", status: "success" },
                    { date: "Ayer, 18:45", device: "Safari en iPhone", ip: "192.168.1.2", status: "success" },
                    { date: "Hace 3 días, 14:20", device: "Firefox en Mac", ip: "192.168.1.3", status: "failed" }
                ],
                activity: []
            };

            let state;
            try {
                const saved = JSON.parse(localStorage.getItem('perfilState'));
                state = saved ? { ...defaultState, ...saved, currentUser: { ...defaultState.currentUser, ...saved.currentUser }, preferences: { ...defaultState.preferences, ...saved.preferences } } : JSON.parse(JSON.stringify(defaultState));
            } catch (e) {
                state = JSON.parse(JSON.stringify(defaultState));
            }

            const $ = s => document.querySelector(s);
            const $$ = s => document.querySelectorAll(s);

            function saveState() {
                localStorage.setItem('perfilState', JSON.stringify(state));
            }

            function showToast(message, type = 'success') {
                const container = $('#toastContainer');
                if (!container) return;
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
                toast.innerHTML = `<i class="fas ${icons[type]}"></i><span>${message}</span>`;
                container.appendChild(toast);
                setTimeout(() => {
                    toast.style.animation = 'slideOut 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }

            function logActivity(action, details = '') {
                state.activity.unshift({ id: Date.now(), action, details, date: new Date().toLocaleString('es-ES') });
                if (state.activity.length > 100) state.activity = state.activity.slice(0, 100);
                saveState();
                renderActivity();
            }

            function switchTab(tabName) {
                $$('.tab-btn').forEach(b => b.classList.remove('active'));
                const btn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
                if (btn) {
                    btn.classList.add('active');
                    if (isMobileView()) {
                        btn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
                    }
                }
                $$('.tab-content').forEach(c => c.style.display = 'none');
                const tab = $(`#tab-${tabName}`);
                if (tab) tab.style.display = 'block';
            }

            function updateProfileUI() {
                const user = state.currentUser;
                const hasData = user.firstName || user.lastName;

                const displayName = hasData ? `${user.firstName.split(' ')[0]} ${user.lastName.split(' ')[0]}` : '— Sin nombre —';
                $('#profileName').textContent = displayName;
                const role = user.role || 'Sin cargo';
                $('#profileRole').innerHTML = `<i class="fas fa-briefcase"></i> ${role}`;
                $('#profileEmail').textContent = user.email || '—';
                $('#profilePhone').textContent = user.phone || '—';
                $('#profileDepartment').textContent = user.department || '—';
                $('#profileManager').textContent = user.manager || '—';
                $('#profileJoinDate').textContent = user.joinDate ? formatDate(user.joinDate) : '—';

                if (user.photo) {
                    $('#profilePhoto').src = user.photo;
                } else if (hasData) {
                    $('#profilePhoto').src = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.firstName)}+${encodeURIComponent(user.lastName)}&size=130&background=3a5ec7&color=fff&bold=true`;
                } else {
                    $('#profilePhoto').src = `https://ui-avatars.com/api/?name=User&size=130&background=3a5ec7&color=fff&bold=true`;
                }

                $('#fullName').textContent = hasData ? `${user.firstName} ${user.lastName}` : '— Sin información —';
                $('#corpEmail').textContent = user.email || '—';
                $('#personalPhone').textContent = user.phone || '—';

                if (user.birthDate) {
                    const birthDate = new Date(user.birthDate);
                    const age = new Date().getFullYear() - birthDate.getFullYear();
                    const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
                    $('#birthDate').textContent = `${birthDate.getDate()} ${monthNames[birthDate.getMonth()]} ${birthDate.getFullYear()} (${age} años)`;
                } else {
                    $('#birthDate').textContent = '—';
                }

                $('#address').textContent = user.address || '—';
                $('#nss').textContent = user.nss || '—';
                $('#rfc').textContent = user.rfc || '—';
                updateCompleteness();
            }

            function updateCompleteness() {
                const user = state.currentUser;
                const fields = ['firstName', 'lastName', 'email', 'phone', 'birthDate', 'address', 'role', 'department', 'manager', 'nss', 'rfc'];
                const filled = fields.filter(f => user[f] && user[f].toString().trim() !== '').length;
                const percent = Math.round((filled / fields.length) * 100);
                $('#completenessText').textContent = `${percent}%`;
                $('#completenessFill').style.width = `${percent}%`;
                if (percent === 100) {
                    $('#completenessFill').style.background = 'linear-gradient(90deg, #10b981, #06b6d4)';
                } else if (percent >= 50) {
                    $('#completenessFill').style.background = 'linear-gradient(90deg, #f59e0b, #10b981)';
                } else {
                    $('#completenessFill').style.background = 'linear-gradient(90deg, #ef4444, #f59e0b)';
                }
            }

            function formatDate(dateStr) {
                if (!dateStr) return '—';
                if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
                    const [y, m, d] = dateStr.split('-');
                    const months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
                    return `${parseInt(d)} ${months[parseInt(m) - 1]} ${y}`;
                }
                return dateStr;
            }

            function renderPermissions() {
                const container = $('#permissionsList');
                let allowed = 0, limited = 0, denied = 0;
                let html = '';
                state.permissions.forEach(cat => {
                    html += `<div class="permission-category"><h4>${cat.category}</h4><ul class="permission-list">`;
                    cat.items.forEach(p => {
                        const iconClass = p.status === 'allowed' ? 'allowed' : p.status === 'limited' ? 'limited' : 'denied';
                        const iconName = p.status === 'allowed' ? 'fa-check-circle' : p.status === 'limited' ? 'fa-clock' : 'fa-times-circle';
                        const statusText = p.status === 'allowed' ? 'Permitido' : p.status === 'limited' ? 'Limitado' : 'Denegado';
                        if (p.status === 'allowed') allowed++;
                        else if (p.status === 'limited') limited++;
                        else denied++;
                        html += `<li class="permission-item">
                            <div class="permission-icon ${iconClass}"><i class="fas ${iconName}"></i></div>
                            <div class="permission-content"><div class="permission-name">${p.name}</div><div class="permission-desc">${p.desc}</div></div>
                            <span class="permission-status ${iconClass}">${statusText}</span>
                        </li>`;
                    });
                    html += '</ul></div>';
                });
                container.innerHTML = html;
                $('#allowedCount').textContent = `${allowed} permisos concedidos`;
                $('#limitedCount').textContent = `${limited} permisos limitados`;
                $('#deniedCount').textContent = `${denied} permisos denegados`;
            }

            function renderAnnouncements(filter = 'all', search = '') {
                const container = $('#announcementsList');
                const recentContainer = $('#recentAnnouncements');
                let filtered = [...state.announcements];
                if (filter === 'public') filtered = filtered.filter(a => a.visibility === 'public');
                else if (filter === 'manager') filtered = filtered.filter(a => a.visibility === 'manager');
                else if (filter === 'private') filtered = filtered.filter(a => a.visibility === 'private');
                else if (filter === 'with-rating') filtered = filtered.filter(a => a.rating !== null && a.rating !== undefined);
                if (search) {
                    const s = search.toLowerCase();
                    filtered = filtered.filter(a => (a.content || '').toLowerCase().includes(s) || (a.author || '').toLowerCase().includes(s));
                }

                const renderItem = a => {
                    const badgeClass = a.role === 'manager' ? 'badge-manager' : 'badge-hr';
                    const badgeText = a.role === 'manager' ? 'Jefe' : 'RRHH';
                    const visibilityIcon = a.visibility === 'public' ? 'fa-globe' : a.visibility === 'manager' ? 'fa-user-tie' : 'fa-lock';
                    const visibilityText = a.visibility === 'public' ? 'Público' : a.visibility === 'manager' ? 'Solo Jefes' : 'Privado';
                    let ratingHtml = '';
                    if (a.rating) ratingHtml = `<span class="rating-badge"><i class="fas fa-star"></i> ${a.rating}/5</span>`;
                    return `<div class="announcement-item" data-id="${a.id}">
                        <div class="announcement-header">
                            <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(a.author)}&size=48&background=3a5ec7&color=fff" class="announcer-avatar">
                            <div class="announcer-info">
                                <div class="announcer-name">${a.author} <span class="${badgeClass}">${badgeText}</span>${ratingHtml}</div>
                                <div class="announcement-time"><i class="far fa-clock"></i> ${a.time}</div>
                            </div>
                            <span class="announcement-visibility"><i class="fas ${visibilityIcon}"></i> ${visibilityText}</span>
                        </div>
                        <div class="announcement-content"><i class="fas fa-quote-left"></i> ${a.content}</div>
                        <div class="announcement-actions">
                            <button class="btn btn-sm btn-outline delete-announcement" data-id="${a.id}"><i class="fas fa-trash"></i> Eliminar</button>
                        </div>
                    </div>`;
                };

                if (filtered.length === 0) {
                    container.innerHTML = `<div class="empty-state"><i class="fas fa-comments"></i><p>No hay anuncios ${search ? 'que coincidan con la búsqueda' : 'publicados'}</p></div>`;
                } else {
                    container.innerHTML = filtered.map(renderItem).join('');
                }

                if (state.announcements.length === 0) {
                    recentContainer.innerHTML = `<div class="empty-state"><i class="fas fa-bullhorn"></i><p>No hay anuncios disponibles</p></div>`;
                } else {
                    recentContainer.innerHTML = state.announcements.slice(0, 2).map(renderItem).join('');
                }

                $$('.delete-announcement').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const id = parseInt(this.getAttribute('data-id'));
                        if (confirm('¿Eliminar este anuncio?')) {
                            state.announcements = state.announcements.filter(a => a.id !== id);
                            saveState();
                            renderAnnouncements($('#filterAnnouncements')?.value || 'all', $('#searchAnnouncements')?.value || '');
                            logActivity('Anuncio eliminado');
                            showToast('Anuncio eliminado', 'success');
                        }
                    });
                });
            }

            function renderMetrics() {
                const container = $('#performanceMetrics');
                if (!container) return;
                let html = '<div class="metrics-list">';
                state.metrics.forEach(m => {
                    if (m.isRating) {
                        html += `<div class="metric-item"><div class="metric-info"><div class="metric-name">${m.name}</div><div class="metric-value">${m.value}/5.0</div></div></div>`;
                    } else {
                        const percent = m.target > 0 ? (m.value / m.target) * 100 : 0;
                        html += `<div class="metric-item"><div class="metric-info"><div class="metric-name">${m.name}</div><div class="metric-progress"><div class="progress-bar-container"><div class="progress-bar-fill" style="width:${percent}%"></div></div><span class="metric-value">${m.value}%</span></div></div></div>`;
                    }
                });
                html += '</div>';
                container.innerHTML = html;
            }

            function renderEvaluations() {
                const container = $('#recentEvaluations');
                if (state.evaluations.length === 0) {
                    container.innerHTML = `<div class="empty-state"><i class="fas fa-clipboard"></i><p>Sin evaluaciones registradas</p></div>`;
                    return;
                }
                container.innerHTML = state.evaluations.map(e => {
                    const stars = '★'.repeat(Math.floor(e.score)) + (e.score % 1 >= 0.5 ? '½' : '') + '☆'.repeat(5 - Math.ceil(e.score));
                    return `<div style="padding: 16px; border-bottom: 1px solid var(--card-border);">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <strong>${e.date}</strong>
                            <span style="color: var(--warning);">${stars} ${e.score}</span>
                        </div>
                        <p style="color: var(--text-muted); margin: 0;">${e.comments}</p>
                    </div>`;
                }).join('');
            }

            function renderAchievements() {
                const container = $('#achievementsList');
                if (!container) return;
                container.innerHTML = state.achievements.map(a => `
                    <div class="achievement-badge ${a.unlocked ? '' : 'locked'}">
                        <div class="achievement-icon" style="background: rgba(58,94,199,0.1); color: var(--${a.color});">
                            <i class="fas fa-${a.icon}"></i>
                        </div>
                        <div style="flex: 1; min-width: 0;">
                            <strong>${a.title}</strong><br>
                            <small style="color: var(--text-muted);">${a.unlocked ? a.date : 'Bloqueado'}</small>
                        </div>
                        <i class="fas fa-${a.unlocked ? 'check-circle' : 'lock'}" style="color: var(--${a.unlocked ? 'success' : 'gray'}); font-size: 20px;"></i>
                    </div>
                `).join('');
            }

            function renderDocuments() {
                const grid = $('#documentsGrid');
                if (state.documents.length === 0) {
                    grid.innerHTML = `<div class="empty-state" style="grid-column: 1 / -1;"><i class="fas fa-folder-open"></i><p>No hay documentos subidos</p></div>`;
                    return;
                }
                grid.innerHTML = state.documents.map(d => {
                    let iconClass = 'doc';
                    let iconName = 'fa-file';
                    if (d.type === 'pdf' || d.name.endsWith('.pdf')) { iconClass = 'pdf'; iconName = 'fa-file-pdf'; }
                    else if (d.type === 'image' || /\.(jpg|jpeg|png|gif)$/i.test(d.name)) { iconClass = 'img'; iconName = 'fa-file-image'; }
                    else if (/\.(doc|docx)$/i.test(d.name)) { iconName = 'fa-file-word'; }
                    else if (/\.(xls|xlsx)$/i.test(d.name)) { iconName = 'fa-file-excel'; }
                    return `<div class="document-card" onclick="downloadDocument('${d.id}')">
                        <button class="document-delete" onclick="event.stopPropagation(); deleteDocument('${d.id}')"><i class="fas fa-times"></i></button>
                        <div class="document-icon ${iconClass}"><i class="fas ${iconName}"></i></div>
                        <div class="document-name">${d.name}</div>
                        <div class="document-meta">${d.size} · ${d.date}</div>
                    </div>`;
                }).join('');
            }

            function renderSessions() {
                const container = $('#sessionsList');
                container.innerHTML = state.sessions.map(s => `
                    <div class="session-item">
                        <div class="session-info">
                            <div class="session-device">${s.current ? `<span class="session-current">Sesión actual</span> ` : ''}${s.device}</div>
                            <div class="session-meta">${s.location} · IP: ${s.ip} · ${s.lastActive}</div>
                        </div>
                        ${!s.current ? `<button class="btn btn-sm btn-danger" onclick="closeSession(${s.id})"><i class="fas fa-times"></i> Cerrar</button>` : ''}
                    </div>
                `).join('');
            }

            function renderLoginHistory() {
                const container = $('#loginHistory');
                container.innerHTML = state.loginHistory.map(h => `
                    <div style="padding: 10px 0; border-bottom: 1px solid var(--card-border); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                        <div style="min-width: 0;">
                            <div style="font-weight: 600; font-size: 13px;">${h.device}</div>
                            <div style="font-size: 12px; color: var(--text-muted);">${h.date} · IP: ${h.ip}</div>
                        </div>
                        <span class="badge-${h.status === 'success' ? 'success' : 'warning'}">${h.status === 'success' ? 'Exitosa' : 'Fallida'}</span>
                    </div>
                `).join('');
            }

            function renderActivity() {
                const container = $('#activityTimeline');
                if (state.activity.length === 0) {
                    container.innerHTML = `<div class="empty-state"><i class="fas fa-history"></i><p>Sin actividad registrada</p></div>`;
                    return;
                }
                container.innerHTML = state.activity.map(a => `
                    <div class="timeline-item">
                        <div class="timeline-marker"></div>
                        <div class="timeline-content">
                            <div class="timeline-title">${a.action}</div>
                            ${a.details ? `<div style="font-size: 13px; color: var(--text-muted); margin-bottom: 4px;">${a.details}</div>` : ''}
                            <div class="timeline-date"><i class="far fa-clock"></i> ${a.date}</div>
                        </div>
                    </div>
                `).join('');
            }

            function renderPreferences() {
                $('#prefEmailNotifications').checked = state.preferences.emailNotifications;
                $('#prefPushNotifications').checked = state.preferences.pushNotifications;
                $('#prefWeeklySummary').checked = state.preferences.weeklySummary;
                $('#prefLanguage').value = state.preferences.language;
                $('#prefTimezone').value = state.preferences.timezone;
                $('#prefDateFormat').value = state.preferences.dateFormat;
                $('#twoFactorToggle').checked = state.twoFactor;
            }

            function openEditModal() {
                const user = state.currentUser;
                $('#editFirstName').value = user.firstName;
                $('#editLastName').value = user.lastName;
                $('#editEmail').value = user.email;
                $('#editPhone').value = user.phone;
                $('#editBirthDate').value = user.birthDate;
                $('#editAddress').value = user.address;
                $('#editDepartment').value = user.department;
                $('#editRole').value = user.role;
                $('#editManager').value = user.manager;
                $('#editNSS').value = user.nss;
                $('#editRFC').value = user.rfc;
                if (user.joinDate && /^\d{4}-\d{2}-\d{2}$/.test(user.joinDate)) {
                    $('#editJoinDate').value = user.joinDate;
                }
                $('#editProfileModal').classList.add('show');
            }

            function closeEditModal() {
                $('#editProfileModal').classList.remove('show');
            }

            function saveProfileChanges(e) {
                e.preventDefault();
                const user = state.currentUser;
                user.firstName = $('#editFirstName').value.trim();
                user.lastName = $('#editLastName').value.trim();
                user.email = $('#editEmail').value.trim();
                user.phone = $('#editPhone').value.trim();
                user.birthDate = $('#editBirthDate').value;
                user.address = $('#editAddress').value.trim();
                user.department = $('#editDepartment').value;
                user.role = $('#editRole').value;
                user.manager = $('#editManager').value.trim();
                user.nss = $('#editNSS').value.trim();
                user.rfc = $('#editRFC').value.trim();
                user.joinDate = $('#editJoinDate').value;
                user.name = `${user.firstName} ${user.lastName}`.trim();
                saveState();
                updateProfileUI();
                closeEditModal();
                logActivity('Perfil actualizado', user.name);
                showToast('Perfil actualizado correctamente', 'success');
            }

            function changeProfilePhoto() {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = 'image/*';
                input.onchange = (e) => {
                    const file = e.target.files[0];
                    if (!file) return;
                    if (file.size > 2 * 1024 * 1024) {
                        showToast('La imagen no debe superar 2MB', 'error');
                        return;
                    }
                    const reader = new FileReader();
                    reader.onload = (event) => {
                        state.currentUser.photo = event.target.result;
                        saveState();
                        $('#profilePhoto').src = event.target.result;
                        logActivity('Foto de perfil actualizada');
                        showToast('Foto de perfil actualizada', 'success');
                    };
                    reader.readAsDataURL(file);
                };
                input.click();
            }

            function exportProfile(format = 'txt') {
                const user = state.currentUser;
                if (format === 'pdf') {
                    try {
                        const { jsPDF } = window.jspdf;
                        const doc = new jsPDF();
                        doc.setFontSize(20);
                        doc.setTextColor(58, 94, 199);
                        doc.text('SmartStock AI - Perfil de Usuario', 105, 20, { align: 'center' });
                        doc.setFontSize(10);
                        doc.setTextColor(100, 100, 100);
                        doc.text(`Generado: ${new Date().toLocaleString('es-ES')}`, 105, 28, { align: 'center' });
                        doc.setFontSize(14);
                        doc.setTextColor(43, 45, 66);
                        doc.text('Información Personal', 20, 45);
                        doc.autoTable({
                            startY: 50,
                            body: [
                                ['Nombre Completo', `${user.firstName} ${user.lastName}` || '—'],
                                ['Email', user.email || '—'],
                                ['Teléfono', user.phone || '—'],
                                ['Departamento', user.department || '—'],
                                ['Cargo', user.role || '—'],
                                ['Reporta a', user.manager || '—'],
                                ['Fecha de Ingreso', formatDate(user.joinDate)],
                                ['NSS', user.nss || '—'],
                                ['RFC', user.rfc || '—'],
                                ['Dirección', user.address || '—']
                            ],
                            theme: 'grid',
                            styles: { fontSize: 10 },
                            columnStyles: { 0: { fontStyle: 'bold', fillColor: [240, 242, 255] } }
                        });
                        doc.save(`perfil_${user.firstName || 'usuario'}_${new Date().toISOString().split('T')[0]}.pdf`);
                        logActivity('Perfil exportado', 'PDF');
                        showToast('PDF generado correctamente', 'success');
                    } catch (e) {
                        showToast('Error al generar PDF: ' + e.message, 'error');
                    }
                    return;
                }
                if (format === 'json') {
                    const data = {
                        user: state.currentUser,
                        preferences: state.preferences,
                        metrics: state.metrics,
                        achievements: state.achievements,
                        exportDate: new Date().toISOString(),
                        version: '1.0'
                    };
                    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `perfil_${user.firstName || 'usuario'}_${new Date().toISOString().split('T')[0]}.json`;
                    a.click();
                    URL.revokeObjectURL(url);
                    logActivity('Perfil exportado', 'JSON');
                    showToast('JSON exportado correctamente', 'success');
                    return;
                }
                let content = "=== PERFIL DE USUARIO - SMARTSTOCK AI ===\n\n";
                content += "INFORMACIÓN PERSONAL\n";
                content += "====================\n";
                content += `Nombre: ${user.firstName} ${user.lastName}\n`;
                content += `Email: ${user.email}\n`;
                content += `Teléfono: ${user.phone}\n`;
                content += `Departamento: ${user.department}\n`;
                content += `Cargo: ${user.role}\n`;
                content += `Reporta a: ${user.manager}\n`;
                content += `Fecha de Ingreso: ${formatDate(user.joinDate)}\n`;
                content += `NSS: ${user.nss}\n`;
                content += `RFC: ${user.rfc}\n`;
                content += `Dirección: ${user.address}\n\n`;
                content += `Generado: ${new Date().toLocaleString('es-ES')}`;
                const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `perfil_${user.firstName || 'usuario'}_${new Date().toISOString().split('T')[0]}.txt`;
                a.click();
                URL.revokeObjectURL(url);
                logActivity('Perfil exportado', 'TXT');
                showToast('Perfil exportado correctamente', 'success');
            }

            function importProfile() {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.json';
                input.onchange = (e) => {
                    const file = e.target.files[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = (event) => {
                        try {
                            const data = JSON.parse(event.target.result);
                            if (data.user) {
                                state.currentUser = { ...state.currentUser, ...data.user };
                                if (data.preferences) state.preferences = { ...state.preferences, ...data.preferences };
                                saveState();
                                updateProfileUI();
                                renderPreferences();
                                logActivity('Perfil importado desde JSON');
                                showToast('Perfil importado correctamente', 'success');
                            } else {
                                showToast('Formato de archivo inválido', 'error');
                            }
                        } catch (err) {
                            showToast('Error al leer archivo: ' + err.message, 'error');
                        }
                    };
                    reader.readAsText(file);
                };
                input.click();
            }

            window.downloadDocument = function(id) {
                const doc = state.documents.find(d => d.id == id);
                if (doc) {
                    showToast(`Descargando: ${doc.name}`, 'info');
                    logActivity('Documento descargado', doc.name);
                }
            };

            window.deleteDocument = function(id) {
                if (confirm('¿Eliminar este documento?')) {
                    const doc = state.documents.find(d => d.id == id);
                    state.documents = state.documents.filter(d => d.id != id);
                    saveState();
                    renderDocuments();
                    logActivity('Documento eliminado', doc?.name || '');
                    showToast('Documento eliminado', 'success');
                }
            };

            window.closeSession = function(id) {
                if (confirm('¿Cerrar esta sesión?')) {
                    state.sessions = state.sessions.filter(s => s.id !== id);
                    saveState();
                    renderSessions();
                    logActivity('Sesión cerrada');
                    showToast('Sesión cerrada', 'success');
                }
            };

            window.switchTab = switchTab;

            function init() {
                // ✅ CORREGIDO: NO registrar theme toggle aquí (ya está en el global)
                // Solo sincronizar el icono con el estado actual
                if (document.body.classList.contains('dark-mode')) {
                    const themeBtn = document.querySelector('#themeToggleBtn i');
                    if (themeBtn) themeBtn.className = 'fas fa-sun';
                }

                updateProfileUI();
                renderPermissions();
                renderAnnouncements();
                renderMetrics();
                renderEvaluations();
                renderAchievements();
                renderDocuments();
                renderSessions();
                renderLoginHistory();
                renderActivity();
                renderPreferences();

                $$('.tab-btn').forEach(btn => {
                    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
                });

                // ✅ CORREGIDO: ELIMINADO el listener duplicado de themeToggleBtn
                // (ya está registrado en el bloque DOMContentLoaded global)

                $('#shortcutsBtn').addEventListener('click', () => {
                    $('#shortcutsModal').classList.add('show');
                });

                $('#shortcutsCloseBtn').addEventListener('click', () => {
                    $('#shortcutsModal').classList.remove('show');
                });

                $('#shortcutsModal').addEventListener('click', (e) => {
                    if (e.target === $('#shortcutsModal')) {
                        $('#shortcutsModal').classList.remove('show');
                    }
                });

                $('#changePhotoBtn').addEventListener('click', changeProfilePhoto);
                $('#editProfileBtn').addEventListener('click', openEditModal);
                $('#editPersonalInfoBtn')?.addEventListener('click', openEditModal);
                $('#closeModalBtn').addEventListener('click', closeEditModal);
                $('#cancelModalBtn').addEventListener('click', closeEditModal);
                $('#editProfileForm').addEventListener('submit', saveProfileChanges);

                $('#editProfileModal').addEventListener('click', (e) => {
                    if (e.target === $('#editProfileModal')) closeEditModal();
                });

                $('#exportProfileBtn').addEventListener('click', () => {
                    const format = prompt('Formato de exportación (txt, json, pdf):', 'pdf');
                    if (format && ['txt', 'json', 'pdf'].includes(format.toLowerCase())) {
                        exportProfile(format.toLowerCase());
                    }
                });

                $('#importProfileBtn').addEventListener('click', importProfile);

                $('#uploadDocBtn').addEventListener('click', () => {
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.accept = '.pdf,.doc,.docx,.jpg,.jpeg,.png,.xlsx,.xls,.txt';
                    input.onchange = (e) => {
                        const file = e.target.files[0];
                        if (!file) return;
                        if (file.size > 5 * 1024 * 1024) {
                            showToast('El archivo no debe superar 5MB', 'error');
                            return;
                        }
                        const newDoc = {
                            id: Date.now(),
                            name: file.name,
                            size: (file.size / 1024).toFixed(1) + ' KB',
                            date: new Date().toLocaleDateString('es-ES'),
                            type: file.type
                        };
                        state.documents.push(newDoc);
                        saveState();
                        renderDocuments();
                        logActivity('Documento subido', file.name);
                        showToast('Documento subido correctamente', 'success');
                    };
                    input.click();
                });

                $('#changePasswordForm').addEventListener('submit', (e) => {
                    e.preventDefault();
                    const newPass = $('#newPassword').value;
                    const confirm = $('#confirmPassword').value;
                    if (newPass !== confirm) {
                        showToast('Las contraseñas no coinciden', 'error');
                        return;
                    }
                    if (newPass.length < 6) {
                        showToast('La contraseña debe tener al menos 6 caracteres', 'error');
                        return;
                    }
                    logActivity('Contraseña cambiada');
                    showToast('Contraseña actualizada correctamente', 'success');
                    e.target.reset();
                    $('#passwordStrengthFill').style.width = '0%';
                    $('#passwordStrengthText').textContent = 'Ingresa una contraseña';
                });

                $('#newPassword').addEventListener('input', function() {
                    const pass = this.value;
                    const fill = $('#passwordStrengthFill');
                    const text = $('#passwordStrengthText');
                    let strength = 0;
                    if (pass.length >= 6) strength++;
                    if (pass.length >= 10) strength++;
                    if (/[A-Z]/.test(pass)) strength++;
                    if (/[0-9]/.test(pass)) strength++;
                    if (/[^A-Za-z0-9]/.test(pass)) strength++;
                    if (strength <= 2) {
                        fill.className = 'password-strength-fill strength-weak';
                        text.textContent = 'Contraseña débil';
                        text.style.color = 'var(--danger)';
                    } else if (strength <= 3) {
                        fill.className = 'password-strength-fill strength-medium';
                        text.textContent = 'Contraseña media';
                        text.style.color = 'var(--warning)';
                    } else {
                        fill.className = 'password-strength-fill strength-strong';
                        text.textContent = 'Contraseña fuerte';
                        text.style.color = 'var(--secondary)';
                    }
                });

                $('#twoFactorToggle').addEventListener('change', function() {
                    state.twoFactor = this.checked;
                    saveState();
                    $('#twoFactorSetup').style.display = this.checked ? 'block' : 'none';
                    logActivity('2FA ' + (this.checked ? 'activado' : 'desactivado'));
                    showToast('2FA ' + (this.checked ? 'activado' : 'desactivado'), 'success');
                });

                $('#closeAllSessionsBtn').addEventListener('click', () => {
                    if (confirm('¿Cerrar todas las sesiones excepto la actual?')) {
                        state.sessions = state.sessions.filter(s => s.current);
                        saveState();
                        renderSessions();
                        logActivity('Todas las sesiones cerradas');
                        showToast('Sesiones cerradas', 'success');
                    }
                });

                $('#savePreferencesBtn').addEventListener('click', () => {
                    state.preferences = {
                        emailNotifications: $('#prefEmailNotifications').checked,
                        pushNotifications: $('#prefPushNotifications').checked,
                        weeklySummary: $('#prefWeeklySummary').checked,
                        language: $('#prefLanguage').value,
                        timezone: $('#prefTimezone').value,
                        dateFormat: $('#prefDateFormat').value
                    };
                    saveState();
                    logActivity('Preferencias actualizadas');
                    showToast('Preferencias guardadas correctamente', 'success');
                    if (state.preferences.pushNotifications && 'Notification' in window && Notification.permission !== 'granted') {
                        Notification.requestPermission();
                    }
                });

                $$('.visibility-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        $$('.visibility-btn').forEach(b => b.classList.remove('active'));
                        this.classList.add('active');
                    });
                });

                $('#postAnnouncementBtn').addEventListener('click', () => {
                    const text = $('#announcementText').value.trim();
                    const rating = $('#ratingSelect').value;
                    const visibility = $('.visibility-btn.active')?.dataset.visibility || 'public';
                    if (!text) {
                        showToast('Escribe un mensaje', 'error');
                        return;
                    }
                    const user = state.currentUser;
                    const authorName = user.firstName ? `${user.firstName} ${user.lastName}` : 'Anónimo';
                    const newAnnouncement = {
                        id: Date.now(),
                        author: authorName,
                        role: user.isManager ? 'manager' : 'hr',
                        content: text,
                        time: 'Ahora mismo',
                        visibility: visibility,
                        rating: rating ? parseInt(rating) : null
                    };
                    state.announcements.unshift(newAnnouncement);
                    saveState();
                    renderAnnouncements($('#filterAnnouncements').value || 'all', $('#searchAnnouncements').value || '');
                    $('#announcementText').value = '';
                    $('#ratingSelect').value = '';
                    logActivity('Anuncio publicado');
                    showToast('Anuncio publicado correctamente', 'success');
                });

                $('#filterAnnouncements').addEventListener('change', (e) => {
                    renderAnnouncements(e.target.value, $('#searchAnnouncements').value);
                });

                $('#searchAnnouncements').addEventListener('input', (e) => {
                    renderAnnouncements($('#filterAnnouncements').value, e.target.value);
                });

                $('#clearActivityBtn').addEventListener('click', () => {
                    if (confirm('¿Limpiar todo el historial de actividad?')) {
                        state.activity = [];
                        saveState();
                        renderActivity();
                        showToast('Historial limpiado', 'success');
                    }
                });

                document.addEventListener('keydown', (e) => {
                    if (e.ctrlKey && e.key === 'e') { e.preventDefault(); openEditModal(); }
                    if (e.ctrlKey && e.key === 's') { e.preventDefault(); exportProfile('pdf'); }
                    if (e.ctrlKey && e.key === 'd') { e.preventDefault(); $('#themeToggleBtn').click(); }
                    if (e.ctrlKey && e.key === 'p') { e.preventDefault(); window.print(); }
                    if (e.key === 'Escape') {
                        $$('.modal-overlay.show').forEach(m => m.classList.remove('show'));
                    }
                });

                setTimeout(() => {
                    const user = state.currentUser;
                    const fields = ['firstName', 'lastName', 'email', 'phone', 'birthDate', 'address', 'role', 'department', 'manager', 'nss', 'rfc'];
                    const filled = fields.filter(f => user[f] && user[f].toString().trim() !== '').length;
                    if (filled >= 5) state.achievements[3].unlocked = true;
                    if (filled >= 10) state.achievements[0].unlocked = true;
                    if (state.activity.length >= 5) state.achievements[1].unlocked = true;
                    if (state.documents.length >= 1) state.achievements[2].unlocked = true;
                    if (state.currentUser.joinDate) {
                        const years = (new Date() - new Date(state.currentUser.joinDate)) / (1000 * 60 * 60 * 24 * 365);
                        if (years >= 1) state.achievements[4].unlocked = true;
                    }
                    saveState();
                    renderAchievements();
                }, 100);

                logActivity('Sesión iniciada');
            }

            document.addEventListener('DOMContentLoaded', init);
        })();
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>