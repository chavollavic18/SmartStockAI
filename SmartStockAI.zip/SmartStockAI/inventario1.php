<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>SmartStock AI - Inventario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1"></script>

    <style>
        :root {
            --primary: #3a5ec7;
            --primary-light: #5a7ed7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --secondary-light: #48c765;
            --secondary-dark: #218838;
            --danger: #dc3545;
            --danger-light: #e55a6a;
            --danger-dark: #c82333;
            --warning: #ffc107;
            --warning-light: #ffd145;
            --warning-dark: #e0a800;
            --info: #17a2b8;
            --info-light: #3ab7cc;
            --info-dark: #138496;
            --dark: #2c3e50;
            --darker: #1a252f;
            --light: #f8f9fa;
            --lighter: #ffffff;
            --gray-100: #f8f9fa;
            --gray-200: #e9ecef;
            --gray-300: #dee2e6;
            --gray-400: #ced4da;
            --gray-500: #adb5bd;
            --gray-600: #6c757d;
            --gray-700: #495057;
            --gray-800: #343a40;
            --gray-900: #212529;

            --bg-primary: #f5f7fb;
            --bg-secondary: #ffffff;
            --bg-card: #ffffff;
            --bg-sidebar: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            --text-primary: #000000;
            --text-secondary: #6c757d;
            --text-muted: #6c757d;
            --border-color: rgba(0,0,0,0.1);
            --shadow-color: rgba(0,0,0,0.05);
            --shadow-hover: rgba(0,0,0,0.1);
            --input-bg: #ffffff;
            --input-border: #ced4da;
            --input-focus: rgba(58, 94, 199, 0.25);

            --success-bg: rgba(40, 167, 69, 0.1);
            --success-text: #28a745;
            --warning-bg: rgba(255, 193, 7, 0.1);
            --warning-text: #856404;
            --danger-bg: rgba(220, 53, 69, 0.1);
            --danger-text: #dc3545;
            --info-bg: rgba(23, 162, 184, 0.1);
            --info-text: #17a2b8;

            --border-radius: 12px;
            --border-radius-sm: 8px;
            --border-radius-lg: 16px;
            --transition: all 0.3s ease;
            --sidebar-width: 270px;
            --sidebar-collapsed: 80px;
            --font-main: 'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            --sidebar-opacity: 1;

            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }

        body.dark-mode {
            --bg-primary: #1a1f2e;
            --bg-secondary: #242a3a;
            --bg-card: #2c3345;
            --text-primary: #ffffff;
            --text-secondary: #a0a8b8;
            --text-muted: #7a8395;
            --border-color: rgba(255,255,255,0.1);
            --shadow-color: rgba(0,0,0,0.3);
            --shadow-hover: rgba(0,0,0,0.4);
            --input-bg: #2c3345;
            --input-border: #40485a;
            --input-focus: rgba(58, 94, 199, 0.5);

            --success-bg: rgba(40, 167, 69, 0.2);
            --success-text: #6fcf97;
            --warning-bg: rgba(255, 193, 7, 0.2);
            --warning-text: #f9ca7f;
            --danger-bg: rgba(220, 53, 69, 0.2);
            --danger-text: #f28b82;
            --info-bg: rgba(23, 162, 184, 0.2);
            --info-text: #7fd1e0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-main);
        }

        html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }

        body {
            background: var(--bg-primary);
            color: var(--text-primary);
            transition: var(--transition);
            min-height: 100vh;
            min-height: 100dvh;
            overflow-x: hidden;
            -webkit-tap-highlight-color: transparent;
            -webkit-font-smoothing: antialiased;
        }

        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg-secondary); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary-dark); }

        .app-container { display: flex; min-height: 100vh; min-height: 100dvh; }

        /* ============================================
           OVERLAY MÓVIL
           ============================================ */
        .sidebar-overlay {
            display: none; position: fixed; inset: 0;
            background: rgba(15, 23, 42, 0.55);
            backdrop-filter: blur(3px); -webkit-backdrop-filter: blur(3px);
            z-index: 1040; opacity: 0; transition: opacity 0.3s ease;
        }
        .sidebar-overlay.active { display: block !important; opacity: 1; }

        /* ============================================
           SIDEBAR
           ============================================ */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--bg-sidebar);
            color: #ffffff;
            height: 100vh;
            height: 100dvh;
            position: fixed;
            left: 0; top: 0;
            padding: 24px 16px;
            padding-top: calc(24px + var(--safe-top));
            padding-bottom: calc(24px + var(--safe-bottom));
            transition: var(--transition);
            z-index: 1050;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 25px rgba(0,0,0,0.15);
            overflow-y: auto;
            opacity: var(--sidebar-opacity);
            will-change: transform;
        }

        .sidebar-header {
            padding: 0 12px 24px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .sidebar .logo {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -0.5px;
            background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }
        .sidebar .logo span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .sidebar .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            -webkit-text-fill-color: white;
            flex-shrink: 0;
        }

        .sidebar .sidebar-toggle {
            background: rgba(255,255,255,0.15);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            font-size: 12px;
            flex-shrink: 0;
        }

        .sidebar .sidebar-toggle:hover {
            background: rgba(255,255,255,0.25);
            transform: scale(1.1);
        }

        .sidebar-close-btn {
            display: none;
            background: rgba(255,255,255,0.08);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            transition: var(--transition);
            flex-shrink: 0;
        }
        .sidebar-close-btn:hover { background: var(--danger); }

        .sidebar-nav-container {
            flex: 1;
            overflow-y: auto;
            padding-right: 4px;
            -webkit-overflow-scrolling: touch;
        }

        .menu-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #64748b;
            font-weight: 700;
            margin: 16px 12px 8px 12px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li { margin-bottom: 4px; }

        .sidebar-menu a {
            color: #94a3b8;
            text-decoration: none;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border-radius: 8px;
            transition: var(--transition);
            font-weight: 500;
            font-size: 14px;
            cursor: pointer;
            gap: 12px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .sidebar-menu a:hover {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.06);
            transform: translateX(3px);
        }

        .sidebar-menu a.active {
            color: #ffffff;
            background: var(--primary);
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .sidebar-menu i {
            font-size: 18px;
            width: 22px;
            text-align: center;
            flex-shrink: 0;
        }

        .sidebar-footer {
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            margin-top: auto;
        }

        .logout-btn {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
            width: 100%;
            padding: 12px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: var(--transition);
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .logout-btn:hover {
            background: var(--danger);
            color: white;
            border-color: var(--danger);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .sidebar.collapsed { width: var(--sidebar-collapsed); }
        .sidebar.collapsed .menu-label,
        .sidebar.collapsed .logo span,
        .sidebar.collapsed .sidebar-menu a span,
        .sidebar.collapsed .logout-btn span { display: none; }
        .sidebar.collapsed .sidebar-menu a { justify-content: center; padding: 12px; }
        .sidebar.collapsed .sidebar-menu i { margin: 0; }
        .sidebar.collapsed .sidebar-header { justify-content: center; }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
            transition: var(--transition);
            min-width: 0;
            overflow-x: hidden;
        }

        .main-content.expanded { margin-left: var(--sidebar-collapsed); }

        .header {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px 30px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 5px 20px var(--shadow-color);
            border: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .page-title i { color: var(--primary); }

        .header-controls { display: flex; align-items: center; gap: 15px; flex-wrap: wrap; }

        .search-box { position: relative; width: 280px; max-width: 100%; }

        .search-box input {
            width: 100%;
            padding: 11px 15px 11px 40px;
            border: 1px solid var(--input-border);
            border-radius: 30px;
            background: var(--input-bg);
            color: var(--text-primary);
            transition: var(--transition);
            font-size: 16px;
            min-height: 44px;
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px var(--input-focus);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 14px;
        }

        .search-suggestions {
            position: absolute;
            top: calc(100% + 4px);
            left: 0; right: 0;
            background: var(--bg-card);
            border-radius: var(--border-radius-sm);
            box-shadow: 0 5px 15px var(--shadow-hover);
            z-index: 1000;
            max-height: 250px;
            overflow-y: auto;
            display: none;
            border: 1px solid var(--border-color);
        }

        .search-suggestions.show { display: block; animation: fadeIn 0.3s ease; }

        .suggestion-item {
            padding: 10px 15px;
            cursor: pointer;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            gap: 10px;
            transition: var(--transition);
            font-size: 13px;
        }

        .suggestion-item:hover { background: var(--bg-secondary); }
        .suggestion-item i { color: var(--primary); width: 18px; font-size: 14px; }
        .suggestion-item small { color: var(--text-muted); margin-left: auto; font-size: 11px; }

        .theme-switcher, .notification-btn {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: var(--bg-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            color: var(--text-primary);
            position: relative;
            border: 1px solid var(--border-color);
            font-size: 16px;
            flex-shrink: 0;
            touch-action: manipulation;
        }

        .theme-switcher:hover, .notification-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px var(--shadow-hover);
        }

        .notification-badge {
            position: absolute;
            top: -5px; right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }

        .notification-container { position: relative; }

        .notification-dropdown {
            position: absolute;
            top: 50px; right: 0;
            width: 320px;
            background: var(--bg-card);
            border-radius: var(--border-radius);
            box-shadow: 0 10px 30px var(--shadow-hover);
            z-index: 1000;
            display: none;
            border: 1px solid var(--border-color);
        }

        .notification-dropdown.show { display: block; animation: slideDown 0.3s ease; }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .notification-header {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            font-weight: 600;
            background: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 14px;
        }

        .notification-header button {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            cursor: pointer;
            transition: var(--transition);
        }

        .notification-header button:hover { background: rgba(255,255,255,0.3); }

        .notification-list { max-height: 300px; overflow-y: auto; }

        .notification-item {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            transition: var(--transition);
            cursor: pointer;
        }

        .notification-item:hover { background: var(--bg-secondary); }
        .notification-item.unread { background: var(--info-bg); border-left: 3px solid var(--primary); }
        .notification-item strong { display: block; margin-bottom: 3px; color: var(--text-primary); font-size: 13px; }
        .notification-item p { margin-bottom: 3px; font-size: 12px; color: var(--text-secondary); }
        .notification-item small { color: var(--text-muted); font-size: 10px; }

        .notification-footer {
            padding: 8px;
            text-align: center;
            border-top: 1px solid var(--border-color);
        }

        .notification-footer a { color: var(--primary); text-decoration: none; font-size: 12px; }

        /* ============================================
           QUICK ACTIONS
           ============================================ */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 12px;
            margin-bottom: 25px;
        }

        .action-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 15px 10px;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
            border: 1px solid var(--border-color);
            min-height: 110px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 8px;
            touch-action: manipulation;
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px var(--shadow-hover);
            border-color: var(--primary);
        }

        .action-card:active { transform: scale(0.98); }
        .action-card i { font-size: 24px; color: var(--primary); }
        .action-card span { display: block; font-weight: 500; color: var(--text-primary); font-size: 13px; }
        .action-card small { color: var(--text-muted); font-size: 11px; }

        /* ============================================
           DASHBOARD CARDS
           ============================================ */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 18px;
            box-shadow: 0 5px 15px var(--shadow-color);
            transition: var(--transition);
            border-left: 4px solid transparent;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px var(--shadow-hover); }
        .stat-card.primary { border-left-color: var(--primary); }
        .stat-card.success { border-left-color: var(--secondary); }
        .stat-card.warning { border-left-color: var(--warning); }
        .stat-card.danger { border-left-color: var(--danger); }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
        }

        .stat-card.primary .stat-icon { background: var(--info-bg); color: var(--primary); }
        .stat-card.success .stat-icon { background: var(--success-bg); color: var(--secondary); }
        .stat-card.warning .stat-icon { background: var(--warning-bg); color: var(--warning); }
        .stat-card.danger .stat-icon { background: var(--danger-bg); color: var(--danger); }

        .stat-content { flex: 1; min-width: 0; }
        .stat-label { color: var(--text-muted); font-size: 13px; margin-bottom: 3px; }
        .stat-value { font-size: 24px; font-weight: 700; color: var(--text-primary); line-height: 1.2; }

        .stat-change {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            margin-top: 3px;
            flex-wrap: wrap;
        }

        .stat-change.positive { color: var(--secondary); }
        .stat-change.negative { color: var(--danger); }

        /* ============================================
           CHARTS
           ============================================ */
        .charts-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .chart-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 18px;
            box-shadow: 0 5px 15px var(--shadow-color);
            border: 1px solid var(--border-color);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            gap: 10px;
            flex-wrap: wrap;
        }

        .chart-title { font-size: 15px; font-weight: 600; color: var(--text-primary); margin: 0; }
        .chart-title i { color: var(--primary); margin-right: 6px; }

        .chart-period {
            padding: 6px 10px;
            border: 1px solid var(--border-color);
            border-radius: 20px;
            background: transparent;
            color: var(--text-primary);
            cursor: pointer;
            transition: var(--transition);
            font-size: 12px;
            min-height: 36px;
        }

        .chart-period:hover { background: var(--bg-secondary); }

        .chart-container { position: relative; height: 220px; }

        /* ============================================
           TABLES
           ============================================ */
        .table-container {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 18px;
            box-shadow: 0 5px 15px var(--shadow-color);
            margin-bottom: 25px;
            border: 1px solid var(--border-color);
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            gap: 12px;
            flex-wrap: wrap;
        }

        .table-title { font-size: 16px; font-weight: 600; color: var(--text-primary); margin: 0; display: flex; align-items: center; gap: 8px; }
        .table-title i { color: var(--primary); }

        .table-actions { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }

        .btn {
            padding: 10px 16px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3); }
        .btn-success { background: var(--secondary); color: white; }
        .btn-success:hover { background: var(--secondary-dark); transform: translateY(-2px); }
        .btn-warning { background: var(--warning); color: #212529; }
        .btn-warning:hover { background: var(--warning-dark); transform: translateY(-2px); }
        .btn-outline { background: transparent; border: 1px solid var(--border-color); color: var(--text-primary); }
        .btn-outline:hover { background: var(--bg-secondary); }
        .btn-sm { padding: 6px 12px; font-size: 12px; min-height: 36px; }

        .table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; margin-bottom: 15px; }
        table { width: 100%; border-collapse: collapse; }

        th {
            text-align: left;
            padding: 12px;
            font-weight: 600;
            color: var(--text-primary);
            background: var(--bg-secondary);
            border-bottom: 2px solid var(--border-color);
            font-size: 13px;
            white-space: nowrap;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
            font-size: 13px;
        }

        tr:hover { background: var(--bg-secondary); }

        .product-info { display: flex; align-items: center; gap: 8px; min-width: 0; }
        .product-thumb { width: 32px; height: 32px; border-radius: 6px; object-fit: cover; border: 1px solid var(--border-color); flex-shrink: 0; }

        .badge {
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
            display: inline-block;
            white-space: nowrap;
        }

        .badge-success { background: var(--success-bg); color: var(--success-text); }
        .badge-warning { background: var(--warning-bg); color: var(--warning-text); }
        .badge-danger { background: var(--danger-bg); color: var(--danger-text); }
        .badge-info { background: var(--info-bg); color: var(--info-text); }

        .stock-indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 5px;
        }

        .stock-critical { background: var(--danger); box-shadow: 0 0 0 2px var(--danger-bg); }
        .stock-low { background: var(--warning); box-shadow: 0 0 0 2px var(--warning-bg); }
        .stock-good { background: var(--secondary); box-shadow: 0 0 0 2px var(--success-bg); }
        .stock-normal { background: var(--primary); box-shadow: 0 0 0 2px var(--info-bg); }

        .action-buttons { display: flex; gap: 4px; flex-wrap: wrap; }

        .icon-btn {
            width: 34px;
            height: 34px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 13px;
            flex-shrink: 0;
            touch-action: manipulation;
        }

        .icon-btn.view { background: var(--info); }
        .icon-btn.edit { background: var(--primary); }
        .icon-btn.delete { background: var(--danger); }
        .icon-btn.qr { background: #6f42c1; }
        .icon-btn.barcode { background: #fd7e14; }
        .icon-btn:hover { transform: translateY(-2px); filter: brightness(1.1); }

        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid var(--border-color);
            gap: 12px;
            flex-wrap: wrap;
        }

        .pagination-info { color: var(--text-muted); font-size: 13px; }
        .pagination { display: flex; gap: 4px; list-style: none; padding: 0; margin: 0; flex-wrap: wrap; }

        .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 40px;
            height: 40px;
            padding: 0 10px;
            border-radius: 6px;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            font-size: 13px;
            touch-action: manipulation;
        }

        .page-link:hover, .page-item.active .page-link {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.disabled .page-link { opacity: 0.5; cursor: not-allowed; }

        /* ============================================
           MODALES
           ============================================ */
        .modal-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.55);
            display: none;
            visibility: hidden;
            opacity: 0;
            align-items: center;
            justify-content: center;
            z-index: 99999;
            backdrop-filter: blur(5px);
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
        }

        .modal-overlay.show {
            display: flex !important;
            visibility: visible !important;
            opacity: 1 !important;
        }

        #productModal.show,
        #supplierModal.show,
        #qrModal.show,
        #barcodeModal.show {
            display: flex !important;
            visibility: visible !important;
            opacity: 1 !important;
            z-index: 99999 !important;
        }

        #productModal.show .modal,
        #supplierModal.show .modal,
        #qrModal.show .modal,
        #barcodeModal.show .modal {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            z-index: 100000 !important;
            transform: none !important;
        }

        .modal {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            width: 90%;
            max-width: 550px;
            max-height: calc(100vh - 40px);
            max-height: calc(100dvh - 40px);
            overflow-y: auto;
            box-shadow: 0 20px 40px rgba(0,0,0,0.4);
            z-index: 100000;
            position: relative;
            color: var(--text-primary);
            -webkit-overflow-scrolling: touch;
        }

        .modal-lg { max-width: 700px; }
        .modal-sm { max-width: 350px; }

        .modal-header {
            padding: 15px 18px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--primary);
            color: white;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .modal-header h5 { margin: 0; display: flex; align-items: center; gap: 8px; color: white; font-size: 16px; }

        .modal-close {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            font-size: 14px;
            flex-shrink: 0;
            touch-action: manipulation;
        }

        .modal-close:hover { background: rgba(255,255,255,0.3); transform: rotate(90deg); }

        .modal-body { padding: 18px; color: var(--text-primary); }

        .modal-footer {
            padding: 15px 18px;
            border-top: 1px solid var(--border-color);
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            flex-wrap: wrap;
            position: sticky;
            bottom: 0;
            background: var(--bg-card);
            z-index: 10;
        }

        .form-group { margin-bottom: 12px; }

        .form-label {
            display: block;
            margin-bottom: 4px;
            font-weight: 500;
            color: var(--text-primary);
            font-size: 13px;
        }

        .form-control {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--input-border);
            border-radius: 6px;
            background: var(--input-bg);
            color: var(--text-primary);
            transition: var(--transition);
            font-size: 16px;
            min-height: 44px;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px var(--input-focus);
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
        }

        /* ============================================
           TOAST
           ============================================ */
        .toast-container {
            position: fixed;
            top: calc(20px + var(--safe-top));
            right: calc(20px + var(--safe-right));
            left: 20px;
            z-index: 999999;
            display: flex;
            flex-direction: column;
            gap: 8px;
            pointer-events: none;
            align-items: flex-end;
        }

        .toast {
            background: var(--bg-card);
            border-radius: var(--border-radius-sm);
            padding: 12px 15px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 5px 15px var(--shadow-hover);
            border-left: 4px solid;
            min-width: 250px;
            max-width: 400px;
            animation: slideInRight 0.3s ease;
            color: var(--text-primary);
            pointer-events: auto;
        }

        .toast.success { border-left-color: var(--secondary); }
        .toast.error { border-left-color: var(--danger); }
        .toast.warning { border-left-color: var(--warning); }
        .toast.info { border-left-color: var(--primary); }

        .toast i { font-size: 18px; flex-shrink: 0; }
        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        .toast.info i { color: var(--primary); }

        .toast-content { flex: 1; min-width: 0; }
        .toast-title { font-weight: 600; margin-bottom: 2px; font-size: 13px; }
        .toast-message { font-size: 12px; color: var(--text-muted); }

        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        /* ============================================
           QR / BARCODE
           ============================================ */
        .code-container { text-align: center; padding: 15px; }
        .code-container svg, .code-container canvas { max-width: 100%; height: auto; max-height: 150px; }
        .code-actions { display: flex; gap: 8px; justify-content: center; margin-top: 15px; flex-wrap: wrap; }

        /* ============================================
           LOADING
           ============================================ */
        .loading-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 999999;
        }

        .loading-overlay.active { display: flex; }

        .loading-spinner {
            width: 40px;
            height: 40px;
            border: 3px solid var(--bg-card);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        /* ============================================
           EMPTY STATE
           ============================================ */
        .empty-state { text-align: center; padding: 30px; color: var(--text-muted); }
        .empty-state i { font-size: 40px; margin-bottom: 12px; }
        .empty-state h4 { margin-bottom: 8px; font-size: 16px; }
        .empty-state p { font-size: 13px; }

        /* ============================================
           TOOLTIP
           ============================================ */
        [data-tooltip] { position: relative; }

        [data-tooltip]:before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 4px 8px;
            background: var(--darker);
            color: white;
            border-radius: 4px;
            font-size: 11px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 1000;
            pointer-events: none;
        }

        [data-tooltip]:hover:before {
            opacity: 1;
            visibility: visible;
            bottom: 120%;
        }

        @media (hover: none) {
            [data-tooltip]:before { display: none; }
        }

        /* ============================================
           EXPORT OPTIONS
           ============================================ */
        .export-options {
            position: absolute;
            top: calc(100% + 4px); right: 0;
            background: var(--bg-card);
            border-radius: var(--border-radius-sm);
            box-shadow: 0 5px 15px var(--shadow-hover);
            z-index: 100;
            min-width: 140px;
            border: 1px solid var(--border-color);
        }

        .export-option {
            padding: 10px 14px;
            cursor: pointer;
            border-bottom: 1px solid var(--border-color);
            transition: var(--transition);
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .export-option:last-child { border-bottom: none; }
        .export-option:hover { background: var(--bg-secondary); }
        .export-option i { width: 16px; color: var(--primary); }

        /* ============================================
           MENU TOGGLE
           ============================================ */
        .menu-toggle {
            display: none;
            position: fixed;
            bottom: calc(20px + var(--safe-bottom));
            right: calc(20px + var(--safe-right));
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            border: none;
            cursor: pointer;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            z-index: 1200;
            box-shadow: 0 5px 15px var(--shadow-hover);
            transition: var(--transition);
            touch-action: manipulation;
            -webkit-tap-highlight-color: transparent;
        }

        .menu-toggle:hover { transform: scale(1.1); background: var(--primary-dark); }
        .menu-toggle:active { transform: scale(0.92); }

        /* ============================================
           RESPONSIVE - TABLET (≤1200px)
           ============================================ */
        @media (max-width: 1200px) {
            .charts-section { grid-template-columns: 1fr; }
            .dashboard-cards { grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); }
        }

        /* ============================================
           RESPONSIVE - TABLET (≤992px)
           ============================================ */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%) !important;
                width: 88vw;
                max-width: 320px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .sidebar.mobile-open { transform: translateX(0) !important; }
            .sidebar.collapsed { width: 88vw; }
            .sidebar.collapsed .menu-label,
            .sidebar.collapsed .logo span,
            .sidebar.collapsed .sidebar-menu a span,
            .sidebar.collapsed .logout-btn span { display: inline; }
            .sidebar.collapsed .sidebar-menu a { justify-content: flex-start; padding: 12px 16px; }
            .sidebar.collapsed .sidebar-header { justify-content: space-between; }
            .sidebar-close-btn { display: flex !important; }
            .sidebar .sidebar-toggle { display: none; }

            .main-content {
                margin-left: 0 !important;
                padding: 20px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .main-content.expanded { margin-left: 0 !important; }
            .menu-toggle { display: flex !important; }

            .header { flex-direction: column; align-items: stretch; gap: 14px; padding: 16px 20px; }
            .header-controls { justify-content: space-between; flex-wrap: wrap; gap: 8px; width: 100%; }
            .search-box { width: 100%; order: -1; }

            .notification-dropdown {
                position: fixed;
                top: auto;
                bottom: calc(90px + var(--safe-bottom));
                left: 16px;
                right: 16px;
                width: auto;
                max-width: 440px;
                margin: 0 auto;
            }

            .quick-actions { grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; }
            .action-card { min-height: 100px; padding: 12px 8px; }
            .action-card i { font-size: 22px; }

            .dashboard-cards { grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; }

            .table-header { flex-direction: column; align-items: stretch; gap: 12px; }
            .table-actions { justify-content: space-between; }
            .pagination-container { flex-direction: column; align-items: stretch; }
        }

        /* ============================================
           RESPONSIVE - MÓVIL (≤640px)
           ============================================ */
        @media (max-width: 640px) {
            .main-content {
                padding: 16px;
                padding-top: calc(16px + var(--safe-top));
                padding-bottom: calc(90px + var(--safe-bottom));
            }

            .sidebar {
                width: 88vw;
                max-width: 320px;
                padding: 20px 12px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }

            .header { padding: 14px 16px; margin-bottom: 18px; border-radius: var(--border-radius-sm); gap: 10px; }
            .page-title { font-size: 17px; }
            .page-title i { font-size: 16px; }
            .header-controls { gap: 6px; }
            .theme-switcher, .notification-btn { width: 40px; height: 40px; font-size: 14px; }
            .search-box input { font-size: 16px; min-height: 42px; }

            .quick-actions { grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 18px; }
            .action-card { min-height: 90px; padding: 12px 8px; gap: 6px; }
            .action-card i { font-size: 20px; }
            .action-card span { font-size: 12px; }
            .action-card small { font-size: 10px; }

            .dashboard-cards { grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 18px; }
            .stat-card { padding: 12px; gap: 8px; }
            .stat-icon { width: 40px; height: 40px; font-size: 16px; }
            .stat-value { font-size: 18px; }
            .stat-label { font-size: 11px; }
            .stat-change { font-size: 10px; }

            .charts-section { gap: 12px; margin-bottom: 18px; }
            .chart-card { padding: 14px; }
            .chart-title { font-size: 13px; }
            .chart-container { height: 200px; }
            .chart-period { font-size: 11px; padding: 4px 8px; min-height: 32px; }

            .table-container { padding: 14px; border-radius: var(--border-radius-sm); margin-bottom: 18px; }
            .table-title { font-size: 14px; }
            .table-actions { gap: 6px; }
            .table-actions .btn { padding: 8px 12px; font-size: 12px; min-height: 40px; }

            table { min-width: 700px; }
            th, td { padding: 10px 12px; font-size: 12px; }
            th { font-size: 11px; }

            .action-buttons { gap: 3px; }
            .icon-btn { width: 32px; height: 32px; font-size: 12px; }

            .pagination-info { font-size: 12px; text-align: center; }
            .page-link { min-width: 36px; height: 36px; padding: 0 8px; font-size: 12px; }

            .form-row { grid-template-columns: 1fr; }

            .modal-overlay {
                padding: 0;
                padding-top: calc(40px + var(--safe-top));
                align-items: flex-end;
            }
            .modal {
                max-width: 100%;
                width: 100%;
                max-height: calc(100dvh - 40px);
                border-radius: var(--border-radius-lg) var(--border-radius-lg) 0 0;
            }
            .modal-header {
                padding: 16px 18px;
                border-radius: var(--border-radius-lg) var(--border-radius-lg) 0 0;
            }
            .modal-header h5 { font-size: 15px; }
            .modal-body { padding: 16px; }
            .modal-footer {
                padding: 14px 18px calc(14px + var(--safe-bottom));
                flex-direction: column-reverse;
            }
            .modal-footer .btn { width: 100%; }

            .toast-container { top: calc(12px + var(--safe-top)); right: 12px; left: 12px; align-items: stretch; }
            .toast { min-width: 0; max-width: 100%; width: 100%; padding: 12px 14px; font-size: 13px; }

            .empty-state { padding: 24px 16px; }
            .empty-state i { font-size: 36px; }
            .empty-state h4 { font-size: 14px; }
            .empty-state p { font-size: 12px; }

            .menu-toggle { width: 48px; height: 48px; font-size: 18px; }

            .export-options { right: auto; left: 0; min-width: 130px; }
        }

        /* ============================================
           RESPONSIVE - MÓVIL PEQUEÑO (≤380px)
           ============================================ */
        @media (max-width: 380px) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); padding-bottom: calc(80px + var(--safe-bottom)); }
            .page-title { font-size: 15px; }
            .theme-switcher, .notification-btn { width: 36px; height: 36px; font-size: 13px; }
            .quick-actions { grid-template-columns: repeat(2, 1fr); gap: 8px; }
            .action-card { min-height: 80px; padding: 10px 6px; }
            .action-card i { font-size: 18px; }
            .action-card span { font-size: 11px; }
            .action-card small { display: none; }
            .dashboard-cards { grid-template-columns: 1fr; }
            .chart-container { height: 180px; }
        }

        /* ============================================
           LANDSCAPE MÓVIL
           ============================================ */
        @media (max-height: 500px) and (orientation: landscape) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); }
            .header { padding: 10px 16px; margin-bottom: 12px; }
            .chart-container { height: 180px; }
            .sidebar { padding: 16px 12px; padding-top: calc(16px + var(--safe-top)); }
            .quick-actions { grid-template-columns: repeat(4, 1fr); }
            .action-card { min-height: 70px; padding: 8px 4px; }
            .action-card small { display: none; }
            .modal { max-height: 95dvh; }
        }

        /* ============================================
           PANTALLAS GRANDES
           ============================================ */
        @media (min-width: 1440px) {
            .main-content { padding: 30px; }
            .dashboard-cards { grid-template-columns: repeat(4, 1fr); }
            .chart-container { height: 280px; }
        }
        @media (min-width: 1920px) {
            .main-content { padding: 40px 60px; max-width: 1800px; margin-left: auto; margin-right: auto; }
        }

        /* ============================================
           TOUCH
           ============================================ */
        @media (hover: none) {
            .action-card:hover { transform: none; box-shadow: none; border-color: var(--border-color); }
            .stat-card:hover { transform: none; }
            .theme-switcher:hover, .notification-btn:hover { transform: none; box-shadow: none; }
            .icon-btn:hover { transform: none; filter: none; }
            .sidebar-menu a:hover { transform: none; background: transparent; }
            .sidebar-menu a.active:hover { background: var(--primary); }
            .btn:hover { transform: none; box-shadow: none; }
            .page-link:hover { background: var(--bg-secondary); color: var(--text-primary); border-color: var(--border-color); }
            .page-item.active .page-link:hover { background: var(--primary); color: white; }
            .chart-period:hover { background: transparent; }
        }

        /* ============================================
           REDUCED MOTION
           ============================================ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        /* ============================================
           PRINT
           ============================================ */
        @media print {
            .sidebar, .header, .menu-toggle, .quick-actions, .charts-section,
            .table-actions, .action-buttons, .pagination-container,
            .notification-container, .search-box, .theme-switcher,
            .chart-header, .header-controls { display: none !important; }
            .main-content { margin-left: 0 !important; padding: 0 !important; }
            .stat-card { box-shadow: none; border: 1px solid #ddd; page-break-inside: avoid; }
            .table-container { box-shadow: none; border: 1px solid #ddd; }
            table { min-width: 0 !important; }
            .chart-card { page-break-inside: avoid; }
        }
    </style>
</head>
<body>
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner"></div>
    </div>

    <div class="app-container">
        <!-- OVERLAY MÓVIL -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-brain"></i></div>
                    <span class="system-name-display">SmartStock AI</span>
                </div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú" type="button">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a href="#" data-view="dashboard"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
                    <li><a href="#" data-view="inventory" class="active"><i class="fas fa-boxes-stacked"></i> <span>Inventario</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Trassanciones.php"><i class="fas fa-right-left"></i> <span>Transacciones</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-column"></i> <span>Reportes</span></a></li>
                </ul>

                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/clientes.php"><i class="fas fa-address-book"></i> <span>Clientes</span></a></li>
                    <li><a href="#" data-view="suppliers"><i class="fas fa-truck-field"></i> <span>Proveedores</span></a></li>
                </ul>

                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users-gear"></i> <span>Usuarios</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-halved"></i> <span>Seguridad</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-circle-user"></i> <span>Mi Perfil</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-sliders"></i> <span>Configuración</span></a></li>
                </ul>
            </div>

            <div class="sidebar-footer">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    <span>Cerrar Sesión</span>
                </button>
            </div>
        </aside>

        <div class="main-content" id="mainContent">
            <div class="header">
                <h1 class="page-title" id="pageTitle">
                    <i class="fas fa-home"></i>
                    Dashboard
                </h1>

                <div class="header-controls">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" id="globalSearch" placeholder="Buscar productos...">
                        <div class="search-suggestions" id="searchSuggestions"></div>
                    </div>
                    <div class="theme-switcher" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notification-container">
                        <div class="notification-btn" id="notificationBtn">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge" id="notificationCount">0</span>
                        </div>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-header">
                                <span>Notificaciones</span>
                                <button id="markAllRead">Marcar todas</button>
                            </div>
                            <div class="notification-list" id="notificationList"></div>
                            <div class="notification-footer">
                                <a href="#" id="viewAllNotifications">Ver todas</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="dashboardView">
                <div class="quick-actions">
                    <div class="action-card" id="quickAddProduct">
                        <i class="fas fa-plus-circle"></i>
                        <span>Nuevo Producto</span>
                        <small>Agregar al inventario</small>
                    </div>
                    <div class="action-card" id="quickScanQR">
                        <i class="fas fa-qrcode"></i>
                        <span>Escanear QR</span>
                        <small>Buscar producto</small>
                    </div>
                    <div class="action-card" id="quickGenerateReport">
                        <i class="fas fa-file-pdf"></i>
                        <span>Generar Reporte</span>
                        <small>Exportar datos</small>
                    </div>
                    <div class="action-card" id="quickCheckStock">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>Ver Stock Bajo</span>
                        <small>Revisar alertas</small>
                    </div>
                </div>

                <div class="dashboard-cards">
                    <div class="stat-card primary">
                        <div class="stat-icon"><i class="fas fa-boxes"></i></div>
                        <div class="stat-content">
                            <div class="stat-label">Total Productos</div>
                            <div class="stat-value" id="totalProducts">0</div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+12% este mes</span>
                            </div>
                        </div>
                    </div>
                    <div class="stat-card success">
                        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                        <div class="stat-content">
                            <div class="stat-label">En Stock</div>
                            <div class="stat-value" id="inStockCount">0</div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+8% vs ayer</span>
                            </div>
                        </div>
                    </div>
                    <div class="stat-card warning">
                        <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                        <div class="stat-content">
                            <div class="stat-label">Stock Bajo</div>
                            <div class="stat-value" id="lowStockCount">0</div>
                            <div class="stat-change negative">
                                <i class="fas fa-arrow-up"></i>
                                <span>+3 nuevos</span>
                            </div>
                        </div>
                    </div>
                    <div class="stat-card danger">
                        <div class="stat-icon"><i class="fas fa-times-circle"></i></div>
                        <div class="stat-content">
                            <div class="stat-label">Agotados</div>
                            <div class="stat-value" id="outOfStockCount">0</div>
                            <div class="stat-change">
                                <i class="fas fa-minus"></i>
                                <span>Sin cambios</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="charts-section">
                    <div class="chart-card">
                        <div class="chart-header">
                            <h5 class="chart-title"><i class="fas fa-chart-pie"></i> Distribución por Categoría</h5>
                            <select class="chart-period" id="categoryPeriod">
                                <option value="all">Todos</option>
                                <option value="month">Este mes</option>
                                <option value="year">Este año</option>
                            </select>
                        </div>
                        <div class="chart-container"><canvas id="categoryChart"></canvas></div>
                    </div>
                    <div class="chart-card">
                        <div class="chart-header">
                            <h5 class="chart-title"><i class="fas fa-chart-line"></i> Movimiento de Stock</h5>
                            <select class="chart-period" id="movementPeriod">
                                <option value="7">7 días</option>
                                <option value="30">30 días</option>
                                <option value="90">90 días</option>
                            </select>
                        </div>
                        <div class="chart-container"><canvas id="movementChart"></canvas></div>
                    </div>
                </div>

                <div class="table-container">
                    <div class="table-header">
                        <h5 class="table-title"><i class="fas fa-clock"></i> Productos Recientes</h5>
                        <div class="table-actions">
                            <button class="btn btn-outline" id="refreshRecent"><i class="fas fa-sync-alt"></i></button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Precio</th>
                                    <th>Stock</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="recentProductsTable"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="inventoryView" style="display: none;">
                <div class="table-container">
                    <div class="table-header">
                        <h5 class="table-title"><i class="fas fa-boxes"></i> Inventario Completo</h5>
                        <div class="table-actions">
                            <button class="btn btn-success" id="importBtn"><i class="fas fa-file-import"></i> Importar</button>
                            <input type="file" id="importFileInput" accept=".json,application/json" hidden>
                            <div style="position: relative;">
                                <button class="btn btn-warning" id="exportDropdownBtn"><i class="fas fa-download"></i> Exportar</button>
                                <div class="export-options" id="exportOptions" style="display: none;">
                                    <div class="export-option" data-format="pdf"><i class="fas fa-file-pdf"></i> PDF</div>
                                    <div class="export-option" data-format="excel"><i class="fas fa-file-excel"></i> Excel</div>
                                    <div class="export-option" data-format="csv"><i class="fas fa-file-csv"></i> CSV</div>
                                    <div class="export-option" data-format="json"><i class="fas fa-file-code"></i> JSON</div>
                                </div>
                            </div>
                            <button class="btn btn-primary" id="newProductBtn"><i class="fas fa-plus"></i> Nuevo Producto</button>
                        </div>
                    </div>

                    <div style="margin-bottom: 15px;">
                        <div class="form-row">
                            <div class="form-group">
                                <input type="text" class="form-control" id="inventorySearch" placeholder="Buscar productos...">
                            </div>
                            <div class="form-group">
                                <select class="form-control" id="inventoryCategoryFilter">
                                    <option value="all">Todas las categorías</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="form-control" id="inventoryStatusFilter">
                                    <option value="all">Todos los estados</option>
                                    <option value="En stock">En stock</option>
                                    <option value="Stock bajo">Stock bajo</option>
                                    <option value="Stock crítico">Stock crítico</option>
                                    <option value="Agotado">Agotado</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-outline w-100" id="clearInventoryFilters"><i class="fas fa-times"></i> Limpiar</button>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Producto</th>
                                    <th>Categoría</th>
                                    <th>Precio</th>
                                    <th>Stock</th>
                                    <th>Ubicación</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="inventoryTableBody"></tbody>
                        </table>
                    </div>

                    <div class="pagination-container">
                        <div class="pagination-info" id="inventoryPaginationInfo"></div>
                        <ul class="pagination" id="inventoryPagination"></ul>
                    </div>
                </div>
            </div>

            <div id="suppliersView" style="display: none;">
                <div class="table-container">
                    <div class="table-header">
                        <h5 class="table-title"><i class="fas fa-truck"></i> Proveedores</h5>
                        <div class="table-actions">
                            <button class="btn btn-primary" id="newSupplierBtn"><i class="fas fa-plus"></i> Nuevo Proveedor</button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Contacto</th>
                                    <th>Teléfono</th>
                                    <th>Email</th>
                                    <th>Productos</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="suppliersTableBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="reportsView" style="display: none;">
                <div class="charts-section">
                    <div class="chart-card">
                        <div class="chart-header">
                            <h5 class="chart-title"><i class="fas fa-chart-bar"></i> Valor por Categoría</h5>
                        </div>
                        <div class="chart-container"><canvas id="valueCategoryChart"></canvas></div>
                    </div>
                    <div class="chart-card">
                        <div class="chart-header">
                            <h5 class="chart-title"><i class="fas fa-chart-line"></i> Tendencia de Ventas</h5>
                        </div>
                        <div class="chart-container"><canvas id="salesTrendChart"></canvas></div>
                    </div>
                </div>

                <div class="dashboard-cards">
                    <div class="stat-card primary">
                        <div class="stat-content">
                            <div class="stat-value" id="reportTotalValue">$0</div>
                            <div class="stat-label">Valor Total</div>
                        </div>
                    </div>
                    <div class="stat-card success">
                        <div class="stat-content">
                            <div class="stat-value" id="reportAvgPrice">$0</div>
                            <div class="stat-label">Precio Promedio</div>
                        </div>
                    </div>
                    <div class="stat-card warning">
                        <div class="stat-content">
                            <div class="stat-value" id="reportTotalItems">0</div>
                            <div class="stat-label">Total Items</div>
                        </div>
                    </div>
                    <div class="stat-card danger">
                        <div class="stat-content">
                            <div class="stat-value" id="reportLowStock">0</div>
                            <div class="stat-label">Stock Bajo</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal producto -->
    <div class="modal-overlay" id="productModal">
        <div class="modal modal-lg">
            <div class="modal-header">
                <h5 id="productModalTitle"><i class="fas fa-plus-circle"></i> Nuevo Producto</h5>
                <button class="modal-close" onclick="closeModal('productModal')" aria-label="Cerrar"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <form id="productForm" onsubmit="return false;">
                    <input type="hidden" id="productId">

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Nombre del Producto *</label>
                            <input type="text" class="form-control" id="productName" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">SKU</label>
                            <input type="text" class="form-control" id="productSKU">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Categoría *</label>
                            <select class="form-control" id="productCategory" required>
                                <option value="">Seleccionar</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Proveedor</label>
                            <select class="form-control" id="productSupplier">
                                <option value="">Seleccionar</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Precio *</label>
                            <input type="number" class="form-control" id="productPrice" step="0.01" min="0" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Costo</label>
                            <input type="number" class="form-control" id="productCost" step="0.01" min="0">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Stock *</label>
                            <input type="number" class="form-control" id="productStock" min="0" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Stock Mínimo</label>
                            <input type="number" class="form-control" id="productMinStock" min="0" value="5">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Ubicación</label>
                            <select class="form-control" id="productLocation">
                                <option value="">Seleccionar</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Descripción</label>
                        <textarea class="form-control" id="productDescription" rows="2"></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Imagen URL</label>
                        <input type="url" class="form-control" id="productImage" placeholder="https://...">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="closeModal('productModal')">Cancelar</button>
                <button class="btn btn-primary" id="saveProduct" type="button">Guardar Producto</button>
            </div>
        </div>
    </div>

    <!-- Modal proveedor -->
    <div class="modal-overlay" id="supplierModal">
        <div class="modal">
            <div class="modal-header">
                <h5 id="supplierModalTitle"><i class="fas fa-truck"></i> Nuevo Proveedor</h5>
                <button class="modal-close" onclick="closeModal('supplierModal')" aria-label="Cerrar"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <form id="supplierForm" onsubmit="return false;">
                    <input type="hidden" id="supplierId">
                    <div class="form-group">
                        <label class="form-label">Nombre *</label>
                        <input type="text" class="form-control" id="supplierName" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Contacto</label>
                        <input type="text" class="form-control" id="supplierContact">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Teléfono</label>
                            <input type="text" class="form-control" id="supplierPhone">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" id="supplierEmail">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Dirección</label>
                        <textarea class="form-control" id="supplierAddress" rows="2"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="closeModal('supplierModal')">Cancelar</button>
                <button class="btn btn-primary" id="saveSupplier" type="button">Guardar Proveedor</button>
            </div>
        </div>
    </div>

    <!-- Modal QR -->
    <div class="modal-overlay" id="qrModal">
        <div class="modal modal-sm">
            <div class="modal-header">
                <h5><i class="fas fa-qrcode"></i> Código QR</h5>
                <button class="modal-close" onclick="closeModal('qrModal')" aria-label="Cerrar"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="code-container">
                    <div id="qrcode"></div>
                    <p id="qrProductName" style="font-weight:bold; margin-top:8px;"></p>
                    <div class="code-actions">
                        <button class="btn btn-primary" id="downloadQR"><i class="fas fa-download"></i> Descargar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal barcode -->
    <div class="modal-overlay" id="barcodeModal">
        <div class="modal modal-sm">
            <div class="modal-header">
                <h5><i class="fas fa-barcode"></i> Código de Barras</h5>
                <button class="modal-close" onclick="closeModal('barcodeModal')" aria-label="Cerrar"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="code-container">
                    <svg id="barcode"></svg>
                    <p id="barcodeProductName" style="font-weight:bold; margin-top:8px;"></p>
                    <div class="code-actions">
                        <button class="btn btn-success" id="downloadBarcode"><i class="fas fa-download"></i> Descargar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle" aria-label="Abrir menú" type="button"><i class="fas fa-bars"></i></button>
    <div class="toast-container" id="toastContainer"></div>

    <script>
        // ============================================
        // STORAGE API
        // ============================================
        const StorageAPI = {
            getProducts() {
                try {
                    const raw = localStorage.getItem('products');
                    const data = raw ? JSON.parse(raw) : [];
                    return Array.isArray(data) ? data : [];
                } catch (e) { return []; }
            },
            setProducts(products) {
                try { localStorage.setItem('products', JSON.stringify(products)); return true; }
                catch (e) { return false; }
            },
            getSuppliers() {
                try {
                    const raw = localStorage.getItem('suppliers');
                    const data = raw ? JSON.parse(raw) : [];
                    return Array.isArray(data) ? data : [];
                } catch (e) { return []; }
            },
            setSuppliers(suppliers) {
                try { localStorage.setItem('suppliers', JSON.stringify(suppliers)); return true; }
                catch (e) { return false; }
            },
            getNotifications() {
                try {
                    const raw = localStorage.getItem('notifications');
                    const data = raw ? JSON.parse(raw) : [];
                    return Array.isArray(data) ? data : [];
                } catch (e) { return []; }
            },
            setNotifications(notifications) {
                try { localStorage.setItem('notifications', JSON.stringify(notifications)); return true; }
                catch (e) { return false; }
            },
            sanitizeProducts(products) {
                return products.map(p => {
                    if (p.image && p.image.includes('via.placeholder.com')) p.image = '';
                    return p;
                });
            }
        };

        // ============================================
        // PLACEHOLDER SVG
        // ============================================
        function productThumb(product) {
            if (product && product.image && product.image.trim() && !product.image.includes('via.placeholder.com')) {
                return product.image;
            }
            const name = (product && product.name) ? product.name : '?';
            const initial = name.trim().charAt(0).toUpperCase() || '?';
            const colors = ['#3a5ec7', '#28a745', '#dc3545', '#ffc107', '#6f42c1', '#17a2b8', '#fd7e14'];
            const color = colors[(initial.charCodeAt(0) || 0) % colors.length];
            const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><rect width="40" height="40" rx="6" fill="${color}"/><text x="50%" y="54%" text-anchor="middle" dominant-baseline="middle" font-family="Arial, sans-serif" font-size="18" font-weight="bold" fill="#ffffff">${initial}</text></svg>`;
            return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
        }

        // ============================================
        // RESPONSIVE STATE + MENÚ MÓVIL
        // ============================================
        const APP_STATE = {
            isMobile: window.matchMedia('(max-width: 992px)').matches,
            isTouch: ('ontouchstart' in window) || (navigator.maxTouchPoints > 0)
        };

        function openMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.add('mobile-open');
            if (ov) ov.classList.add('active');
            document.body.style.overflow = 'hidden';
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(5);
        }

        function closeMobileSidebar() {
            const sb = document.getElementById('sidebar');
            const ov = document.getElementById('sidebarOverlay');
            if (sb) sb.classList.remove('mobile-open');
            if (ov) ov.classList.remove('active');
            document.body.style.overflow = '';
        }

        function setupMobileSidebar() {
            const overlay = document.getElementById('sidebarOverlay');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.getElementById('menuToggle');

            console.log('🔍 setupMobileSidebar:');
            console.log('  - overlay:', !!overlay);
            console.log('  - closeBtn:', !!closeBtn);
            console.log('  - sidebar:', !!sidebar);
            console.log('  - menuToggle:', !!menuToggle);

            if (overlay) overlay.addEventListener('click', closeMobileSidebar);
            if (closeBtn) closeBtn.addEventListener('click', closeMobileSidebar);

            if (menuToggle) {
                // Clonar para quitar listeners previos
                const newToggle = menuToggle.cloneNode(true);
                menuToggle.parentNode.replaceChild(newToggle, menuToggle);

                newToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('🍔 Menú clickeado');
                    const sb = document.getElementById('sidebar');
                    if (sb && sb.classList.contains('mobile-open')) {
                        closeMobileSidebar();
                    } else {
                        openMobileSidebar();
                    }
                });
            } else {
                console.error('❌ menuToggle NO ENCONTRADO');
            }

            // Swipe para cerrar
            if (sidebar) {
                let touchStartX = 0, touchCurrentX = 0;
                sidebar.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
                sidebar.addEventListener('touchmove', (e) => {
                    touchCurrentX = e.touches[0].clientX;
                    const diff = touchCurrentX - touchStartX;
                    if (diff < 0 && diff > -100) sidebar.style.transform = `translateX(${diff}px)`;
                }, { passive: true });
                sidebar.addEventListener('touchend', () => {
                    const diff = touchCurrentX - touchStartX;
                    sidebar.style.transform = '';
                    if (diff < -60) closeMobileSidebar();
                    touchStartX = 0; touchCurrentX = 0;
                });
            }

            // Cerrar al navegar
            document.querySelectorAll('.sidebar-menu a').forEach(a => {
                a.addEventListener('click', () => {
                    if (window.matchMedia('(max-width: 992px)').matches) closeMobileSidebar();
                });
            });

            // Cerrar con Escape
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') closeMobileSidebar();
            });

            // Detectar resize
            window.addEventListener('resize', () => {
                if (window.matchMedia('(min-width: 993px)').matches) closeMobileSidebar();
            });
        }

        // ============================================
        // CLASE PRINCIPAL
        // ============================================
        class SmartStockManager {
            constructor() {
                this.products = StorageAPI.sanitizeProducts(StorageAPI.getProducts());
                this.suppliers = StorageAPI.getSuppliers();
                this.categories = ['Electrónicos', 'Ropa', 'Hogar', 'Deportes', 'Alimentos', 'Juguetes'];
                this.locations = ['Almacén A', 'Almacén B', 'Tienda Central', 'Sucursal Norte'];
                this.notifications = StorageAPI.getNotifications();
                this.currentPage = 1;
                this.itemsPerPage = 8;
                this.filteredProducts = [];
                this.charts = {};

                try {
                    const savedCats = localStorage.getItem('categories');
                    if (savedCats) this.categories = JSON.parse(savedCats);
                    const savedLocs = localStorage.getItem('locations');
                    if (savedLocs) this.locations = JSON.parse(savedLocs);
                } catch (e) {}

                if (this.products.length === 0) this.initializeSampleProducts();
                if (this.suppliers.length === 0) this.initializeSampleSuppliers();

                this.saveProducts();
                this.filterProducts();
                this.checkStockAlerts();
            }

            initializeSampleProducts() {
                this.products = [
                    { id: 'PRD-001', name: 'Laptop HP Pavilion 15', category: 'Electrónicos', price: 850.00, cost: 700.00, stock: 15, minStock: 5, location: 'Almacén A', supplier: 'SUP-001', image: '', createdAt: '2024-01-15' },
                    { id: 'PRD-002', name: 'Smartphone Samsung Galaxy S23', category: 'Electrónicos', price: 899.99, cost: 750.00, stock: 8, minStock: 10, location: 'Tienda Central', supplier: 'SUP-001', image: '', createdAt: '2024-01-20' },
                    { id: 'PRD-003', name: 'Tablet iPad Air', category: 'Electrónicos', price: 699.00, cost: 550.00, stock: 12, minStock: 5, location: 'Almacén A', supplier: 'SUP-001', image: '', createdAt: '2024-02-01' },
                    { id: 'PRD-004', name: 'Monitor LG 27" 4K', category: 'Electrónicos', price: 349.99, cost: 280.00, stock: 5, minStock: 3, location: 'Almacén B', supplier: 'SUP-001', image: '', createdAt: '2024-02-05' },
                    { id: 'PRD-005', name: 'Auriculares Sony WH-1000XM4', category: 'Electrónicos', price: 299.99, cost: 220.00, stock: 20, minStock: 8, location: 'Tienda Central', supplier: 'SUP-001', image: '', createdAt: '2024-02-10' },
                    { id: 'PRD-006', name: 'Teclado Mecánico Logitech', category: 'Electrónicos', price: 89.99, cost: 60.00, stock: 25, minStock: 10, location: 'Almacén A', supplier: 'SUP-001', image: '', createdAt: '2024-02-12' },
                    { id: 'PRD-007', name: 'Mouse Inalámbrico Logitech', category: 'Electrónicos', price: 29.99, cost: 18.00, stock: 40, minStock: 15, location: 'Almacén A', supplier: 'SUP-001', image: '', createdAt: '2024-02-15' },
                    { id: 'PRD-008', name: 'Disco Duro Externo 1TB', category: 'Electrónicos', price: 59.99, cost: 40.00, stock: 18, minStock: 8, location: 'Almacén B', supplier: 'SUP-001', image: '', createdAt: '2024-02-18' },
                    { id: 'PRD-009', name: 'Cámara Web Logitech C920', category: 'Electrónicos', price: 79.99, cost: 55.00, stock: 12, minStock: 5, location: 'Almacén A', supplier: 'SUP-001', image: '', createdAt: '2024-02-20' },
                    { id: 'PRD-010', name: 'Router WiFi 6 TP-Link', category: 'Electrónicos', price: 129.99, cost: 90.00, stock: 7, minStock: 4, location: 'Almacén B', supplier: 'SUP-001', image: '', createdAt: '2024-02-22' },
                    { id: 'PRD-011', name: 'Smart TV Samsung 55" 4K', category: 'Electrónicos', price: 699.99, cost: 550.00, stock: 4, minStock: 2, location: 'Almacén A', supplier: 'SUP-001', image: '', createdAt: '2024-02-25' },
                    { id: 'PRD-012', name: 'Consola PS5', category: 'Electrónicos', price: 499.99, cost: 400.00, stock: 2, minStock: 3, location: 'Almacén A', supplier: 'SUP-001', image: '', createdAt: '2024-02-28' },
                    { id: 'PRD-013', name: 'Consola Xbox Series X', category: 'Electrónicos', price: 499.99, cost: 400.00, stock: 0, minStock: 3, location: 'Almacén A', supplier: 'SUP-001', image: '', createdAt: '2024-03-01' },
                    { id: 'PRD-014', name: 'Nintendo Switch OLED', category: 'Electrónicos', price: 349.99, cost: 280.00, stock: 6, minStock: 4, location: 'Almacén A', supplier: 'SUP-001', image: '', createdAt: '2024-03-02' },
                    { id: 'PRD-015', name: 'Tablet Samsung Tab S9', category: 'Electrónicos', price: 799.99, cost: 650.00, stock: 3, minStock: 2, location: 'Tienda Central', supplier: 'SUP-001', image: '', createdAt: '2024-03-03' },
                    { id: 'PRD-016', name: 'Camiseta Algodón M/C', category: 'Ropa', price: 19.99, cost: 10.00, stock: 50, minStock: 20, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-01-10' },
                    { id: 'PRD-017', name: 'Jeans Hombre Slim Fit', category: 'Ropa', price: 39.99, cost: 22.00, stock: 35, minStock: 15, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-01-12' },
                    { id: 'PRD-018', name: 'Vestido Mujer Floral', category: 'Ropa', price: 29.99, cost: 16.00, stock: 20, minStock: 10, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-01-15' },
                    { id: 'PRD-019', name: 'Chaqueta de Cuero', category: 'Ropa', price: 89.99, cost: 55.00, stock: 8, minStock: 5, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-01-18' },
                    { id: 'PRD-020', name: 'Sudadera con Capucha', category: 'Ropa', price: 34.99, cost: 20.00, stock: 25, minStock: 12, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-01-20' },
                    { id: 'PRD-021', name: 'Pantalón Deportivo', category: 'Ropa', price: 24.99, cost: 14.00, stock: 30, minStock: 15, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-01-22' },
                    { id: 'PRD-022', name: 'Zapatos Casuales Hombre', category: 'Ropa', price: 49.99, cost: 30.00, stock: 18, minStock: 8, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-01-25' },
                    { id: 'PRD-023', name: 'Botas de Invierno', category: 'Ropa', price: 79.99, cost: 50.00, stock: 10, minStock: 5, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-01-28' },
                    { id: 'PRD-024', name: 'Gorra Deportiva', category: 'Ropa', price: 14.99, cost: 8.00, stock: 45, minStock: 20, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-02-01' },
                    { id: 'PRD-025', name: 'Bufanda de Lana', category: 'Ropa', price: 12.99, cost: 6.00, stock: 28, minStock: 12, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-02-05' },
                    { id: 'PRD-026', name: 'Guantes de Invierno', category: 'Ropa', price: 9.99, cost: 5.00, stock: 32, minStock: 15, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-02-08' },
                    { id: 'PRD-027', name: 'Calcetines (Pack 3)', category: 'Ropa', price: 8.99, cost: 4.00, stock: 60, minStock: 25, location: 'Almacén B', supplier: 'SUP-003', image: '', createdAt: '2024-02-10' },
                    { id: 'PRD-028', name: 'Silla de Oficina Ergonómica', category: 'Hogar', price: 149.99, cost: 100.00, stock: 8, minStock: 4, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-01-05' },
                    { id: 'PRD-029', name: 'Mesa de Centro', category: 'Hogar', price: 89.99, cost: 55.00, stock: 6, minStock: 3, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-01-08' },
                    { id: 'PRD-030', name: 'Lámpara de Pie', category: 'Hogar', price: 39.99, cost: 22.00, stock: 12, minStock: 5, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-01-12' },
                    { id: 'PRD-031', name: 'Juego de Sábanas', category: 'Hogar', price: 29.99, cost: 16.00, stock: 25, minStock: 10, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-01-15' },
                    { id: 'PRD-032', name: 'Cojines Decorativos (2 uds)', category: 'Hogar', price: 19.99, cost: 10.00, stock: 30, minStock: 12, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-01-18' },
                    { id: 'PRD-033', name: 'Cortinas Blackout', category: 'Hogar', price: 34.99, cost: 20.00, stock: 15, minStock: 6, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-01-20' },
                    { id: 'PRD-034', name: 'Juego de Toallas', category: 'Hogar', price: 24.99, cost: 14.00, stock: 22, minStock: 8, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-01-22' },
                    { id: 'PRD-035', name: 'Set de Cocina (5 piezas)', category: 'Hogar', price: 44.99, cost: 28.00, stock: 14, minStock: 6, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-01-25' },
                    { id: 'PRD-036', name: 'Organizador de Escritorio', category: 'Hogar', price: 14.99, cost: 8.00, stock: 28, minStock: 12, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-01-28' },
                    { id: 'PRD-037', name: 'Espejo de Pared', category: 'Hogar', price: 39.99, cost: 22.00, stock: 9, minStock: 4, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-02-01' },
                    { id: 'PRD-038', name: 'Alfombra Moderna', category: 'Hogar', price: 59.99, cost: 35.00, stock: 7, minStock: 3, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-02-05' },
                    { id: 'PRD-039', name: 'Estantería 5 niveles', category: 'Hogar', price: 79.99, cost: 48.00, stock: 5, minStock: 2, location: 'Almacén A', supplier: 'SUP-004', image: '', createdAt: '2024-02-08' },
                    { id: 'PRD-040', name: 'Zapatillas Running Nike', category: 'Deportes', price: 89.99, cost: 60.00, stock: 14, minStock: 6, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-01-05' },
                    { id: 'PRD-041', name: 'Balón de Fútbol Profesional', category: 'Deportes', price: 29.99, cost: 18.00, stock: 22, minStock: 10, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-01-08' },
                    { id: 'PRD-042', name: 'Raqueta de Tenis', category: 'Deportes', price: 49.99, cost: 32.00, stock: 12, minStock: 5, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-01-12' },
                    { id: 'PRD-043', name: 'Pesas 2kg (Par)', category: 'Deportes', price: 19.99, cost: 12.00, stock: 35, minStock: 15, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-01-15' },
                    { id: 'PRD-044', name: 'Esterilla de Yoga', category: 'Deportes', price: 14.99, cost: 8.00, stock: 28, minStock: 12, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-01-18' },
                    { id: 'PRD-045', name: 'Bicicleta Estática', category: 'Deportes', price: 249.99, cost: 180.00, stock: 4, minStock: 2, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-01-20' },
                    { id: 'PRD-046', name: 'Cinta de Correr', category: 'Deportes', price: 399.99, cost: 300.00, stock: 2, minStock: 1, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-01-22' },
                    { id: 'PRD-047', name: 'Kit de Boxeo', category: 'Deportes', price: 59.99, cost: 40.00, stock: 8, minStock: 4, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-01-25' },
                    { id: 'PRD-048', name: 'Guantes de Boxeo', category: 'Deportes', price: 24.99, cost: 15.00, stock: 15, minStock: 6, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-01-28' },
                    { id: 'PRD-049', name: 'Rodilleras Deportivas', category: 'Deportes', price: 12.99, cost: 7.00, stock: 20, minStock: 8, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-02-01' },
                    { id: 'PRD-050', name: 'Botella de Agua Deportiva', category: 'Deportes', price: 8.99, cost: 4.00, stock: 45, minStock: 20, location: 'Sucursal Norte', supplier: 'SUP-002', image: '', createdAt: '2024-02-05' },
                    { id: 'PRD-051', name: 'Café Molido Premium 500g', category: 'Alimentos', price: 12.99, cost: 8.00, stock: 30, minStock: 15, location: 'Almacén B', supplier: 'SUP-005', image: '', createdAt: '2024-02-10' },
                    { id: 'PRD-052', name: 'Aceite de Oliva 1L', category: 'Alimentos', price: 9.99, cost: 6.00, stock: 25, minStock: 12, location: 'Almacén B', supplier: 'SUP-005', image: '', createdAt: '2024-02-12' },
                    { id: 'PRD-053', name: 'Arroz Integral 5kg', category: 'Alimentos', price: 7.99, cost: 5.00, stock: 40, minStock: 20, location: 'Almacén B', supplier: 'SUP-005', image: '', createdAt: '2024-02-15' },
                    { id: 'PRD-054', name: 'Lentejas 1kg', category: 'Alimentos', price: 2.99, cost: 1.80, stock: 55, minStock: 25, location: 'Almacén B', supplier: 'SUP-005', image: '', createdAt: '2024-02-18' },
                    { id: 'PRD-055', name: 'Miel Pura 500g', category: 'Alimentos', price: 6.99, cost: 4.00, stock: 22, minStock: 10, location: 'Almacén B', supplier: 'SUP-005', image: '', createdAt: '2024-02-20' }
                ];
                this.saveProducts();
            }

            initializeSampleSuppliers() {
                this.suppliers = [
                    { id: 'SUP-001', name: 'TecnoImport S.A.', contact: 'Juan Pérez', phone: '+123456789', email: 'juan@tecnoimport.com', address: 'Av. Tecnología 123' },
                    { id: 'SUP-002', name: 'DeportesMax', contact: 'María García', phone: '+987654321', email: 'maria@deportesmax.com', address: 'Calle Deportiva 456' },
                    { id: 'SUP-003', name: 'Textiles del Norte', contact: 'Carlos Rodríguez', phone: '+456123789', email: 'carlos@textiles.com', address: 'Zona Industrial Norte' },
                    { id: 'SUP-004', name: 'Hogar y Más', contact: 'Ana Martínez', phone: '+789456123', email: 'ana@hogarymas.com', address: 'Centro Comercial Plaza' },
                    { id: 'SUP-005', name: 'Alimentos Naturales', contact: 'Roberto Sánchez', phone: '+321654987', email: 'roberto@alimentos.com', address: 'Av. Salud 789' }
                ];
                this.saveSuppliers();
            }

            generateId(prefix) {
                const items = prefix === 'PRD' ? this.products : this.suppliers;
                const lastId = items.length > 0 ? Math.max(...items.map(i => parseInt(i.id.split('-')[1]))) : 0;
                return `${prefix}-${String(lastId + 1).padStart(3, '0')}`;
            }

            saveProducts() { return StorageAPI.setProducts(this.products); }
            saveSuppliers() { return StorageAPI.setSuppliers(this.suppliers); }
            saveNotifications() { return StorageAPI.setNotifications(this.notifications); }

            getProductStatus(stock, minStock) {
                if (stock === 0) return 'Agotado';
                if (stock <= minStock * 0.2) return 'Stock crítico';
                if (stock <= minStock) return 'Stock bajo';
                return 'En stock';
            }

            getStatusClass(status) {
                switch(status) {
                    case 'En stock': return 'badge-success';
                    case 'Stock bajo': return 'badge-warning';
                    case 'Stock crítico': return 'badge-danger';
                    case 'Agotado': return 'badge-danger';
                    default: return 'badge-info';
                }
            }

            getStockIndicator(stock, minStock) {
                if (stock === 0) return 'stock-critical';
                if (stock <= minStock * 0.2) return 'stock-critical';
                if (stock <= minStock) return 'stock-low';
                if (stock <= minStock * 2) return 'stock-good';
                return 'stock-normal';
            }

            checkStockAlerts() {
                this.products.forEach(product => {
                    const status = this.getProductStatus(product.stock, product.minStock);
                    if (status !== 'En stock') {
                        const existingAlert = this.notifications.find(n => n.productId === product.id && n.type === 'stock' && !n.read);
                        if (!existingAlert) {
                            this.addNotification({
                                title: 'Alerta de Stock',
                                message: `${product.name} tiene stock ${status.toLowerCase()}`,
                                type: 'stock',
                                productId: product.id
                            });
                        }
                    }
                });
            }

            addNotification(notification) {
                const newNotification = {
                    id: Date.now() + Math.random(),
                    ...notification,
                    time: new Date().toLocaleString(),
                    read: false
                };
                this.notifications.unshift(newNotification);
                if (this.notifications.length > 20) this.notifications = this.notifications.slice(0, 20);
                this.saveNotifications();
                this.showNotification(notification.message, notification.type === 'stock' ? 'warning' : 'info');
            }

            markNotificationAsRead(id) {
                const notification = this.notifications.find(n => String(n.id) === String(id));
                if (notification) { notification.read = true; this.saveNotifications(); }
            }

            markAllNotificationsAsRead() {
                this.notifications.forEach(n => n.read = true);
                this.saveNotifications();
            }

            getUnreadCount() { return this.notifications.filter(n => !n.read).length; }

            addProduct(product) {
                product.id = this.generateId('PRD');
                product.createdAt = new Date().toISOString().split('T')[0];
                this.products.push(product);
                this.saveProducts();
                this.filterProducts();
                this.checkStockAlerts();
                return product.id;
            }

            updateProduct(id, updatedProduct) {
                const index = this.products.findIndex(p => p.id === id);
                if (index !== -1) {
                    this.products[index] = { ...updatedProduct, id, createdAt: this.products[index].createdAt };
                    this.saveProducts();
                    this.filterProducts();
                    this.checkStockAlerts();
                    return true;
                }
                return false;
            }

            deleteProduct(id) {
                const index = this.products.findIndex(p => p.id === id);
                if (index !== -1) {
                    this.products.splice(index, 1);
                    this.saveProducts();
                    this.filterProducts();
                    this.currentPage = Math.min(this.currentPage, Math.max(1, this.getTotalPages()));
                    this.showNotification('Producto eliminado', 'success');
                    return true;
                }
                return false;
            }

            getProductById(id) { return this.products.find(p => p.id === id); }

            filterProducts(search = '', category = 'all', status = 'all') {
                const normalizedSearch = search.trim().toLowerCase();
                this.filteredProducts = this.products.filter(product => {
                    const searchableText = [product.name, product.id, product.sku, product.category, product.location].filter(Boolean).join(' ').toLowerCase();
                    const matchesSearch = normalizedSearch === '' || searchableText.includes(normalizedSearch);
                    const matchesCategory = category === 'all' || product.category === category;
                    let matchesStatus = true;
                    if (status !== 'all') {
                        const productStatus = this.getProductStatus(product.stock, product.minStock);
                        matchesStatus = productStatus === status;
                    }
                    return matchesSearch && matchesCategory && matchesStatus;
                });
                return this.filteredProducts;
            }

            getPaginatedProducts(page = this.currentPage) {
                const start = (page - 1) * this.itemsPerPage;
                return this.filteredProducts.slice(start, start + this.itemsPerPage);
            }

            getTotalPages() { return Math.ceil(this.filteredProducts.length / this.itemsPerPage); }

            getRecentProducts(limit = 5) {
                return [...this.products].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, limit);
            }

            addSupplier(supplier) {
                supplier.id = this.generateId('SUP');
                this.suppliers.push(supplier);
                this.saveSuppliers();
                this.showNotification('Proveedor agregado', 'success');
                return supplier.id;
            }

            updateSupplier(id, updatedSupplier) {
                const index = this.suppliers.findIndex(s => s.id === id);
                if (index !== -1) {
                    this.suppliers[index] = { ...updatedSupplier, id };
                    this.saveSuppliers();
                    this.showNotification('Proveedor actualizado', 'success');
                    return true;
                }
                return false;
            }

            deleteSupplier(id) {
                const index = this.suppliers.findIndex(s => s.id === id);
                if (index !== -1) {
                    this.suppliers.splice(index, 1);
                    this.saveSuppliers();
                    this.showNotification('Proveedor eliminado', 'success');
                    return true;
                }
                return false;
            }

            getSupplierById(id) { return this.suppliers.find(s => s.id === id); }

            getStats() {
                const total = this.products.length;
                let inStock = 0, lowStock = 0, outOfStock = 0;
                let totalValue = 0;
                this.products.forEach(p => {
                    const status = this.getProductStatus(p.stock, p.minStock);
                    if (status === 'En stock') inStock++;
                    else if (status === 'Stock bajo' || status === 'Stock crítico') lowStock++;
                    else if (status === 'Agotado') outOfStock++;
                    totalValue += p.price * p.stock;
                });
                return {
                    total, inStock, lowStock, outOfStock, totalValue,
                    avgPrice: total > 0 ? totalValue / total : 0,
                    categories: [...new Set(this.products.map(p => p.category))].length,
                    suppliers: this.suppliers.length
                };
            }

            getCategoryData() {
                const data = {};
                this.products.forEach(p => { data[p.category] = (data[p.category] || 0) + 1; });
                return { labels: Object.keys(data), values: Object.values(data) };
            }

            getCategoryValueData() {
                const data = {};
                this.products.forEach(p => { data[p.category] = (data[p.category] || 0) + (p.price * p.stock); });
                return { labels: Object.keys(data), values: Object.values(data) };
            }

            getMovementData(days = 7) {
                const labels = [], entradas = [], salidas = [];
                for (let i = days - 1; i >= 0; i--) {
                    const date = new Date();
                    date.setDate(date.getDate() - i);
                    labels.push(`${date.getDate()}/${date.getMonth() + 1}`);
                    entradas.push(Math.floor(Math.random() * 15) + 5);
                    salidas.push(Math.floor(Math.random() * 12) + 3);
                }
                return { labels, entradas, salidas };
            }

            showNotification(message, type = 'info') {
                const container = document.getElementById('toastContainer');
                if (!container) return;
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                const icons = {
                    success: 'fa-check-circle',
                    error: 'fa-exclamation-circle',
                    warning: 'fa-exclamation-triangle',
                    info: 'fa-info-circle'
                };
                toast.innerHTML = `
                    <i class="fas ${icons[type] || icons.info}"></i>
                    <div class="toast-content">
                        <div class="toast-title">${type.charAt(0).toUpperCase() + type.slice(1)}</div>
                        <div class="toast-message">${message}</div>
                    </div>
                `;
                container.appendChild(toast);
                setTimeout(() => {
                    toast.style.animation = 'slideOutRight 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }

            toggleTheme() {
                document.body.classList.toggle('dark-mode');
                const isDark = document.body.classList.contains('dark-mode');
                const icon = document.querySelector('#themeToggle i');
                if (icon) icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', isDark ? '#1a1f2e' : '#3a5ec7');
                try {
                    const settings = JSON.parse(localStorage.getItem('globalSettings')) || {};
                    settings.darkMode = isDark;
                    settings.autoDarkMode = 'disabled';
                    localStorage.setItem('globalSettings', JSON.stringify(settings));
                } catch (e) {}
                if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(10);
                updateCharts();
            }
        }

        const app = new SmartStockManager();

        // ============================================
        // RENDERIZADO
        // ============================================
        function renderDashboard() {
            const stats = app.getStats();
            document.getElementById('totalProducts').textContent = stats.total;
            document.getElementById('inStockCount').textContent = stats.inStock;
            document.getElementById('lowStockCount').textContent = stats.lowStock;
            document.getElementById('outOfStockCount').textContent = stats.outOfStock;

            const recentProducts = app.getRecentProducts(5);
            const tbody = document.getElementById('recentProductsTable');
            tbody.innerHTML = '';
            if (recentProducts.length === 0) {
                tbody.innerHTML = `<tr><td colspan="6" class="text-center empty-state"><i class="fas fa-box-open"></i><p>No hay productos recientes</p></td></tr>`;
            } else {
                recentProducts.forEach(product => {
                    const status = app.getProductStatus(product.stock, product.minStock);
                    const statusClass = app.getStatusClass(status);
                    const indicator = app.getStockIndicator(product.stock, product.minStock);
                    tbody.innerHTML += `
                        <tr>
                            <td>
                                <div class="product-info">
                                    <img src="${productThumb(product)}" class="product-thumb" alt="${product.name}">
                                    <span>${product.name}</span>
                                </div>
                            </td>
                            <td>${product.category}</td>
                            <td>${formatInventoryPrice(product.price)}</td>
                            <td><span class="stock-indicator ${indicator}"></span>${product.stock}</td>
                            <td><span class="badge ${statusClass}">${status}</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="icon-btn view" onclick="viewProduct('${product.id}')" data-tooltip="Ver"><i class="fas fa-eye"></i></button>
                                    <button class="icon-btn edit" onclick="editProduct('${product.id}')" data-tooltip="Editar"><i class="fas fa-edit"></i></button>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            }
            updateCharts();
        }

        function renderInventory() {
            const search = document.getElementById('inventorySearch')?.value || '';
            const category = document.getElementById('inventoryCategoryFilter')?.value || 'all';
            const status = document.getElementById('inventoryStatusFilter')?.value || 'all';
            app.filterProducts(search, category, status);
            const products = app.getPaginatedProducts(app.currentPage);
            const tbody = document.getElementById('inventoryTableBody');
            tbody.innerHTML = '';
            if (products.length === 0) {
                tbody.innerHTML = `<tr><td colspan="8" class="text-center empty-state"><i class="fas fa-box-open"></i><p>No se encontraron productos</p></td></tr>`;
            } else {
                products.forEach(product => {
                    const productStatus = app.getProductStatus(product.stock, product.minStock);
                    const statusClass = app.getStatusClass(productStatus);
                    const indicator = app.getStockIndicator(product.stock, product.minStock);
                    tbody.innerHTML += `
                        <tr>
                            <td><span class="badge badge-info">${product.id}</span></td>
                            <td>
                                <div class="product-info">
                                    <img src="${productThumb(product)}" class="product-thumb" alt="${product.name}">
                                    <span>${product.name}</span>
                                </div>
                            </td>
                            <td>${product.category}</td>
                            <td>${formatInventoryPrice(product.price)}</td>
                            <td><span class="stock-indicator ${indicator}"></span>${product.stock}</td>
                            <td>${product.location || 'N/A'}</td>
                            <td><span class="badge ${statusClass}">${productStatus}</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="icon-btn view" onclick="viewProduct('${product.id}')" data-tooltip="Ver"><i class="fas fa-eye"></i></button>
                                    <button class="icon-btn edit" onclick="editProduct('${product.id}')" data-tooltip="Editar"><i class="fas fa-edit"></i></button>
                                    <button class="icon-btn qr" onclick="showQR('${product.id}')" data-tooltip="QR"><i class="fas fa-qrcode"></i></button>
                                    <button class="icon-btn barcode" onclick="showBarcode('${product.id}')" data-tooltip="Barcode"><i class="fas fa-barcode"></i></button>
                                    <button class="icon-btn delete" onclick="deleteProduct('${product.id}')" data-tooltip="Eliminar"><i class="fas fa-trash"></i></button>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            }
            renderInventoryPagination();
        }

        function renderSuppliers() {
            const tbody = document.getElementById('suppliersTableBody');
            tbody.innerHTML = '';
            if (app.suppliers.length === 0) {
                tbody.innerHTML = `<tr><td colspan="7" class="text-center empty-state"><i class="fas fa-truck"></i><p>No hay proveedores registrados</p></td></tr>`;
            } else {
                app.suppliers.forEach(supplier => {
                    const productCount = app.products.filter(p => p.supplier === supplier.id).length;
                    tbody.innerHTML += `
                        <tr>
                            <td><span class="badge badge-info">${supplier.id}</span></td>
                            <td>${supplier.name}</td>
                            <td>${supplier.contact || '-'}</td>
                            <td>${supplier.phone || '-'}</td>
                            <td>${supplier.email || '-'}</td>
                            <td><span class="badge badge-success">${productCount}</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="icon-btn edit" onclick="editSupplier('${supplier.id}')" data-tooltip="Editar"><i class="fas fa-edit"></i></button>
                                    <button class="icon-btn delete" onclick="deleteSupplier('${supplier.id}')" data-tooltip="Eliminar"><i class="fas fa-trash"></i></button>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            }
        }

        function renderNotifications(showAll = false) {
            const list = document.getElementById('notificationList');
            const count = document.getElementById('notificationCount');
            count.textContent = app.getUnreadCount();
            list.innerHTML = '';
            const items = showAll ? app.notifications : app.notifications.slice(0, 5);
            if (items.length === 0) {
                list.innerHTML = '<div class="notification-item">No hay notificaciones</div>';
            } else {
                items.forEach(n => {
                    list.innerHTML += `
                        <div class="notification-item ${n.read ? '' : 'unread'}" onclick="markNotificationRead('${n.id}')">
                            <strong>${n.title}</strong>
                            <p>${n.message}</p>
                            <small>${n.time}</small>
                        </div>
                    `;
                });
            }
        }

        function renderInventoryPagination() {
            const totalPages = app.getTotalPages();
            const currentPage = app.currentPage;
            const pagination = document.getElementById('inventoryPagination');
            const info = document.getElementById('inventoryPaginationInfo');
            info.textContent = `Página ${currentPage} de ${totalPages || 1}`;
            pagination.innerHTML = '';
            pagination.innerHTML += `
                <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                    <a class="page-link" onclick="changeInventoryPage(${currentPage - 1})"><i class="fas fa-chevron-left"></i></a>
                </li>
            `;
            const startPage = Math.max(1, currentPage - 2);
            const endPage = Math.min(totalPages, startPage + 4);
            for (let i = startPage; i <= endPage; i++) {
                pagination.innerHTML += `
                    <li class="page-item ${currentPage === i ? 'active' : ''}">
                        <a class="page-link" onclick="changeInventoryPage(${i})">${i}</a>
                    </li>
                `;
            }
            pagination.innerHTML += `
                <li class="page-item ${currentPage === totalPages || totalPages === 0 ? 'disabled' : ''}">
                    <a class="page-link" onclick="changeInventoryPage(${currentPage + 1})"><i class="fas fa-chevron-right"></i></a>
                </li>
            `;
        }

        function updateCharts() {
            const textColor = getComputedStyle(document.body).getPropertyValue('--text-primary').trim();

            const categoryData = app.getCategoryData();
            const categoryCtx = document.getElementById('categoryChart')?.getContext('2d');
            if (categoryCtx) {
                if (app.charts.category) app.charts.category.destroy();
                app.charts.category = new Chart(categoryCtx, {
                    type: 'doughnut',
                    data: {
                        labels: categoryData.labels,
                        datasets: [{
                            data: categoryData.values,
                            backgroundColor: ['#3a5ec7', '#28a745', '#ffc107', '#dc3545', '#6f42c1', '#17a2b8', '#fd7e14'],
                            borderWidth: 0
                        }]
                    },
                    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: textColor, boxWidth: 12 } } } }
                });
            }

            const movementData = app.getMovementData(7);
            const movementCtx = document.getElementById('movementChart')?.getContext('2d');
            if (movementCtx) {
                if (app.charts.movement) app.charts.movement.destroy();
                app.charts.movement = new Chart(movementCtx, {
                    type: 'line',
                    data: {
                        labels: movementData.labels,
                        datasets: [
                            { label: 'Entradas', data: movementData.entradas, borderColor: '#28a745', backgroundColor: 'rgba(40, 167, 69, 0.1)', fill: true, tension: 0.4 },
                            { label: 'Salidas', data: movementData.salidas, borderColor: '#dc3545', backgroundColor: 'rgba(220, 53, 69, 0.1)', fill: true, tension: 0.4 }
                        ]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        scales: {
                            y: { beginAtZero: true, grid: { color: 'rgba(128,128,128,0.1)' }, ticks: { color: textColor } },
                            x: { grid: { display: false }, ticks: { color: textColor } }
                        },
                        plugins: { legend: { labels: { color: textColor } } }
                    }
                });
            }

            const valueData = app.getCategoryValueData();
            const valueCtx = document.getElementById('valueCategoryChart')?.getContext('2d');
            if (valueCtx) {
                if (app.charts.value) app.charts.value.destroy();
                app.charts.value = new Chart(valueCtx, {
                    type: 'bar',
                    data: { labels: valueData.labels, datasets: [{ label: 'Valor ($)', data: valueData.values, backgroundColor: '#3a5ec7' }] },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        scales: {
                            y: { beginAtZero: true, ticks: { callback: value => '$' + value.toLocaleString(), color: textColor } },
                            x: { ticks: { color: textColor } }
                        },
                        plugins: { legend: { display: false } }
                    }
                });
            }

            const stats = app.getStats();
            const el1 = document.getElementById('reportTotalValue');
            const el2 = document.getElementById('reportAvgPrice');
            const el3 = document.getElementById('reportTotalItems');
            const el4 = document.getElementById('reportLowStock');
            if (el1) el1.textContent = '$' + stats.totalValue.toFixed(2);
            if (el2) el2.textContent = '$' + stats.avgPrice.toFixed(2);
            if (el3) el3.textContent = stats.total;
            if (el4) el4.textContent = stats.lowStock;
        }

        // ============================================
        // NAVEGACIÓN
        // ============================================
        function showView(view) {
            ['dashboardView', 'inventoryView', 'suppliersView', 'reportsView'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.style.display = 'none';
            });
            const target = document.getElementById(`${view}View`);
            if (target) target.style.display = 'block';

            const titles = { dashboard: 'Dashboard', inventory: 'Inventario', suppliers: 'Proveedores', reports: 'Reportes' };
            const icons = { dashboard: 'home', inventory: 'boxes', suppliers: 'truck', reports: 'chart-line' };
            const titleEl = document.getElementById('pageTitle');
            if (titleEl) titleEl.innerHTML = `<i class="fas fa-${icons[view]}"></i> ${titles[view]}`;

            if (view === 'dashboard') renderDashboard();
            else if (view === 'inventory') renderInventory();
            else if (view === 'suppliers') renderSuppliers();
            else if (view === 'reports') updateCharts();

            document.querySelectorAll('.sidebar-menu a[data-view]').forEach(link => link.classList.remove('active'));
            const activeLink = document.querySelector(`.sidebar-menu a[data-view="${view}"]`);
            if (activeLink) activeLink.classList.add('active');

            if (APP_STATE.isMobile) closeMobileSidebar();
        }

        // ============================================
        // MODALES
        // ============================================
        function openModal(id) {
            const modal = document.getElementById(id);
            if (!modal) {
                console.error(`❌ No se encontró el modal #${id}`);
                return;
            }
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }

        function closeModal(id) {
            const modal = document.getElementById(id);
            if (!modal) return;
            modal.classList.remove('show');
            document.body.style.overflow = '';
        }

        // ============================================
        // PRODUCTOS
        // ============================================
        function openProductModal(mode = 'add', productId = null) {
            try {
                const title = document.getElementById('productModalTitle');
                if (mode === 'add') {
                    if (title) title.innerHTML = '<i class="fas fa-plus-circle"></i> Nuevo Producto';
                    const form = document.getElementById('productForm');
                    if (form) form.reset();
                    document.getElementById('productId').value = '';
                    document.getElementById('productMinStock').value = getGlobalSettings().minStockAlert || 5;
                } else {
                    if (title) title.innerHTML = '<i class="fas fa-edit"></i> Editar Producto';
                    const product = app.getProductById(productId);
                    if (product) {
                        document.getElementById('productId').value = product.id;
                        document.getElementById('productName').value = product.name;
                        document.getElementById('productSKU').value = product.sku || '';
                        document.getElementById('productCategory').value = product.category;
                        document.getElementById('productPrice').value = product.price;
                        document.getElementById('productCost').value = product.cost || '';
                        document.getElementById('productStock').value = product.stock;
                        document.getElementById('productMinStock').value = product.minStock ?? 5;
                        document.getElementById('productLocation').value = product.location || '';
                        document.getElementById('productDescription').value = product.description || '';
                        document.getElementById('productImage').value = product.image || '';
                        document.getElementById('productSupplier').value = product.supplier || '';
                    }
                }
                openModal('productModal');
            } catch (err) {
                console.error('❌ Error en openProductModal:', err);
            }
        }

        function saveProduct() {
            const productId = document.getElementById('productId').value;
            const product = {
                name: document.getElementById('productName').value,
                sku: document.getElementById('productSKU').value,
                category: document.getElementById('productCategory').value,
                price: parseFloat(document.getElementById('productPrice').value),
                cost: parseFloat(document.getElementById('productCost').value) || 0,
                stock: parseInt(document.getElementById('productStock').value),
                minStock: parseInt(document.getElementById('productMinStock').value),
                location: document.getElementById('productLocation').value,
                supplier: document.getElementById('productSupplier').value,
                description: document.getElementById('productDescription').value,
                image: document.getElementById('productImage').value
            };
            if (!product.category || !product.name.trim() || !Number.isFinite(product.price) || product.price < 0 ||
                !Number.isInteger(product.stock) || product.stock < 0 || !Number.isInteger(product.minStock) || product.minStock < 0) {
                app.showNotification('Completa los campos obligatorios con valores válidos', 'error');
                return;
            }
            if (productId) {
                app.updateProduct(productId, product);
                app.showNotification('Producto actualizado', 'success');
            } else {
                app.addProduct(product);
                app.showNotification('Producto agregado', 'success');
            }
            closeModal('productModal');
            renderDashboard();
            renderInventory();
        }

        function viewProduct(id) {
            const product = app.getProductById(id);
            if (!product) return;
            const status = app.getProductStatus(product.stock, product.minStock);
            app.showNotification(`${product.name} - Stock: ${product.stock} - Estado: ${status}`, 'info');
        }

        function editProduct(id) { openProductModal('edit', id); }

        function deleteProduct(id) {
            if (confirm('¿Eliminar este producto?')) {
                app.deleteProduct(id);
                renderDashboard();
                renderInventory();
            }
        }

        // ============================================
        // PROVEEDORES
        // ============================================
        function openSupplierModal(mode = 'add', supplierId = null) {
            const title = document.getElementById('supplierModalTitle');
            if (mode === 'add') {
                if (title) title.innerHTML = '<i class="fas fa-truck"></i> Nuevo Proveedor';
                const form = document.getElementById('supplierForm');
                if (form) form.reset();
                document.getElementById('supplierId').value = '';
            } else {
                if (title) title.innerHTML = '<i class="fas fa-edit"></i> Editar Proveedor';
                const supplier = app.getSupplierById(supplierId);
                if (supplier) {
                    document.getElementById('supplierId').value = supplier.id;
                    document.getElementById('supplierName').value = supplier.name;
                    document.getElementById('supplierContact').value = supplier.contact || '';
                    document.getElementById('supplierPhone').value = supplier.phone || '';
                    document.getElementById('supplierEmail').value = supplier.email || '';
                    document.getElementById('supplierAddress').value = supplier.address || '';
                }
            }
            openModal('supplierModal');
        }

        function saveSupplier() {
            const supplierId = document.getElementById('supplierId').value;
            const supplier = {
                name: document.getElementById('supplierName').value,
                contact: document.getElementById('supplierContact').value,
                phone: document.getElementById('supplierPhone').value,
                email: document.getElementById('supplierEmail').value,
                address: document.getElementById('supplierAddress').value
            };
            if (!supplier.name) {
                app.showNotification('El nombre del proveedor es obligatorio', 'error');
                return;
            }
            if (supplierId) app.updateSupplier(supplierId, supplier);
            else app.addSupplier(supplier);
            closeModal('supplierModal');
            renderSuppliers();
        }

        function editSupplier(id) { openSupplierModal('edit', id); }

        function deleteSupplier(id) {
            const productCount = app.products.filter(p => p.supplier === id).length;
            if (productCount > 0) {
                if (!confirm(`Este proveedor tiene ${productCount} producto(s). ¿Eliminar de todas formas?`)) return;
            } else {
                if (!confirm('¿Eliminar este proveedor?')) return;
            }
            app.deleteSupplier(id);
            renderSuppliers();
        }

        // ============================================
        // QR / BARCODE
        // ============================================
        function showQR(productId) {
            const product = app.getProductById(productId);
            if (!product) return;
            const qrContainer = document.getElementById('qrcode');
            qrContainer.innerHTML = '';
            const productData = JSON.stringify({ id: product.id, name: product.name, price: product.price, sku: product.sku || product.id });
            const canvas = document.createElement('canvas');
            qrContainer.appendChild(canvas);
            if (typeof QRCode !== 'undefined') {
                QRCode.toCanvas(canvas, productData, { width: 180, margin: 1 }, (error) => {
                    if (error) console.error(error);
                });
            }
            document.getElementById('qrProductName').textContent = product.name;
            document.getElementById('downloadQR').onclick = () => {
                const c = qrContainer.querySelector('canvas');
                if (c) {
                    const link = document.createElement('a');
                    link.download = `qr_${product.id}.png`;
                    link.href = c.toDataURL('image/png');
                    link.click();
                }
            };
            openModal('qrModal');
        }

        function showBarcode(productId) {
            const product = app.getProductById(productId);
            if (!product) return;
            const barcodeValue = String(product.sku || product.id).replace(/[^A-Za-z0-9\-\.]/g, '');
            if (typeof JsBarcode === 'undefined') {
                app.showNotification('Barcode no disponible', 'error');
                return;
            }
            try {
                JsBarcode('#barcode', barcodeValue, { format: 'CODE128', displayValue: true, fontSize: 14, height: 50, margin: 10 });
            } catch (err) {
                app.showNotification('No se pudo generar el código de barras', 'error');
                return;
            }
            document.getElementById('barcodeProductName').textContent = product.name;
            document.getElementById('downloadBarcode').onclick = () => {
                const svg = document.getElementById('barcode');
                const serializer = new XMLSerializer();
                const source = serializer.serializeToString(svg);
                const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(source);
                const link = document.createElement('a');
                link.download = `barcode_${product.id}.svg`;
                link.href = url;
                link.click();
            };
            openModal('barcodeModal');
        }

        // ============================================
        // UTILIDADES
        // ============================================
        function changeInventoryPage(page) {
            if (page < 1 || page > app.getTotalPages()) return;
            app.currentPage = page;
            renderInventory();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function markNotificationRead(id) {
            app.markNotificationAsRead(id);
            renderNotifications();
            const dd = document.getElementById('notificationDropdown');
            if (dd) dd.classList.remove('show');
        }

        function downloadInventoryFile(content, fileName, mimeType) {
            const blob = new Blob([content], { type: mimeType });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(url);
        }

        function exportInventory(format) {
            const products = app.products;
            const date = new Date().toISOString().split('T')[0];
            if (format === 'json') {
                downloadInventoryFile(JSON.stringify(products, null, 2), `inventario_${date}.json`, 'application/json');
            } else if (format === 'csv') {
                const escapeCsv = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
                const rows = [
                    ['ID', 'Nombre', 'SKU', 'Categoría', 'Precio', 'Costo', 'Stock', 'Stock mínimo', 'Ubicación', 'Proveedor'],
                    ...products.map(p => [p.id, p.name, p.sku || '', p.category, p.price, p.cost || 0, p.stock, p.minStock, p.location || '', p.supplier || ''])
                ];
                downloadInventoryFile('\ufeff' + rows.map(row => row.map(escapeCsv).join(',')).join('\n'), `inventario_${date}.csv`, 'text/csv;charset=utf-8');
            } else if (format === 'excel' && window.XLSX) {
                const sheet = XLSX.utils.json_to_sheet(products);
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, sheet, 'Inventario');
                XLSX.writeFile(workbook, `inventario_${date}.xlsx`);
            } else if (format === 'pdf' && window.jspdf) {
                const { jsPDF } = window.jspdf;
                const pdf = new jsPDF();
                pdf.text('Inventario SmartStock AI', 14, 15);
                pdf.text(`Productos: ${products.length}`, 14, 24);
                products.slice(0, 25).forEach((product, index) => {
                    pdf.text(`${product.id} - ${product.name} | Stock: ${product.stock}`, 14, 34 + (index * 6));
                });
                pdf.save(`inventario_${date}.pdf`);
            } else {
                app.showNotification('El formato solicitado no está disponible', 'error');
                return;
            }
            app.showNotification(`Inventario exportado a ${format.toUpperCase()}`, 'success');
        }

        function importInventoryFile(file) {
            const reader = new FileReader();
            reader.onload = event => {
                try {
                    const importedProducts = JSON.parse(event.target.result);
                    if (!Array.isArray(importedProducts)) throw new Error('El archivo debe contener una lista de productos');
                    const validProducts = importedProducts.filter(p => p.name && p.category && Number.isFinite(Number(p.stock)));
                    if (!validProducts.length) throw new Error('No se encontraron productos válidos');
                    const existingIds = new Set(app.products.map(p => p.id));
                    let nextId = app.products.reduce((h, p) => {
                        const n = parseInt(String(p.id).split('-')[1], 10);
                        return Number.isFinite(n) ? Math.max(h, n) : h;
                    }, 0) + 1;
                    validProducts.forEach(p => {
                        if (!p.id || existingIds.has(p.id)) {
                            p.id = `PRD-${String(nextId).padStart(3, '0')}`;
                            nextId++;
                        }
                        p.price = Number(p.price) || 0;
                        p.cost = Number(p.cost) || 0;
                        p.stock = Number(p.stock);
                        p.minStock = Number.isFinite(Number(p.minStock)) ? Number(p.minStock) : (getGlobalSettings().minStockAlert || 5);
                        if (p.image && p.image.includes('via.placeholder.com')) p.image = '';
                        existingIds.add(p.id);
                    });
                    app.products.push(...validProducts);
                    app.saveProducts();
                    app.filterProducts();
                    renderDashboard();
                    renderInventory();
                    app.showNotification(`${validProducts.length} productos importados correctamente`, 'success');
                } catch (error) {
                    app.showNotification(`No se pudo importar: ${error.message}`, 'error');
                }
            };
            reader.readAsText(file);
        }

        function getGlobalSettings() {
            try { return JSON.parse(localStorage.getItem('globalSettings')) || {}; }
            catch (e) { return {}; }
        }

        function darkenColor(hex, percent = 15) {
            try {
                hex = String(hex).replace('#', '');
                if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
                const num = parseInt(hex, 16);
                const amt = Math.round(2.55 * percent);
                const R = Math.max(0, (num >> 16) - amt);
                const G = Math.max(0, ((num >> 8) & 0x00FF) - amt);
                const B = Math.max(0, (num & 0x0000FF) - amt);
                return '#' + (0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1);
            } catch (e) { return hex; }
        }

        function applyGlobalConfig() {
            const settings = getGlobalSettings();
            const colors = { blue: '#3a5ec7', green: '#28a745', red: '#dc3545', purple: '#6f42c1', orange: '#fd7e14', teal: '#20c997' };
            const primaryColor = colors[settings.themeColor] || '#3a5ec7';
            const root = document.documentElement;
            const darkMode = settings.darkMode === true;

            document.body.classList.toggle('dark-mode', darkMode);
            root.style.setProperty('--primary', primaryColor);
            root.style.setProperty('--primary-dark', darkenColor(primaryColor, 15));
            root.style.setProperty('--primary-light', `${primaryColor}33`);
            root.style.setProperty('--font-main', settings.fontFamily || "'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif");
            root.style.setProperty('--border-radius', settings.borderRadius || '12px');
            root.style.setProperty('--transition', settings.enableAnimations === false ? 'none' : 'all 0.3s ease');
            root.style.setProperty('--sidebar-opacity', String(parseInt(settings.sidebarOpacity || 100, 10) / 100));

            if (settings.sidebarTheme === 'dark') {
                root.style.setProperty('--bg-sidebar', 'linear-gradient(180deg, #111827 0%, #030712 100%)');
            } else if (settings.sidebarTheme === 'light') {
                root.style.setProperty('--bg-sidebar', '#ffffff');
            } else {
                root.style.setProperty('--bg-sidebar', `linear-gradient(180deg, ${primaryColor} 0%, ${primaryColor} 100%)`);
            }

            document.querySelectorAll('.system-name-display').forEach(el => {
                el.textContent = settings.systemName || 'SmartStock AI';
            });

            const themeIcon = document.querySelector('#themeToggle i');
            if (themeIcon) themeIcon.className = darkMode ? 'fas fa-sun' : 'fas fa-moon';
            document.querySelector('meta[name="theme-color"]')?.setAttribute('content', darkMode ? '#1a1f2e' : primaryColor);
        }

        function formatInventoryPrice(price) {
            const settings = getGlobalSettings();
            const symbol = settings.currencySymbol || '$';
            const code = settings.currency || 'MXN';
            return `${symbol}${Number(price).toFixed(2)} ${code}`;
        }

        function toggleSidebarSimple() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const icon = document.querySelector('#sidebarToggle i');
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            if (icon) icon.className = sidebar.classList.contains('collapsed') ? 'fas fa-chevron-right' : 'fas fa-chevron-left';
        }

        // ============================================
        // BIND SEGURO
        // ============================================
        function bindSafe(id, event, handler) {
            const el = document.getElementById(id);
            if (!el) {
                console.warn(`⚠️ Elemento no encontrado: #${id}`);
                return;
            }
            el.addEventListener(event, handler);
        }

        // ============================================
        // INICIALIZACIÓN
        // ============================================
        document.addEventListener('DOMContentLoaded', () => {
            console.log('🚀 SmartStock AI iniciando...');
            applyGlobalConfig();

            const cleaned = StorageAPI.sanitizeProducts(StorageAPI.getProducts());
            StorageAPI.setProducts(cleaned);
            app.products = cleaned;

            // Setup responsive + menú móvil
            setupMobileSidebar();

            // Prevenir zoom doble-tap iOS
            if (APP_STATE.isTouch) {
                let lastTouchEnd = 0;
                document.addEventListener('touchend', (e) => {
                    const now = Date.now();
                    if (now - lastTouchEnd <= 300) e.preventDefault();
                    lastTouchEnd = now;
                }, { passive: false });
            }

            // Detectar orientación
            window.addEventListener('orientationchange', () => {
                setTimeout(() => {
                    APP_STATE.isMobile = window.matchMedia('(max-width: 992px)').matches;
                    if (!APP_STATE.isMobile) closeMobileSidebar();
                    Object.values(app.charts).forEach(c => { try { c.resize(); } catch (e) {} });
                }, 150);
            });

            // Resize charts
            let resizeTimeout;
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(() => {
                    APP_STATE.isMobile = window.matchMedia('(max-width: 992px)').matches;
                    Object.values(app.charts).forEach(c => { try { c.resize(); } catch (e) {} });
                }, 200);
            });

            // Cerrar sidebar con Escape
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    closeMobileSidebar();
                    document.querySelectorAll('.modal-overlay.show').forEach(m => closeModal(m.id));
                    const dd = document.getElementById('notificationDropdown');
                    if (dd) dd.classList.remove('show');
                }
            });

            window.addEventListener('storage', (event) => {
                if (event.key === 'globalSettings') {
                    applyGlobalConfig();
                    renderDashboard();
                    renderInventory();
                }
            });
            window.addEventListener('focus', applyGlobalConfig);

            ['productCategory', 'inventoryCategoryFilter'].forEach(id => {
                const select = document.getElementById(id);
                if (select) {
                    select.innerHTML = id === 'inventoryCategoryFilter'
                        ? '<option value="all">Todas las categorías</option>'
                        : '<option value="">Seleccionar</option>';
                    app.categories.forEach(cat => {
                        select.innerHTML += `<option value="${cat}">${cat}</option>`;
                    });
                }
            });

            const locationSelect = document.getElementById('productLocation');
            if (locationSelect) {
                locationSelect.innerHTML = '<option value="">Seleccionar</option>';
                app.locations.forEach(loc => {
                    locationSelect.innerHTML += `<option value="${loc}">${loc}</option>`;
                });
            }

            const supplierSelect = document.getElementById('productSupplier');
            if (supplierSelect) {
                supplierSelect.innerHTML = '<option value="">Seleccionar</option>';
                app.suppliers.forEach(sup => {
                    supplierSelect.innerHTML += `<option value="${sup.id}">${sup.name}</option>`;
                });
            }

            showView('inventory');
            renderNotifications();

            bindSafe('sidebarToggle', 'click', toggleSidebarSimple);
            // El menú móvil se maneja dentro de setupMobileSidebar con el clonado

            bindSafe('logoutBtn', 'click', () => {
                if (confirm('¿Desea cerrar la sesión actual?')) {
                    localStorage.removeItem('currentUser');
                    window.location.href = 'http://localhost/SmartStockAI/login.php';
                }
            });

            bindSafe('themeToggle', 'click', () => app.toggleTheme());

            bindSafe('notificationBtn', 'click', (e) => {
                e.stopPropagation();
                const dd = document.getElementById('notificationDropdown');
                if (dd) dd.classList.toggle('show');
            });
            bindSafe('markAllRead', 'click', (e) => {
                e.stopPropagation();
                app.markAllNotificationsAsRead();
                renderNotifications();
            });
            bindSafe('viewAllNotifications', 'click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                renderNotifications(true);
            });

            document.querySelectorAll('.sidebar-menu a[data-view]').forEach(link => {
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    showView(link.dataset.view);
                });
            });

            bindSafe('quickAddProduct', 'click', () => openProductModal('add'));
            bindSafe('quickScanQR', 'click', () => {
                const code = prompt('Escanea o pega el código del producto (ID, SKU o nombre):');
                if (!code) return;
                const term = code.trim().toLowerCase();
                const product = app.products.find(p =>
                    p.id.toLowerCase() === term ||
                    (p.sku && p.sku.toLowerCase() === term) ||
                    p.name.toLowerCase().includes(term)
                );
                if (product) {
                    showView('inventory');
                    document.getElementById('inventorySearch').value = product.name;
                    app.currentPage = 1;
                    renderInventory();
                    app.showNotification(`Producto encontrado: ${product.name}`, 'success');
                } else {
                    app.showNotification('Producto no encontrado', 'error');
                }
            });
            bindSafe('quickGenerateReport', 'click', () => {
                app.showNotification('Generando reporte...', 'info');
                setTimeout(() => {
                    exportInventory('pdf');
                    if (typeof confetti === 'function') confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
                }, 800);
            });
            bindSafe('quickCheckStock', 'click', () => {
                showView('inventory');
                const sf = document.getElementById('inventoryStatusFilter');
                if (sf) sf.value = 'Stock bajo';
                app.currentPage = 1;
                renderInventory();
            });

            bindSafe('newProductBtn', 'click', () => openProductModal('add'));
            bindSafe('newSupplierBtn', 'click', () => openSupplierModal('add'));
            bindSafe('saveProduct', 'click', saveProduct);
            bindSafe('saveSupplier', 'click', saveSupplier);

            bindSafe('inventorySearch', 'input', () => { app.currentPage = 1; renderInventory(); });
            bindSafe('inventoryCategoryFilter', 'change', () => { app.currentPage = 1; renderInventory(); });
            bindSafe('inventoryStatusFilter', 'change', () => { app.currentPage = 1; renderInventory(); });
            bindSafe('clearInventoryFilters', 'click', () => {
                document.getElementById('inventorySearch').value = '';
                document.getElementById('inventoryCategoryFilter').value = 'all';
                document.getElementById('inventoryStatusFilter').value = 'all';
                app.currentPage = 1;
                renderInventory();
            });

            bindSafe('refreshRecent', 'click', () => {
                renderDashboard();
                app.showNotification('Datos actualizados', 'success');
            });

            bindSafe('exportDropdownBtn', 'click', (e) => {
                e.stopPropagation();
                const options = document.getElementById('exportOptions');
                if (options) options.style.display = options.style.display === 'none' ? 'block' : 'none';
            });
            document.querySelectorAll('.export-option').forEach(opt => {
                opt.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const format = opt.dataset.format;
                    const options = document.getElementById('exportOptions');
                    if (options) options.style.display = 'none';
                    exportInventory(format);
                });
            });

            bindSafe('importBtn', 'click', () => {
                const fi = document.getElementById('importFileInput');
                if (fi) fi.click();
            });
            bindSafe('importFileInput', 'change', (event) => {
                if (event.target.files[0]) importInventoryFile(event.target.files[0]);
                event.target.value = '';
            });

            bindSafe('globalSearch', 'input', (e) => {
                const search = e.target.value;
                const suggestions = document.getElementById('searchSuggestions');
                if (!suggestions) return;
                if (search.length >= 2) {
                    const results = app.products.filter(p => p.name.toLowerCase().includes(search.toLowerCase())).slice(0, 5);
                    if (results.length > 0) {
                        suggestions.innerHTML = results.map(p => `
                            <div class="suggestion-item" data-product-id="${p.id}">
                                <i class="fas fa-box"></i>
                                <span>${p.name}</span>
                                <small>${p.id}</small>
                            </div>
                        `).join('');
                        suggestions.querySelectorAll('.suggestion-item').forEach(item => {
                            item.addEventListener('click', () => {
                                const product = app.getProductById(item.dataset.productId);
                                if (!product) return;
                                showView('inventory');
                                document.getElementById('inventorySearch').value = product.name;
                                app.currentPage = 1;
                                renderInventory();
                                suggestions.classList.remove('show');
                            });
                        });
                        suggestions.classList.add('show');
                    } else {
                        suggestions.classList.remove('show');
                    }
                } else {
                    suggestions.classList.remove('show');
                }
            });

            document.addEventListener('click', (e) => {
                if (!e.target.closest('.notification-container')) {
                    const dd = document.getElementById('notificationDropdown');
                    if (dd) dd.classList.remove('show');
                }
                if (!e.target.closest('#exportDropdownBtn') && !e.target.closest('#exportOptions')) {
                    const opts = document.getElementById('exportOptions');
                    if (opts) opts.style.display = 'none';
                }
                if (!e.target.closest('.search-box')) {
                    const ss = document.getElementById('searchSuggestions');
                    if (ss) ss.classList.remove('show');
                }
            });

            document.querySelectorAll('.modal-overlay').forEach(overlay => {
                overlay.addEventListener('click', (e) => {
                    if (e.target === overlay) closeModal(overlay.id);
                });
            });

            bindSafe('categoryPeriod', 'change', updateCharts);
            bindSafe('movementPeriod', 'change', updateCharts);

            setInterval(renderNotifications, 30000);

            console.log('%c✅ SmartStock AI listo', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (APP_STATE.isMobile ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });

        // Exponer funciones globales
        window.viewProduct = viewProduct;
        window.editProduct = editProduct;
        window.deleteProduct = deleteProduct;
        window.editSupplier = editSupplier;
        window.deleteSupplier = deleteSupplier;
        window.showQR = showQR;
        window.showBarcode = showBarcode;
        window.closeModal = closeModal;
        window.openModal = openModal;
        window.changeInventoryPage = changeInventoryPage;
        window.markNotificationRead = markNotificationRead;
        window.openProductModal = openProductModal;
        window.openSupplierModal = openSupplierModal;
        window.showView = showView;
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>