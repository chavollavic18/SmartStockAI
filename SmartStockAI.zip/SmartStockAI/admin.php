<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Panel de Control Profesional</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <style>
        /* Variables y estilos base optimizados */
        *{margin:0;padding:0;box-sizing:border-box}
        :root{
            --primary:#4361ee;--primary-dark:#3a56d4;--primary-light:#eef2ff;
            --secondary:#06d6a0;--secondary-dark:#05c095;--danger:#ef476f;
            --danger-dark:#d43f63;--warning:#ffd166;--warning-dark:#e6bc5c;
            --info:#4cc9f0;--info-dark:#3fb5d8;--dark:#2b2d42;--gray:#8d99ae;
            --gray-light:#edf2f4;--light:#f8f9fa;--success:#06d6a0;
            --success-dark:#05c095;--bg:#f8fafd;--card-bg:#ffffff;
            --text:#2b2d42;--text-light:#6c757d;--border-radius:16px;
            --border-radius-sm:12px;--border-radius-lg:24px;
            --transition:all 0.25s ease;--shadow-sm:0 4px 6px -1px rgba(0,0,0,0.1);
            --shadow-md:0 10px 15px -3px rgba(0,0,0,0.1);
            --shadow-lg:0 20px 25px -5px rgba(0,0,0,0.1);
        }
        .dark-mode{
            --bg:#1e1e2e;--card-bg:#2d2d44;--text:#f8f9fa;
            --text-light:#a0a0b0;--gray-light:#3d3d54;--primary-light:#2d2d44;
        }
        body{
            background:var(--bg);font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
            color:var(--text);transition:var(--transition);min-height:100vh;font-size:14px;line-height:1.6;
        }
        ::-webkit-scrollbar{width:8px;height:8px}
        ::-webkit-scrollbar-track{background:var(--gray-light);border-radius:4px}
        ::-webkit-scrollbar-thumb{background:var(--primary);border-radius:4px}
        .app-container{display:flex;min-height:100vh}
        
        /* Sidebar */
        .sidebar{
            width:280px;background:linear-gradient(180deg,var(--primary) 0%,var(--primary-dark) 100%);
            color:#fff;height:100vh;position:fixed;left:0;top:0;padding:24px 0;
            transition:var(--transition);z-index:1000;box-shadow:4px 0 20px rgba(0,0,0,0.15);
            display:flex;flex-direction:column;overflow-y:auto;
        }
        .sidebar-header{padding:0 24px 24px;border-bottom:1px solid rgba(255,255,255,0.15);margin-bottom:20px}
        .logo{font-size:24px;font-weight:700;letter-spacing:-0.5px;display:flex;align-items:center;gap:12px}
        .logo i{font-size:28px;background:rgba(255,255,255,0.2);padding:8px;border-radius:12px}
        .logo span{background:rgba(255,255,255,0.15);padding:4px 10px;border-radius:30px;font-size:11px;font-weight:500;margin-left:8px}
        .sidebar-menu{list-style:none;padding:0;flex:1}
        .sidebar-menu li{margin-bottom:2px}
        .sidebar-menu a{
            color:#fff;text-decoration:none;padding:14px 24px;display:flex;align-items:center;
            transition:var(--transition);border-left:4px solid transparent;font-weight:500;gap:14px;
        }
        .sidebar-menu a:hover,.sidebar-menu a.active{background:rgba(255,255,255,0.15);border-left-color:#fff}
        .sidebar-menu a i{width:24px;font-size:18px;text-align:center}
        .sidebar-menu .badge{background:var(--danger);color:#fff;font-size:11px;padding:4px 8px;border-radius:30px;margin-left:auto}
        .admin-label{font-size:12px;text-transform:uppercase;letter-spacing:1px;padding:0 24px;margin:20px 0 10px;opacity:0.7}
        .logout-section{margin-top:auto;padding:20px 24px;border-top:1px solid rgba(255,255,255,0.15)}
        .logout-btn{
            background:rgba(255,255,255,0.1);color:#fff;border:none;width:100%;padding:14px 20px;
            border-radius:var(--border-radius-sm);display:flex;align-items:center;gap:12px;
            transition:var(--transition);cursor:pointer;font-size:15px;font-weight:500;
        }
        .logout-btn:hover{background:rgba(255,255,255,0.2);transform:translateY(-2px)}
        
        /* Main Content */
        .main-content{flex:1;margin-left:280px;padding:25px 30px;transition:var(--transition)}
        .header{
            display:flex;justify-content:space-between;align-items:center;margin-bottom:30px;
            padding-bottom:20px;border-bottom:2px solid var(--gray-light);
        }
        .user-info{display:flex;align-items:center;gap:15px}
        .user-avatar{
            width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,var(--primary),var(--primary-dark));
            color:#fff;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:600;
        }
        .user-details h4{margin-bottom:5px;font-size:18px;font-weight:600}
        .user-details p{margin:0;color:var(--text-light);font-size:14px}
        .user-role{display:inline-block;padding:4px 12px;border-radius:30px;font-size:12px;font-weight:600;margin-top:6px}
        .role-admin{background:var(--warning);color:#000}
        .role-employee{background:var(--secondary);color:#fff}
        .role-manager{background:var(--info);color:#fff}
        .controls{display:flex;align-items:center;gap:15px}
        .search-container{position:relative;width:320px}
        .search-input{
            width:100%;padding:12px 20px 12px 48px;border:2px solid var(--gray-light);
            border-radius:40px;background:var(--card-bg);color:var(--text);font-size:14px;
        }
        .search-input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 4px rgba(67,97,238,0.15)}
        .search-icon{position:absolute;left:18px;top:50%;transform:translateY(-50%);color:var(--text-light)}
        .theme-switcher,.notifications,.fullscreen-btn{
            background:var(--card-bg);width:48px;height:48px;border-radius:14px;display:flex;
            align-items:center;justify-content:center;cursor:pointer;transition:var(--transition);
            box-shadow:var(--shadow-sm);border:2px solid var(--gray-light);
        }
        .theme-switcher:hover,.notifications:hover,.fullscreen-btn:hover{
            transform:translateY(-3px);box-shadow:var(--shadow-md);border-color:var(--primary);
        }
        .notifications{position:relative}
        .notification-badge{
            position:absolute;top:-5px;right:-5px;background:var(--danger);color:#fff;
            border-radius:50%;width:22px;height:22px;font-size:12px;display:flex;
            align-items:center;justify-content:center;font-weight:600;
        }
        
        /* Quick Actions */
        .quick-actions{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:30px}
        .action-btn{
            background:var(--card-bg);border:2px solid var(--gray-light);border-radius:var(--border-radius);
            padding:22px 16px;text-align:center;cursor:pointer;transition:var(--transition);
            box-shadow:var(--shadow-sm);position:relative;overflow:hidden;
        }
        .action-btn::before{
            content:'';position:absolute;top:0;left:0;right:0;height:4px;
            background:var(--primary);transform:scaleX(0);transition:var(--transition);
        }
        .action-btn:hover::before{transform:scaleX(1)}
        .action-btn:hover{transform:translateY(-5px);box-shadow:var(--shadow-hover);border-color:var(--primary)}
        .action-icon{font-size:32px;margin-bottom:12px;color:var(--primary)}
        .action-text{font-size:15px;font-weight:600}
        .action-badge{
            position:absolute;top:10px;right:10px;background:var(--danger);color:#fff;
            border-radius:30px;padding:3px 10px;font-size:11px;font-weight:600;
        }
        
        /* Stats */
        .stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-bottom:30px}
        .stat-card{
            background:var(--card-bg);border-radius:var(--border-radius);padding:24px;
            box-shadow:var(--shadow-md);transition:var(--transition);position:relative;overflow:hidden;
        }
        .stat-card::after{
            content:'';position:absolute;top:0;right:0;width:120px;height:120px;
            background:var(--primary-light);border-radius:50%;transform:translate(40px,-40px);opacity:0.3;
        }
        .stat-card:hover{transform:translateY(-5px);box-shadow:var(--shadow-lg)}
        .stat-value{font-size:34px;font-weight:700;margin-bottom:8px;position:relative;z-index:1}
        .stat-label{font-size:14px;color:var(--text-light);text-transform:uppercase;letter-spacing:0.5px;font-weight:600}
        .stat-icon{position:absolute;bottom:15px;right:15px;font-size:48px;color:var(--primary);opacity:0.15}
        .stat-change{font-size:13px;margin-top:10px;display:flex;align-items:center;gap:6px}
        .stat-change.positive{color:var(--secondary)}
        .stat-change.negative{color:var(--danger)}
        
        /* Cards */
        .dashboard-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:24px;margin-bottom:30px}
        .card{
            background:var(--card-bg);border-radius:var(--border-radius-lg);padding:24px;
            box-shadow:var(--shadow-md);border:2px solid var(--gray-light);
        }
        .card-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
        .card-title{font-size:16px;font-weight:600;color:var(--text-light);text-transform:uppercase}
        .card-icon{
            width:56px;height:56px;border-radius:16px;display:flex;align-items:center;
            justify-content:center;font-size:24px;
        }
        .bg-primary-light{background:var(--primary-light);color:var(--primary)}
        .bg-success-light{background:rgba(6,214,160,0.15);color:var(--secondary)}
        .bg-warning-light{background:rgba(255,209,102,0.15);color:var(--warning)}
        .bg-danger-light{background:rgba(239,71,111,0.15);color:var(--danger)}
        .bg-info-light{background:rgba(76,201,240,0.15);color:var(--info)}
        .card-value{font-size:38px;font-weight:700;margin:15px 0 8px}
        .card-description{font-size:14px;color:var(--text-light);display:flex;justify-content:space-between}
        .progress{height:8px;background:var(--gray-light);border-radius:4px;margin:15px 0;overflow:hidden}
        .progress-bar{height:100%;border-radius:4px;transition:width 0.6s}
        
        /* Charts */
        .charts-section{display:grid;grid-template-columns:2fr 1fr;gap:24px;margin-bottom:30px}
        .chart-container{
            background:var(--card-bg);border-radius:var(--border-radius-lg);padding:24px;
            box-shadow:var(--shadow-md);border:2px solid var(--gray-light);
        }
        .chart-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
        .chart-title{font-size:18px;font-weight:600;display:flex;align-items:center;gap:10px}
        .chart-actions{display:flex;gap:8px;background:var(--gray-light);padding:4px;border-radius:40px}
        .chart-btn{
            background:0 0;border:none;border-radius:30px;padding:8px 18px;font-size:13px;
            font-weight:600;cursor:pointer;color:var(--text-light);
        }
        .chart-btn.active{background:var(--primary);color:#fff}
        
        /* Activity */
        .activity-list{list-style:none;padding:0}
        .activity-item{
            display:flex;align-items:center;padding:16px 0;border-bottom:1px solid var(--gray-light);
            transition:var(--transition);
        }
        .activity-item:hover{background:var(--gray-light);padding-left:12px;border-radius:var(--border-radius-sm)}
        .activity-icon{
            width:48px;height:48px;border-radius:14px;display:flex;align-items:center;
            justify-content:center;margin-right:16px;font-size:20px;
        }
        .activity-content{flex:1}
        .activity-title{font-weight:600;margin-bottom:5px}
        .activity-time{font-size:12px;color:var(--text-light);display:flex;align-items:center;gap:8px}
        
        /* Admin Section */
        .admin-section{
            background:var(--card-bg);border-radius:var(--border-radius-lg);padding:30px;
            margin-bottom:30px;box-shadow:var(--shadow-md);border:2px solid var(--gray-light);
        }
        .section-title{
            font-size:20px;font-weight:600;margin-bottom:25px;padding-bottom:15px;
            border-bottom:2px solid var(--gray-light);display:flex;align-items:center;gap:10px;
        }
        .admin-feature{
            padding:20px 24px;border-radius:var(--border-radius);background:var(--bg);
            margin-bottom:15px;display:flex;align-items:center;cursor:pointer;
            transition:var(--transition);border:2px solid transparent;
        }
        .admin-feature:hover{transform:translateX(10px);border-color:var(--primary);box-shadow:var(--shadow-md)}
        .admin-feature i{
            width:56px;height:56px;border-radius:14px;background:var(--primary);color:#fff;
            display:flex;align-items:center;justify-content:center;margin-right:20px;font-size:22px;
        }
        .admin-feature h5{margin-bottom:6px;font-size:16px;font-weight:600}
        .admin-feature p{margin:0;color:var(--text-light)}
        .restricted-section{
            background:var(--card-bg);border-radius:var(--border-radius-lg);padding:30px;
            margin-bottom:30px;box-shadow:var(--shadow-md);border-left:6px solid var(--danger);
        }
        
        /* Modales */
        .modal-overlay{
            position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);
            backdrop-filter:blur(5px);display:none;align-items:center;justify-content:center;
            z-index:2000;
        }
        .modal-overlay.show{display:flex}
        .modal{
            background:var(--card-bg);border-radius:28px;width:95%;max-width:750px;
            max-height:90vh;overflow-y:auto;box-shadow:0 30px 60px rgba(0,0,0,0.3);
            border:2px solid var(--gray-light);
        }
        .modal-header{
            padding:24px 28px;border-bottom:2px solid var(--gray-light);display:flex;
            justify-content:space-between;align-items:center;background:var(--primary-light);
            border-radius:28px 28px 0 0;position:sticky;top:0;z-index:2;
        }
        .modal-body{padding:28px}
        .modal-footer{
            padding:24px 28px;border-top:2px solid var(--gray-light);display:flex;
            justify-content:flex-end;gap:12px;background:var(--bg);
        }
        
        /* Forms */
        .form-group{margin-bottom:22px}
        .form-group label{display:block;margin-bottom:8px;font-weight:600}
        .form-control,.form-select{
            width:100%;padding:12px 16px;border:2px solid var(--gray-light);
            border-radius:12px;background:var(--card-bg);color:var(--text);
        }
        .form-control:focus,.form-select:focus{outline:none;border-color:var(--primary)}
        
        /* Buttons */
        .btn{
            padding:12px 28px;border:none;border-radius:12px;cursor:pointer;
            transition:var(--transition);font-weight:600;font-size:14px;
            display:inline-flex;align-items:center;gap:8px;justify-content:center;
        }
        .btn-primary{background:var(--primary);color:#fff}
        .btn-primary:hover{background:var(--primary-dark);transform:translateY(-2px)}
        .btn-secondary{background:var(--gray);color:#fff}
        .btn-success{background:var(--secondary);color:#fff}
        .btn-danger{background:var(--danger);color:#fff}
        .btn-outline{background:0 0;border:2px solid var(--primary);color:var(--primary)}
        .btn-sm{padding:8px 16px;font-size:13px}
        
        /* Notifications Panel */
        .notifications-panel{
            position:fixed;top:90px;right:30px;width:400px;background:var(--card-bg);
            border-radius:var(--border-radius-lg);box-shadow:var(--shadow-lg);z-index:1000;
            display:none;max-height:550px;overflow-y:auto;border:2px solid var(--gray-light);
        }
        .notifications-panel.show{display:block}
        .notification-header{
            padding:20px 24px;border-bottom:2px solid var(--gray-light);display:flex;
            justify-content:space-between;align-items:center;background:var(--primary-light);
        }
        .notification-item{
            padding:18px 24px;border-bottom:1px solid var(--gray-light);cursor:pointer;
        }
        .notification-item.unread{background:var(--primary-light);position:relative}
        .notification-item.unread::before{
            content:'';position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--primary);
        }
        
        /* Product & Cart */
        .product-item{
            display:flex;justify-content:space-between;align-items:center;padding:16px;
            border:2px solid var(--gray-light);border-radius:var(--border-radius);margin-bottom:10px;
        }
        .product-price{font-weight:700;color:var(--secondary);font-size:20px}
        .cart-item{
            display:flex;justify-content:space-between;align-items:center;padding:12px;
            border:2px solid var(--gray-light);border-radius:var(--border-radius-sm);margin-bottom:10px;
        }
        .qr-container{text-align:center;padding:30px;background:#fff;border-radius:var(--border-radius)}
        #qrcode{margin:20px auto;display:inline-block;padding:20px;background:#fff}
        
        /* Table */
        .table{width:100%;border-collapse:collapse}
        .table th{background:var(--primary-light);padding:15px;text-align:left;font-weight:600}
        .table td{padding:15px;border-bottom:1px solid var(--gray-light)}
        
        /* Badges */
        .badge{padding:5px 12px;border-radius:30px;font-size:12px;font-weight:600}
        .badge.bg-success{background:var(--secondary);color:#fff}
        .badge.bg-warning{background:var(--warning);color:#000}
        .badge.bg-danger{background:var(--danger);color:#fff}
        .badge.bg-info{background:var(--info);color:#fff}
        
        /* Toast */
        .toast-container{position:fixed;bottom:30px;right:30px;z-index:2100}
        .toast{
            min-width:300px;background:var(--card-bg);border:2px solid var(--gray-light);
            border-radius:var(--border-radius);overflow:hidden;
        }
        .toast-header{padding:12px 18px;border-bottom:2px solid var(--gray-light)}
        .toast-body{padding:15px 18px}
        
        /* Menu Toggle */
        .menu-toggle{
            display:none;background:var(--primary);color:#fff;border:none;width:56px;
            height:56px;border-radius:16px;position:fixed;bottom:25px;left:25px;
            z-index:1001;box-shadow:var(--shadow-lg);cursor:pointer;font-size:22px;
        }
        
        /* Responsive */
        @media (max-width:1200px){.stats-grid{grid-template-columns:repeat(2,1fr)}}
        @media (max-width:992px){
            .sidebar{transform:translateX(-100%);width:0}
            .sidebar.open{transform:translateX(0);width:280px}
            .main-content{margin-left:0}
            .menu-toggle{display:flex}
            .charts-section{grid-template-columns:1fr}
        }
        @media (max-width:768px){
            .main-content{padding:20px 15px}
            .header{flex-direction:column;align-items:flex-start;gap:20px}
            .controls{width:100%;justify-content:space-between}
            .search-container{width:100%}
            .stats-grid{grid-template-columns:1fr}
            .quick-actions{grid-template-columns:repeat(2,1fr)}
            .notifications-panel{width:90%;right:5%;left:5%}
        }
        
        /* Utilidades */
        .text-success{color:var(--secondary)!important}
        .text-danger{color:var(--danger)!important}
        .text-warning{color:var(--warning)!important}
        .text-primary{color:var(--primary)!important}
        .inventory-item.low-stock{background:rgba(255,209,102,0.1)}
        .inventory-item.critical-stock{background:rgba(239,71,111,0.1)}
        .inventory-item.out-stock{background:rgba(239,71,111,0.2)}
    </style>
</head>
<body>
<div class="app-container">
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo"><i class="fas fa-robot"></i>SmartStock<span>v3.0</span></div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="#" data-page="dashboard" class="active"><i class="fas fa-home"></i>Dashboard<span class="badge">Nuevo</span></a></li>
            <li><a href="#" data-page="inventario"><i class="fas fa-boxes"></i>Inventario</a></li>
            <li><a href="#" data-page="reportes"><i class="fas fa-chart-line"></i>Reportes</a></li>
            <li><a href="#" data-page="clientes"><i class="fas fa-users"></i>Clientes</a></li>
            <li><a href="#" data-page="proveedores"><i class="fas fa-truck"></i>Proveedores</a></li>
            <li><a href="#" data-page="transacciones"><i class="fas fa-exchange-alt"></i>Transacciones</a></li>
            <li><a href="#" data-page="ventas"><i class="fas fa-shopping-cart"></i>Ventas</a></li>
            <li><div class="admin-label" id="adminMenuLabel">Administración</div></li>
            <li><a href="#" data-page="usuarios"><i class="fas fa-user-cog"></i>Usuarios</a></li>
            <li><a href="#" data-page="perfil"><i class="fas fa-user-circle"></i>Mi Perfil</a></li>
            <li><a href="#" data-page="seguridad"><i class="fas fa-shield-alt"></i>Seguridad</a></li>
            <li><a href="#" data-page="configuracion"><i class="fas fa-cog"></i>Configuración</a></li>
            <li><a href="#" data-page="ayuda"><i class="fas fa-question-circle"></i>Ayuda</a></li>
        </ul>
        <div class="logout-section">
            <button class="logout-btn" id="logoutBtn"><i class="fas fa-sign-out-alt"></i>Cerrar Sesión</button>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <div class="user-info">
                <div class="user-avatar" id="userAvatar">AG</div>
                <div class="user-details">
                    <h4 id="userName">Ana García</h4>
                    <p id="userEmail">admin@smartstock.ai</p>
                    <span class="user-role role-admin" id="userRole">Administrador</span>
                </div>
            </div>
            <div class="controls">
                <div class="search-container">
                    <input type="text" class="search-input" id="searchInput" placeholder="Buscar productos, clientes...">
                    <i class="fas fa-search search-icon"></i>
                </div>
                <div class="fullscreen-btn" id="fullscreenToggle"><i class="fas fa-expand"></i></div>
                <div class="theme-switcher" id="themeToggle"><i class="fas fa-moon"></i></div>
                <div class="notifications" id="notificationsBtn">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge" id="notificationBadge">3</span>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <button class="action-btn" id="quickSaleBtn"><div class="action-icon"><i class="fas fa-cash-register"></i></div><div class="action-text">Venta Rápida</div></button>
            <button class="action-btn" id="addProductBtn"><div class="action-icon"><i class="fas fa-plus-circle"></i></div><div class="action-text">Agregar Producto</div></button>
            <button class="action-btn" id="generateReportBtn"><div class="action-icon"><i class="fas fa-file-pdf"></i></div><div class="action-text">Generar Reporte</div></button>
            <button class="action-btn" id="inventoryCheckBtn"><div class="action-icon"><i class="fas fa-clipboard-check"></i></div><div class="action-text">Revisar Inventario</div><span class="action-badge">3</span></button>
            <button class="action-btn" id="aiAnalysisBtn"><div class="action-icon"><i class="fas fa-brain"></i></div><div class="action-text">Análisis IA</div></button>
            <button class="action-btn" id="qrGeneratorBtn"><div class="action-icon"><i class="fas fa-qrcode"></i></div><div class="action-text">Generar QR</div></button>
            <button class="action-btn" id="importDataBtn"><div class="action-icon"><i class="fas fa-file-import"></i></div><div class="action-text">Importar Datos</div></button>
            <button class="action-btn" id="exportDataBtn"><div class="action-icon"><i class="fas fa-file-export"></i></div><div class="action-text">Exportar Datos</div></button>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card"><div class="stat-value" id="dailySales">$4,850</div><div class="stat-label">Ventas Hoy</div><div class="stat-change positive"><i class="fas fa-arrow-up"></i>+15.3% vs ayer</div><i class="fas fa-shopping-cart stat-icon"></i></div>
            <div class="stat-card"><div class="stat-value" id="lowStock">3</div><div class="stat-label">Stock Bajo</div><div class="stat-change negative"><i class="fas fa-arrow-down"></i>-2 vs ayer</div><i class="fas fa-exclamation-triangle stat-icon"></i></div>
            <div class="stat-card"><div class="stat-value" id="pendingOrders">15</div><div class="stat-label">Pedidos Pendientes</div><div class="stat-change positive"><i class="fas fa-arrow-up"></i>+5 nuevos</div><i class="fas fa-truck stat-icon"></i></div>
            <div class="stat-card"><div class="stat-value" id="customerCount">234</div><div class="stat-label">Clientes Activos</div><div class="stat-change positive"><i class="fas fa-arrow-up"></i>+18 este mes</div><i class="fas fa-users stat-icon"></i></div>
        </div>

        <!-- Dashboard Cards -->
        <div class="dashboard-cards">
            <div class="card"><div class="card-header"><div class="card-title">Productos en Stock</div><div class="card-icon bg-primary-light"><i class="fas fa-box"></i></div></div><div class="card-value" id="totalProducts">1,456</div><div class="progress"><div class="progress-bar" style="width:82%;background:var(--primary)"></div></div><div class="card-description"><span><i class="fas fa-arrow-up text-success"></i>+108 este mes</span><span>82% capacidad</span></div></div>
            <div class="card"><div class="card-header"><div class="card-title">Ventas del Mes</div><div class="card-icon bg-success-light"><i class="fas fa-shopping-cart"></i></div></div><div class="card-value" id="monthlySales">$32,450</div><div class="progress"><div class="progress-bar" style="width:78%;background:var(--secondary)"></div></div><div class="card-description"><span><i class="fas fa-arrow-up text-success"></i>+18% vs mes ant</span><span>78% meta</span></div></div>
            <div class="card"><div class="card-header"><div class="card-title">Pedidos Pendientes</div><div class="card-icon bg-warning-light"><i class="fas fa-clipboard-list"></i></div></div><div class="card-value">42</div><div class="progress"><div class="progress-bar" style="width:52%;background:var(--warning)"></div></div><div class="card-description"><span><i class="fas fa-exclamation-circle text-warning"></i>12 urgentes</span><span>52% procesados</span></div></div>
            <div class="card"><div class="card-header"><div class="card-title">Alertas del Sistema</div><div class="card-icon bg-danger-light"><i class="fas fa-exclamation-triangle"></i></div></div><div class="card-value" id="systemAlerts">2</div><div class="progress"><div class="progress-bar" style="width:100%;background:var(--danger)"></div></div><div class="card-description"><span><i class="fas fa-clock"></i>1 crítica</span><span>Revisar ahora</span></div></div>
        </div>

        <!-- Charts Section -->
        <div class="charts-section">
            <div class="chart-container">
                <div class="chart-header">
                    <div class="chart-title"><i class="fas fa-chart-line text-primary"></i>Ventas 2024</div>
                    <div class="chart-actions">
                        <button class="chart-btn active" data-period="week">Semana</button>
                        <button class="chart-btn" data-period="month">Mes</button>
                        <button class="chart-btn" data-period="quarter">Trimestre</button>
                        <button class="chart-btn" data-period="year">Año</button>
                    </div>
                </div>
                <canvas id="salesChart" style="height:300px;width:100%"></canvas>
            </div>
            <div class="chart-container">
                <div class="chart-header">
                    <div class="chart-title"><i class="fas fa-history text-info"></i>Actividad Reciente</div>
                    <button class="btn btn-sm btn-outline" id="refreshActivityBtn"><i class="fas fa-sync-alt"></i></button>
                </div>
                <ul class="activity-list" id="activityList"></ul>
            </div>
        </div>

        <!-- Admin Section -->
        <div class="admin-section" id="adminSection">
            <h3 class="section-title"><i class="fas fa-crown text-warning"></i>Panel de Administración</h3>
            <div class="row g-4">
                <div class="col-md-6"><div class="admin-feature" data-feature="users"><i class="fas fa-user-cog"></i><div><h5>Gestión de Usuarios</h5><p>Crear, editar y eliminar usuarios. Asignar roles y permisos.</p><small>12 usuarios activos · 3 pendientes</small></div></div></div>
                <div class="col-md-6"><div class="admin-feature" data-feature="database"><i class="fas fa-database"></i><div><h5>Base de Datos</h5><p>Copias de seguridad, restauración y optimización.</p><small>Último backup: Hoy 10:30 · 2.3 GB</small></div></div></div>
                <div class="col-md-6"><div class="admin-feature" data-feature="security"><i class="fas fa-shield-alt"></i><div><h5>Seguridad</h5><p>Políticas de seguridad, 2FA y logs de acceso.</p><small>Nivel: Alto · 2FA activado</small></div></div></div>
                <div class="col-md-6"><div class="admin-feature" data-feature="system"><i class="fas fa-cogs"></i><div><h5>Ajustes del Sistema</h5><p>Configuración general y personalización.</p><small>v3.0 · Actualización disponible</small></div></div></div>
            </div>
        </div>

        <!-- Restricted Section -->
        <div class="restricted-section" id="restrictedSection" style="display:none">
            <div class="restricted-header"><i class="fas fa-lock"></i><h3>Acceso Restringido</h3></div>
            <div class="restricted-content">
                <p><strong>No tienes permisos para acceder al panel de administración.</strong></p>
                <p>Tus funciones disponibles son:</p>
                <ul>
                    <li><i class="fas fa-check text-success"></i>Gestión de Inventario</li>
                    <li><i class="fas fa-check text-success"></i>Ventas y Transacciones</li>
                    <li><i class="fas fa-check text-success"></i>Reportes Básicos</li>
                    <li><i class="fas fa-check text-success"></i>Clientes y Proveedores</li>
                    <li><i class="fas fa-times text-danger"></i>Administración de Usuarios</li>
                    <li><i class="fas fa-times text-danger"></i>Configuración del Sistema</li>
                </ul>
                <button class="btn btn-primary mt-3" id="requestAccessBtn"><i class="fas fa-paper-plane"></i>Solicitar Acceso</button>
            </div>
        </div>
    </div>
</div>

<!-- Notifications Panel -->
<div class="notifications-panel" id="notificationsPanel">
    <div class="notification-header">
        <h5><i class="fas fa-bell"></i>Notificaciones (<span id="notifCount">3</span>)</h5>
        <button class="btn btn-sm btn-secondary" id="markAllReadBtn"><i class="fas fa-check-double"></i>Leer todas</button>
    </div>
    <div id="notificationsList"></div>
</div>

<!-- Modales -->
<div class="modal-overlay" id="quickSaleModal"><div class="modal"><div class="modal-header"><h4><i class="fas fa-cash-register"></i>Venta Rápida</h4><button class="btn btn-secondary btn-sm close-modal"><i class="fas fa-times"></i></button></div><div class="modal-body"><div class="row mb-4"><div class="col-md-8"><div class="form-group"><label>Buscar Producto</label><input type="text" class="form-control" id="productSearchInput" placeholder="Nombre o código..."></div></div><div class="col-md-4"><div class="form-group"><label>Cliente</label><select class="form-select" id="customerSelect"><option value="general">Cliente General</option><option value="1">Juan Pérez</option><option value="2">María López</option></select></div></div></div><div class="row mb-3"><div class="col-12"><h6>Productos Disponibles</h6><div class="row g-2" id="productGrid"></div></div></div><div class="row mt-4"><div class="col-12"><h6>Carrito <span class="badge bg-primary" id="cartCount">0</span></h6><div id="cartItems" class="border rounded p-3 mb-3" style="min-height:100px;max-height:200px;overflow-y:auto"></div><div class="row"><div class="col-md-6"><div class="form-group"><label>Método de Pago</label><select class="form-select" id="paymentMethodSelect"><option value="cash">Efectivo</option><option value="card">Tarjeta</option></select></div></div><div class="col-md-6"><div class="form-group"><label>Descuento (%)</label><input type="number" class="form-control" id="discountInput" min="0" max="100" value="0"></div></div></div><div class="text-end mt-3"><h5>Subtotal: $<span id="cartSubtotal">0.00</span></h5><h5>Descuento: $<span id="discountAmount">0.00</span></h5><h4 class="text-primary">Total: $<span id="cartTotal">0.00</span></h4></div></div></div></div><div class="modal-footer"><button class="btn btn-secondary close-modal">Cancelar</button><button class="btn btn-success" id="processSaleBtn" disabled>Procesar Venta</button></div></div></div>

<div class="modal-overlay" id="addProductModal"><div class="modal"><div class="modal-header"><h4><i class="fas fa-plus-circle"></i>Agregar Producto</h4><button class="btn btn-secondary btn-sm close-modal"><i class="fas fa-times"></i></button></div><div class="modal-body"><form id="addProductForm"><div class="row"><div class="col-md-6"><div class="form-group"><label>Nombre *</label><input type="text" class="form-control" id="productNameInput" required></div></div><div class="col-md-6"><div class="form-group"><label>Código *</label><input type="text" class="form-control" id="productCodeInput" required></div></div></div><div class="row"><div class="col-md-6"><div class="form-group"><label>Categoría *</label><select class="form-select" id="productCategorySelect" required><option value="">Seleccionar</option><option>Electrónica</option><option>Computación</option></select></div></div><div class="col-md-6"><div class="form-group"><label>Proveedor</label><select class="form-select" id="productSupplierSelect"><option value="">Seleccionar</option><option>TecnoSupply</option></select></div></div></div><div class="row"><div class="col-md-4"><div class="form-group"><label>Precio Compra ($)</label><input type="number" class="form-control" id="purchasePriceInput" min="0" step="0.01"></div></div><div class="col-md-4"><div class="form-group"><label>Precio Venta ($) *</label><input type="number" class="form-control" id="priceInput" min="0" step="0.01" required></div></div><div class="col-md-4"><div class="form-group"><label>Margen (%)</label><input type="text" class="form-control" id="marginInput" readonly></div></div></div><div class="row"><div class="col-md-4"><div class="form-group"><label>Stock Inicial *</label><input type="number" class="form-control" id="stockInput" min="0" required></div></div><div class="col-md-4"><div class="form-group"><label>Stock Mínimo *</label><input type="number" class="form-control" id="minStockInput" min="0" required></div></div><div class="col-md-4"><div class="form-group"><label>Stock Máximo</label><input type="number" class="form-control" id="maxStockInput" min="0"></div></div></div><div class="form-group"><label>Descripción</label><textarea class="form-control" id="descriptionInput" rows="2"></textarea></div></form></div><div class="modal-footer"><button class="btn btn-secondary close-modal">Cancelar</button><button class="btn btn-primary" id="saveProductBtn">Guardar</button></div></div></div>

<div class="modal-overlay" id="generateReportModal"><div class="modal"><div class="modal-header"><h4><i class="fas fa-file-pdf"></i>Generar Reporte</h4><button class="btn btn-secondary btn-sm close-modal"><i class="fas fa-times"></i></button></div><div class="modal-body"><div class="form-group"><label>Tipo de Reporte</label><select class="form-select" id="reportTypeSelect"><option value="inventory">Inventario General</option><option value="sales">Ventas</option></select></div><div class="form-group"><label>Formato</label><select class="form-select" id="reportFormatSelect"><option value="pdf">PDF</option><option value="excel">Excel</option></select></div><div class="form-group"><label>Período</label><select class="form-select" id="dateRangeSelect"><option value="today">Hoy</option><option value="week">Esta Semana</option><option value="month">Este Mes</option></select></div></div><div class="modal-footer"><button class="btn btn-secondary close-modal">Cancelar</button><button class="btn btn-primary" id="generateReportActionBtn">Generar</button></div></div></div>

<div class="modal-overlay" id="inventoryCheckModal"><div class="modal" style="max-width:900px"><div class="modal-header"><h4><i class="fas fa-clipboard-check"></i>Revisión de Inventario</h4><button class="btn btn-secondary btn-sm close-modal"><i class="fas fa-times"></i></button></div><div class="modal-body"><div class="row mb-4"><div class="col-md-8"><div class="tab-buttons"><button class="tab-btn active" data-tab="all">Todos</button><button class="tab-btn" data-tab="low">Stock Bajo</button><button class="tab-btn" data-tab="critical">Crítico</button></div></div><div class="col-md-4"><input type="text" class="form-control" id="filterInventoryInput" placeholder="Filtrar..."></div></div><div id="inventoryList" style="max-height:400px;overflow-y:auto"><table class="table table-hover"><thead><tr><th>Código</th><th>Producto</th><th>Categoría</th><th>Stock</th><th>Mínimo</th><th>Estado</th><th>Acciones</th></tr></thead><tbody id="inventoryTableBody"></tbody></table></div></div><div class="modal-footer"><button class="btn btn-secondary close-modal">Cerrar</button><button class="btn btn-primary" id="exportInventoryBtn">Exportar</button><button class="btn btn-success" id="reorderStockBtn">Reordenar</button></div></div></div>

<div class="modal-overlay" id="aiAnalysisModal"><div class="modal" style="max-width:800px"><div class="modal-header"><h4><i class="fas fa-brain"></i>Análisis IA</h4><button class="btn btn-secondary btn-sm close-modal"><i class="fas fa-times"></i></button></div><div class="modal-body"><div id="aiResults"><div class="row"><div class="col-md-6"><div class="ai-analysis-result"><h5><i class="fas fa-chart-line text-primary"></i>Predicción de Ventas</h5><div id="aiPredictions"></div></div></div><div class="col-md-6"><div class="ai-analysis-result"><h5><i class="fas fa-shopping-cart text-success"></i>Recomendaciones</h5><ul class="list-unstyled" id="aiRecommendations"></ul></div></div></div></div></div><div class="modal-footer"><button class="btn btn-secondary close-modal">Cerrar</button><button class="btn btn-primary" id="refreshAIAnalysisBtn">Actualizar</button><button class="btn btn-success" id="exportAIAnalysisBtn">Exportar</button></div></div></div>

<div class="modal-overlay" id="qrModal"><div class="modal" style="max-width:500px"><div class="modal-header"><h4><i class="fas fa-qrcode"></i>Generar QR</h4><button class="btn btn-secondary btn-sm close-modal"><i class="fas fa-times"></i></button></div><div class="modal-body"><div class="form-group"><label>Tipo</label><select class="form-select" id="qrTypeSelect"><option value="product">Producto</option><option value="invoice">Factura</option><option value="custom">Personalizado</option></select></div><div class="form-group" id="qrProductGroup"><label>Producto</label><select class="form-select" id="qrProductSelect"></select></div><div class="form-group" id="qrCustomGroup" style="display:none"><label>Texto</label><input type="text" class="form-control" id="qrCustomText" placeholder="Texto para QR"></div><div class="form-group"><label>Tamaño</label><select class="form-select" id="qrSizeSelect"><option value="150">Pequeño</option><option value="200" selected>Mediano</option><option value="250">Grande</option></select></div><div class="qr-container" id="qrContainer" style="display:none"><div id="qrcode"></div><p id="qrText" class="text-muted small mt-2"></p><div class="btn-group w-100"><button class="btn btn-primary" id="downloadQRBtn"><i class="fas fa-download"></i>Descargar</button><button class="btn btn-success" id="printQRBtn"><i class="fas fa-print"></i>Imprimir</button></div></div><button class="btn btn-primary btn-block mt-3" id="generateQRActionBtn"><i class="fas fa-qrcode"></i>Generar QR</button></div><div class="modal-footer"><button class="btn btn-secondary close-modal">Cerrar</button></div></div></div>

<div class="modal-overlay" id="importModal"><div class="modal"><div class="modal-header"><h4><i class="fas fa-file-import"></i>Importar Datos</h4><button class="btn btn-secondary btn-sm close-modal"><i class="fas fa-times"></i></button></div><div class="modal-body"><div class="form-group"><label>Tipo</label><select class="form-select" id="importTypeSelect"><option value="products">Productos</option><option value="customers">Clientes</option></select></div><div class="form-group"><label>Archivo</label><input type="file" class="form-control" id="importFileInput" accept=".xlsx,.xls,.csv"></div><div class="alert alert-info"><i class="fas fa-info-circle"></i>Descarga la <a href="#" id="downloadTemplateLink">plantilla</a></div></div><div class="modal-footer"><button class="btn btn-secondary close-modal">Cancelar</button><button class="btn btn-primary" id="processImportBtn" disabled>Importar</button></div></div></div>

<div class="modal-overlay" id="exportModal"><div class="modal"><div class="modal-header"><h4><i class="fas fa-file-export"></i>Exportar Datos</h4><button class="btn btn-secondary btn-sm close-modal"><i class="fas fa-times"></i></button></div><div class="modal-body"><div class="form-group"><label>Tipo</label><select class="form-select" id="exportTypeSelect"><option value="products">Productos</option><option value="customers">Clientes</option></select></div><div class="form-group"><label>Formato</label><select class="form-select" id="exportFormatSelect"><option value="excel">Excel</option><option value="csv">CSV</option></select></div></div><div class="modal-footer"><button class="btn btn-secondary close-modal">Cancelar</button><button class="btn btn-primary" id="processExportBtn">Exportar</button></div></div></div>

<div class="modal-overlay" id="requestAccessModal"><div class="modal"><div class="modal-header"><h4><i class="fas fa-paper-plane"></i>Solicitar Acceso</h4><button class="btn btn-secondary btn-sm close-modal"><i class="fas fa-times"></i></button></div><div class="modal-body"><div class="form-group"><label>Nombre</label><input type="text" class="form-control" id="requestNameInput" readonly></div><div class="form-group"><label>Rol</label><input type="text" class="form-control" id="requestRoleInput" readonly></div><div class="form-group"><label>Funciones</label><select class="form-select" id="requestFeaturesSelect" multiple size="3"><option value="users">Usuarios</option><option value="database">Base de Datos</option></select></div><div class="form-group"><label>Justificación</label><textarea class="form-control" id="requestJustificationInput" rows="3"></textarea></div></div><div class="modal-footer"><button class="btn btn-secondary close-modal">Cancelar</button><button class="btn btn-primary" id="submitRequestBtn">Enviar</button></div></div></div>

<!-- Toast -->
<div class="toast-container"><div id="toast" class="toast" style="display:none"><div class="toast-header" id="toastHeader"><i class="fas fa-check-circle me-2"></i><strong class="me-auto" id="toastTitle">Éxito</strong></div><div class="toast-body" id="toastMessage"></div></div></div>

<button class="menu-toggle" id="menuToggleBtn"><i class="fas fa-bars"></i></button>

<script>
(function(){
    "use strict";

    function loadAdminProducts() {
        try {
            const products = JSON.parse(localStorage.getItem('products'));
            if (Array.isArray(products) && products.length) {
                return products.map(product => ({
                    ...product,
                    code: product.code || product.id,
                    price: Number(product.price) || 0,
                    stock: Number(product.stock) || 0,
                    minStock: Number.isFinite(Number(product.minStock)) ? Number(product.minStock) : 5
                }));
            }
        } catch (error) {
            console.warn('No se pudieron cargar los productos guardados', error);
        }
        return [
            { code: "LPT001", name: "Laptop HP Pavilion", category: "Computación", price: 850, stock: 15, minStock: 5, purchasePrice: 650 },
            { code: "MOU002", name: "Mouse Inalámbrico", category: "Accesorios", price: 25, stock: 42, minStock: 10, purchasePrice: 15 },
            { code: "TEC003", name: "Teclado Mecánico", category: "Accesorios", price: 89, stock: 8, minStock: 10, purchasePrice: 60 },
            { code: "MON004", name: "Monitor 24\"", category: "Electrónica", price: 299, stock: 3, minStock: 5, purchasePrice: 220 },
            { code: "SSD005", name: "SSD 1TB", category: "Computación", price: 129, stock: 2, minStock: 10, purchasePrice: 95 },
            { code: "IMP006", name: "Impresora", category: "Oficina", price: 450, stock: 12, minStock: 3, purchasePrice: 350 }
        ];
    }

    function persistAdminProducts(products) {
        localStorage.setItem('products', JSON.stringify(products));
    }

    // ==================== DATOS ====================
    const state = {
        currentUser: null,
        cart: [],
        salesChart: null,
        products: loadAdminProducts(),
        notifications: [
            { id: 1, title: "Stock crítico", message: "3 productos requieren atención", time: "Hace 10 min", read: false, type: "warning" },
            { id: 2, title: "Nuevo pedido #1245", message: "Cliente Corp - $2,450", time: "Hace 25 min", read: false, type: "success" },
            { id: 3, title: "Backup completado", message: "Copia automática exitosa", time: "Hace 2 horas", read: false, type: "info" }
        ],
        activities: [
            { icon: "shopping-cart", color: "primary", title: "Venta #2345 - $850", time: "Hace 5 min", badge: { text: "Completado", class: "success" } },
            { icon: "box", color: "success", title: "Stock actualizado: Laptop HP", time: "Hace 1 hora", badge: { text: "+15", class: "info" } },
            { icon: "exclamation-triangle", color: "warning", title: "Alerta: Monitor 24\" bajo", time: "Hace 2 horas", badge: { text: "Stock: 3", class: "warning" } }
        ]
    };

    const users = {
        "admin@smartstock.ai": { name: "Ana García", role: "admin", avatar: "AG" },
        "empleado@smartstock.ai": { name: "Carlos López", role: "empleado", avatar: "CL" }
    };

    // ==================== UTILIDADES ====================
    const $ = s => document.querySelector(s);
    const $$ = s => document.querySelectorAll(s);
    
    function showToast(message, type = 'success') {
        const toast = $('#toast');
        const header = $('#toastHeader');
        const title = $('#toastTitle');
        const msg = $('#toastMessage');
        
        header.className = 'toast-header';
        const icon = header.querySelector('i');
        if (type === 'success') {
            header.classList.add('bg-success', 'text-white');
            icon.className = 'fas fa-check-circle me-2';
            title.textContent = 'Éxito';
        } else if (type === 'error') {
            header.classList.add('bg-danger', 'text-white');
            icon.className = 'fas fa-exclamation-circle me-2';
            title.textContent = 'Error';
        } else {
            header.classList.add('bg-warning');
            icon.className = 'fas fa-exclamation-triangle me-2';
            title.textContent = 'Aviso';
        }
        msg.textContent = message;
        toast.style.display = 'block';
        setTimeout(() => toast.style.display = 'none', 3000);
    }

    function closeAllModals() {
        $$('.modal-overlay').forEach(m => m.classList.remove('show'));
    }

    function updateStats() {
        const lowStock = state.products.filter(p => p.stock <= p.minStock).length;
        const critical = state.products.filter(p => p.stock <= p.minStock/2).length;
        $('#lowStock').textContent = lowStock;
        $('#systemAlerts').textContent = critical;
        $('#notificationBadge').textContent = state.notifications.filter(n => !n.read).length;
        $('#notifCount').textContent = state.notifications.filter(n => !n.read).length;
    }

    function renderNotifications() {
        const container = $('#notificationsList');
        const unread = state.notifications.filter(n => !n.read);
        container.innerHTML = unread.map(n => `
            <div class="notification-item unread" data-id="${n.id}">
                <div class="notification-title"><i class="fas fa-${n.type === 'warning' ? 'exclamation-triangle' : n.type === 'success' ? 'shopping-cart' : 'database'} text-${n.type}"></i>${n.title}</div>
                <div class="notification-message">${n.message}</div>
                <div class="notification-time"><i class="far fa-clock"></i>${n.time}</div>
            </div>
        `).join('') || '<div class="p-3 text-center text-muted">No hay notificaciones</div>';
    }

    function renderActivities() {
        const container = $('#activityList');
        container.innerHTML = state.activities.map(a => `
            <li class="activity-item">
                <div class="activity-icon bg-${a.color}-light"><i class="fas fa-${a.icon}"></i></div>
                <div class="activity-content">
                    <div class="activity-title">${a.title}</div>
                    <div class="activity-time"><i class="far fa-clock"></i>${a.time}<span class="badge bg-${a.badge.class}">${a.badge.text}</span></div>
                </div>
            </li>
        `).join('');
    }

    function loadUser() {
        const email = new URLSearchParams(window.location.search).get('email') || "admin@smartstock.ai";
        state.currentUser = users[email] || users["admin@smartstock.ai"];
        
        $('#userName').textContent = state.currentUser.name;
        $('#userEmail').textContent = email;
        $('#userAvatar').textContent = state.currentUser.avatar;
        
        const roleEl = $('#userRole');
        const isAdmin = state.currentUser.role === 'admin';
        roleEl.textContent = isAdmin ? 'Administrador' : 'Empleado';
        roleEl.className = `user-role ${isAdmin ? 'role-admin' : 'role-employee'}`;
        
        $('#adminSection').style.display = isAdmin ? 'block' : 'none';
        $('#adminMenuLabel').style.display = isAdmin ? 'block' : 'none';
        $('#restrictedSection').style.display = isAdmin ? 'none' : 'block';
        
        if (!isAdmin) {
            $('#requestNameInput').value = state.currentUser.name;
            $('#requestRoleInput').value = 'Empleado';
        }
    }

    // ==================== CHART ====================
    function initChart() {
        const ctx = $('#salesChart').getContext('2d');
        state.salesChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
                datasets: [{
                    label: 'Ventas',
                    data: [12500, 14800, 13200, 15800, 17200, 19800, 14500],
                    borderColor: '#4361ee',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
        });
    }

    // ==================== VENTA RÁPIDA ====================
    function renderProductGrid(filter = '') {
        const grid = $('#productGrid');
        const filtered = state.products.filter(p => 
            p.name.toLowerCase().includes(filter.toLowerCase()) || 
            p.code.toLowerCase().includes(filter.toLowerCase())
        );
        grid.innerHTML = filtered.map(p => `
            <div class="col-md-6">
                <div class="product-item">
                    <div class="product-info">
                        <h6>${p.name}</h6>
                        <p>Código: ${p.code} | Stock: ${p.stock}</p>
                    </div>
                    <div class="text-end">
                        <div class="product-price">$${p.price}</div>
                        <button class="btn btn-primary btn-sm add-to-cart-btn w-100" data-code="${p.code}"><i class="fas fa-plus"></i>Agregar</button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    function updateCartDisplay() {
        const cartItems = $('#cartItems');
        const cartCount = $('#cartCount');
        const subtotalEl = $('#cartSubtotal');
        const discountEl = $('#discountAmount');
        const totalEl = $('#cartTotal');
        const processBtn = $('#processSaleBtn');
        
        if (state.cart.length === 0) {
            cartItems.innerHTML = '<p class="text-center text-muted my-3">Carrito vacío</p>';
            cartCount.textContent = '0';
            subtotalEl.textContent = '0.00';
            discountEl.textContent = '0.00';
            totalEl.textContent = '0.00';
            processBtn.disabled = true;
            return;
        }
        
        let subtotal = 0;
        let html = '';
        state.cart.forEach((item, idx) => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;
            html += `<div class="cart-item"><div><strong>${item.name}</strong><br><small>$${item.price} x ${item.quantity}</small></div><div><strong>$${itemTotal.toFixed(2)}</strong><button class="btn btn-danger btn-sm ms-2 remove-cart-item" data-index="${idx}"><i class="fas fa-times"></i></button></div></div>`;
        });
        
        cartItems.innerHTML = html;
        cartCount.textContent = state.cart.reduce((s, i) => s + i.quantity, 0);
        
        const discount = parseFloat($('#discountInput').value) || 0;
        const discountVal = subtotal * (discount / 100);
        const total = subtotal - discountVal;
        
        subtotalEl.textContent = subtotal.toFixed(2);
        discountEl.textContent = discountVal.toFixed(2);
        totalEl.textContent = total.toFixed(2);
        processBtn.disabled = false;
        
        $$('.remove-cart-item').forEach(btn => {
            btn.addEventListener('click', () => {
                state.cart.splice(parseInt(btn.dataset.index), 1);
                updateCartDisplay();
            });
        });
    }

    // ==================== INVENTARIO ====================
    function renderInventoryTable(filter = '') {
        const tbody = $('#inventoryTableBody');
        const filtered = state.products.filter(p => 
            p.name.toLowerCase().includes(filter.toLowerCase()) || 
            p.code.toLowerCase().includes(filter.toLowerCase())
        );
        
        tbody.innerHTML = filtered.map(p => {
            const status = p.stock === 0 ? 'Agotado' : p.stock <= p.minStock/2 ? 'Crítico' : p.stock <= p.minStock ? 'Bajo' : 'Bueno';
            const badgeClass = status === 'Agotado' || status === 'Crítico' ? 'danger' : status === 'Bajo' ? 'warning' : 'success';
            const rowClass = status === 'Agotado' ? 'out-stock' : status === 'Crítico' ? 'critical-stock' : status === 'Bajo' ? 'low-stock' : '';
            return `<tr class="inventory-item ${rowClass}"><td>${p.code}</td><td>${p.name}</td><td>${p.category}</td><td>${p.stock}</td><td>${p.minStock}</td><td><span class="badge bg-${badgeClass}">${status}</span></td><td><button class="btn btn-sm btn-primary adjust-stock-btn" data-code="${p.code}"><i class="fas fa-edit"></i></button></td></tr>`;
        }).join('');
    }

    // ==================== ANÁLISIS IA ====================
    function renderAIAnalysis() {
        const predictions = $('#aiPredictions');
        const recommendations = $('#aiRecommendations');
        const lowStock = state.products.filter(p => p.stock <= p.minStock);
        
        predictions.innerHTML = state.products.slice(0, 5).map(p => {
            const predicted = Math.floor(p.stock * 1.5) + Math.floor(Math.random() * 10);
            return `<div class="prediction-item"><span>${p.name}</span><span>Próx. mes: <strong>${predicted}</strong> <span class="text-success">(+${predicted - p.stock})</span></span></div>`;
        }).join('');
        
        recommendations.innerHTML = lowStock.length ? lowStock.map(p => 
            `<li class="mb-3"><i class="fas fa-circle text-danger me-2" style="font-size:8px"></i>Comprar ${p.minStock * 3 - p.stock} unidades de ${p.name}</li>`
        ).join('') : '<li class="mb-3 text-success">Stock suficiente en todos los productos</li>';
    }

    // ==================== QR ====================
    function renderQRProductSelect() {
        const select = $('#qrProductSelect');
        select.innerHTML = state.products.map(p => `<option value="${p.code}">${p.name}</option>`).join('');
    }

    // ==================== INICIALIZACIÓN ====================
    function init() {
        loadUser();
        initChart();
        renderActivities();
        renderNotifications();
        renderProductGrid();
        renderInventoryTable();
        renderQRProductSelect();
        updateStats();

        // Event Listeners generales
        $('#themeToggle').addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            $('#themeToggle i').className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
        });

        $('#fullscreenToggle').addEventListener('click', () => {
            document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
        });

        $('#menuToggleBtn').addEventListener('click', () => $('#sidebar').classList.toggle('open'));

        $('#logoutBtn').addEventListener('click', () => {
            if (confirm('¿Cerrar sesión?')) window.location.href = 'login.php';
        });

        $('#notificationsBtn').addEventListener('click', () => $('#notificationsPanel').classList.toggle('show'));

        $('#markAllReadBtn').addEventListener('click', () => {
            state.notifications.forEach(n => n.read = true);
            renderNotifications();
            updateStats();
        });

        $('#refreshActivityBtn').addEventListener('click', () => {
            showToast('Actividad actualizada', 'success');
            renderActivities();
        });

        $('#searchInput').addEventListener('keypress', e => {
            if (e.key === 'Enter') showToast(`Buscando: ${e.target.value}`, 'info');
        });

        // Chart buttons
        $$('.chart-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                $$('.chart-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                const period = this.dataset.period;
                let labels, data;
                if (period === 'week') { labels = ['Lun','Mar','Mié','Jue','Vie','Sáb','Dom']; data = [12500,14800,13200,15800,17200,19800,14500]; }
                else if (period === 'month') { labels = ['Sem 1','Sem 2','Sem 3','Sem 4']; data = [45800,51200,56800,62400]; }
                else if (period === 'quarter') { labels = ['Q1','Q2','Q3','Q4']; data = [79500,112200,148600,72400]; }
                else { labels = ['2021','2022','2023','2024']; data = [245000,312000,458000,678000]; }
                state.salesChart.data.labels = labels;
                state.salesChart.data.datasets[0].data = data;
                state.salesChart.update();
            });
        });

        // Sidebar navigation
        $$('.sidebar-menu a').forEach(link => {
            link.addEventListener('click', e => {
                e.preventDefault();
                $$('.sidebar-menu a').forEach(l => l.classList.remove('active'));
                link.classList.add('active');
                    const routes = {
                        dashboard: 'principal.php',
                        inventario: 'inventario1.php',
                        reportes: 'Reportes.php',
                        clientes: 'clientes.php',
                        proveedores: 'proveedores.php',
                        transacciones: 'Trassanciones.php',
                        ventas: 'Trassanciones.php',
                        usuarios: 'usuarios.php',
                        perfil: 'perfil.php',
                        seguridad: 'seguridad.php',
                        configuracion: 'configuracion.php'
                    };
                    if (routes[link.dataset.page]) window.location.href = routes[link.dataset.page];
                    else if (link.dataset.page === 'ayuda') showToast('La ayuda estará disponible próximamente', 'info');
            });
        });

        // Close modals
        $$('.close-modal').forEach(btn => btn.addEventListener('click', closeAllModals));
        $$('.modal-overlay').forEach(modal => modal.addEventListener('click', e => { if (e.target === modal) closeAllModals(); }));

        // ==================== QUICK SALE ====================
        $('#quickSaleBtn').addEventListener('click', () => {
            state.cart = [];
            renderProductGrid();
            updateCartDisplay();
            $('#quickSaleModal').classList.add('show');
        });

        $('#productGrid').addEventListener('click', e => {
            const btn = e.target.closest('.add-to-cart-btn');
            if (!btn) return;
            const code = btn.dataset.code;
            const product = state.products.find(p => p.code === code);
            if (!product) return;
            
            const existing = state.cart.find(i => i.code === code);
            if (existing) {
                if (existing.quantity < product.stock) existing.quantity++;
                else { showToast('Stock insuficiente', 'error'); return; }
            } else {
                state.cart.push({ ...product, quantity: 1 });
            }
            updateCartDisplay();
            showToast(`${product.name} agregado`, 'success');
        });

        $('#productSearchInput').addEventListener('keyup', e => renderProductGrid(e.target.value));
        $('#discountInput').addEventListener('input', updateCartDisplay);

        $('#processSaleBtn').addEventListener('click', () => {
            const total = parseFloat($('#cartTotal').textContent);
            state.cart.forEach(item => {
                const product = state.products.find(p => p.code === item.code);
                if (product) product.stock -= item.quantity;
            });
                persistAdminProducts(state.products);
            
            // Actualizar estadísticas
            const daily = $('#dailySales');
            daily.textContent = '$' + (parseFloat(daily.textContent.replace(/[$,]/g, '')) + total).toFixed(2);
            
            state.activities.unshift({
                icon: "shopping-cart", color: "primary", 
                title: `Venta #${Math.floor(Math.random()*10000)} - $${total.toFixed(2)}`, 
                time: "Ahora mismo", badge: { text: "Completado", class: "success" }
            });
            if (state.activities.length > 5) state.activities.pop();
            
            renderActivities();
            updateStats();
            showToast(`Venta procesada: $${total.toFixed(2)}`, 'success');
            closeAllModals();
        });

        // ==================== ADD PRODUCT ====================
        $('#addProductBtn').addEventListener('click', () => {
            $('#addProductForm').reset();
            $('#addProductModal').classList.add('show');
        });

        const purchaseInput = $('#purchasePriceInput');
        const priceInput = $('#priceInput');
        const marginInput = $('#marginInput');
        
        [purchaseInput, priceInput].forEach(i => i.addEventListener('input', () => {
            const p = parseFloat(purchaseInput.value) || 0;
            const s = parseFloat(priceInput.value) || 0;
            marginInput.value = p > 0 && s > 0 ? ((s - p) / p * 100).toFixed(2) + '%' : '';
        }));

        $('#saveProductBtn').addEventListener('click', () => {
            const name = $('#productNameInput').value;
            const code = $('#productCodeInput').value;
            const category = $('#productCategorySelect').value;
            const price = parseFloat($('#priceInput').value);
            const stock = parseInt($('#stockInput').value);
            const minStock = parseInt($('#minStockInput').value);
            const purchasePrice = parseFloat($('#purchasePriceInput').value) || price * 0.7;
            
            if (!name || !code || !category || !price || isNaN(stock) || isNaN(minStock)) {
                showToast('Complete todos los campos obligatorios', 'error');
                return;
            }
            
            state.products.push({ code, name, category, price, stock, minStock, purchasePrice });
            persistAdminProducts(state.products);
            state.activities.unshift({
                icon: "plus-circle", color: "success", title: `Nuevo producto: ${name}`, 
                time: "Ahora mismo", badge: { text: `Stock: ${stock}`, class: "info" }
            });
            if (state.activities.length > 5) state.activities.pop();
            
            renderActivities();
            renderProductGrid();
            updateStats();
            showToast(`Producto ${name} agregado`, 'success');
            closeAllModals();
        });

        // ==================== GENERATE REPORT ====================
        $('#generateReportBtn').addEventListener('click', () => $('#generateReportModal').classList.add('show'));
        $('#generateReportActionBtn').addEventListener('click', () => {
            const type = $('#reportTypeSelect').value;
            const format = $('#reportFormatSelect').value;
            showToast(`Reporte ${type} generado en ${format}`, 'success');
            closeAllModals();
        });

        // ==================== INVENTORY CHECK ====================
        $('#inventoryCheckBtn').addEventListener('click', () => {
            renderInventoryTable();
            $('#inventoryCheckModal').classList.add('show');
        });

        $('#filterInventoryInput').addEventListener('keyup', e => renderInventoryTable(e.target.value));

        $('#inventoryTableBody').addEventListener('click', e => {
            const btn = e.target.closest('.adjust-stock-btn');
            if (!btn) return;
            const code = btn.dataset.code;
            const product = state.products.find(p => p.code === code);
            if (!product) return;
            
            const newStock = prompt(`Nuevo stock para ${product.name}:`, product.stock);
            if (newStock && !isNaN(newStock) && newStock >= 0) {
                product.stock = parseInt(newStock);
                persistAdminProducts(state.products);
                renderInventoryTable($('#filterInventoryInput').value);
                renderProductGrid();
                updateStats();
                showToast(`Stock actualizado a ${newStock}`, 'success');
            }
        });

        $('#exportInventoryBtn').addEventListener('click', () => {
            const blob = new Blob([JSON.stringify(state.products, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `inventario_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(url);
            showToast('Inventario exportado correctamente', 'success');
        });
        $('#reorderStockBtn').addEventListener('click', () => showToast('Órdenes de reabastecimiento generadas', 'success'));

        // ==================== AI ANALYSIS ====================
        $('#aiAnalysisBtn').addEventListener('click', () => {
            renderAIAnalysis();
            $('#aiAnalysisModal').classList.add('show');
        });
        $('#refreshAIAnalysisBtn').addEventListener('click', () => {
            renderAIAnalysis();
            showToast('Análisis actualizado', 'success');
        });
        $('#exportAIAnalysisBtn').addEventListener('click', () => showToast('Reporte IA exportado', 'success'));

        // ==================== QR GENERATOR ====================
        $('#qrGeneratorBtn').addEventListener('click', () => {
            renderQRProductSelect();
            $('#qrContainer').style.display = 'none';
            $('#qrModal').classList.add('show');
        });

        $('#qrTypeSelect').addEventListener('change', e => {
            const isCustom = e.target.value === 'custom';
            $('#qrProductGroup').style.display = isCustom ? 'none' : 'block';
            $('#qrCustomGroup').style.display = isCustom ? 'block' : 'none';
        });

        $('#generateQRActionBtn').addEventListener('click', () => {
            const qrDiv = $('#qrcode');
            qrDiv.innerHTML = '';
            let data = '';
            const type = $('#qrTypeSelect').value;
            
            if (type === 'product') {
                data = `PRODUCTO:${$('#qrProductSelect').value}`;
            } else if (type === 'custom') {
                data = $('#qrCustomText').value || 'SmartStock';
            } else {
                data = `${type.toUpperCase()}:${Date.now()}`;
            }
            
            const qr = qrcode(0, 'M');
            qr.addData(data);
            qr.make();
            qrDiv.innerHTML = qr.createImgTag(5);
            $('#qrText').textContent = data;
            $('#qrContainer').style.display = 'block';
            showToast('QR generado', 'success');
        });

        $('#downloadQRBtn').addEventListener('click', () => {
            const img = $('#qrcode img');
            if (img) {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                canvas.getContext('2d').drawImage(img, 0, 0);
                const link = document.createElement('a');
                link.download = `qr_${Date.now()}.png`;
                link.href = canvas.toDataURL();
                link.click();
            }
        });

        $('#printQRBtn').addEventListener('click', () => {
            const win = window.open('', '_blank');
            win.document.write(`<html><body>${$('#qrcode').innerHTML}<p>${$('#qrText').textContent}</p></body></html>`);
            win.print();
        });

        // ==================== IMPORT/EXPORT ====================
        $('#importDataBtn').addEventListener('click', () => $('#importModal').classList.add('show'));
        $('#exportDataBtn').addEventListener('click', () => $('#exportModal').classList.add('show'));
        
        $('#importFileInput').addEventListener('change', () => $('#processImportBtn').disabled = false);
        $('#processImportBtn').addEventListener('click', () => {
            showToast('Datos importados', 'success');
            closeAllModals();
        });
        $('#processExportBtn').addEventListener('click', () => {
            showToast('Datos exportados', 'success');
            closeAllModals();
        });
        $('#downloadTemplateLink').addEventListener('click', e => {
            e.preventDefault();
            showToast('Plantilla descargada', 'success');
        });

        // ==================== REQUEST ACCESS ====================
        $('#requestAccessBtn').addEventListener('click', () => $('#requestAccessModal').classList.add('show'));
        $('#submitRequestBtn').addEventListener('click', () => {
            showToast('Solicitud enviada al administrador', 'success');
            closeAllModals();
        });

        // Admin features
        $$('.admin-feature').forEach(f => f.addEventListener('click', () => showToast('Funcionalidad en desarrollo', 'info')));
    }

    document.addEventListener('DOMContentLoaded', init);
})();
</script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>