<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="theme-color" content="#3a5ec7">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>SmartStock AI - Transacciones y Pedidos Inteligentes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-light: #5a7ed7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --secondary-light: #48c765;
            --secondary-dark: #218838;
            --danger: #dc3545;
            --danger-light: #e55a6a;
            --danger-dark: #c82333;
            --warning: #ffc107;
            --warning-light: #ffd145;
            --warning-dark: #e0a800;
            --info: #17a2b8;
            --info-light: #3ab7cc;
            --info-dark: #138496;
            --dark: #2c3e50;
            --darker: #1a252f;
            --light: #f8f9fa;
            --lighter: #ffffff;
            --gray-100: #f8f9fa;
            --gray-200: #e9ecef;
            --gray-300: #dee2e6;
            --gray-400: #ced4da;
            --gray-500: #adb5bd;
            --gray-600: #6c757d;
            --gray-700: #495057;
            --gray-800: #343a40;
            --gray-900: #212529;

            --bg-primary: #f5f7fb;
            --bg-secondary: #ffffff;
            --bg-card: #ffffff;
            --bg-sidebar: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            --text-primary: #000000;
            --text-secondary: #6c757d;
            --text-muted: #6c757d;
            --border-color: rgba(0,0,0,0.1);
            --shadow-color: rgba(0,0,0,0.05);
            --shadow-hover: rgba(0,0,0,0.1);
            --input-bg: #ffffff;
            --input-border: #ced4da;
            --input-focus: rgba(58, 94, 199, 0.25);

            --success-bg: rgba(40, 167, 69, 0.1);
            --success-text: #28a745;
            --warning-bg: rgba(255, 193, 7, 0.1);
            --warning-text: #856404;
            --danger-bg: rgba(220, 53, 69, 0.1);
            --danger-text: #dc3545;
            --info-bg: rgba(23, 162, 184, 0.1);
            --info-text: #17a2b8;

            --border-radius: 12px;
            --border-radius-sm: 8px;
            --border-radius-lg: 16px;
            --transition: all 0.3s ease;
            --sidebar-width: 270px;
            --sidebar-collapsed: 80px;
            --font-main: 'Plus Jakarta Sans', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            --sidebar-opacity: 1;
            --primary-rgb: 58, 94, 199;

            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
            --safe-left: env(safe-area-inset-left, 0px);
            --safe-right: env(safe-area-inset-right, 0px);
        }

        body.dark-mode {
            --bg-primary: #1a1f2e;
            --bg-secondary: #242a3a;
            --bg-card: #2c3345;
            --text-primary: #ffffff;
            --text-secondary: #a0a8b8;
            --text-muted: #7a8395;
            --border-color: rgba(255,255,255,0.1);
            --shadow-color: rgba(0,0,0,0.3);
            --shadow-hover: rgba(0,0,0,0.4);
            --input-bg: #2c3345;
            --input-border: #40485a;
            --input-focus: rgba(58, 94, 199, 0.5);

            --success-bg: rgba(40, 167, 69, 0.2);
            --success-text: #6fcf97;
            --warning-bg: rgba(255, 193, 7, 0.2);
            --warning-text: #f9ca7f;
            --danger-bg: rgba(220, 53, 69, 0.2);
            --danger-text: #f28b82;
            --info-bg: rgba(23, 162, 184, 0.2);
            --info-text: #7fd1e0;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: var(--font-main); }

        html { -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }

        body {
            background: var(--bg-primary);
            color: var(--text-primary);
            transition: var(--transition);
            min-height: 100vh;
            min-height: 100dvh;
            overflow-x: hidden;
            -webkit-tap-highlight-color: transparent;
            -webkit-font-smoothing: antialiased;
        }

        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: var(--bg-secondary); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--primary-dark); }

        .app-container { display: flex; min-height: 100vh; min-height: 100dvh; }

        /* ============================================
           OVERLAY MÓVIL
           ============================================ */
        .sidebar-overlay {
            display: none; position: fixed; inset: 0;
            background: rgba(15, 23, 42, 0.55);
            backdrop-filter: blur(3px); -webkit-backdrop-filter: blur(3px);
            z-index: 1040; opacity: 0; transition: opacity 0.3s ease;
        }
        .sidebar-overlay.active { display: block; opacity: 1; }

        /* ============================================
           SIDEBAR
           ============================================ */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--bg-sidebar);
            color: #ffffff;
            height: 100vh;
            height: 100dvh;
            position: fixed;
            left: 0; top: 0;
            padding: 24px 16px;
            padding-top: calc(24px + var(--safe-top));
            padding-bottom: calc(24px + var(--safe-bottom));
            transition: var(--transition);
            z-index: 1050;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 25px rgba(0,0,0,0.15);
            overflow-y: auto;
            opacity: var(--sidebar-opacity);
            will-change: transform;
        }

        .sidebar-header {
            padding: 0 12px 24px 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .sidebar .logo {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: -0.5px;
            background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }
        .sidebar .logo span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .sidebar .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            -webkit-text-fill-color: white;
            flex-shrink: 0;
        }

        .sidebar .sidebar-toggle {
            background: rgba(255,255,255,0.15);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            font-size: 12px;
            flex-shrink: 0;
        }

        .sidebar .sidebar-toggle:hover {
            background: rgba(255,255,255,0.25);
            transform: scale(1.1);
        }

        .sidebar-close-btn {
            display: none;
            background: rgba(255,255,255,0.08);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            transition: var(--transition);
            flex-shrink: 0;
        }
        .sidebar-close-btn:hover { background: var(--danger); }

        .sidebar-nav-container {
            flex: 1;
            overflow-y: auto;
            padding-right: 4px;
            -webkit-overflow-scrolling: touch;
        }

        .menu-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #64748b;
            font-weight: 700;
            margin: 16px 12px 8px 12px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li { margin-bottom: 4px; }

        .sidebar-menu a {
            color: #94a3b8;
            text-decoration: none;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border-radius: 8px;
            transition: var(--transition);
            font-weight: 500;
            font-size: 14px;
            cursor: pointer;
            gap: 12px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .sidebar-menu a:hover {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.06);
            transform: translateX(3px);
        }

        .sidebar-menu a.active {
            color: #ffffff;
            background: var(--primary);
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .sidebar-menu i {
            font-size: 18px;
            width: 22px;
            text-align: center;
            flex-shrink: 0;
        }

        .sidebar-footer {
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            margin-top: auto;
        }

        .logout-btn {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.2);
            width: 100%;
            padding: 12px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: var(--transition);
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .logout-btn:hover {
            background: var(--danger);
            color: white;
            border-color: var(--danger);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .sidebar.collapsed { width: var(--sidebar-collapsed); }
        .sidebar.collapsed .menu-label,
        .sidebar.collapsed .logo span,
        .sidebar.collapsed .sidebar-menu a span,
        .sidebar.collapsed .logout-btn span { display: none; }
        .sidebar.collapsed .sidebar-menu a { justify-content: center; padding: 12px; }
        .sidebar.collapsed .sidebar-menu i { margin: 0; }
        .sidebar.collapsed .sidebar-header { justify-content: center; }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 20px;
            padding-top: calc(20px + var(--safe-top));
            padding-bottom: calc(20px + var(--safe-bottom));
            transition: var(--transition);
            min-width: 0;
            overflow-x: hidden;
        }

        .main-content.expanded { margin-left: var(--sidebar-collapsed); }

        .header {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px 30px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 5px 20px var(--shadow-color);
            border: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .page-title i { color: var(--primary); }

        .controls { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }

        .theme-switcher, .notifications, .icon-btn {
            background: var(--bg-secondary);
            width: 44px; height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            color: var(--text-primary);
            position: relative;
            border: 1px solid var(--border-color);
            font-size: 16px;
            flex-shrink: 0;
            touch-action: manipulation;
        }

        .theme-switcher:hover, .notifications:hover, .icon-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px var(--shadow-hover);
        }

        .notification-badge {
            position: absolute;
            top: -5px; right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            min-width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            padding: 0 4px;
        }

        .notification-badge.hidden { display: none; }
        .notification-container { position: relative; }

        .notification-dropdown {
            position: absolute;
            top: 55px; right: 0;
            width: 350px;
            background: var(--bg-card);
            border-radius: var(--border-radius);
            box-shadow: 0 10px 30px var(--shadow-hover);
            z-index: 1050;
            display: none;
            border: 1px solid var(--border-color);
            max-height: 450px;
            overflow: hidden;
        }

        .notification-dropdown.show { display: block; animation: slideDown 0.3s ease; }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        .notification-header {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            font-weight: 600;
            background: var(--primary);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 14px;
        }

        .notification-header button {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            cursor: pointer;
            transition: var(--transition);
        }

        .notification-header button:hover { background: rgba(255,255,255,0.3); }

        .notification-list { max-height: 350px; overflow-y: auto; }

        .notification-item {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            transition: var(--transition);
            cursor: pointer;
        }

        .notification-item:hover { background: var(--bg-secondary); }
        .notification-item.unread { background: var(--info-bg); border-left: 3px solid var(--primary); }
        .notification-item strong { display: block; margin-bottom: 3px; color: var(--text-primary); font-size: 13px; }
        .notification-item p { margin-bottom: 3px; font-size: 12px; color: var(--text-secondary); }
        .notification-item small { color: var(--text-muted); font-size: 10px; }

        .notification-footer {
            padding: 8px;
            text-align: center;
            border-top: 1px solid var(--border-color);
        }

        .notification-footer a { color: var(--primary); text-decoration: none; font-size: 12px; }

        /* ============================================
           FILTROS, STATS Y CHARTS
           ============================================ */
        .filters-section {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px var(--shadow-color);
            border: 1px solid var(--border-color);
        }

        .filters-section h5 { margin-bottom: 15px; color: var(--primary); }

        .search-box { position: relative; }

        .search-box input {
            padding-left: 40px;
            padding-right: 45px;
            color: var(--text-primary);
            border-radius: var(--border-radius);
            border: 1px solid var(--border-color);
            background: var(--input-bg);
            font-size: 16px;
            min-height: 44px;
        }

        .search-box input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem var(--input-focus);
            background: var(--input-bg);
            color: var(--text-primary);
        }

        .search-box > i {
            position: absolute;
            left: 15px; top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
        }

        .voice-search-btn {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: var(--primary);
            cursor: pointer;
            font-size: 16px;
            padding: 6px 10px;
            border-radius: 4px;
            transition: var(--transition);
            min-height: 32px;
        }

        .voice-search-btn:hover { background: var(--info-bg); }
        .voice-search-btn.listening { color: var(--danger); animation: pulse 1s infinite; }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .filter-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 15px; flex-wrap: wrap; }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px var(--shadow-color);
            display: flex;
            align-items: center;
            transition: var(--transition);
            border-left: 4px solid transparent;
        }

        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px var(--shadow-hover); }

        .stat-sales { border-left-color: var(--primary); }
        .stat-orders { border-left-color: var(--secondary); }
        .stat-pending { border-left-color: var(--warning); }
        .stat-completed { border-left-color: var(--info); }

        .stat-icon {
            width: 60px; height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
            flex-shrink: 0;
        }

        .stat-sales .stat-icon { background: var(--info-bg); color: var(--primary); }
        .stat-orders .stat-icon { background: var(--success-bg); color: var(--secondary); }
        .stat-pending .stat-icon { background: var(--warning-bg); color: var(--warning); }
        .stat-completed .stat-icon { background: var(--info-bg); color: var(--info); }

        .stat-content { flex: 1; min-width: 0; }
        .stat-value { font-size: 28px; font-weight: 700; color: var(--text-primary); line-height: 1.2; }
        .stat-label { color: var(--text-muted); font-size: 14px; margin-bottom: 5px; }
        .stat-trend { font-size: 12px; display: flex; align-items: center; gap: 5px; flex-wrap: wrap; }
        .trend-up { color: var(--secondary); }
        .trend-down { color: var(--danger); }

        .charts-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .chart-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px;
            box-shadow: 0 5px 15px var(--shadow-color);
            border: 1px solid var(--border-color);
        }

        .chart-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .chart-title i { margin-right: 8px; }
        .chart-container { height: 250px; position: relative; }

        /* ============================================
           NOTIFICATION SETTINGS
           ============================================ */
        .notification-settings {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px var(--shadow-color);
            border: 1px solid var(--border-color);
        }

        .notification-settings h5 { margin-bottom: 15px; color: var(--primary); }

        .setting-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 10px;
        }

        .setting-item:last-child { border-bottom: none; }
        .setting-info { flex: 1; min-width: 200px; }
        .setting-title { font-weight: 600; margin-bottom: 3px; color: var(--text-primary); }
        .setting-desc { font-size: 13px; color: var(--text-muted); }

        .switch {
            position: relative;
            display: inline-block;
            width: 52px; height: 26px;
            flex-shrink: 0;
        }

        .switch input { opacity: 0; width: 0; height: 0; }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 26px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 20px; width: 20px;
            left: 3px; bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider { background-color: var(--primary); }
        input:checked + .slider:before { transform: translateX(26px); }

        /* ============================================
           TABS
           ============================================ */
        .nav-tabs {
            border-bottom: 2px solid var(--border-color);
            margin-bottom: 20px;
            flex-wrap: nowrap;
            overflow-x: auto;
            overflow-y: hidden;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
            scroll-snap-type: x proximity;
        }

        .nav-tabs::-webkit-scrollbar { display: none; }

        .nav-tabs .nav-link {
            color: var(--text-primary);
            border: none;
            padding: 12px 25px;
            font-weight: 500;
            transition: var(--transition);
            white-space: nowrap;
            flex-shrink: 0;
            scroll-snap-align: start;
            background: transparent;
            min-height: 44px;
            touch-action: manipulation;
        }

        .nav-tabs .nav-link i { margin-right: 8px; }

        .nav-tabs .nav-link:hover {
            border-color: transparent;
            background: var(--info-bg);
        }

        .nav-tabs .nav-link.active {
            color: var(--primary);
            border-bottom: 3px solid var(--primary);
            background: transparent;
            font-weight: 600;
        }

        /* ============================================
           TABLES
           ============================================ */
        .transactions-table {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 5px 15px var(--shadow-color);
            margin-bottom: 20px;
            border: 1px solid var(--border-color);
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
            background: var(--bg-secondary);
            flex-wrap: wrap;
            gap: 10px;
        }

        .table-title { font-size: 18px; font-weight: 600; color: var(--text-primary); display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .table-title i { color: var(--primary); }
        .table-actions { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; }

        table { width: 100%; border-collapse: collapse; }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
        }

        th {
            font-weight: 600;
            background: var(--bg-secondary);
            color: var(--primary);
            font-size: 14px;
            cursor: pointer;
            user-select: none;
            position: relative;
            white-space: nowrap;
        }

        th:hover { background: var(--info-bg); }
        th .sort-icon { margin-left: 5px; opacity: 0.3; font-size: 11px; }
        th.sorted-asc .sort-icon, th.sorted-desc .sort-icon { opacity: 1; color: var(--primary); }
        tr:hover { background: var(--bg-secondary); }

        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
            display: inline-block;
            white-space: nowrap;
        }

        .badge.bg-success { background-color: var(--secondary); }
        .badge.bg-warning { background-color: var(--warning); color: #000; }
        .badge.bg-danger { background-color: var(--danger); }
        .badge.bg-info { background-color: var(--info); }
        .badge.bg-primary { background-color: var(--primary); }
        .badge.bg-secondary { background-color: var(--gray-600); }

        .action-btn {
            padding: 6px 10px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            margin-right: 3px;
            margin-bottom: 3px;
            transition: var(--transition);
            color: white;
            font-size: 12px;
            min-height: 32px;
            min-width: 32px;
            touch-action: manipulation;
        }

        .btn-view { background: var(--info); }
        .btn-edit { background: var(--primary); }
        .btn-delete { background: var(--danger); }
        .btn-process { background: var(--warning); color: #000; }
        .btn-notify { background: #25D366; }
        .btn-track { background: var(--secondary); }
        .btn-duplicate { background: #6f42c1; }

        .action-btn:hover { opacity: 0.8; transform: translateY(-2px); }

        /* ============================================
           MODALES
           ============================================ */
        .modal-content {
            border-radius: var(--border-radius);
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            color: var(--text-primary) !important;
            background-color: var(--bg-card) !important;
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border-top-left-radius: var(--border-radius);
            border-top-right-radius: var(--border-radius);
            padding: 20px;
        }

        .modal-header h5 { color: white; }
        .modal-header .btn-close { filter: invert(1); }
        .modal-body { padding: 25px; color: var(--text-primary) !important; }

        .modal-body p, .modal-body span, .modal-body strong,
        .modal-body div:not(.badge):not(.btn):not(.action-btn) {
            color: var(--text-primary);
        }

        .modal-footer { padding: 20px; border-top: 1px solid var(--border-color); flex-wrap: wrap; gap: 8px; }

        /* ============================================
           PRODUCT LIST
           ============================================ */
        .product-list {
            max-height: 250px;
            overflow-y: auto;
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            margin: 15px 0;
            -webkit-overflow-scrolling: touch;
        }

        .product-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            transition: var(--transition);
            gap: 10px;
        }

        .product-item:hover { background: var(--bg-secondary); }
        .product-item:last-child { border-bottom: none; }
        .product-info { flex: 1; min-width: 0; }
        .product-name { font-weight: 600; margin-bottom: 3px; color: var(--text-primary); }
        .product-meta { font-size: 12px; color: var(--text-muted); }
        .product-price { font-weight: 600; color: var(--primary); white-space: nowrap; }

        .transaction-summary {
            background: var(--info-bg);
            border-radius: var(--border-radius);
            padding: 15px;
            margin-top: 15px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding: 5px 0;
            color: var(--text-primary);
            gap: 10px;
        }

        .summary-total {
            font-weight: 700;
            font-size: 18px;
            border-top: 2px solid var(--primary);
            padding-top: 10px;
            margin-top: 10px;
            color: var(--primary);
        }

        /* ============================================
           PAGINACIÓN
           ============================================ */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-top: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 10px;
        }

        .pagination-info { color: var(--text-muted); font-size: 14px; }
        .pagination { display: flex; gap: 5px; list-style: none; padding: 0; margin: 0; flex-wrap: wrap; }
        .page-item { list-style: none; }

        .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 40px;
            height: 40px;
            padding: 0 10px;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            text-decoration: none;
            transition: var(--transition);
            font-size: 14px;
            cursor: pointer;
            background: var(--bg-card);
            touch-action: manipulation;
        }

        .page-link:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.active .page-link {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .page-item.disabled .page-link { opacity: 0.5; cursor: not-allowed; }

        /* ============================================
           TIMELINE
           ============================================ */
        .timeline { position: relative; padding: 20px 0; margin-top: 20px; }

        .timeline::before {
            content: '';
            position: absolute;
            left: 20px; top: 0; bottom: 0;
            width: 2px;
            background: var(--primary);
            opacity: 0.3;
        }

        .timeline-item { position: relative; padding-left: 50px; margin-bottom: 25px; }

        .timeline-marker {
            position: absolute;
            left: 11px;
            width: 20px; height: 20px;
            border-radius: 50%;
            background: var(--primary);
            border: 3px solid var(--bg-card);
            z-index: 1;
        }

        .timeline-content {
            background: var(--bg-secondary);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid var(--border-color);
        }

        .timeline-date { font-size: 12px; color: var(--text-muted); margin-bottom: 5px; }
        .timeline-title { font-weight: 600; margin-bottom: 5px; color: var(--text-primary); }
        .timeline-desc { font-size: 13px; color: var(--text-muted); }

        /* ============================================
           TOAST
           ============================================ */
        .toast-container {
            position: fixed;
            top: calc(20px + var(--safe-top));
            right: calc(20px + var(--safe-right));
            left: 20px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            pointer-events: none;
            align-items: flex-end;
        }

        .toast {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            padding: 15px 20px;
            display: flex;
            align-items: center;
            animation: slideInRight 0.3s forwards;
            min-width: 280px;
            max-width: 400px;
            border-left: 4px solid var(--primary);
            color: var(--text-primary);
            pointer-events: auto;
        }

        .toast.success { border-left-color: var(--secondary); }
        .toast.error { border-left-color: var(--danger); }
        .toast.warning { border-left-color: var(--warning); }
        .toast.info { border-left-color: var(--primary); }

        .toast i { margin-right: 15px; font-size: 20px; flex-shrink: 0; }
        .toast.success i { color: var(--secondary); }
        .toast.error i { color: var(--danger); }
        .toast.warning i { color: var(--warning); }
        .toast.info i { color: var(--primary); }

        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }

        /* ============================================
           TOOLTIP
           ============================================ */
        [data-tooltip] { position: relative; cursor: help; }

        [data-tooltip]:before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 5px 10px;
            background: var(--darker);
            color: white;
            border-radius: 4px;
            font-size: 12px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 1000;
            pointer-events: none;
        }

        [data-tooltip]:hover:before { opacity: 1; visibility: visible; bottom: 120%; }

        /* Ocultar tooltips en touch */
        @media (hover: none) {
            [data-tooltip]:before { display: none; }
        }

        .empty-state { text-align: center; padding: 40px; color: var(--text-muted); }
        .empty-state i { font-size: 48px; margin-bottom: 15px; color: var(--text-muted); }
        .empty-state h4 { margin-bottom: 10px; color: var(--text-primary); }

        /* ============================================
           NOTIFICATION TYPES
           ============================================ */
        .notification-type {
            display: flex;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
            cursor: pointer;
            transition: var(--transition);
        }

        .notification-type:hover { background: var(--bg-secondary); transform: translateX(5px); }
        .notification-type:last-child { border-bottom: none; }

        .notification-type i {
            width: 40px; height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 20px;
            flex-shrink: 0;
        }

        .whatsapp-notification { background: rgba(37, 211, 102, 0.1); color: #25D366; }
        .sms-notification { background: var(--info-bg); color: var(--primary); }
        .email-notification { background: var(--danger-bg); color: var(--danger); }
        .notification-type div { flex: 1; }
        .notification-type strong { display: block; margin-bottom: 3px; color: var(--text-primary); }
        .notification-type p { color: var(--text-muted); font-size: 13px; margin: 0; }

        .select-checkbox {
            width: 18px; height: 18px;
            cursor: pointer;
            accent-color: var(--primary);
        }

        .bulk-actions {
            background: var(--primary);
            color: white;
            padding: 12px 20px;
            border-radius: var(--border-radius);
            margin-bottom: 15px;
            display: none;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            animation: slideDown 0.3s ease;
        }

        .bulk-actions.show { display: flex; }
        .bulk-actions-info { font-weight: 600; }
        .bulk-actions-buttons { display: flex; gap: 8px; flex-wrap: wrap; }

        .tag {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
            background: var(--info-bg);
            color: var(--primary);
            margin-right: 3px;
            margin-bottom: 3px;
        }

        .tag.priority-high { background: var(--danger-bg); color: var(--danger); }
        .tag.priority-medium { background: var(--warning-bg); color: #e0a800; }
        .tag.priority-low { background: var(--success-bg); color: var(--secondary); }

        .activity-item {
            padding: 10px 15px;
            border-left: 3px solid var(--primary);
            background: var(--info-bg);
            margin-bottom: 8px;
            border-radius: 0 8px 8px 0;
            font-size: 13px;
            color: var(--text-primary);
        }

        .activity-item .activity-time {
            color: var(--text-muted);
            font-size: 11px;
            display: block;
            margin-top: 3px;
        }

        .compact-mode th,
        .compact-mode td {
            padding: 8px 10px;
            font-size: 13px;
        }

        .trash-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: var(--danger-bg);
            border-left: 3px solid var(--danger);
            border-radius: 0 8px 8px 0;
            margin-bottom: 8px;
            flex-wrap: wrap;
            gap: 10px;
            color: var(--text-primary);
        }

        .advanced-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }

        .advanced-stat {
            padding: 15px;
            background: var(--bg-secondary);
            border-radius: 8px;
            border-left: 3px solid var(--primary);
        }

        .advanced-stat .stat-label {
            font-size: 12px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .advanced-stat .stat-value {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            margin-top: 5px;
        }

        /* ============================================
           FORM CONTROLS
           ============================================ */
        .form-control, .form-select {
            color: var(--text-primary);
            background-color: var(--input-bg);
            border: 1px solid var(--input-border);
            border-radius: 8px;
            padding: 10px;
            font-size: 16px;
            min-height: 44px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem var(--input-focus);
            background-color: var(--input-bg);
            color: var(--text-primary);
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            min-height: 44px;
            touch-action: manipulation;
        }

        .btn-primary { background: var(--primary); color: white !important; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(58, 94, 199, 0.3); }
        .btn-success { background: var(--secondary); color: white !important; }
        .btn-success:hover { background: var(--secondary-dark); transform: translateY(-2px); }
        .btn-warning { background: var(--warning); color: #000 !important; }
        .btn-warning:hover { background: var(--warning-dark); transform: translateY(-2px); }
        .btn-info { background: var(--info); color: white !important; }
        .btn-info:hover { background: var(--info-dark); transform: translateY(-2px); }
        .btn-danger { background: var(--danger); color: white !important; }
        .btn-danger:hover { background: var(--danger-dark); transform: translateY(-2px); }
        .btn-secondary { background: var(--gray-600); color: white !important; }
        .btn-outline-secondary { border: 1px solid var(--border-color); color: var(--text-primary); background: transparent; }
        .btn-outline-secondary:hover { background: var(--bg-secondary); }
        .btn-outline-primary { border: 1px solid var(--primary); color: var(--primary); background: transparent; }
        .btn-outline-primary:hover { background: var(--primary); color: white; }
        .btn-sm { padding: 5px 12px; font-size: 13px; min-height: 36px; }

        .list-group-item {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            padding: 12px 15px;
            color: var(--text-primary);
            border-radius: 8px;
            margin-bottom: 8px;
        }

        .text-muted { color: var(--text-muted) !important; }
        .text-danger { color: var(--danger) !important; }
        .text-success { color: var(--secondary) !important; }
        .bg-light { background: var(--bg-secondary) !important; color: var(--text-primary) !important; }

        .fade-in { animation: fadeIn 0.3s ease; }
        .slide-up { animation: slideUp 0.3s ease; }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ============================================
           MENU TOGGLE
           ============================================ */
        .menu-toggle {
            display: none;
            background: var(--primary);
            color: white;
            border: none;
            width: 52px; height: 52px;
            border-radius: 50%;
            position: fixed;
            bottom: calc(20px + var(--safe-bottom));
            right: calc(20px + var(--safe-right));
            z-index: 1001;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            cursor: pointer;
            transition: var(--transition);
            align-items: center;
            justify-content: center;
            font-size: 20px;
            touch-action: manipulation;
        }

        .menu-toggle:hover { transform: scale(1.1); background: var(--primary-dark); }
        .menu-toggle:active { transform: scale(0.92); }

        /* ============================================
           RESPONSIVE - TABLET (≤1200px)
           ============================================ */
        @media (max-width: 1200px) {
            .charts-section { grid-template-columns: 1fr; }
            .stats-container { grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); }
        }

        /* ============================================
           RESPONSIVE - TABLET (≤992px)
           ============================================ */
        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); width: var(--sidebar-width); }
            .sidebar.mobile-open { transform: translateX(0); }
            .sidebar.collapsed { width: var(--sidebar-width); }
            .sidebar.collapsed .menu-label,
            .sidebar.collapsed .logo span,
            .sidebar.collapsed .sidebar-menu a span,
            .sidebar.collapsed .logout-btn span { display: inline; }
            .sidebar.collapsed .sidebar-menu a { justify-content: flex-start; padding: 12px 16px; }
            .sidebar.collapsed .sidebar-header { justify-content: space-between; }
            .sidebar-close-btn { display: flex; }
            .sidebar .sidebar-toggle { display: none; }

            .main-content {
                margin-left: 0;
                padding: 20px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }
            .main-content.expanded { margin-left: 0; }
            .menu-toggle { display: flex; }

            .header { flex-direction: column; align-items: stretch; gap: 14px; }
            .controls { justify-content: space-between; flex-wrap: wrap; width: 100%; gap: 8px; }

            .notification-dropdown {
                position: fixed;
                top: auto;
                bottom: calc(90px + var(--safe-bottom));
                left: 16px;
                right: 16px;
                width: auto;
                max-width: 440px;
                margin: 0 auto;
            }

            /* TABS - scroll horizontal */
            .nav-tabs {
                flex-wrap: nowrap;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                scrollbar-width: thin;
                scrollbar-color: var(--primary) transparent;
                padding-bottom: 4px;
            }
            .nav-tabs::-webkit-scrollbar { height: 4px; display: block; }
            .nav-tabs::-webkit-scrollbar-track { background: rgba(58,94,199,0.08); border-radius: 4px; }
            .nav-tabs::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 4px; }
            .nav-tabs .nav-link { flex-shrink: 0; }

            .filter-actions { flex-direction: column; }
            .filter-actions .btn { width: 100%; }

            .table-header { flex-direction: column; align-items: stretch; gap: 12px; }
            .table-actions { justify-content: space-between; }

            .pagination-container { flex-direction: column; gap: 10px; }
        }

        /* ============================================
           RESPONSIVE - MÓVIL (≤640px)
           ============================================ */
        @media (max-width: 640px) {
            .main-content {
                padding: 16px;
                padding-top: calc(16px + var(--safe-top));
                padding-bottom: calc(90px + var(--safe-bottom));
            }

            .sidebar {
                width: 88vw;
                max-width: 320px;
                padding: 20px 12px;
                padding-top: calc(20px + var(--safe-top));
                padding-bottom: calc(20px + var(--safe-bottom));
            }

            .header { padding: 16px 18px; margin-bottom: 18px; border-radius: var(--border-radius-sm); }
            .page-title { font-size: 17px; gap: 8px; }
            .page-title i { font-size: 16px; }

            .controls { gap: 8px; }
            .theme-switcher, .notifications, .icon-btn { width: 40px; height: 40px; font-size: 14px; }

            .controls .btn-primary {
                width: 100%;
                order: 10;
                margin-top: 4px;
            }

            /* STATS */
            .stats-container { grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 16px; }
            .stat-card { padding: 14px; border-radius: var(--border-radius-sm); flex-direction: column; align-items: flex-start; gap: 8px; }
            .stat-icon { width: 40px; height: 40px; font-size: 18px; margin-right: 0; }
            .stat-value { font-size: 18px; }
            .stat-label { font-size: 11px; }
            .stat-trend { font-size: 10px; }

            /* CHARTS */
            .charts-section { gap: 12px; margin-bottom: 16px; }
            .chart-card { padding: 14px; border-radius: var(--border-radius-sm); }
            .chart-title { font-size: 14px; margin-bottom: 12px; }
            .chart-container { height: 200px; }

            /* ADVANCED STATS */
            .advanced-stats-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
            .advanced-stat { padding: 12px; }
            .advanced-stat .stat-value { font-size: 16px; }
            .advanced-stat .stat-label { font-size: 10px; }

            /* NOTIFICATION SETTINGS */
            .notification-settings { padding: 16px; border-radius: var(--border-radius-sm); }
            .setting-item { flex-direction: column; align-items: flex-start; gap: 8px; padding: 12px 0; }
            .switch { align-self: flex-end; }

            /* FILTERS */
            .filters-section { padding: 16px; border-radius: var(--border-radius-sm); }
            .filters-section h5 { font-size: 15px; }
            .filter-actions { flex-direction: column; }
            .filter-actions .btn { width: 100%; }

            /* TABS */
            .nav-tabs { margin-bottom: 16px; }
            .nav-tabs .nav-link { padding: 10px 16px; font-size: 13px; }
            .nav-tabs .nav-link i { margin-right: 5px; }

            /* TABLES - Scroll horizontal */
            .transactions-table { border-radius: var(--border-radius-sm); margin-bottom: 16px; }
            .table-header { padding: 14px 16px; }
            .table-title { font-size: 14px; }
            .table-actions { flex-wrap: wrap; gap: 6px; }
            .table-actions .btn-sm { padding: 5px 10px; font-size: 12px; min-height: 34px; }

            table { min-width: 700px; }
            th, td { padding: 10px 12px; font-size: 12px; }
            th { font-size: 11px; }
            .badge { padding: 4px 8px; font-size: 10px; }

            .action-btn { padding: 5px 8px; font-size: 11px; min-height: 28px; min-width: 28px; margin-right: 2px; }

            /* PAGINACIÓN */
            .pagination-container { padding: 14px; }
            .pagination-info { font-size: 12px; text-align: center; width: 100%; }
            .page-link { min-width: 34px; height: 34px; font-size: 12px; padding: 0 6px; }

            /* TIMELINE */
            .timeline { padding: 14px 0; }
            .timeline::before { left: 14px; }
            .timeline-item { padding-left: 42px; margin-bottom: 18px; }
            .timeline-marker { left: 5px; width: 18px; height: 18px; }
            .timeline-content { padding: 12px; }
            .timeline-title { font-size: 13px; }
            .timeline-desc { font-size: 12px; }

            /* PAPELERA */
            .trash-item { flex-direction: column; align-items: flex-start; gap: 10px; padding: 14px; }
            .trash-item > div:last-child { width: 100%; display: flex; gap: 8px; }
            .trash-item .btn { flex: 1; }

            /* ACTIVITY */
            .activity-item { padding: 10px 12px; font-size: 12px; }

            /* MODALES - Bottom sheet en móvil */
            .modal-dialog {
                margin: 0;
                max-width: 100%;
                align-items: flex-end;
                min-height: calc(100% - 40px);
            }
            .modal-content {
                border-radius: var(--border-radius-lg) var(--border-radius-lg) 0 0;
                max-height: calc(100vh - 40px);
                max-height: calc(100dvh - 40px);
            }
            .modal-header { padding: 16px 20px; border-radius: var(--border-radius-lg) var(--border-radius-lg) 0 0; }
            .modal-header h5 { font-size: 15px; }
            .modal-body { padding: 20px; max-height: 65vh; overflow-y: auto; }
            .modal-footer { padding: 14px 20px calc(14px + var(--safe-bottom)); flex-direction: column-reverse; }
            .modal-footer .btn { width: 100%; }

            .product-list { max-height: 200px; }
            .product-item { padding: 10px 12px; }
            .product-name { font-size: 13px; }

            .summary-row { font-size: 13px; }
            .summary-total { font-size: 16px; }

            /* NOTIFICACIONES TYPES */
            .notification-type { padding: 16px; }
            .notification-type i { width: 36px; height: 36px; font-size: 18px; }
            .notification-type strong { font-size: 14px; }
            .notification-type p { font-size: 12px; }

            /* BULK ACTIONS */
            .bulk-actions { padding: 12px 16px; flex-direction: column; align-items: stretch; gap: 12px; }
            .bulk-actions-buttons { flex-wrap: wrap; }
            .bulk-actions-buttons .btn { flex: 1; min-width: 100px; }

            /* TOAST */
            .toast-container { top: calc(12px + var(--safe-top)); right: 12px; left: 12px; align-items: stretch; }
            .toast { min-width: 0; max-width: 100%; width: 100%; padding: 12px 16px; font-size: 13px; }

            /* EMPTY STATE */
            .empty-state { padding: 30px 16px; }
            .empty-state i { font-size: 40px; }
            .empty-state h4 { font-size: 15px; }
            .empty-state p { font-size: 12px; }

            /* BOTONES GLOBALES */
            .btn { padding: 10px 16px; font-size: 13px; }
            .btn-sm { padding: 6px 10px; font-size: 12px; }

            .menu-toggle { width: 48px; height: 48px; font-size: 18px; }
        }

        /* ============================================
           RESPONSIVE - MÓVIL PEQUEÑO (≤380px)
           ============================================ */
        @media (max-width: 380px) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); padding-bottom: calc(80px + var(--safe-bottom)); }
            .page-title { font-size: 15px; }
            .theme-switcher, .notifications, .icon-btn { width: 36px; height: 36px; font-size: 13px; }
            .stats-container { grid-template-columns: 1fr; }
            .advanced-stats-grid { grid-template-columns: 1fr; }
            .chart-container { height: 180px; }
            .modal-header h5 { font-size: 14px; }
            table { min-width: 650px; }
        }

        /* ============================================
           LANDSCAPE MÓVIL
           ============================================ */
        @media (max-height: 500px) and (orientation: landscape) {
            .main-content { padding: 12px; padding-top: calc(12px + var(--safe-top)); }
            .header { padding: 10px 16px; margin-bottom: 12px; }
            .chart-container { height: 180px; }
            .sidebar { padding: 16px 12px; padding-top: calc(16px + var(--safe-top)); }
            .modal-content { max-height: 95vh; }
        }

        /* ============================================
           PANTALLAS GRANDES
           ============================================ */
        @media (min-width: 1440px) {
            .main-content { padding: 30px; }
            .stats-container { grid-template-columns: repeat(4, 1fr); }
            .chart-container { height: 300px; }
        }
        @media (min-width: 1920px) {
            .main-content { padding: 40px 60px; max-width: 1800px; margin-left: auto; margin-right: auto; }
        }

        /* ============================================
           TOUCH - Deshabilitar hover en touch
           ============================================ */
        @media (hover: none) {
            .stat-card:hover { transform: none; box-shadow: 0 5px 15px var(--shadow-color); }
            .theme-switcher:hover, .notifications:hover, .icon-btn:hover { transform: none; box-shadow: none; }
            .action-btn:hover { transform: none; opacity: 1; }
            .notification-type:hover { transform: none; }
            .sidebar-menu a:hover { transform: none; background: transparent; }
            .sidebar-menu a.active:hover { background: var(--primary); }
            .page-link:hover { background: var(--bg-card); color: var(--text-primary); border-color: var(--border-color); }
            .page-item.active .page-link:hover { background: var(--primary); color: white; }
        }

        /* ============================================
           REDUCED MOTION
           ============================================ */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }

        /* ============================================
           PRINT
           ============================================ */
        @media print {
            .sidebar, .header, .menu-toggle, .filters-section,
            .notification-settings, .charts-section, .pagination-container,
            .table-actions, .action-btn, .bulk-actions, .controls { display: none !important; }
            .main-content { margin-left: 0 !important; padding: 0 !important; }
            .stat-card { box-shadow: none; border: 1px solid #ddd; }
            .transactions-table { box-shadow: none; border: 1px solid #ddd; }
            table { min-width: 0 !important; }
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- OVERLAY MÓVIL -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon"><i class="fas fa-brain"></i></div>
                    <span class="system-name-display">SmartStock AI</span>
                </div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Cerrar menú">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="sidebar-nav-container">
                <div class="menu-label">Principal</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/principal.php"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/inventario1.php"><i class="fas fa-boxes-stacked"></i> <span>Inventario</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Trassanciones.php" class="active"><i class="fas fa-right-left"></i> <span>Transacciones</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/Reportes.php"><i class="fas fa-chart-column"></i> <span>Reportes</span></a></li>
                </ul>

                <div class="menu-label">Relaciones</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/clientes.php"><i class="fas fa-address-book"></i> <span>Clientes</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/proveedores.php"><i class="fas fa-truck-field"></i> <span>Proveedores</span></a></li>
                </ul>

                <div class="menu-label">Administración</div>
                <ul class="sidebar-menu">
                    <li><a href="http://localhost/SmartStockAI/usuarios.php"><i class="fas fa-users-gear"></i> <span>Usuarios</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/seguridad.php"><i class="fas fa-shield-halved"></i> <span>Seguridad</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/perfil.php"><i class="fas fa-circle-user"></i> <span>Mi Perfil</span></a></li>
                    <li><a href="http://localhost/SmartStockAI/configuracion.php"><i class="fas fa-sliders"></i> <span>Configuración</span></a></li>
                </ul>
            </div>

            <div class="sidebar-footer">
                <button class="logout-btn" id="logoutBtn">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    <span>Cerrar Sesión</span>
                </button>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="main-content" id="mainContent">
            <div class="header">
                <h1 class="page-title">
                    <i class="fas fa-exchange-alt"></i>
                    Gestión de Transacciones y Pedidos
                </h1>

                <div class="controls">
                    <button class="icon-btn" id="compactModeBtn" data-tooltip="Modo compacto">
                        <i class="fas fa-list"></i>
                    </button>
                    <button class="icon-btn" id="printBtn" data-tooltip="Imprimir">
                        <i class="fas fa-print"></i>
                    </button>
                    <button class="icon-btn" id="shortcutsBtn" data-tooltip="Atajos de teclado">
                        <i class="fas fa-keyboard"></i>
                    </button>
                    <div class="theme-switcher" id="themeToggle" data-tooltip="Cambiar tema">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notification-container">
                        <div class="notifications" id="notificationBtn" data-tooltip="Notificaciones">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge" id="notificationBadge">0</span>
                        </div>
                        <div class="notification-dropdown" id="notificationDropdown">
                            <div class="notification-header">
                                <span><i class="fas fa-bell me-2"></i>Notificaciones</span>
                                <button id="markAllRead">Marcar todas</button>
                            </div>
                            <div class="notification-list" id="notificationList"></div>
                            <div class="notification-footer">
                                <a href="#" id="viewAllNotifications">Ver todas las notificaciones</a>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTransactionModal">
                        <i class="fas fa-plus"></i> Nueva Transacción
                    </button>
                </div>
            </div>

            <div class="stats-container">
                <div class="stat-card stat-sales">
                    <div class="stat-icon"><i class="fas fa-dollar-sign"></i></div>
                    <div class="stat-content">
                        <div class="stat-label">Ventas del Mes</div>
                        <div class="stat-value" id="monthlySales">$0.00</div>
                        <div class="stat-trend">
                            <i class="fas fa-arrow-up trend-up"></i>
                            <span class="trend-up">+12.5% vs mes anterior</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-orders">
                    <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
                    <div class="stat-content">
                        <div class="stat-label">Pedidos Activos</div>
                        <div class="stat-value" id="activeOrders">0</div>
                        <div class="stat-trend">
                            <i class="fas fa-arrow-up trend-up"></i>
                            <span class="trend-up" id="newOrdersTrend">+0 nuevos hoy</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-pending">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-content">
                        <div class="stat-label">Pendientes de Procesar</div>
                        <div class="stat-value" id="pendingOrders">0</div>
                        <div class="stat-trend">
                            <i class="fas fa-exclamation-triangle trend-down"></i>
                            <span class="trend-down" id="urgentOrdersTrend">0 urgentes</span>
                        </div>
                    </div>
                </div>
                <div class="stat-card stat-completed">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-content">
                        <div class="stat-label">Completados Hoy</div>
                        <div class="stat-value" id="completedToday">0</div>
                        <div class="stat-trend">
                            <i class="fas fa-check-circle text-success"></i>
                            <span class="text-success" id="successRate">Tasa de éxito 0%</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="charts-section">
                <div class="chart-card">
                    <div class="chart-title"><i class="fas fa-chart-bar"></i> Ventas por Día (Últimos 7 días)</div>
                    <div class="chart-container"><canvas id="salesChart"></canvas></div>
                </div>
                <div class="chart-card">
                    <div class="chart-title"><i class="fas fa-chart-pie"></i> Estado de Pedidos</div>
                    <div class="chart-container"><canvas id="ordersChart"></canvas></div>
                </div>
            </div>

            <div class="chart-card" style="margin-bottom: 20px;">
                <div class="chart-title"><i class="fas fa-chart-line"></i> Estadísticas Avanzadas</div>
                <div class="advanced-stats-grid">
                    <div class="advanced-stat">
                        <div class="stat-label">Total Transacciones</div>
                        <div class="stat-value" id="advTotalTransactions">0</div>
                    </div>
                    <div class="advanced-stat">
                        <div class="stat-label">Total Pedidos</div>
                        <div class="stat-value" id="advTotalOrders">0</div>
                    </div>
                    <div class="advanced-stat">
                        <div class="stat-label">Ingresos Totales</div>
                        <div class="stat-value" id="advTotalIncome">$0</div>
                    </div>
                    <div class="advanced-stat">
                        <div class="stat-label">Ticket Promedio</div>
                        <div class="stat-value" id="advAvgTicket">$0</div>
                    </div>
                    <div class="advanced-stat">
                        <div class="stat-label">Pedidos Cancelados</div>
                        <div class="stat-value" id="advCancelledOrders">0</div>
                    </div>
                    <div class="advanced-stat">
                        <div class="stat-label">Clientes Únicos</div>
                        <div class="stat-value" id="advUniqueClients">0</div>
                    </div>
                </div>
            </div>

            <div class="notification-settings">
                <h5><i class="fas fa-bell me-2"></i>Configuración de Notificaciones</h5>
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-title">Notificaciones por WhatsApp</div>
                        <div class="setting-desc">Recibir alertas en tiempo real por WhatsApp</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="whatsappNotifications" checked>
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-title">Notificaciones por SMS</div>
                        <div class="setting-desc">Recibir alertas por mensaje de texto</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="smsNotifications">
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-title">Notificaciones por Email</div>
                        <div class="setting-desc">Recibir alertas por correo electrónico</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="emailNotifications" checked>
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-title">Notificaciones Push del Navegador</div>
                        <div class="setting-desc">Recibir alertas push en el navegador</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="pushNotifications">
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="setting-item">
                    <div class="setting-info">
                        <div class="setting-title">Notificaciones de Stock Bajo</div>
                        <div class="setting-desc">Alertas cuando el stock esté por debajo del mínimo</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="stockNotifications" checked>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>

            <div class="filters-section">
                <h5><i class="fas fa-filter me-2"></i>Filtros Avanzados</h5>
                <div class="row g-3">
                    <div class="col-md-3 col-12">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" class="form-control" id="searchInput" placeholder="Buscar... (Ctrl+K)">
                            <button class="voice-search-btn" id="voiceSearchBtn" data-tooltip="Búsqueda por voz">
                                <i class="fas fa-microphone"></i>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-2 col-6">
                        <select class="form-select" id="typeFilter">
                            <option value="all">Todos los tipos</option>
                            <option value="Venta">Venta</option>
                            <option value="Compra">Compra</option>
                            <option value="Devolución">Devolución</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-6">
                        <select class="form-select" id="statusFilter">
                            <option value="all">Todos los estados</option>
                            <option value="Completado">Completado</option>
                            <option value="Pendiente">Pendiente</option>
                            <option value="Procesando">Procesando</option>
                            <option value="Enviado">Enviado</option>
                            <option value="Entregado">Entregado</option>
                            <option value="Nuevo">Nuevo</option>
                            <option value="Cancelado">Cancelado</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-12">
                        <input type="date" class="form-control" id="dateFilter">
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="filter-actions">
                            <button class="btn btn-outline-secondary" id="clearFilters">
                                <i class="fas fa-times me-1"></i> Limpiar
                            </button>
                            <div class="dropdown">
                                <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-download me-1"></i> Exportar
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#" id="exportPdfBtn"><i class="fas fa-file-pdf me-2"></i>PDF</a></li>
                                    <li><a class="dropdown-item" href="#" id="exportCsvBtn"><i class="fas fa-file-csv me-2"></i>CSV</a></li>
                                    <li><a class="dropdown-item" href="#" id="exportExcelBtn"><i class="fas fa-file-excel me-2"></i>Excel</a></li>
                                    <li><a class="dropdown-item" href="#" id="exportJsonBtn"><i class="fas fa-file-code me-2"></i>JSON</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <ul class="nav nav-tabs" id="transactionsTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="transactions-tab" data-bs-toggle="tab" data-bs-target="#transactions" type="button" role="tab">
                        <i class="fas fa-list"></i> Transacciones
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="orders-tab" data-bs-toggle="tab" data-bs-target="#orders" type="button" role="tab">
                        <i class="fas fa-shopping-cart"></i> Pedidos
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="timeline-tab" data-bs-toggle="tab" data-bs-target="#timeline" type="button" role="tab">
                        <i class="fas fa-clock"></i> Timeline
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="trash-tab" data-bs-toggle="tab" data-bs-target="#trash" type="button" role="tab">
                        <i class="fas fa-trash"></i> Papelera
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity" type="button" role="tab">
                        <i class="fas fa-history"></i> Actividad
                    </button>
                </li>
            </ul>

            <div class="tab-content" id="transactionsTabContent">
                <div class="tab-pane fade show active" id="transactions" role="tabpanel">
                    <div class="transactions-table">
                        <div class="table-header">
                            <h3 class="table-title"><i class="fas fa-list"></i> Historial de Transacciones</h3>
                            <div class="table-actions">
                                <button class="btn btn-sm btn-outline-primary" id="refreshTransactions" data-tooltip="Actualizar">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-primary" id="selectAllTransactions" data-tooltip="Seleccionar todo">
                                    <i class="fas fa-check-square"></i>
                                </button>
                                <span id="transactionCount" class="badge bg-primary">0 transacciones</span>
                            </div>
                        </div>

                        <div class="bulk-actions" id="bulkActions">
                            <div class="bulk-actions-info">
                                <i class="fas fa-check-circle me-2"></i>
                                <span id="selectedCount">0</span> elemento(s) seleccionado(s)
                            </div>
                            <div class="bulk-actions-buttons">
                                <button class="btn btn-sm btn-success" id="bulkCompleteBtn"><i class="fas fa-check"></i>Completar</button>
                                <button class="btn btn-sm btn-warning" id="bulkPendingBtn"><i class="fas fa-clock"></i>Pendiente</button>
                                <button class="btn btn-sm btn-danger" id="bulkDeleteBtn"><i class="fas fa-trash"></i>Eliminar</button>
                                <button class="btn btn-sm btn-secondary" id="bulkCancelBtn"><i class="fas fa-times"></i>Cancelar</button>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table id="transactionsTable">
                                <thead>
                                    <tr>
                                        <th style="width: 40px;"><input type="checkbox" class="select-checkbox" id="selectAllCheckbox"></th>
                                        <th data-sort="id">ID <i class="fas fa-sort sort-icon"></i></th>
                                        <th data-sort="client">Cliente/Proveedor <i class="fas fa-sort sort-icon"></i></th>
                                        <th data-sort="type">Tipo <i class="fas fa-sort sort-icon"></i></th>
                                        <th data-sort="date">Fecha <i class="fas fa-sort sort-icon"></i></th>
                                        <th data-sort="total">Total <i class="fas fa-sort sort-icon"></i></th>
                                        <th data-sort="payment">Método <i class="fas fa-sort sort-icon"></i></th>
                                        <th data-sort="status">Estado <i class="fas fa-sort sort-icon"></i></th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="transactionsTableBody"></tbody>
                            </table>
                        </div>

                        <div class="pagination-container">
                            <div class="pagination-info" id="transactionsPaginationInfo">Mostrando 0 de 0 transacciones</div>
                            <ul class="pagination" id="transactionsPagination"></ul>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="orders" role="tabpanel">
                    <div class="transactions-table">
                        <div class="table-header">
                            <h3 class="table-title"><i class="fas fa-shopping-cart"></i> Gestión de Pedidos</h3>
                            <div class="table-actions">
                                <button class="btn btn-sm btn-outline-primary" id="refreshOrders" data-tooltip="Actualizar">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                                <select class="form-select form-select-sm" id="orderStatusFilter" style="width: auto; min-width: 140px;">
                                    <option value="all">Todos los estados</option>
                                    <option value="Nuevo">Nuevo</option>
                                    <option value="Procesando">Procesando</option>
                                    <option value="Enviado">Enviado</option>
                                    <option value="Entregado">Entregado</option>
                                    <option value="Cancelado">Cancelado</option>
                                </select>
                                <span id="ordersCount" class="badge bg-primary">0 pedidos</span>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table id="ordersTable">
                                <thead>
                                    <tr>
                                        <th data-sort="id">Nº Pedido <i class="fas fa-sort sort-icon"></i></th>
                                        <th data-sort="client">Cliente <i class="fas fa-sort sort-icon"></i></th>
                                        <th data-sort="date">Fecha <i class="fas fa-sort sort-icon"></i></th>
                                        <th>Productos</th>
                                        <th data-sort="total">Total <i class="fas fa-sort sort-icon"></i></th>
                                        <th data-sort="status">Estado <i class="fas fa-sort sort-icon"></i></th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="ordersTableBody"></tbody>
                            </table>
                        </div>

                        <div class="pagination-container">
                            <div class="pagination-info" id="ordersPaginationInfo">Mostrando 0 de 0 pedidos</div>
                            <ul class="pagination" id="ordersPagination"></ul>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="timeline" role="tabpanel">
                    <div class="transactions-table">
                        <div class="table-header">
                            <h3 class="table-title"><i class="fas fa-clock"></i> Línea de Tiempo de Actividad Reciente</h3>
                        </div>
                        <div class="timeline" id="timelineContainer" style="padding: 20px;"></div>
                    </div>
                </div>

                <div class="tab-pane fade" id="trash" role="tabpanel">
                    <div class="transactions-table">
                        <div class="table-header">
                            <h3 class="table-title"><i class="fas fa-trash"></i> Papelera de Reciclaje</h3>
                            <button class="btn btn-sm btn-danger" id="emptyTrashBtn"><i class="fas fa-trash-alt"></i>Vaciar Papelera</button>
                        </div>
                        <div style="padding: 20px;" id="trashList"></div>
                    </div>
                </div>

                <div class="tab-pane fade" id="activity" role="tabpanel">
                    <div class="transactions-table">
                        <div class="table-header">
                            <h3 class="table-title"><i class="fas fa-history"></i> Historial de Actividad</h3>
                            <button class="btn btn-sm btn-danger" id="clearActivityBtn"><i class="fas fa-trash"></i>Limpiar</button>
                        </div>
                        <div style="padding: 20px;" id="activityList"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Ver Transacción -->
    <div class="modal fade" id="viewTransactionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-eye me-2"></i>Detalles de la Transacción</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-4 g-3">
                        <div class="col-md-6 col-12">
                            <p><strong>ID Transacción:</strong> <span id="viewTransactionId"></span></p>
                            <p><strong>Cliente/Proveedor:</strong> <span id="viewTransactionClient"></span></p>
                            <p><strong>Teléfono:</strong> <span id="viewTransactionPhone"></span></p>
                            <p><strong>Email:</strong> <span id="viewTransactionEmail"></span></p>
                        </div>
                        <div class="col-md-6 col-12">
                            <p><strong>Tipo:</strong> <span id="viewTransactionType"></span></p>
                            <p><strong>Fecha:</strong> <span id="viewTransactionDate"></span></p>
                            <p><strong>Método de Pago:</strong> <span id="viewTransactionPayment"></span></p>
                            <p><strong>Estado:</strong> <span id="viewTransactionStatus" class="badge"></span></p>
                        </div>
                    </div>
                    <h6><i class="fas fa-box me-2"></i>Productos:</h6>
                    <div class="product-list" id="viewTransactionProducts"></div>
                    <div class="transaction-summary">
                        <div class="summary-row"><span>Subtotal:</span><span id="viewTransactionSubtotal">$0.00</span></div>
                        <div class="summary-row"><span>Impuestos:</span><span id="viewTransactionTax">$0.00</span></div>
                        <div class="summary-row"><span>Descuento:</span><span id="viewTransactionDiscount">$0.00</span></div>
                        <div class="summary-row summary-total"><span>TOTAL:</span><span id="viewTransactionTotal">$0.00</span></div>
                    </div>
                    <div class="mt-4">
                        <strong><i class="fas fa-sticky-note me-2"></i>Notas:</strong>
                        <p id="viewTransactionNotes" class="mt-2 p-3 bg-light rounded">Sin notas adicionales</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-info" id="btnEditTransaction"><i class="fas fa-edit me-1"></i> Editar</button>
                    <button type="button" class="btn btn-primary" id="btnPrintTransaction"><i class="fas fa-print me-1"></i> Imprimir</button>
                    <button type="button" class="btn btn-success" id="btnNotifyTransaction"><i class="fab fa-whatsapp me-1"></i> Notificar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Ver Pedido -->
    <div class="modal fade" id="viewOrderModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-box me-2"></i>Detalles del Pedido</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-4 g-3">
                        <div class="col-md-6 col-12">
                            <p><strong>Nº Pedido:</strong> <span id="viewOrderId"></span></p>
                            <p><strong>Cliente:</strong> <span id="viewOrderClient"></span></p>
                            <p><strong>Email:</strong> <span id="viewOrderEmail"></span></p>
                            <p><strong>Teléfono:</strong> <span id="viewOrderPhone"></span></p>
                        </div>
                        <div class="col-md-6 col-12">
                            <p><strong>Fecha:</strong> <span id="viewOrderDate"></span></p>
                            <p><strong>Estado:</strong> <span id="viewOrderStatus" class="badge"></span></p>
                            <p><strong>Método de Envío:</strong> <span id="viewOrderShipping"></span></p>
                            <p><strong>Dirección:</strong> <span id="viewOrderAddress"></span></p>
                        </div>
                    </div>
                    <h6><i class="fas fa-box me-2"></i>Productos:</h6>
                    <div class="product-list" id="viewOrderProducts"></div>
                    <div class="transaction-summary">
                        <div class="summary-row"><span>Subtotal:</span><span id="viewOrderSubtotal">$0.00</span></div>
                        <div class="summary-row"><span>Envío:</span><span id="viewOrderShippingCost">$0.00</span></div>
                        <div class="summary-row"><span>Impuestos:</span><span id="viewOrderTax">$0.00</span></div>
                        <div class="summary-row summary-total"><span>TOTAL:</span><span id="viewOrderTotal">$0.00</span></div>
                    </div>
                    <div class="mt-4">
                        <strong><i class="fas fa-sticky-note me-2"></i>Notas:</strong>
                        <p id="viewOrderNotes" class="mt-2 p-3 bg-light rounded">Sin notas adicionales</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary" id="btnUpdateOrderStatus"><i class="fas fa-sync me-1"></i> Actualizar Estado</button>
                    <button type="button" class="btn btn-success" id="btnNotifyOrder"><i class="fab fa-whatsapp me-1"></i> Notificar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Agregar Transacción -->
    <div class="modal fade" id="addTransactionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus me-2"></i>Nueva Transacción</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addTransactionForm">
                        <div class="row g-3">
                            <div class="col-md-6 col-12">
                                <label for="transactionType" class="form-label">Tipo de Transacción *</label>
                                <select class="form-select" id="transactionType" required>
                                    <option value="">Seleccionar...</option>
                                    <option value="Venta">Venta</option>
                                    <option value="Compra">Compra</option>
                                    <option value="Devolución">Devolución</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="transactionClient" class="form-label">Cliente/Proveedor *</label>
                                <input type="text" class="form-control" id="transactionClient" required>
                            </div>
                        </div>
                        <div class="row g-3 mt-1">
                            <div class="col-md-6 col-12">
                                <label for="transactionPhone" class="form-label">Teléfono</label>
                                <input type="tel" class="form-control" id="transactionPhone" placeholder="+1234567890">
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="transactionEmail" class="form-label">Email</label>
                                <input type="email" class="form-control" id="transactionEmail" placeholder="cliente@ejemplo.com">
                            </div>
                        </div>
                        <div class="row g-3 mt-1">
                            <div class="col-md-4 col-12">
                                <label for="transactionDate" class="form-label">Fecha *</label>
                                <input type="date" class="form-control" id="transactionDate" required>
                            </div>
                            <div class="col-md-4 col-12">
                                <label for="transactionPayment" class="form-label">Método de Pago</label>
                                <select class="form-select" id="transactionPayment">
                                    <option value="Efectivo">Efectivo</option>
                                    <option value="Tarjeta de Crédito">Tarjeta de Crédito</option>
                                    <option value="Tarjeta de Débito">Tarjeta de Débito</option>
                                    <option value="Transferencia">Transferencia</option>
                                    <option value="PayPal">PayPal</option>
                                </select>
                            </div>
                            <div class="col-md-4 col-12">
                                <label for="transactionStatus" class="form-label">Estado</label>
                                <select class="form-select" id="transactionStatus">
                                    <option value="Pendiente">Pendiente</option>
                                    <option value="Completado">Completado</option>
                                    <option value="Cancelado">Cancelado</option>
                                </select>
                            </div>
                        </div>
                        <div class="mt-3">
                            <label class="form-label">Productos</label>
                            <div id="transactionProductsList"></div>
                            <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="addProductToTransaction">
                                <i class="fas fa-plus me-1"></i>Agregar Producto
                            </button>
                        </div>
                        <div class="row g-3 mt-1">
                            <div class="col-md-6 col-12">
                                <label for="transactionDiscount" class="form-label">Descuento ($)</label>
                                <input type="number" class="form-control" id="transactionDiscount" value="0" min="0" step="0.01">
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="transactionTax" class="form-label">Impuestos (%)</label>
                                <input type="number" class="form-control" id="transactionTax" value="10" min="0" max="100">
                            </div>
                        </div>
                        <div class="mt-3">
                            <label for="transactionPriority" class="form-label">Prioridad</label>
                            <select class="form-select" id="transactionPriority">
                                <option value="Baja">Baja</option>
                                <option value="Media" selected>Media</option>
                                <option value="Alta">Alta</option>
                            </select>
                        </div>
                        <div class="mt-3">
                            <label for="transactionNotes" class="form-label">Notas</label>
                            <textarea class="form-control" id="transactionNotes" rows="3" placeholder="Notas adicionales..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveTransaction"><i class="fas fa-save me-1"></i> Guardar Transacción</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Editar Transacción -->
    <div class="modal fade" id="editTransactionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Editar Transacción</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editTransactionForm">
                        <input type="hidden" id="editTransactionId">
                        <div class="row g-3">
                            <div class="col-md-6 col-12">
                                <label for="editTransactionType" class="form-label">Tipo *</label>
                                <select class="form-select" id="editTransactionType" required>
                                    <option value="Venta">Venta</option>
                                    <option value="Compra">Compra</option>
                                    <option value="Devolución">Devolución</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="editTransactionClient" class="form-label">Cliente/Proveedor *</label>
                                <input type="text" class="form-control" id="editTransactionClient" required>
                            </div>
                        </div>
                        <div class="row g-3 mt-1">
                            <div class="col-md-6 col-12">
                                <label for="editTransactionPhone" class="form-label">Teléfono</label>
                                <input type="tel" class="form-control" id="editTransactionPhone">
                            </div>
                            <div class="col-md-6 col-12">
                                <label for="editTransactionEmail" class="form-label">Email</label>
                                <input type="email" class="form-control" id="editTransactionEmail">
                            </div>
                        </div>
                        <div class="row g-3 mt-1">
                            <div class="col-md-4 col-12">
                                <label for="editTransactionPayment" class="form-label">Método de Pago</label>
                                <select class="form-select" id="editTransactionPayment">
                                    <option value="Efectivo">Efectivo</option>
                                    <option value="Tarjeta de Crédito">Tarjeta de Crédito</option>
                                    <option value="Tarjeta de Débito">Tarjeta de Débito</option>
                                    <option value="Transferencia">Transferencia</option>
                                    <option value="PayPal">PayPal</option>
                                </select>
                            </div>
                            <div class="col-md-4 col-12">
                                <label for="editTransactionStatus" class="form-label">Estado</label>
                                <select class="form-select" id="editTransactionStatus">
                                    <option value="Pendiente">Pendiente</option>
                                    <option value="Completado">Completado</option>
                                    <option value="Cancelado">Cancelado</option>
                                </select>
                            </div>
                            <div class="col-md-4 col-12">
                                <label for="editTransactionPriority" class="form-label">Prioridad</label>
                                <select class="form-select" id="editTransactionPriority">
                                    <option value="Baja">Baja</option>
                                    <option value="Media">Media</option>
                                    <option value="Alta">Alta</option>
                                </select>
                            </div>
                        </div>
                        <div class="mt-3">
                            <label for="editTransactionNotes" class="form-label">Notas</label>
                            <textarea class="form-control" id="editTransactionNotes" rows="3"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="updateTransaction"><i class="fas fa-save me-1"></i> Guardar Cambios</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Notificación -->
    <div class="modal fade notification-modal" id="notificationModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-bell me-2"></i>Enviar Notificación</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="padding: 0;">
                    <div class="notification-type" data-type="whatsapp">
                        <i class="fab fa-whatsapp whatsapp-notification"></i>
                        <div><strong>WhatsApp</strong><p>Enviar notificación por WhatsApp</p></div>
                    </div>
                    <div class="notification-type" data-type="sms">
                        <i class="fas fa-sms sms-notification"></i>
                        <div><strong>SMS</strong><p>Enviar notificación por mensaje de texto</p></div>
                    </div>
                    <div class="notification-type" data-type="email">
                        <i class="fas fa-envelope email-notification"></i>
                        <div><strong>Email</strong><p>Enviar notificación por correo electrónico</p></div>
                    </div>
                    <div class="notification-type" data-type="copy">
                        <i class="fas fa-copy" style="background: rgba(108, 117, 125, 0.1); color: #6c757d;"></i>
                        <div><strong>Copiar al portapapeles</strong><p>Copiar mensaje de notificación</p></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Actualizar Estado -->
    <div class="modal fade" id="updateOrderStatusModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-sync me-2"></i>Actualizar Estado del Pedido</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="updateOrderId">
                    <div class="mb-3">
                        <label for="newOrderStatus" class="form-label">Nuevo Estado</label>
                        <select class="form-select" id="newOrderStatus">
                            <option value="Nuevo">Nuevo</option>
                            <option value="Procesando">Procesando</option>
                            <option value="Enviado">Enviado</option>
                            <option value="Entregado">Entregado</option>
                            <option value="Cancelado">Cancelado</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="statusNotes" class="form-label">Notas (opcional)</label>
                        <textarea class="form-control" id="statusNotes" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-check">
                            <input type="checkbox" class="form-check-input" id="notifyCustomer" checked>
                            <span class="form-check-label">Notificar al cliente</span>
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="confirmUpdateStatus"><i class="fas fa-check me-1"></i> Actualizar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Atajos -->
    <div class="modal fade" id="shortcutsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-keyboard me-2"></i>Atajos de Teclado</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <ul style="list-style: none; padding: 0;">
                        <li style="padding: 8px 0; border-bottom: 1px solid var(--border-color);"><strong>Ctrl + K</strong> - Enfocar búsqueda</li>
                        <li style="padding: 8px 0; border-bottom: 1px solid var(--border-color);"><strong>Ctrl + N</strong> - Nueva transacción</li>
                        <li style="padding: 8px 0; border-bottom: 1px solid var(--border-color);"><strong>Ctrl + E</strong> - Exportar PDF</li>
                        <li style="padding: 8px 0; border-bottom: 1px solid var(--border-color);"><strong>Ctrl + P</strong> - Imprimir</li>
                        <li style="padding: 8px 0; border-bottom: 1px solid var(--border-color);"><strong>Ctrl + D</strong> - Cambiar tema</li>
                        <li style="padding: 8px 0;"><strong>Esc</strong> - Cerrar modales</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle" aria-label="Abrir menú">
        <i class="fas fa-bars"></i>
    </button>
    <div class="toast-container" id="toastContainer"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ============================================
        // CLASE PRINCIPAL
        // ============================================
        class EnhancedTransactionManager {
            constructor() {
                this.transactions = JSON.parse(localStorage.getItem('transactions')) || [];
                this.orders = JSON.parse(localStorage.getItem('orders')) || [];
                this.notificationSettings = JSON.parse(localStorage.getItem('notificationSettings')) || {
                    whatsapp: true, sms: false, email: true, push: false, stock: true
                };
                this.notifications = JSON.parse(localStorage.getItem('notifications')) || [];
                this.trash = JSON.parse(localStorage.getItem('trash')) || [];
                this.activity = JSON.parse(localStorage.getItem('activity')) || [];
                this.selectedIds = new Set();
                this.currentPage = { transactions: 1, orders: 1 };
                this.itemsPerPage = 8;
                this.filteredTransactions = [];
                this.filteredOrders = [];
                this.sortField = { transactions: null, orders: null };
                this.sortDirection = { transactions: 'asc', orders: 'asc' };
                this.currentNotificationItem = null;
                this.currentNotificationType = null;
                this.charts = {};
                this.compactMode = localStorage.getItem('compactMode') === 'true';
                this.currentViewItem = null;

                if (this.transactions.length === 0) this.initializeSampleData();
                if (this.notifications.length === 0) this.initializeNotifications();
            }

            initializeSampleData() {
                this.transactions = [
                    { id: 'TXN-78912', client: 'María García', type: 'Venta', date: '15/06/2023', total: 935.00, payment: 'Tarjeta de Crédito', status: 'Completado', products: [{ id: 'PRD-001', name: 'Laptop HP Pavilion', price: 850.00, quantity: 1 }], subtotal: 850.00, tax: 85.00, discount: 0, notes: '', phone: '+34123456789', email: 'maria.garcia@empresa.com', priority: 'Media' },
                    { id: 'TXN-78911', client: 'Proveedor TechImport', type: 'Compra', date: '14/06/2023', total: 2150.00, payment: 'Transferencia', status: 'Completado', products: [{ id: 'PRD-007', name: 'Tablet Android', price: 299.99, quantity: 5 }, { id: 'PRD-004', name: 'Monitor LG 24"', price: 220.00, quantity: 3 }], subtotal: 2150.00, tax: 0, discount: 0, notes: 'Pedido de reposición', phone: '+34987654321', email: 'contacto@techimport.com', priority: 'Alta' },
                    { id: 'TXN-78910', client: 'Carlos López', type: 'Venta', date: '14/06/2023', total: 214.50, payment: 'Efectivo', status: 'Pendiente', products: [{ id: 'PRD-009', name: 'Auriculares Inalámbricos', price: 150.00, quantity: 1 }, { id: 'PRD-010', name: 'Mochila Impermeable', price: 45.00, quantity: 1 }], subtotal: 195.00, tax: 19.50, discount: 0, notes: 'Pago en efectivo', phone: '+34678901234', email: 'carlos.lopez@email.com', priority: 'Baja' },
                    { id: 'TXN-78909', client: 'Juan Pérez', type: 'Devolución', date: '13/06/2023', total: -120.00, payment: 'Reembolso', status: 'Completado', products: [{ id: 'PRD-006', name: 'Silla de Oficina', price: 120.00, quantity: 1 }], subtotal: -120.00, tax: 0, discount: 0, notes: 'Producto defectuoso', phone: '+34567890123', email: 'juan.perez@email.com', priority: 'Alta' },
                    { id: 'TXN-78908', client: 'Ana Martínez', type: 'Venta', date: '13/06/2023', total: 504.35, payment: 'Tarjeta de Débito', status: 'Completado', products: [{ id: 'PRD-005', name: 'Camiseta Algodón', price: 25.00, quantity: 3 }, { id: 'PRD-003', name: 'Zapatillas Deportivas', price: 75.00, quantity: 2 }, { id: 'PRD-008', name: 'Set de Herramientas', price: 89.99, quantity: 2 }], subtotal: 458.50, tax: 45.85, discount: 0, notes: '', phone: '+34789012345', email: 'ana.martinez@email.com', priority: 'Media' },
                    { id: 'TXN-78907', client: 'Proveedor MobileTech', type: 'Compra', date: '12/06/2023', total: 3745.00, payment: 'Transferencia', status: 'Cancelado', products: [{ id: 'PRD-002', name: 'Smartphone Samsung Galaxy', price: 620.00, quantity: 4 }, { id: 'PRD-001', name: 'Laptop HP Pavilion', price: 850.00, quantity: 1 }], subtotal: 3745.00, tax: 0, discount: 0, notes: 'Cancelado por falta de stock', phone: '+34123456789', email: 'ventas@mobiletech.com', priority: 'Alta' },
                    { id: 'TXN-78906', client: 'Laura Rodríguez', type: 'Venta', date: '12/06/2023', total: 682.00, payment: 'Tarjeta de Crédito', status: 'Completado', products: [{ id: 'PRD-002', name: 'Smartphone Samsung Galaxy', price: 620.00, quantity: 1 }], subtotal: 620.00, tax: 62.00, discount: 0, notes: 'Cliente frecuente', phone: '+34654321098', email: 'laura.rodriguez@email.com', priority: 'Baja' },
                    { id: 'TXN-78905', client: 'Roberto Sánchez', type: 'Venta', date: '11/06/2023', total: 175.50, payment: 'Efectivo', status: 'Pendiente', products: [{ id: 'PRD-003', name: 'Zapatillas Deportivas', price: 75.00, quantity: 1 }, { id: 'PRD-010', name: 'Mochila Impermeable', price: 45.00, quantity: 1 }], subtotal: 120.00, tax: 12.00, discount: 0, notes: 'Pendiente de confirmación', phone: '+34765432109', email: 'roberto.sanchez@email.com', priority: 'Media' }
                ];

                this.orders = [
                    { id: 'ORD-2023-1052', client: 'María García', date: '15/06/2023', status: 'Nuevo', products: [{ id: 'PRD-001', name: 'Laptop HP Pavilion', price: 850.00, quantity: 1 }], subtotal: 850.00, shipping: 0, tax: 85.00, email: 'maria.garcia@empresa.com', phone: '+34123456789', shippingMethod: 'Recogida en tienda', address: 'Calle Mayor 123, Madrid', notes: 'Cliente recogerá en tienda' },
                    { id: 'ORD-2023-1051', client: 'Carlos López', date: '14/06/2023', status: 'Procesando', products: [{ id: 'PRD-009', name: 'Auriculares Inalámbricos', price: 150.00, quantity: 1 }, { id: 'PRD-010', name: 'Mochila Impermeable', price: 45.00, quantity: 1 }], subtotal: 195.00, shipping: 5.99, tax: 19.50, email: 'carlos.lopez@email.com', phone: '+34678901234', shippingMethod: 'Correo ordinario', address: 'Av. Constitución 45, Barcelona', notes: 'Incluir factura' },
                    { id: 'ORD-2023-1050', client: 'Ana Martínez', date: '14/06/2023', status: 'Enviado', products: [{ id: 'PRD-005', name: 'Camiseta Algodón', price: 25.00, quantity: 3 }, { id: 'PRD-003', name: 'Zapatillas Deportivas', price: 75.00, quantity: 2 }, { id: 'PRD-008', name: 'Set de Herramientas', price: 89.99, quantity: 2 }], subtotal: 458.50, shipping: 0, tax: 45.85, email: 'ana.martinez@email.com', phone: '+34789012345', shippingMethod: 'Envío exprés', address: 'Plaza España 7, Valencia', notes: 'Envío exprés garantizado' },
                    { id: 'ORD-2023-1049', client: 'Laura Rodríguez', date: '13/06/2023', status: 'Entregado', products: [{ id: 'PRD-002', name: 'Smartphone Samsung Galaxy', price: 620.00, quantity: 1 }], subtotal: 620.00, shipping: 0, tax: 62.00, email: 'laura.rodriguez@email.com', phone: '+34654321098', shippingMethod: 'Recogida en tienda', address: '', notes: 'Entregado personalmente' },
                    { id: 'ORD-2023-1048', client: 'Roberto Sánchez', date: '12/06/2023', status: 'Enviado', products: [{ id: 'PRD-003', name: 'Zapatillas Deportivas', price: 75.00, quantity: 1 }, { id: 'PRD-010', name: 'Mochila Impermeable', price: 45.00, quantity: 1 }], subtotal: 120.00, shipping: 3.99, tax: 12.00, email: 'roberto.sanchez@email.com', phone: '+34765432109', shippingMethod: 'Correo ordinario', address: 'Calle Sol 34, Sevilla', notes: 'Tracking: SE123456ES' },
                    { id: 'ORD-2023-1047', client: 'Juan Pérez', date: '11/06/2023', status: 'Cancelado', products: [{ id: 'PRD-006', name: 'Silla de Oficina', price: 120.00, quantity: 1 }], subtotal: 120.00, shipping: 15.00, tax: 12.00, email: 'juan.perez@email.com', phone: '+34567890123', shippingMethod: 'Mensajería', address: 'Av. Libertad 56, Bilbao', notes: 'Cancelado por solicitud del cliente' }
                ];

                this.saveData();
            }

            initializeNotifications() {
                this.notifications = [
                    { id: 1, title: 'Nuevo pedido recibido', message: 'Pedido #ORD-2023-1052 de María García', time: 'Hace 10 minutos', read: false, type: 'order' },
                    { id: 2, title: 'Pago confirmado', message: 'El pago de la transacción #TXN-78912 fue confirmado', time: 'Hace 25 minutos', read: false, type: 'transaction' },
                    { id: 3, title: 'Pedido enviado', message: 'El pedido #ORD-2023-1050 ha sido enviado', time: 'Hace 1 hora', read: false, type: 'order' },
                    { id: 4, title: 'Stock actualizado', message: 'El inventario se actualizó después de las ventas del día', time: 'Ayer a las 18:30', read: true, type: 'inventory' },
                    { id: 5, title: 'Pedido cancelado', message: 'El pedido #ORD-2023-1047 fue cancelado', time: 'Ayer a las 14:15', read: true, type: 'order' }
                ];
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
            }

            logActivity(action, details = '') {
                const activity = { id: Date.now(), action, details, date: new Date().toLocaleString() };
                this.activity.unshift(activity);
                if (this.activity.length > 100) this.activity = this.activity.slice(0, 100);
                localStorage.setItem('activity', JSON.stringify(this.activity));
            }

            getStatusClass(status) {
                switch(status) {
                    case 'Completado': case 'Entregado': return 'bg-success';
                    case 'Pendiente': case 'Procesando': return 'bg-warning';
                    case 'Nuevo': return 'bg-primary';
                    case 'Enviado': return 'bg-info';
                    case 'Cancelado': return 'bg-danger';
                    default: return 'bg-secondary';
                }
            }

            getPriorityClass(priority) {
                switch(priority) {
                    case 'Alta': return 'priority-high';
                    case 'Media': return 'priority-medium';
                    case 'Baja': return 'priority-low';
                    default: return '';
                }
            }

            getUnreadNotifications() { return this.notifications.filter(n => !n.read); }

            markAllNotificationsAsRead() {
                this.notifications.forEach(n => n.read = true);
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
            }

            markNotificationAsRead(id) {
                const n = this.notifications.find(n => n.id === id);
                if (n) { n.read = true; localStorage.setItem('notifications', JSON.stringify(this.notifications)); }
            }

            addNotification(title, message, type = 'info') {
                const newNotification = { id: Date.now(), title, message, time: 'Ahora', read: false, type };
                this.notifications.unshift(newNotification);
                localStorage.setItem('notifications', JSON.stringify(this.notifications));
                this.showNotification(message, 'info');

                if (this.notificationSettings.push && 'Notification' in window && Notification.permission === 'granted') {
                    new Notification(title, { body: message });
                }
                return newNotification;
            }

            sendWhatsAppNotification(item, type) {
                let message = '', phone = '';
                if (type === 'transaction') {
                    message = `✅ *SmartStock AI - Transacción*\n\n*ID:* ${item.id}\n*Cliente:* ${item.client}\n*Tipo:* ${item.type}\n*Total:* $${Math.abs(item.total).toFixed(2)}\n*Estado:* ${item.status}\n*Fecha:* ${item.date}\n\nGracias por confiar en SmartStock AI.`;
                    phone = (item.phone || '').replace(/[^0-9]/g, '');
                } else if (type === 'order') {
                    const total = (item.subtotal + item.tax + (item.shipping || 0)).toFixed(2);
                    message = `📦 *SmartStock AI - Pedido*\n\n*Pedido:* ${item.id}\n*Cliente:* ${item.client}\n*Estado:* ${item.status}\n*Total:* $${total}\n*Productos:* ${item.products.length}\n*Fecha:* ${item.date}\n\nGracias por tu compra.`;
                    phone = (item.phone || '').replace(/[^0-9]/g, '');
                }
                if (!phone) {
                    this.showNotification('No hay número de teléfono disponible', 'error');
                    return;
                }
                const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
                window.open(whatsappUrl, '_blank');
                this.addNotification('Notificación WhatsApp', `Mensaje enviado a ${item.client}`, 'whatsapp');
            }

            sendSMSNotification(item) { this.addNotification('SMS enviado', `Mensaje enviado a ${item.client}`, 'sms'); }
            sendEmailNotification(item) { this.addNotification('Email enviado', `Correo a ${item.email || item.client}`, 'email'); }

            copyNotificationToClipboard(item, type) {
                let text = '';
                if (type === 'transaction') {
                    text = `Transacción ${item.id} - ${item.client} - $${item.total.toFixed(2)} - Estado: ${item.status}`;
                } else {
                    text = `Pedido ${item.id} - ${item.client} - Estado: ${item.status}`;
                }
                navigator.clipboard.writeText(text).then(() => {
                    this.showNotification('Mensaje copiado al portapapeles', 'success');
                }).catch(() => {
                    this.showNotification('Error al copiar', 'error');
                });
            }

            sendNotification(item, type, notificationType) {
                if (notificationType !== 'copy' && !this.notificationSettings[notificationType]) {
                    this.showNotification(`Notificaciones por ${notificationType.toUpperCase()} desactivadas`, 'warning');
                    return;
                }
                switch(notificationType) {
                    case 'whatsapp': this.sendWhatsAppNotification(item, type); break;
                    case 'sms': this.sendSMSNotification(item); break;
                    case 'email': this.sendEmailNotification(item); break;
                    case 'copy': this.copyNotificationToClipboard(item, type); break;
                }
            }

            updateNotificationSettings(settings) {
                this.notificationSettings = { ...this.notificationSettings, ...settings };
                localStorage.setItem('notificationSettings', JSON.stringify(this.notificationSettings));
                if (settings.push && 'Notification' in window && Notification.permission !== 'granted') {
                    Notification.requestPermission();
                }
            }

            getStats() {
                const now = new Date();
                const currentMonth = now.getMonth() + 1;
                const currentYear = now.getFullYear();

                const monthlySales = this.transactions
                    .filter(t => {
                        const parts = t.date.split('/');
                        return parseInt(parts[1]) === currentMonth && parseInt(parts[2]) === currentYear && t.type === 'Venta' && t.status === 'Completado';
                    })
                    .reduce((sum, t) => sum + t.total, 0);

                const activeOrders = this.orders.filter(o => o.status !== 'Entregado' && o.status !== 'Cancelado').length;
                const pendingOrders = this.orders.filter(o => o.status === 'Nuevo' || o.status === 'Procesando').length;
                const urgentOrders = this.orders.filter(o => o.status === 'Nuevo').length;
                const completedToday = this.orders.filter(o => {
                    const parts = o.date.split('/');
                    return parseInt(parts[0]) === now.getDate() && parseInt(parts[1]) === currentMonth && parseInt(parts[2]) === currentYear && o.status === 'Entregado';
                }).length;
                const totalIncome = this.transactions.filter(t => t.type === 'Venta' && t.status === 'Completado').reduce((sum, t) => sum + t.total, 0);
                const avgTicket = this.transactions.filter(t => t.type === 'Venta').length > 0
                    ? totalIncome / this.transactions.filter(t => t.type === 'Venta').length
                    : 0;
                const uniqueClients = new Set(this.transactions.map(t => t.client)).size;
                const cancelledOrders = this.orders.filter(o => o.status === 'Cancelado').length;

                return {
                    monthlySales, activeOrders, pendingOrders, completedToday,
                    urgentOrders, totalTransactions: this.transactions.length,
                    totalOrders: this.orders.length, totalIncome, avgTicket,
                    uniqueClients, cancelledOrders
                };
            }

            filterTransactions(searchTerm = '', type = 'all', status = 'all', date = '') {
                this.filteredTransactions = this.transactions.filter(t => {
                    const matchesSearch = t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                         t.client.toLowerCase().includes(searchTerm.toLowerCase());
                    const matchesType = type === 'all' || t.type === type;
                    const matchesStatus = status === 'all' || t.status === status;
                    let matchesDate = true;
                    if (date) {
                        const dateObj = new Date(date);
                        const [day, month, year] = t.date.split('/').map(Number);
                        matchesDate = day === dateObj.getDate() && month === dateObj.getMonth() + 1 && year === dateObj.getFullYear();
                    }
                    return matchesSearch && matchesType && matchesStatus && matchesDate;
                });

                if (this.sortField.transactions) {
                    this.filteredTransactions.sort((a, b) => {
                        let av = a[this.sortField.transactions], bv = b[this.sortField.transactions];
                        if (this.sortField.transactions === 'total') { av = Math.abs(av); bv = Math.abs(bv); }
                        if (typeof av === 'string') av = av.toLowerCase();
                        if (typeof bv === 'string') bv = bv.toLowerCase();
                        if (av < bv) return this.sortDirection.transactions === 'asc' ? -1 : 1;
                        if (av > bv) return this.sortDirection.transactions === 'asc' ? 1 : -1;
                        return 0;
                    });
                }
                return this.filteredTransactions;
            }

            filterOrders(searchTerm = '', status = 'all') {
                this.filteredOrders = this.orders.filter(o => {
                    const matchesSearch = o.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                         o.client.toLowerCase().includes(searchTerm.toLowerCase());
                    const matchesStatus = status === 'all' || o.status === status;
                    return matchesSearch && matchesStatus;
                });

                if (this.sortField.orders) {
                    this.filteredOrders.sort((a, b) => {
                        let av = a[this.sortField.orders], bv = b[this.sortField.orders];
                        if (this.sortField.orders === 'total') {
                            av = a.subtotal + (a.shipping || 0) + a.tax;
                            bv = b.subtotal + (b.shipping || 0) + b.tax;
                        }
                        if (typeof av === 'string') av = av.toLowerCase();
                        if (typeof bv === 'string') bv = bv.toLowerCase();
                        if (av < bv) return this.sortDirection.orders === 'asc' ? -1 : 1;
                        if (av > bv) return this.sortDirection.orders === 'asc' ? 1 : -1;
                        return 0;
                    });
                }
                return this.filteredOrders;
            }

            getPaginatedTransactions(page = 1) {
                const startIndex = (page - 1) * this.itemsPerPage;
                return this.filteredTransactions.slice(startIndex, startIndex + this.itemsPerPage);
            }

            getPaginatedOrders(page = 1) {
                const startIndex = (page - 1) * this.itemsPerPage;
                return this.filteredOrders.slice(startIndex, startIndex + this.itemsPerPage);
            }

            getTotalTransactionPages() { return Math.ceil(this.filteredTransactions.length / this.itemsPerPage) || 1; }
            getTotalOrderPages() { return Math.ceil(this.filteredOrders.length / this.itemsPerPage) || 1; }

            getTransactionById(id) { return this.transactions.find(t => t.id === id); }
            getOrderById(id) { return this.orders.find(o => o.id === id); }

            addTransaction(transaction) {
                const lastId = this.transactions.length > 0
                    ? Math.max(...this.transactions.map(t => parseInt(t.id.split('-')[1])))
                    : 78900;
                transaction.id = `TXN-${lastId + 1}`;

                const subtotal = transaction.products.reduce((sum, p) => sum + (p.price * p.quantity), 0);
                const tax = (subtotal * (transaction.taxRate || 10)) / 100;
                const discount = transaction.discount || 0;
                transaction.total = subtotal + tax - discount;
                transaction.subtotal = subtotal;
                transaction.tax = tax;

                this.transactions.push(transaction);
                this.saveData();
                this.logActivity('Transacción creada', `${transaction.id} - ${transaction.client}`);
                this.addNotification('Nueva transacción', `Transacción ${transaction.id} por $${transaction.total.toFixed(2)}`, 'transaction');
                return transaction.id;
            }

            updateTransaction(id, data) {
                const index = this.transactions.findIndex(t => t.id === id);
                if (index !== -1) {
                    this.transactions[index] = { ...this.transactions[index], ...data };
                    this.saveData();
                    this.logActivity('Transacción actualizada', `${id} - ${data.client}`);
                    this.showNotification('Transacción actualizada correctamente', 'success');
                    return true;
                }
                return false;
            }

            deleteTransaction(id) {
                const index = this.transactions.findIndex(t => t.id === id);
                if (index !== -1) {
                    const item = this.transactions[index];
                    this.trash.push({ ...item, deletedAt: new Date().toISOString(), itemType: 'transaction' });
                    this.transactions.splice(index, 1);
                    this.saveData();
                    this.saveTrash();
                    this.logActivity('Transacción eliminada', `${id} - ${item.client}`);
                    this.showNotification('Transacción movida a papelera', 'success');
                    return true;
                }
                return false;
            }

            restoreFromTrash(id) {
                const index = this.trash.findIndex(t => t.id === id);
                if (index !== -1) {
                    const item = { ...this.trash[index] };
                    const itemType = item.itemType;
                    delete item.deletedAt;
                    delete item.itemType;
                    if (itemType === 'order') this.orders.push(item);
                    else this.transactions.push(item);
                    this.trash.splice(index, 1);
                    this.saveData();
                    this.saveTrash();
                    this.logActivity('Restaurado de papelera', id);
                    this.showNotification('Elemento restaurado', 'success');
                    return true;
                }
                return false;
            }

            permanentlyDeleteFromTrash(id) {
                const index = this.trash.findIndex(t => t.id === id);
                if (index !== -1) {
                    this.trash.splice(index, 1);
                    this.saveTrash();
                    this.logActivity('Eliminado permanentemente', id);
                    this.showNotification('Eliminado permanentemente', 'success');
                    return true;
                }
                return false;
            }

            emptyTrash() {
                this.trash = [];
                this.saveTrash();
                this.logActivity('Papelera vaciada');
                this.showNotification('Papelera vaciada', 'success');
            }

            updateOrderStatus(id, newStatus, notes = '', notify = false) {
                const order = this.getOrderById(id);
                if (!order) return false;
                const oldStatus = order.status;
                order.status = newStatus;
                if (notes) {
                    order.notes = (order.notes ? order.notes + '\n' : '') +
                                 `[${new Date().toLocaleDateString()}] ${oldStatus} → ${newStatus}: ${notes}`;
                }
                this.saveData();
                this.logActivity('Estado actualizado', `Pedido ${id}: ${oldStatus} → ${newStatus}`);
                this.addNotification('Estado actualizado', `Pedido ${id} cambió a ${newStatus}`, 'order');
                if (notify && this.notificationSettings.whatsapp) {
                    this.sendWhatsAppNotification(order, 'order');
                }
                return true;
            }

            saveData() {
                localStorage.setItem('transactions', JSON.stringify(this.transactions));
                localStorage.setItem('orders', JSON.stringify(this.orders));
            }

            saveTrash() { localStorage.setItem('trash', JSON.stringify(this.trash)); }

            showNotification(message, type = 'info') {
                const toast = document.createElement('div');
                toast.className = `toast ${type}`;
                const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
                toast.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i><span>${message}</span>`;
                document.getElementById('toastContainer').appendChild(toast);
                setTimeout(() => {
                    toast.style.animation = 'slideOutRight 0.3s forwards';
                    setTimeout(() => toast.remove(), 300);
                }, 3000);
            }

            getSalesChartData() {
                const days = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
                const sales = [850, 1200, 950, 1100, 1450, 2100, 1800];
                return {
                    labels: days,
                    datasets: [{
                        label: 'Ventas ($)',
                        data: sales,
                        backgroundColor: 'rgba(58, 94, 199, 0.5)',
                        borderColor: '#3a5ec7',
                        borderWidth: 2
                    }]
                };
            }

            getOrdersChartData() {
                const statusCounts = {
                    'Nuevo': this.orders.filter(o => o.status === 'Nuevo').length,
                    'Procesando': this.orders.filter(o => o.status === 'Procesando').length,
                    'Enviado': this.orders.filter(o => o.status === 'Enviado').length,
                    'Entregado': this.orders.filter(o => o.status === 'Entregado').length,
                    'Cancelado': this.orders.filter(o => o.status === 'Cancelado').length
                };
                return {
                    labels: Object.keys(statusCounts),
                    datasets: [{
                        data: Object.values(statusCounts),
                        backgroundColor: ['#3a5ec7', '#ffc107', '#17a2b8', '#28a745', '#dc3545']
                    }]
                };
            }

            getTimelineData() {
                const timeline = [];
                this.transactions.slice(0, 5).forEach(t => {
                    timeline.push({ type: 'transaction', title: `Transacción ${t.id}`, description: `${t.type} - ${t.client} - $${Math.abs(t.total).toFixed(2)}`, date: t.date, status: t.status, icon: t.type === 'Venta' ? 'fa-shopping-cart' : t.type === 'Compra' ? 'fa-truck' : 'fa-undo', color: t.type === 'Venta' ? '#28a745' : t.type === 'Compra' ? '#3a5ec7' : '#ffc107' });
                });
                this.orders.slice(0, 5).forEach(o => {
                    timeline.push({ type: 'order', title: `Pedido ${o.id}`, description: `${o.client} - ${o.products.length} productos`, date: o.date, status: o.status, icon: 'fa-box', color: o.status === 'Entregado' ? '#28a745' : o.status === 'Enviado' ? '#17a2b8' : o.status === 'Cancelado' ? '#dc3545' : '#ffc107' });
                });
                return timeline.slice(0, 10);
            }

            exportToPDF() {
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();
                doc.setFontSize(18);
                doc.setTextColor(40, 40, 40);
                doc.text('Reporte de Transacciones - SmartStock AI', 105, 15, { align: 'center' });
                doc.setFontSize(10);
                doc.setTextColor(100, 100, 100);
                doc.text(`Generado: ${new Date().toLocaleString()}`, 105, 22, { align: 'center' });

                const stats = this.getStats();
                doc.setFontSize(11);
                doc.setTextColor(40, 40, 40);
                doc.text(`Total Transacciones: ${stats.totalTransactions}`, 20, 32);
                doc.text(`Total Pedidos: ${stats.totalOrders}`, 20, 39);
                doc.text(`Ingresos: $${stats.totalIncome.toFixed(2)}`, 20, 46);

                doc.autoTable({
                    startY: 55,
                    head: [['ID', 'Cliente', 'Tipo', 'Fecha', 'Total', 'Estado']],
                    body: this.filteredTransactions.map(t => [t.id, t.client, t.type, t.date, `$${Math.abs(t.total).toFixed(2)}`, t.status]),
                    styles: { fontSize: 9, cellPadding: 4 },
                    headStyles: { fillColor: [58, 94, 199], textColor: [255, 255, 255] }
                });

                doc.save(`transacciones_${new Date().toISOString().split('T')[0]}.pdf`);
                this.logActivity('PDF exportado');
                this.showNotification('PDF generado correctamente', 'success');
            }

            exportToCSV() {
                const headers = ['ID', 'Cliente', 'Tipo', 'Fecha', 'Total', 'Método', 'Estado', 'Prioridad'];
                const rows = this.filteredTransactions.map(t => [t.id, `"${t.client}"`, t.type, t.date, t.total, t.payment, t.status, t.priority || 'Media']);
                const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
                const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `transacciones_${new Date().toISOString().split('T')[0]}.csv`;
                link.click();
                URL.revokeObjectURL(url);
                this.logActivity('CSV exportado');
                this.showNotification('CSV exportado correctamente', 'success');
            }

            exportToExcel() {
                const wb = XLSX.utils.book_new();
                const transactionsData = this.filteredTransactions.map(t => ({
                    'ID': t.id, 'Cliente': t.client, 'Tipo': t.type, 'Fecha': t.date,
                    'Total': t.total, 'Método Pago': t.payment, 'Estado': t.status, 'Prioridad': t.priority || 'Media'
                }));
                XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(transactionsData), 'Transacciones');

                const ordersData = this.filteredOrders.map(o => ({
                    'ID': o.id, 'Cliente': o.client, 'Fecha': o.date,
                    'Total': o.subtotal + (o.shipping || 0) + o.tax, 'Estado': o.status
                }));
                XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(ordersData), 'Pedidos');

                XLSX.writeFile(wb, `transacciones_${new Date().toISOString().split('T')[0]}.xlsx`);
                this.logActivity('Excel exportado');
                this.showNotification('Excel exportado correctamente', 'success');
            }

            exportToJSON() {
                const data = {
                    transactions: this.transactions,
                    orders: this.orders,
                    exportDate: new Date().toISOString(),
                    version: '1.0'
                };
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `backup_${new Date().toISOString().split('T')[0]}.json`;
                link.click();
                URL.revokeObjectURL(url);
                this.logActivity('JSON exportado');
                this.showNotification('JSON exportado correctamente', 'success');
            }
        }

        const transactionManager = new EnhancedTransactionManager();

        // ============================================
        // RESPONSIVE STATE
        // ============================================
        const APP_STATE = {
            isMobile: window.matchMedia('(max-width: 992px)').matches,
            isTouch: ('ontouchstart' in window) || (navigator.maxTouchPoints > 0)
        };

        function openMobileSidebar() {
            document.getElementById('sidebar')?.classList.add('mobile-open');
            document.getElementById('sidebarOverlay')?.classList.add('active');
            document.body.style.overflow = 'hidden';
            if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(5);
        }

        function closeMobileSidebar() {
            document.getElementById('sidebar')?.classList.remove('mobile-open');
            document.getElementById('sidebarOverlay')?.classList.remove('active');
            document.body.style.overflow = '';
        }

        function setupMobileSidebar() {
            const overlay = document.getElementById('sidebarOverlay');
            const closeBtn = document.getElementById('sidebarCloseBtn');
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.getElementById('menuToggle');

            if (overlay) overlay.addEventListener('click', closeMobileSidebar);
            if (closeBtn) closeBtn.addEventListener('click', closeMobileSidebar);
            if (menuToggle) menuToggle.addEventListener('click', () => {
                if (sidebar.classList.contains('mobile-open')) {
                    closeMobileSidebar();
                } else {
                    openMobileSidebar();
                }
            });

            let touchStartX = 0, touchCurrentX = 0;
            sidebar.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
            sidebar.addEventListener('touchmove', (e) => {
                touchCurrentX = e.touches[0].clientX;
                const diff = touchCurrentX - touchStartX;
                if (diff < 0 && diff > -100) sidebar.style.transform = `translateX(${diff}px)`;
            }, { passive: true });
            sidebar.addEventListener('touchend', () => {
                const diff = touchCurrentX - touchStartX;
                sidebar.style.transform = '';
                if (diff < -60) closeMobileSidebar();
                touchStartX = 0; touchCurrentX = 0;
            });
        }

        // ============================================
        // RENDERIZADO
        // ============================================
        function renderTransactionsTable() {
            const tableBody = document.getElementById('transactionsTableBody');
            if (!tableBody) return;

            const searchTerm = document.getElementById('searchInput')?.value || '';
            const type = document.getElementById('typeFilter')?.value || 'all';
            const status = document.getElementById('statusFilter')?.value || 'all';
            const date = document.getElementById('dateFilter')?.value || '';

            transactionManager.filterTransactions(searchTerm, type, status, date);
            const transactions = transactionManager.getPaginatedTransactions(transactionManager.currentPage.transactions);
            const totalPages = transactionManager.getTotalTransactionPages();

            tableBody.innerHTML = '';

            if (transactions.length === 0) {
                tableBody.innerHTML = `
                    <tr><td colspan="9" class="text-center py-4">
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <h4>No hay transacciones</h4>
                            <p>No se encontraron transacciones con los filtros aplicados</p>
                            <button class="btn btn-primary btn-sm mt-2" onclick="clearFilters()">
                                <i class="fas fa-times me-2"></i>Limpiar filtros
                            </button>
                        </div>
                    </td></tr>
                `;
            } else {
                transactions.forEach(t => {
                    const isChecked = transactionManager.selectedIds.has(t.id);
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td><input type="checkbox" class="select-checkbox row-checkbox" data-id="${t.id}" ${isChecked ? 'checked' : ''}></td>
                        <td><span class="badge bg-primary">${t.id}</span></td>
                        <td>
                            <strong>${t.client}</strong>
                            ${t.priority ? `<br><span class="tag ${transactionManager.getPriorityClass(t.priority)}">${t.priority}</span>` : ''}
                        </td>
                        <td><span class="badge ${t.type === 'Venta' ? 'bg-success' : t.type === 'Compra' ? 'bg-info' : 'bg-warning'}">${t.type}</span></td>
                        <td>${t.date}</td>
                        <td class="fw-bold ${t.total < 0 ? 'text-danger' : ''}">$${Math.abs(t.total).toFixed(2)}</td>
                        <td>${t.payment}</td>
                        <td><span class="badge ${transactionManager.getStatusClass(t.status)}">${t.status}</span></td>
                        <td>
                            <button class="action-btn btn-view" data-id="${t.id}" data-tooltip="Ver"><i class="fas fa-eye"></i></button>
                            <button class="action-btn btn-edit" data-id="${t.id}" data-tooltip="Editar"><i class="fas fa-edit"></i></button>
                            <button class="action-btn btn-notify" data-id="${t.id}" data-type="transaction" data-tooltip="Notificar"><i class="fab fa-whatsapp"></i></button>
                            <button class="action-btn btn-delete" data-id="${t.id}" data-tooltip="Eliminar"><i class="fas fa-trash"></i></button>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });
            }

            document.getElementById('transactionCount').textContent = `${transactionManager.filteredTransactions.length} transacciones`;
            document.getElementById('transactionsPaginationInfo').textContent = `Mostrando ${transactions.length} de ${transactionManager.filteredTransactions.length} transacciones`;

            renderTransactionsPagination(totalPages);
            addTransactionTableListeners();
            updateBulkActions();
        }

        function renderTransactionsPagination(totalPages) {
            const pagination = document.getElementById('transactionsPagination');
            if (!pagination) return;
            pagination.innerHTML = '';
            if (totalPages <= 1) return;

            const currentPage = transactionManager.currentPage.transactions;

            const prevLi = document.createElement('li');
            prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
            prevLi.innerHTML = `<a class="page-link"><i class="fas fa-chevron-left"></i></a>`;
            prevLi.addEventListener('click', () => {
                if (currentPage > 1) { transactionManager.currentPage.transactions--; renderTransactionsTable(); }
            });
            pagination.appendChild(prevLi);

            for (let i = 1; i <= totalPages; i++) {
                const pageLi = document.createElement('li');
                pageLi.className = `page-item ${currentPage === i ? 'active' : ''}`;
                pageLi.innerHTML = `<a class="page-link">${i}</a>`;
                pageLi.addEventListener('click', () => { transactionManager.currentPage.transactions = i; renderTransactionsTable(); });
                pagination.appendChild(pageLi);
            }

            const nextLi = document.createElement('li');
            nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
            nextLi.innerHTML = `<a class="page-link"><i class="fas fa-chevron-right"></i></a>`;
            nextLi.addEventListener('click', () => {
                if (currentPage < totalPages) { transactionManager.currentPage.transactions++; renderTransactionsTable(); }
            });
            pagination.appendChild(nextLi);
        }

        function renderOrdersTable() {
            const tableBody = document.getElementById('ordersTableBody');
            if (!tableBody) return;

            const searchTerm = document.getElementById('searchInput')?.value || '';
            const status = document.getElementById('orderStatusFilter')?.value || 'all';

            transactionManager.filterOrders(searchTerm, status);
            const orders = transactionManager.getPaginatedOrders(transactionManager.currentPage.orders);
            const totalPages = transactionManager.getTotalOrderPages();

            tableBody.innerHTML = '';

            if (orders.length === 0) {
                tableBody.innerHTML = `
                    <tr><td colspan="7" class="text-center py-4">
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <h4>No hay pedidos</h4>
                            <p>No se encontraron pedidos con los filtros aplicados</p>
                        </div>
                    </td></tr>
                `;
            } else {
                orders.forEach(o => {
                    const total = (o.subtotal + (o.shipping || 0) + o.tax).toFixed(2);
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td><span class="badge bg-primary">${o.id}</span></td>
                        <td><strong>${o.client}</strong></td>
                        <td>${o.date}</td>
                        <td>${o.products.length} productos</td>
                        <td class="fw-bold">$${total}</td>
                        <td><span class="badge ${transactionManager.getStatusClass(o.status)}">${o.status}</span></td>
                        <td>
                            <button class="action-btn btn-view" data-id="${o.id}" data-type="order" data-tooltip="Ver"><i class="fas fa-eye"></i></button>
                            <button class="action-btn btn-process" data-id="${o.id}" data-type="order" data-tooltip="Actualizar estado"><i class="fas fa-sync"></i></button>
                            <button class="action-btn btn-notify" data-id="${o.id}" data-type="order" data-tooltip="Notificar"><i class="fab fa-whatsapp"></i></button>
                            <button class="action-btn btn-track" data-id="${o.id}" data-tooltip="Seguimiento"><i class="fas fa-map-marker-alt"></i></button>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });
            }

            document.getElementById('ordersCount').textContent = `${transactionManager.filteredOrders.length} pedidos`;
            document.getElementById('ordersPaginationInfo').textContent = `Mostrando ${orders.length} de ${transactionManager.filteredOrders.length} pedidos`;

            renderOrdersPagination(totalPages);
            addOrderTableListeners();
        }

        function renderOrdersPagination(totalPages) {
            const pagination = document.getElementById('ordersPagination');
            if (!pagination) return;
            pagination.innerHTML = '';
            if (totalPages <= 1) return;

            const currentPage = transactionManager.currentPage.orders;

            const prevLi = document.createElement('li');
            prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
            prevLi.innerHTML = `<a class="page-link"><i class="fas fa-chevron-left"></i></a>`;
            prevLi.addEventListener('click', () => {
                if (currentPage > 1) { transactionManager.currentPage.orders--; renderOrdersTable(); }
            });
            pagination.appendChild(prevLi);

            for (let i = 1; i <= totalPages; i++) {
                const pageLi = document.createElement('li');
                pageLi.className = `page-item ${currentPage === i ? 'active' : ''}`;
                pageLi.innerHTML = `<a class="page-link">${i}</a>`;
                pageLi.addEventListener('click', () => { transactionManager.currentPage.orders = i; renderOrdersTable(); });
                pagination.appendChild(pageLi);
            }

            const nextLi = document.createElement('li');
            nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
            nextLi.innerHTML = `<a class="page-link"><i class="fas fa-chevron-right"></i></a>`;
            nextLi.addEventListener('click', () => {
                if (currentPage < totalPages) { transactionManager.currentPage.orders++; renderOrdersTable(); }
            });
            pagination.appendChild(nextLi);
        }

        function renderTimeline() {
            const container = document.getElementById('timelineContainer');
            if (!container) return;
            const timeline = transactionManager.getTimelineData();

            if (timeline.length === 0) {
                container.innerHTML = '<p class="text-center text-muted p-4">No hay actividad reciente</p>';
                return;
            }

            container.innerHTML = timeline.map(item => `
                <div class="timeline-item">
                    <div class="timeline-marker" style="background: ${item.color}"></div>
                    <div class="timeline-content">
                        <div class="timeline-date">${item.date}</div>
                        <div class="timeline-title">
                            <i class="fas ${item.icon}" style="color: ${item.color}"></i>
                            ${item.title}
                        </div>
                        <div class="timeline-desc">${item.description}</div>
                        <span class="badge ${transactionManager.getStatusClass(item.status)}">${item.status}</span>
                    </div>
                </div>
            `).join('');
        }

        function renderStats() {
            const stats = transactionManager.getStats();
            document.getElementById('monthlySales').textContent = `$${stats.monthlySales.toFixed(2)}`;
            document.getElementById('activeOrders').textContent = stats.activeOrders;
            document.getElementById('pendingOrders').textContent = stats.pendingOrders;
            document.getElementById('completedToday').textContent = stats.completedToday;
            document.getElementById('newOrdersTrend').textContent = `+${stats.urgentOrders} nuevos`;
            document.getElementById('urgentOrdersTrend').textContent = `${stats.urgentOrders} urgentes`;
            document.getElementById('successRate').textContent = `Tasa de éxito ${stats.totalOrders > 0 ? Math.round((stats.completedToday / stats.totalOrders) * 100) : 0}%`;

            document.getElementById('advTotalTransactions').textContent = stats.totalTransactions;
            document.getElementById('advTotalOrders').textContent = stats.totalOrders;
            document.getElementById('advTotalIncome').textContent = `$${stats.totalIncome.toFixed(2)}`;
            document.getElementById('advAvgTicket').textContent = `$${stats.avgTicket.toFixed(2)}`;
            document.getElementById('advCancelledOrders').textContent = stats.cancelledOrders;
            document.getElementById('advUniqueClients').textContent = stats.uniqueClients;
        }

        function renderNotifications() {
            const list = document.getElementById('notificationList');
            const badge = document.getElementById('notificationBadge');
            if (!list || !badge) return;

            const unreadCount = transactionManager.getUnreadNotifications().length;
            badge.textContent = unreadCount;
            badge.classList.toggle('hidden', unreadCount === 0);

            list.innerHTML = '';
            transactionManager.notifications.slice(0, 10).forEach(notification => {
                const item = document.createElement('div');
                item.className = `notification-item ${notification.read ? '' : 'unread'}`;
                item.innerHTML = `<strong>${notification.title}</strong><p>${notification.message}</p><small>${notification.time}</small>`;
                item.addEventListener('click', () => {
                    transactionManager.markNotificationAsRead(notification.id);
                    renderNotifications();
                });
                list.appendChild(item);
            });
        }

        function renderCharts() {
            const salesCtx = document.getElementById('salesChart')?.getContext('2d');
            if (salesCtx) {
                if (transactionManager.charts.sales) transactionManager.charts.sales.destroy();
                transactionManager.charts.sales = new Chart(salesCtx, {
                    type: 'bar',
                    data: transactionManager.getSalesChartData(),
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        scales: {
                            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } },
                            x: { grid: { display: false } }
                        },
                        plugins: { legend: { position: 'bottom' } }
                    }
                });
            }

            const ordersCtx = document.getElementById('ordersChart')?.getContext('2d');
            if (ordersCtx) {
                if (transactionManager.charts.orders) transactionManager.charts.orders.destroy();
                transactionManager.charts.orders = new Chart(ordersCtx, {
                    type: 'doughnut',
                    data: transactionManager.getOrdersChartData(),
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        plugins: { legend: { position: 'bottom' } },
                        cutout: '60%'
                    }
                });
            }
        }

        function renderTrashList() {
            const container = document.getElementById('trashList');
            if (!container) return;

            if (transactionManager.trash.length === 0) {
                container.innerHTML = '<p class="text-muted text-center py-4">La papelera está vacía</p>';
                return;
            }

            container.innerHTML = transactionManager.trash.map(item => `
                <div class="trash-item">
                    <div>
                        <strong>${item.id}</strong> - ${item.client || 'Sin cliente'}
                        <span class="badge bg-secondary">${item.itemType || 'transaction'}</span>
                        <div class="text-muted" style="font-size: 12px;">Eliminado: ${new Date(item.deletedAt).toLocaleString()}</div>
                    </div>
                    <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                        <button class="btn btn-sm btn-success" onclick="restoreFromTrash('${item.id}')">
                            <i class="fas fa-undo"></i>Restaurar
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="permanentlyDelete('${item.id}')">
                            <i class="fas fa-trash"></i>Eliminar
                        </button>
                    </div>
                </div>
            `).join('');
        }

        function renderActivityList() {
            const container = document.getElementById('activityList');
            if (!container) return;

            if (transactionManager.activity.length === 0) {
                container.innerHTML = '<p class="text-muted text-center py-4">No hay actividad registrada</p>';
                return;
            }

            container.innerHTML = transactionManager.activity.map(a => `
                <div class="activity-item">
                    <strong>${a.action}</strong>
                    ${a.details ? `<div>${a.details}</div>` : ''}
                    <span class="activity-time"><i class="fas fa-clock me-1"></i>${a.date}</span>
                </div>
            `).join('');
        }

        // ============================================
        // EVENT LISTENERS
        // ============================================
        function addTransactionTableListeners() {
            document.querySelectorAll('#transactionsTableBody .btn-view').forEach(btn => {
                btn.addEventListener('click', function() { showTransactionDetails(this.getAttribute('data-id')); });
            });
            document.querySelectorAll('#transactionsTableBody .btn-edit').forEach(btn => {
                btn.addEventListener('click', function() { showEditTransactionModal(this.getAttribute('data-id')); });
            });
            document.querySelectorAll('#transactionsTableBody .btn-notify').forEach(btn => {
                btn.addEventListener('click', function() { showNotificationModal(this.getAttribute('data-id'), 'transaction'); });
            });
            document.querySelectorAll('#transactionsTableBody .btn-delete').forEach(btn => {
                btn.addEventListener('click', function() {
                    if (confirm('¿Mover a papelera?')) {
                        transactionManager.deleteTransaction(this.getAttribute('data-id'));
                        renderTransactionsTable();
                        renderStats();
                        renderTrashList();
                        renderActivityList();
                    }
                });
            });
            document.querySelectorAll('#transactionsTableBody .row-checkbox').forEach(cb => {
                cb.addEventListener('change', function() {
                    const id = this.getAttribute('data-id');
                    if (this.checked) transactionManager.selectedIds.add(id);
                    else transactionManager.selectedIds.delete(id);
                    updateBulkActions();
                });
            });
        }

        function addOrderTableListeners() {
            document.querySelectorAll('#ordersTableBody .btn-view').forEach(btn => {
                btn.addEventListener('click', function() { showOrderDetails(this.getAttribute('data-id')); });
            });
            document.querySelectorAll('#ordersTableBody .btn-notify').forEach(btn => {
                btn.addEventListener('click', function() { showNotificationModal(this.getAttribute('data-id'), 'order'); });
            });
            document.querySelectorAll('#ordersTableBody .btn-process').forEach(btn => {
                btn.addEventListener('click', function() { showUpdateOrderStatusModal(this.getAttribute('data-id')); });
            });
            document.querySelectorAll('#ordersTableBody .btn-track').forEach(btn => {
                btn.addEventListener('click', function() {
                    transactionManager.showNotification(`Seguimiento del pedido ${this.getAttribute('data-id')}`, 'info');
                });
            });
        }

        function updateBulkActions() {
            const bulkActions = document.getElementById('bulkActions');
            const count = transactionManager.selectedIds.size;
            document.getElementById('selectedCount').textContent = count;
            if (count > 0) bulkActions.classList.add('show');
            else bulkActions.classList.remove('show');
        }

        function showTransactionDetails(id) {
            const transaction = transactionManager.getTransactionById(id);
            if (!transaction) return;

            transactionManager.currentViewItem = { type: 'transaction', data: transaction };

            document.getElementById('viewTransactionId').textContent = transaction.id;
            document.getElementById('viewTransactionClient').textContent = transaction.client;
            document.getElementById('viewTransactionPhone').textContent = transaction.phone || 'No disponible';
            document.getElementById('viewTransactionEmail').textContent = transaction.email || 'No disponible';
            document.getElementById('viewTransactionType').textContent = transaction.type;
            document.getElementById('viewTransactionDate').textContent = transaction.date;
            document.getElementById('viewTransactionPayment').textContent = transaction.payment;

            const statusSpan = document.getElementById('viewTransactionStatus');
            statusSpan.textContent = transaction.status;
            statusSpan.className = `badge ${transactionManager.getStatusClass(transaction.status)}`;

            const productsDiv = document.getElementById('viewTransactionProducts');
            productsDiv.innerHTML = transaction.products.map(p => `
                <div class="product-item">
                    <div class="product-info">
                        <div class="product-name">${p.name}</div>
                        <div class="product-meta">Cantidad: ${p.quantity}</div>
                    </div>
                    <div class="product-price">$${(p.price * p.quantity).toFixed(2)}</div>
                </div>
            `).join('');

            document.getElementById('viewTransactionSubtotal').textContent = `$${(transaction.subtotal || 0).toFixed(2)}`;
            document.getElementById('viewTransactionTax').textContent = `$${(transaction.tax || 0).toFixed(2)}`;
            document.getElementById('viewTransactionDiscount').textContent = `$${(transaction.discount || 0).toFixed(2)}`;
            document.getElementById('viewTransactionTotal').textContent = `$${Math.abs(transaction.total).toFixed(2)}`;
            document.getElementById('viewTransactionNotes').textContent = transaction.notes || 'Sin notas adicionales';

            document.getElementById('btnNotifyTransaction').onclick = () => showNotificationModal(transaction.id, 'transaction');
            document.getElementById('btnEditTransaction').onclick = () => {
                bootstrap.Modal.getInstance(document.getElementById('viewTransactionModal')).hide();
                setTimeout(() => showEditTransactionModal(id), 300);
            };

            new bootstrap.Modal(document.getElementById('viewTransactionModal')).show();
        }

        function showOrderDetails(id) {
            const order = transactionManager.getOrderById(id);
            if (!order) return;

            transactionManager.currentViewItem = { type: 'order', data: order };

            const total = (order.subtotal + (order.shipping || 0) + order.tax).toFixed(2);

            document.getElementById('viewOrderId').textContent = order.id;
            document.getElementById('viewOrderClient').textContent = order.client;
            document.getElementById('viewOrderEmail').textContent = order.email || 'No disponible';
            document.getElementById('viewOrderPhone').textContent = order.phone || 'No disponible';
            document.getElementById('viewOrderDate').textContent = order.date;
            document.getElementById('viewOrderShipping').textContent = order.shippingMethod || 'No especificado';
            document.getElementById('viewOrderAddress').textContent = order.address || 'No especificada';

            const statusSpan = document.getElementById('viewOrderStatus');
            statusSpan.textContent = order.status;
            statusSpan.className = `badge ${transactionManager.getStatusClass(order.status)}`;

            document.getElementById('viewOrderProducts').innerHTML = order.products.map(p => `
                <div class="product-item">
                    <div class="product-info">
                        <div class="product-name">${p.name}</div>
                        <div class="product-meta">Cantidad: ${p.quantity}</div>
                    </div>
                    <div class="product-price">$${(p.price * p.quantity).toFixed(2)}</div>
                </div>
            `).join('');

            document.getElementById('viewOrderSubtotal').textContent = `$${order.subtotal.toFixed(2)}`;
            document.getElementById('viewOrderShippingCost').textContent = `$${(order.shipping || 0).toFixed(2)}`;
            document.getElementById('viewOrderTax').textContent = `$${order.tax.toFixed(2)}`;
            document.getElementById('viewOrderTotal').textContent = `$${total}`;
            document.getElementById('viewOrderNotes').textContent = order.notes || 'Sin notas adicionales';

            document.getElementById('btnUpdateOrderStatus').onclick = () => {
                bootstrap.Modal.getInstance(document.getElementById('viewOrderModal')).hide();
                setTimeout(() => showUpdateOrderStatusModal(order.id), 300);
            };
            document.getElementById('btnNotifyOrder').onclick = () => showNotificationModal(order.id, 'order');

            new bootstrap.Modal(document.getElementById('viewOrderModal')).show();
        }

        function showEditTransactionModal(id) {
            const transaction = transactionManager.getTransactionById(id);
            if (!transaction) return;

            document.getElementById('editTransactionId').value = transaction.id;
            document.getElementById('editTransactionType').value = transaction.type;
            document.getElementById('editTransactionClient').value = transaction.client;
            document.getElementById('editTransactionPhone').value = transaction.phone || '';
            document.getElementById('editTransactionEmail').value = transaction.email || '';
            document.getElementById('editTransactionPayment').value = transaction.payment;
            document.getElementById('editTransactionStatus').value = transaction.status;
            document.getElementById('editTransactionPriority').value = transaction.priority || 'Media';
            document.getElementById('editTransactionNotes').value = transaction.notes || '';

            new bootstrap.Modal(document.getElementById('editTransactionModal')).show();
        }

        function showNotificationModal(itemId, itemType) {
            let item = itemType === 'transaction' ? transactionManager.getTransactionById(itemId) : transactionManager.getOrderById(itemId);
            if (!item) return;

            transactionManager.currentNotificationItem = item;
            transactionManager.currentNotificationType = itemType;
            new bootstrap.Modal(document.getElementById('notificationModal')).show();
        }

        function showUpdateOrderStatusModal(orderId) {
            const order = transactionManager.getOrderById(orderId);
            if (!order) return;

            document.getElementById('updateOrderId').value = orderId;
            document.getElementById('newOrderStatus').value = order.status;
            document.getElementById('statusNotes').value = '';
            document.getElementById('notifyCustomer').checked = true;

            new bootstrap.Modal(document.getElementById('updateOrderStatusModal')).show();
        }

        function clearFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('typeFilter').value = 'all';
            document.getElementById('statusFilter').value = 'all';
            document.getElementById('dateFilter').value = '';
            if (document.getElementById('orderStatusFilter')) document.getElementById('orderStatusFilter').value = 'all';
            transactionManager.currentPage.transactions = 1;
            transactionManager.currentPage.orders = 1;
            renderTransactionsTable();
            renderOrdersTable();
        }

        function restoreFromTrash(id) {
            if (transactionManager.restoreFromTrash(id)) {
                renderTrashList();
                renderTransactionsTable();
                renderOrdersTable();
                renderStats();
                renderActivityList();
            }
        }

        function permanentlyDelete(id) {
            if (confirm('¿Eliminar permanentemente?')) {
                if (transactionManager.permanentlyDeleteFromTrash(id)) {
                    renderTrashList();
                    renderActivityList();
                }
            }
        }

        // ============================================
        // INIT
        // ============================================
        document.addEventListener('DOMContentLoaded', function() {
            // Aplicar preferencias guardadas
            const globalSettings = JSON.parse(localStorage.getItem('globalSettings')) || {};
            if (globalSettings.darkMode || localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                const ti = document.querySelector('#themeToggle i');
                if (ti) ti.className = 'fas fa-sun';
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#1a1f2e');
            }

            if (globalSettings.systemName) {
                document.querySelectorAll('.system-name-display').forEach(el => {
                    el.textContent = globalSettings.systemName;
                });
            }

            if (transactionManager.compactMode) {
                document.getElementById('transactionsTable')?.classList.add('compact-mode');
                document.getElementById('ordersTable')?.classList.add('compact-mode');
            }

            // Setup responsive
            setupMobileSidebar();

            // Cerrar sidebar al navegar (móvil)
            document.querySelectorAll('.sidebar-menu a').forEach(a => {
                a.addEventListener('click', () => {
                    if (APP_STATE.isMobile) closeMobileSidebar();
                });
            });

            // Prevenir zoom doble-tap iOS
            if (APP_STATE.isTouch) {
                let lastTouchEnd = 0;
                document.addEventListener('touchend', (e) => {
                    const now = Date.now();
                    if (now - lastTouchEnd <= 300) e.preventDefault();
                    lastTouchEnd = now;
                }, { passive: false });
            }

            // Detectar cambio de orientación
            window.addEventListener('orientationchange', () => {
                setTimeout(() => {
                    APP_STATE.isMobile = window.matchMedia('(max-width: 992px)').matches;
                    if (!APP_STATE.isMobile) closeMobileSidebar();
                    // Redibujar charts
                    Object.values(transactionManager.charts).forEach(c => { try { c.resize(); } catch (e) {} });
                }, 150);
            });

            // Redibujar charts en resize
            let resizeTimeout;
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(() => {
                    APP_STATE.isMobile = window.matchMedia('(max-width: 992px)').matches;
                    Object.values(transactionManager.charts).forEach(c => { try { c.resize(); } catch (e) {} });
                }, 200);
            });

            // Cerrar sidebar con Escape
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    closeMobileSidebar();
                    document.getElementById('notificationDropdown')?.classList.remove('show');
                }
            });

            // Render inicial
            renderStats();
            renderNotifications();
            renderTransactionsTable();
            renderOrdersTable();
            renderTimeline();
            renderCharts();
            renderTrashList();
            renderActivityList();

            // Config notificaciones
            ['whatsapp', 'sms', 'email', 'push', 'stock'].forEach(key => {
                const el = document.getElementById(`${key}Notifications`);
                if (el) {
                    el.checked = transactionManager.notificationSettings[key];
                    el.addEventListener('change', function() {
                        transactionManager.updateNotificationSettings({ [key]: this.checked });
                    });
                }
            });

            // Notificaciones tipo
            document.querySelectorAll('.notification-type').forEach(el => {
                el.addEventListener('click', function() {
                    const type = this.getAttribute('data-type');
                    if (transactionManager.currentNotificationItem && transactionManager.currentNotificationType) {
                        transactionManager.sendNotification(transactionManager.currentNotificationItem, transactionManager.currentNotificationType, type);
                    }
                    const m = bootstrap.Modal.getInstance(document.getElementById('notificationModal'));
                    if (m) m.hide();
                });
            });

            // Sidebar colapsable (desktop)
            const sidebarToggle = document.getElementById('sidebarToggle');
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', function() {
                    const sidebar = document.getElementById('sidebar');
                    const mainContent = document.getElementById('mainContent');
                    const icon = this.querySelector('i');
                    sidebar.classList.toggle('collapsed');
                    mainContent.classList.toggle('expanded');
                    icon.className = sidebar.classList.contains('collapsed') ? 'fas fa-chevron-right' : 'fas fa-chevron-left';
                });
            }

            document.getElementById('logoutBtn')?.addEventListener('click', function() {
                if (confirm('¿Desea cerrar la sesión actual?')) {
                    localStorage.removeItem('currentUser');
                    window.location.href = 'http://localhost/SmartStockAI/login.php';
                }
            });

            // Tema
            document.getElementById('themeToggle').addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
                const isDark = document.body.classList.contains('dark-mode');
                const icon = this.querySelector('i');
                icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
                document.querySelector('meta[name="theme-color"]')?.setAttribute('content', isDark ? '#1a1f2e' : '#3a5ec7');
                if (APP_STATE.isTouch && navigator.vibrate) navigator.vibrate(10);
            });

            // Notificaciones
            document.getElementById('notificationBtn').addEventListener('click', function(e) {
                e.stopPropagation();
                document.getElementById('notificationDropdown').classList.toggle('show');
            });

            document.getElementById('markAllRead').addEventListener('click', function() {
                transactionManager.markAllNotificationsAsRead();
                renderNotifications();
            });

            document.getElementById('viewAllNotifications').addEventListener('click', function(e) {
                e.preventDefault();
                transactionManager.showNotification('Mostrando todas las notificaciones', 'info');
                document.getElementById('notificationDropdown').classList.remove('show');
            });

            // Filtros
            document.getElementById('searchInput').addEventListener('input', function() {
                transactionManager.currentPage.transactions = 1;
                transactionManager.currentPage.orders = 1;
                renderTransactionsTable();
                renderOrdersTable();
            });

            document.getElementById('typeFilter').addEventListener('change', function() {
                transactionManager.currentPage.transactions = 1;
                renderTransactionsTable();
            });

            document.getElementById('statusFilter').addEventListener('change', function() {
                transactionManager.currentPage.transactions = 1;
                renderTransactionsTable();
            });

            document.getElementById('dateFilter').addEventListener('change', function() {
                transactionManager.currentPage.transactions = 1;
                renderTransactionsTable();
            });

            document.getElementById('orderStatusFilter')?.addEventListener('change', function() {
                transactionManager.currentPage.orders = 1;
                renderOrdersTable();
            });

            document.getElementById('clearFilters').addEventListener('click', clearFilters);

            // Exportaciones
            document.getElementById('exportPdfBtn').addEventListener('click', (e) => { e.preventDefault(); transactionManager.exportToPDF(); });
            document.getElementById('exportCsvBtn').addEventListener('click', (e) => { e.preventDefault(); transactionManager.exportToCSV(); });
            document.getElementById('exportExcelBtn').addEventListener('click', (e) => { e.preventDefault(); transactionManager.exportToExcel(); });
            document.getElementById('exportJsonBtn').addEventListener('click', (e) => { e.preventDefault(); transactionManager.exportToJSON(); });

            // Refrescar
            document.getElementById('refreshTransactions').addEventListener('click', function() {
                renderTransactionsTable();
                transactionManager.showNotification('Transacciones actualizadas', 'success');
            });

            document.getElementById('refreshOrders').addEventListener('click', function() {
                renderOrdersTable();
                transactionManager.showNotification('Pedidos actualizados', 'success');
            });

            // Seleccionar todo
            document.getElementById('selectAllCheckbox').addEventListener('change', function() {
                const checkboxes = document.querySelectorAll('#transactionsTableBody .row-checkbox');
                checkboxes.forEach(cb => {
                    cb.checked = this.checked;
                    const id = cb.getAttribute('data-id');
                    if (this.checked) transactionManager.selectedIds.add(id);
                    else transactionManager.selectedIds.delete(id);
                });
                updateBulkActions();
            });

            // Acciones masivas
            document.getElementById('bulkCompleteBtn').addEventListener('click', function() {
                const ids = Array.from(transactionManager.selectedIds);
                ids.forEach(id => {
                    const t = transactionManager.getTransactionById(id);
                    if (t) t.status = 'Completado';
                });
                transactionManager.saveData();
                transactionManager.selectedIds.clear();
                transactionManager.logActivity('Cambio masivo', `${ids.length} → Completado`);
                transactionManager.showNotification(`${ids.length} transacciones completadas`, 'success');
                renderTransactionsTable();
            });

            document.getElementById('bulkPendingBtn').addEventListener('click', function() {
                const ids = Array.from(transactionManager.selectedIds);
                ids.forEach(id => {
                    const t = transactionManager.getTransactionById(id);
                    if (t) t.status = 'Pendiente';
                });
                transactionManager.saveData();
                transactionManager.selectedIds.clear();
                transactionManager.showNotification(`${ids.length} marcadas como pendientes`, 'success');
                renderTransactionsTable();
            });

            document.getElementById('bulkDeleteBtn').addEventListener('click', function() {
                const ids = Array.from(transactionManager.selectedIds);
                if (!confirm(`¿Mover ${ids.length} a papelera?`)) return;
                ids.forEach(id => transactionManager.deleteTransaction(id));
                transactionManager.selectedIds.clear();
                renderTransactionsTable();
                renderStats();
                renderTrashList();
                renderActivityList();
            });

            document.getElementById('bulkCancelBtn').addEventListener('click', function() {
                transactionManager.selectedIds.clear();
                document.querySelectorAll('.row-checkbox').forEach(cb => cb.checked = false);
                document.getElementById('selectAllCheckbox').checked = false;
                updateBulkActions();
            });

            // Modo compacto
            document.getElementById('compactModeBtn').addEventListener('click', function() {
                transactionManager.compactMode = !transactionManager.compactMode;
                document.getElementById('transactionsTable').classList.toggle('compact-mode', transactionManager.compactMode);
                document.getElementById('ordersTable').classList.toggle('compact-mode', transactionManager.compactMode);
                localStorage.setItem('compactMode', transactionManager.compactMode);
                transactionManager.showNotification(transactionManager.compactMode ? 'Modo compacto activado' : 'Modo compacto desactivado', 'info');
            });

            document.getElementById('printBtn').addEventListener('click', () => window.print());

            document.getElementById('shortcutsBtn').addEventListener('click', function() {
                new bootstrap.Modal(document.getElementById('shortcutsModal')).show();
            });

            // Papelera
            document.getElementById('emptyTrashBtn')?.addEventListener('click', function() {
                if (confirm('¿Vaciar la papelera?')) {
                    transactionManager.emptyTrash();
                    renderTrashList();
                    renderActivityList();
                }
            });

            document.getElementById('clearActivityBtn')?.addEventListener('click', function() {
                if (confirm('¿Limpiar historial de actividad?')) {
                    transactionManager.activity = [];
                    localStorage.setItem('activity', '[]');
                    renderActivityList();
                    transactionManager.showNotification('Historial limpiado', 'success');
                }
            });

            // Agregar producto
            document.getElementById('addProductToTransaction').addEventListener('click', function() {
                const list = document.getElementById('transactionProductsList');
                const div = document.createElement('div');
                div.className = 'row mb-2 product-row g-2';
                div.innerHTML = `
                    <div class="col-md-5 col-12"><input type="text" class="form-control product-name" placeholder="Producto"></div>
                    <div class="col-md-3 col-6"><input type="number" class="form-control product-price" placeholder="Precio" step="0.01" min="0"></div>
                    <div class="col-md-2 col-4"><input type="number" class="form-control product-quantity" placeholder="Cant." min="1" value="1"></div>
                    <div class="col-md-2 col-2"><button type="button" class="btn btn-sm btn-danger remove-product w-100"><i class="fas fa-times"></i></button></div>
                `;
                list.appendChild(div);
                div.querySelector('.remove-product').addEventListener('click', () => div.remove());
            });

            // Guardar transacción
            document.getElementById('saveTransaction').addEventListener('click', function() {
                const form = document.getElementById('addTransactionForm');
                if (!form.checkValidity()) { form.reportValidity(); return; }

                const productRows = document.querySelectorAll('.product-row');
                if (productRows.length === 0) { transactionManager.showNotification('Agrega al menos un producto', 'error'); return; }

                const products = [];
                productRows.forEach(row => {
                    const name = row.querySelector('.product-name').value;
                    const price = parseFloat(row.querySelector('.product-price').value);
                    const quantity = parseInt(row.querySelector('.product-quantity').value);
                    if (name && !isNaN(price) && !isNaN(quantity)) products.push({ name, price, quantity });
                });

                if (products.length === 0) { transactionManager.showNotification('Completa los datos de los productos', 'error'); return; }

                transactionManager.addTransaction({
                    client: document.getElementById('transactionClient').value,
                    type: document.getElementById('transactionType').value,
                    date: document.getElementById('transactionDate').value.split('-').reverse().join('/'),
                    payment: document.getElementById('transactionPayment').value,
                    status: document.getElementById('transactionStatus').value,
                    phone: document.getElementById('transactionPhone').value,
                    email: document.getElementById('transactionEmail').value,
                    products: products,
                    discount: parseFloat(document.getElementById('transactionDiscount').value) || 0,
                    taxRate: parseFloat(document.getElementById('transactionTax').value) || 10,
                    priority: document.getElementById('transactionPriority').value,
                    notes: document.getElementById('transactionNotes').value
                });

                bootstrap.Modal.getInstance(document.getElementById('addTransactionModal')).hide();
                form.reset();
                document.getElementById('transactionProductsList').innerHTML = '';
                renderTransactionsTable();
                renderStats();
                renderActivityList();
            });

            // Actualizar transacción
            document.getElementById('updateTransaction').addEventListener('click', function() {
                const id = document.getElementById('editTransactionId').value;
                const data = {
                    type: document.getElementById('editTransactionType').value,
                    client: document.getElementById('editTransactionClient').value,
                    phone: document.getElementById('editTransactionPhone').value,
                    email: document.getElementById('editTransactionEmail').value,
                    payment: document.getElementById('editTransactionPayment').value,
                    status: document.getElementById('editTransactionStatus').value,
                    priority: document.getElementById('editTransactionPriority').value,
                    notes: document.getElementById('editTransactionNotes').value
                };
                if (transactionManager.updateTransaction(id, data)) {
                    bootstrap.Modal.getInstance(document.getElementById('editTransactionModal')).hide();
                    renderTransactionsTable();
                    renderActivityList();
                }
            });

            // Actualizar estado
            document.getElementById('confirmUpdateStatus').addEventListener('click', function() {
                const orderId = document.getElementById('updateOrderId').value;
                const newStatus = document.getElementById('newOrderStatus').value;
                const notes = document.getElementById('statusNotes').value;
                const notify = document.getElementById('notifyCustomer').checked;

                transactionManager.updateOrderStatus(orderId, newStatus, notes, notify);
                bootstrap.Modal.getInstance(document.getElementById('updateOrderStatusModal')).hide();
                renderOrdersTable();
                renderActivityList();
            });

            document.getElementById('btnPrintTransaction').addEventListener('click', () => window.print());

            // Búsqueda por voz
            document.getElementById('voiceSearchBtn').addEventListener('click', function() {
                if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
                    transactionManager.showNotification('Búsqueda por voz no soportada', 'error');
                    return;
                }
                const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
                const recognition = new SpeechRecognition();
                recognition.lang = 'es-ES';
                recognition.continuous = false;

                this.classList.add('listening');
                recognition.start();

                recognition.onresult = (event) => {
                    const transcript = event.results[0][0].transcript;
                    document.getElementById('searchInput').value = transcript;
                    transactionManager.currentPage.transactions = 1;
                    renderTransactionsTable();
                    transactionManager.showNotification(`Búsqueda: "${transcript}"`, 'info');
                };

                recognition.onend = () => this.classList.remove('listening');
                recognition.onerror = () => this.classList.remove('listening');
            });

            // Ordenamiento
            document.querySelectorAll('#transactionsTable th[data-sort]').forEach(th => {
                th.addEventListener('click', function() {
                    const field = this.getAttribute('data-sort');
                    if (transactionManager.sortField.transactions === field) {
                        transactionManager.sortDirection.transactions = transactionManager.sortDirection.transactions === 'asc' ? 'desc' : 'asc';
                    } else {
                        transactionManager.sortField.transactions = field;
                        transactionManager.sortDirection.transactions = 'asc';
                    }
                    document.querySelectorAll('#transactionsTable th').forEach(h => h.classList.remove('sorted-asc', 'sorted-desc'));
                    this.classList.add(`sorted-${transactionManager.sortDirection.transactions}`);
                    renderTransactionsTable();
                });
            });

            document.querySelectorAll('#ordersTable th[data-sort]').forEach(th => {
                th.addEventListener('click', function() {
                    const field = this.getAttribute('data-sort');
                    if (transactionManager.sortField.orders === field) {
                        transactionManager.sortDirection.orders = transactionManager.sortDirection.orders === 'asc' ? 'desc' : 'asc';
                    } else {
                        transactionManager.sortField.orders = field;
                        transactionManager.sortDirection.orders = 'asc';
                    }
                    document.querySelectorAll('#ordersTable th').forEach(h => h.classList.remove('sorted-asc', 'sorted-desc'));
                    this.classList.add(`sorted-${transactionManager.sortDirection.orders}`);
                    renderOrdersTable();
                });
            });

            // Cerrar dropdown notificaciones
            document.addEventListener('click', function(e) {
                const btn = document.getElementById('notificationBtn');
                const dropdown = document.getElementById('notificationDropdown');
                if (btn && dropdown && !btn.contains(e.target) && !dropdown.contains(e.target)) {
                    dropdown.classList.remove('show');
                }
            });

            // Atajos de teclado
            document.addEventListener('keydown', function(e) {
                if (e.ctrlKey && e.key === 'k') { e.preventDefault(); document.getElementById('searchInput').focus(); }
                if (e.ctrlKey && e.key === 'n') { e.preventDefault(); new bootstrap.Modal(document.getElementById('addTransactionModal')).show(); }
                if (e.ctrlKey && e.key === 'e') { e.preventDefault(); transactionManager.exportToPDF(); }
                if (e.ctrlKey && e.key === 'p') { e.preventDefault(); window.print(); }
                if (e.ctrlKey && e.key === 'd') { e.preventDefault(); document.getElementById('themeToggle').click(); }
            });

            setInterval(() => {
                renderStats();
                renderNotifications();
            }, 30000);

            console.log('%c🚀 SmartStock AI - Transacciones cargado', 'color: #3a5ec7; font-weight: bold; font-size: 14px;');
            console.log('%c📱 Modo móvil: ' + (APP_STATE.isMobile ? 'Sí' : 'No'), 'color: #10b981; font-weight: 600;');
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>