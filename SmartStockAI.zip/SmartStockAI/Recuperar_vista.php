<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStock AI - Recuperar Contraseña</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a5ec7;
            --primary-dark: #2a4bb0;
            --secondary: #28a745;
            --dark: #2c3e50;
            --light: #f8f9fa;
            --gray: #6c757d;
            --danger: #dc3545;
            --warning: #ffc107;
            --bg: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            --card-bg: rgba(255, 255, 255, 0.95);
            --text: #2c3e50;
            --border-radius: 16px;
            --transition: all 0.3s ease;
        }

        .dark-mode {
            --bg: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460);
            --card-bg: rgba(26, 30, 42, 0.95);
            --text: #f8f9fa;
            --gray: #adb5bd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: var(--light);
            transition: var(--transition);
        }

        .recovery-container {
            max-width: 450px;
            width: 100%;
        }

        .recovery-card {
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            background: var(--card-bg);
            color: var(--text);
            transition: var(--transition);
        }

        .recovery-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .recovery-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 60%);
            transform: rotate(30deg);
        }

        .logo {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            position: relative;
            display: inline-block;
        }

        .logo::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 3px;
        }

        .recovery-body {
            padding: 30px;
        }

        .form-control {
            padding: 14px 16px;
            border-radius: 10px;
            margin-bottom: 18px;
            border: 1px solid #e1e5eb;
            transition: var(--transition);
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 94, 199, 0.2);
            transform: translateY(-2px);
        }

        .btn-recovery {
            background: var(--primary-dark);
            border: none;
            color: white;
            padding: 14px;
            border-radius: 10px;
            font-weight: 600;
            width: 100%;
            transition: var(--transition);
            margin-top: 8px;
        }

        .btn-recovery:hover {
            background-color: var(--primary);
            transform: translateY(-3px);
            box-shadow: 0 7px 14px dimgrey;
            color: white;
        }

        .input-group-text {
            background-color: white;
            border-right: none;
            padding: 0 16px;
            height: 54px;
        }

        .additional-options {
            text-align: center;
            margin-top: 22px;
            font-size: 14px;
        }

        .system-info {
            text-align: center;
            margin-top: 28px;
            font-size: 13px;
            color: rgba(255, 255, 255, 0.7);
        }

        .language-selector, .theme-switcher {
            position: fixed;
            top: 20px;
            z-index: 100;
            display: flex;
            align-items: center;
            background: rgba(255, 255, 255, 0.2);
            padding: 5px 10px;
            border-radius: 20px;
            color: white;
            backdrop-filter: blur(5px);
            transition: var(--transition);
        }

        .language-selector { right: 20px; }
        .theme-switcher { left: 20px; }

        .theme-switcher button {
            background: transparent;
            border: none;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
        }

        .theme-switcher button:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(30deg);
        }

        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        .particle {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            animation: float 15s infinite ease-in-out;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0) translateX(0); }
            25% { transform: translateY(-20px) translateX(10px); }
            50% { transform: translateY(-35px) translateX(-15px); }
            75% { transform: translateY(-15px) translateX(15px); }
        }

        .notification-toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: white;
            color: var(--dark);
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            transform: translateY(20px);
            transition: var(--transition);
        }

        .notification-toast.show {
            opacity: 1;
            transform: translateY(0);
        }

        .security-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 18px;
            color: var(--gray);
            font-size: 13px;
        }

        .security-badge i {
            margin-right: 8px;
            color: var(--secondary);
        }

        .system-features {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
            text-align: center;
        }

        .feature {
            padding: 10px;
        }

        .feature i {
            font-size: 24px;
            color: var(--primary);
            margin-bottom: 8px;
        }

        .feature p {
            margin: 0;
            font-size: 12px;
            color: var(--gray);
        }

        @media (max-width: 576px) {
            body { padding: 15px; }
            .recovery-header, .recovery-body { padding: 20px; }
            .language-selector, .theme-switcher { top: 15px; }
            .language-selector { right: 15px; }
            .theme-switcher { left: 15px; }
            .system-features { flex-direction: column; gap: 15px; }
        }

        .loading {
            display: none;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
            margin-right: 10px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 25px;
            position: relative;
        }
        
        .step-indicator::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 2px;
            background: #e1e5eb;
            transform: translateY(-50%);
            z-index: 1;
        }
        
        .step {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: white;
            border: 2px solid #e1e5eb;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            position: relative;
            z-index: 2;
        }
        
        .step.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        .step.completed {
            background: var(--secondary);
            color: white;
            border-color: var(--secondary);
        }
        
        .recovery-step {
            display: none;
        }
        
        .recovery-step.active {
            display: block;
        }
    </style>
</head>
<body>
    <div class="particles" id="particles"></div>
    
    <div class="theme-switcher">
        <button id="themeToggle"><i class="fas fa-moon"></i></button>
    </div>
    
    <button class="btn btn-help" id="helpButton" style="position: fixed; bottom: 20px; left: 20px; z-index: 100; background: rgba(255,255,255,0.2); border: none; color: white; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
        <i class="fas fa-question"></i>
    </button>
    
    <div class="recovery-container">
        <div class="recovery-card">
            <div class="recovery-header">
                <div class="logo">
                    <i class="fas fa-robot me-2"></i>SmartStock AI
                </div>
                <p class="mb-0 mt-2">Recuperar Contraseña</p>
            </div>
            
            <div class="recovery-body">
                <div class="step-indicator">
                    <div class="step active" id="step1">1</div>
                    <div class="step" id="step2">2</div>
                    <div class="step" id="step3">3</div>
                </div>
                
                <div class="system-features">
                    <div class="feature">
                        <i class="fas fa-brain"></i>
                        <p>AI Predictiva</p>
                    </div>
                    <div class="feature">
                        <i class="fas fa-bolt"></i>
                        <p>Rápido</p>
                    </div>
                    <div class="feature">
                        <i class="fas fa-shield-alt"></i>
                        <p>Seguro</p>
                    </div>
                </div>
                
                <!-- Paso 1: Ingresar email -->
                <form id="recoveryFormStep1" class="recovery-step active">
                    <div class="mb-4">
                        <p class="text-center">Ingresa tu correo electrónico para recuperar tu contraseña</p>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Correo Electrónico</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Ingresa tu correo electrónico" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-recovery mb-3" id="continueButton">
                        <div class="loading" id="loadingStep1"></div>
                        Continuar <i class="fas fa-arrow-right ms-2"></i>
                    </button>
                    
                    <div class="additional-options">
                        <p class="mb-0">¿Recordaste tu contraseña? <a href="login.php" class="text-decoration-none">Iniciar sesión</a></p>
                    </div>
                </form>
                
                <!-- Paso 2: Ingresar código de verificación -->
                <form id="recoveryFormStep2" class="recovery-step">
                    <div class="mb-4">
                        <p class="text-center">Hemos enviado un código de verificación a tu correo electrónico</p>
                    </div>
                    
                    <div class="mb-3">
                        <label for="verificationCode" class="form-label">Código de Verificación</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-key"></i></span>
                            <input type="text" class="form-control" id="verificationCode" name="verificationCode" placeholder="Ingresa el código de 6 dígitos" required>
                        </div>
                        <small class="text-muted">¿No recibiste el código? <a href="#" id="resendCode">Reenviar código</a></small>
                    </div>
                    
                    <button type="submit" class="btn btn-recovery mb-3" id="verifyCodeButton">
                        <div class="loading" id="loadingStep2"></div>
                        Verificar Código <i class="fas fa-check ms-2"></i>
                    </button>
                    
                    <div class="additional-options">
                        <p class="mb-0"><a href="#" class="text-decoration-none" id="backToStep1"><i class="fas fa-arrow-left me-1"></i> Volver atrás</a></p>
                    </div>
                </form>
                
                <!-- Paso 3: Establecer nueva contraseña -->
                <form id="recoveryFormStep3" class="recovery-step">
                    <div class="mb-4">
                        <p class="text-center">Establece tu nueva contraseña</p>
                    </div>
                    
                    <div class="mb-3">
                        <label for="newPassword" class="form-label">Nueva Contraseña</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="newPassword" name="newPassword" placeholder="Ingresa tu nueva contraseña" required>
                            <button class="btn btn-outline-secondary" type="button" id="toggleNewPassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="progress mt-2" id="passwordStrengthBar">
                            <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                        </div>
                        <small class="password-strength text-muted" id="passwordStrengthText"></small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="confirmPassword" class="form-label">Confirmar Contraseña</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Confirma tu nueva contraseña" required>
                            <button class="btn btn-outline-secondary" type="button" id="toggleConfirmPassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <small id="passwordMatchText" class="text-muted"></small>
                    </div>
                    
                    <button type="submit" class="btn btn-recovery mb-3" id="resetPasswordButton">
                        <div class="loading" id="loadingStep3"></div>
                        Restablecer Contraseña <i class="fas fa-check-circle ms-2"></i>
                    </button>
                    
                    <div class="additional-options">
                        <p class="mb-0"><a href="#" class="text-decoration-none" id="backToStep2"><i class="fas fa-arrow-left me-1"></i> Volver atrás</a></p>
                    </div>
                </form>
                
                <div class="security-badge">
                    <i class="fas fa-shield-alt"></i>
                    <span>Sistema protegido con encriptación AES-256</span>
                </div>
            </div>
        </div>
        
        <div class="system-info">
            <p>© 2023 SmartStock AI. Todos los derechos reservados.</p>
            <p class="mb-0">v2.5.1 | Último acceso: <span id="lastAccess"></span></p>
        </div>
    </div>
    
    <div class="notification-toast" id="notification">
        <i class="fas fa-check-circle"></i>
        <span id="notification-text">Operación completada</span>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Función para crear partículas de fondo
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particlesCount = 30;
            
            for (let i = 0; i < particlesCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                const size = Math.random() * 20 + 5;
                const posX = Math.random() * 100;
                const posY = Math.random() * 100;
                const delay = Math.random() * 15;
                
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.left = `${posX}%`;
                particle.style.top = `${posY}%`;
                particle.style.animationDelay = `${delay}s`;
                
                particlesContainer.appendChild(particle);
            }
        }
        
        // Función para mostrar notificación
        function showNotification(message, isSuccess = true) {
            const notification = document.getElementById('notification');
            const notificationText = document.getElementById('notification-text');
            const icon = notification.querySelector('i');
            
            notificationText.textContent = message;
            icon.className = isSuccess ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
            notification.style.borderLeft = isSuccess ? '4px solid var(--secondary)' : '4px solid var(--danger)';
            
            notification.classList.add('show');
            
            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
        }
        
        // Función para cambiar tema
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            const themeIcon = document.querySelector('#themeToggle i');
            themeIcon.className = document.body.classList.contains('dark-mode') ? 'fas fa-sun' : 'fas fa-moon';
            showNotification(document.body.classList.contains('dark-mode') ? 'Modo oscuro activado' : 'Modo claro activado');
            
            // Guardar preferencia
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }
        
        // Función para evaluar fortaleza de contraseña
        function checkPasswordStrength(password) {
            let strength = 0;
            const bar = document.getElementById('passwordStrengthBar');
            const text = document.getElementById('passwordStrengthText');
            
            if (password.length > 0) {
                bar.classList.remove('d-none');
            } else {
                bar.classList.add('d-none');
                return;
            }
            
            if (password.length >= 8) strength += 20;
            if (/\d/.test(password)) strength += 20;
            if (/[a-z]/.test(password)) strength += 20;
            if (/[A-Z]/.test(password)) strength += 20;
            if (/[^A-Za-z0-9]/.test(password)) strength += 20;
            
            const progressBar = bar.querySelector('.progress-bar');
            progressBar.style.width = `${strength}%`;
            
            if (strength < 40) {
                progressBar.className = 'progress-bar bg-danger';
                text.textContent = 'Contraseña débil';
            } else if (strength < 80) {
                progressBar.className = 'progress-bar bg-warning';
                text.textContent = 'Contraseña media';
            } else {
                progressBar.className = 'progress-bar bg-success';
                text.textContent = 'Contraseña fuerte';
            }
        }
        
        // Función para verificar coincidencia de contraseñas
        function checkPasswordMatch() {
            const password = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const matchText = document.getElementById('passwordMatchText');
            
            if (confirmPassword.length === 0) {
                matchText.textContent = '';
                return;
            }
            
            if (password === confirmPassword) {
                matchText.textContent = 'Las contraseñas coinciden';
                matchText.style.color = 'var(--secondary)';
            } else {
                matchText.textContent = 'Las contraseñas no coinciden';
                matchText.style.color = 'var(--danger)';
            }
        }
        
        // Función para cambiar entre pasos
        function goToStep(stepNumber) {
            // Ocultar todos los pasos
            document.querySelectorAll('.recovery-step').forEach(step => {
                step.classList.remove('active');
            });
            
            // Mostrar el paso actual
            document.getElementById(`recoveryFormStep${stepNumber}`).classList.add('active');
            
            // Actualizar indicador de pasos
            document.querySelectorAll('.step').forEach((step, index) => {
                step.classList.remove('active', 'completed');
                if (index + 1 < stepNumber) {
                    step.classList.add('completed');
                } else if (index + 1 === stepNumber) {
                    step.classList.add('active');
                }
            });
        }
        
        // Función para simular envío de código de verificación
        function sendVerificationCode(email) {
            // Simular envío de código (en un caso real, aquí se conectaría con el backend)
            showNotification(`Código enviado a ${email}`);
            
            // Guardar el código generado para verificación (en desarrollo)
            const verificationCode = Math.floor(100000 + Math.random() * 900000);
            sessionStorage.setItem('recoveryCode', verificationCode);
            sessionStorage.setItem('recoveryEmail', email);
            
            console.log(`Código de verificación para ${email}: ${verificationCode}`); // Solo para pruebas
        }
        
        // Función para verificar el código
        function verifyCode(code) {
            const storedCode = sessionStorage.getItem('recoveryCode');
            return code === storedCode;
        }
        
        // Función para restablecer contraseña
        async function resetPassword(email, newPassword) {
            try {
                // Simular envío al servidor (en un caso real, aquí se conectaría con el backend)
                const response = await fetch('reset_password.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email, newPassword })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('Contraseña restablecida correctamente');
                    // Redirigir al login después de un breve retraso
                    setTimeout(() => {
                        window.location.href = 'login.html';
                    }, 2000);
                } else {
                    showNotification(result.message || 'Error al restablecer la contraseña', false);
                }
            } catch (error) {
                showNotification('Error de conexión: ' + error.message, false);
            }
        }
        
        // Inicialización cuando el DOM está listo
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
            document.getElementById('lastAccess').textContent = new Date().toLocaleString();
            
            // Cargar tema guardado
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-mode');
                document.querySelector('#themeToggle i').className = 'fas fa-sun';
            }
            
            // Paso 1: Enviar email
            document.getElementById('recoveryFormStep1').addEventListener('submit', function(e) {
                e.preventDefault();
                
                const email = document.getElementById('email').value;
                
                if (email === '') {
                    showNotification('Por favor, ingresa tu correo electrónico', false);
                    return;
                }
                
                // Mostrar loading
                document.getElementById('loadingStep1').style.display = 'inline-block';
                document.getElementById('continueButton').disabled = true;
                
                // Simular verificación (en un caso real, aquí se verificaría con el backend)
                setTimeout(() => {
                    // Ocultar loading
                    document.getElementById('loadingStep1').style.display = 'none';
                    document.getElementById('continueButton').disabled = false;
                    
                    // Enviar código de verificación
                    sendVerificationCode(email);
                    
                    // Avanzar al siguiente paso
                    goToStep(2);
                }, 1500);
            });
            
            // Paso 2: Verificar código
            document.getElementById('recoveryFormStep2').addEventListener('submit', function(e) {
                e.preventDefault();
                
                const code = document.getElementById('verificationCode').value;
                
                if (code === '') {
                    showNotification('Por favor, ingresa el código de verificación', false);
                    return;
                }
                
                // Mostrar loading
                document.getElementById('loadingStep2').style.display = 'inline-block';
                document.getElementById('verifyCodeButton').disabled = true;
                
                // Simular verificación (en un caso real, aquí se verificaría con el backend)
                setTimeout(() => {
                    // Ocultar loading
                    document.getElementById('loadingStep2').style.display = 'none';
                    document.getElementById('verifyCodeButton').disabled = false;
                    
                    if (verifyCode(code)) {
                        showNotification('Código verificado correctamente');
                        // Avanzar al siguiente paso
                        goToStep(3);
                    } else {
                        showNotification('Código incorrecto', false);
                    }
                }, 1500);
            });
            
            // Paso 3: Restablecer contraseña
            document.getElementById('recoveryFormStep3').addEventListener('submit', function(e) {
                e.preventDefault();
                
                const newPassword = document.getElementById('newPassword').value;
                const confirmPassword = document.getElementById('confirmPassword').value;
                const email = sessionStorage.getItem('recoveryEmail');
                
                if (newPassword === '' || confirmPassword === '') {
                    showNotification('Por favor, completa todos los campos', false);
                    return;
                }
                
                if (newPassword !== confirmPassword) {
                    showNotification('Las contraseñas no coinciden', false);
                    return;
                }
                
                // Mostrar loading
                document.getElementById('loadingStep3').style.display = 'inline-block';
                document.getElementById('resetPasswordButton').disabled = true;
                
                // Restablecer contraseña
                resetPassword(email, newPassword);
            });
            
            // Reenviar código
            document.getElementById('resendCode').addEventListener('click', function(e) {
                e.preventDefault();
                const email = document.getElementById('email').value || sessionStorage.getItem('recoveryEmail');
                if (email) {
                    sendVerificationCode(email);
                } else {
                    showNotification('Primero ingresa tu correo electrónico', false);
                }
            });
            
            // Navegación entre pasos
            document.getElementById('backToStep1').addEventListener('click', function(e) {
                e.preventDefault();
                goToStep(1);
            });
            
            document.getElementById('backToStep2').addEventListener('click', function(e) {
                e.preventDefault();
                goToStep(2);
            });
            
            // Mostrar/ocultar contraseñas
            document.getElementById('toggleNewPassword').addEventListener('click', function() {
                const passwordInput = document.getElementById('newPassword');
                const icon = this.querySelector('i');
                
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    icon.className = 'fas fa-eye-slash';
                } else {
                    passwordInput.type = 'password';
                    icon.className = 'fas fa-eye';
                }
            });
            
            document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
                const passwordInput = document.getElementById('confirmPassword');
                const icon = this.querySelector('i');
                
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    icon.className = 'fas fa-eye-slash';
                } else {
                    passwordInput.type = 'password';
                    icon.className = 'fas fa-eye';
                }
            });
            
            // Cambiar tema
            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            
            // Botón de ayuda
            document.getElementById('helpButton').addEventListener('click', function() {
                showNotification('Centro de ayuda abierto');
            });
            
            // Verificar fortaleza de la contraseña en tiempo real
            document.getElementById('newPassword').addEventListener('input', function() {
                checkPasswordStrength(this.value);
                checkPasswordMatch();
            });
            
            // Verificar coincidencia de contraseñas en tiempo real
            document.getElementById('confirmPassword').addEventListener('input', checkPasswordMatch);
        });
    </script>
    <script src="public/js/global-settings.js"></script>
</body>
</html>